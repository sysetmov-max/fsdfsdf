﻿// Decompiled with JetBrains decompiler
// Type: むせひなちめいめのねおやしのま.ねさわりくほれぬりそねなちえるみ
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using Newtonsoft.Json;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net.Security;
using System.Runtime.Serialization;
using System.Security.Cryptography.X509Certificates;
using れまけつうおのなおなつれれうれ;

#nullable disable
namespace むせひなちめいめのねおやしのま;

public class ねさわりくほれぬりそねなちえるみ
{
  public string まいちもむもえわをみまやねこえほえめう;
  public string きしうつおひいさふつ;
  public string へとおふぬそもよにりれこをさむ;
  public string かなよすたらののてんをまか;
  public static long らちひさうちとへひそたれひすしうえきつし;
  private static string ゆやおおやるひけねちえむもいのへめけちれねりね;
  private static string なすすすちれよすりゆうふぬきせにりとえをすこよ;
  private bool むとたをいちとろすくまね;
  public ねさわりくほれぬりそねなちえるみ.ををそにてれにのゆ せらふはゆりををわかふれるいえゆはま;
  public ねさわりくほれぬりそねなちえるみ.よきるくおよころせうねやこ なあひわはらしぬつかたた;
  public ねさわりくほれぬりそねなちえるみ.けれよつめのまのかなれとせまみめめゆ やりひひぬとにたりすやせもえく;
  private しいたせれよねもかへこそのきあす たきむぬとうふめれいむはち;

  public ねさわりくほれぬりそねなちえるみ(
    string すこすえよそれめくひこくに,
    string らかもてなすとるひふぬれきまふそゆけいく,
    string らみてこひもほめろれもをねほかち,
    string さられてへみひれくしかりゆあきそ)
  {
    // ISSUE: unable to decompile the method.
  }

  public void りへゆきかあにぬせきこれふめよほよ()
  {
    // ISSUE: unable to decompile the method.
  }

  public void えけうんへりいめしりみなむれをすとくねふ()
  {
    // ISSUE: unable to decompile the method.
  }

  public string きりららひすのなりれしさわにけのるんろおつもふよ(string あなたこりのゆきほみも, int ほあぬわせをこすかこんらせてぬねるきるふまそほ)
  {
    // ISSUE: unable to decompile the method.
  }

  public void とせろそそほきこゆろそこきいひねすてわなさや(
    string いせちそかしんんよをのしへれねうわいえ,
    string なぬれにいすすねゆきすそつられんへれきるさ,
    string あそりされをへらまへしらさのてるすりをにこみむこ,
    string ゆんのといるこひなぬふふゆちせれをぬまえのふ = "")
  {
    // ISSUE: unable to decompile the method.
  }

  public void ゆもはくひぬひてすいんくんふか(string ひめへせれやゆたへまちかをえ, string へめいすゆうよすにぬみひしけ)
  {
    // ISSUE: unable to decompile the method.
  }

  public void すおあきのるそめわちふおちほちほま(string かたけほわみとふ, string ゆほくをわなしたよはりわう)
  {
    // ISSUE: unable to decompile the method.
  }

  public void きひもぬひむこのうけくるふれくらみたこへれろ()
  {
    // ISSUE: unable to decompile the method.
  }

  public void らこされぬいへまたねきにはゆや(string よそやにくゆさこはきふの)
  {
    // ISSUE: unable to decompile the method.
  }

  public void せろあらきはえもみわのをあといをさ(string ろたきめこかめに, string れらたいしちもむたえ)
  {
    // ISSUE: unable to decompile the method.
  }

  public void ろすたよめねとねよち(string おつたけさしゆおふ)
  {
    // ISSUE: unable to decompile the method.
  }

  public void なふいれよろみるえせすかにこの()
  {
    // ISSUE: unable to decompile the method.
  }

  public void ほほろにくしてるねけぬこねてへも(string あつてとたんみよま, string そやまてわかきはりなりよねにろのあをぬをた)
  {
    // ISSUE: unable to decompile the method.
  }

  public string せしたぬうこぬちえきるまきるふけんゆりれ(string るいるなわふろちえるみすやそむろさかお)
  {
    // ISSUE: unable to decompile the method.
  }

  public void せけこくてへなぬつみまのとくをこあひなとかおか(string さくしこるろねゆんめたみ = null)
  {
    // ISSUE: unable to decompile the method.
  }

  public string こちそるあねへもりよあえかたまひ(string まれほねぬけのへねちをきさむふよ)
  {
    // ISSUE: unable to decompile the method.
  }

  public List<ねさわりくほれぬりそねなちえるみ.らともいすほむふわらるねひやてわぬ> りみなこかめむほん()
  {
    // ISSUE: unable to decompile the method.
  }

  public List<ねさわりくほれぬりそねなちえるみ.るとにりむゆやしはにねいあ> ことにやこうみわいそはにるえれみふくるえみろりつ(string めつりえとむゆみひ)
  {
    // ISSUE: unable to decompile the method.
  }

  public bool てみそおほふしあのとたつ(string おかつちのんゆお, string えてもわはへむゆすえほされをれ)
  {
    // ISSUE: unable to decompile the method.
  }

  public bool よあとつへすねつ()
  {
    // ISSUE: unable to decompile the method.
  }

  public string つそなきはもろせすはおのゆつつりてむせにた(
    string をらてさこららろくなねきあなきなふけもまをなせに,
    string れのふろやけくにちひきつるさしひらやかか,
    string ゆらろこほめささいのはわねせそさん = "",
    string すちみほりあえめわねおきまけ = "")
  {
    // ISSUE: unable to decompile the method.
  }

  public byte[] はせはたるほせせふりりひせあほぬうねえ(string くかみみめかなろさたうふな)
  {
    // ISSUE: unable to decompile the method.
  }

  public void きゆせのあへうのこはさろ(string わろたらちらやるきをろきろや)
  {
    // ISSUE: unable to decompile the method.
  }

  public void めもくふこるせんをわさまさえつ(string きるりつふちくへはすすよとなそゆとへちあ)
  {
    // ISSUE: unable to decompile the method.
  }

  public static string ろまゆつおねやんあたし(string やそせたひすをむもひこみこおにここ)
  {
    // ISSUE: unable to decompile the method.
  }

  public static void やおうほわかひしぬれらほゆしけりうり(string あやそゆはおいちとらけねねひもきつははいあえ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string はまそせるなのちこをくひりへむこるるふめか(NameValueCollection れゆみうきこちらふこや)
  {
    // ISSUE: unable to decompile the method.
  }

  private static bool かもあよきひらたろわくはむろにゆ(
    object ししんやこそさらきのしえほ,
    X509Certificate うめれまくりろひてんりいるきえんひせもこぬるて,
    X509Chain ちめやしえちのへとさきほわわいろとみらんろ,
    SslPolicyErrors とおやきををそととく)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void こてもちせそそをあおい(string かせなえみぬうなさへまんと, string ほすらゆよいてる, string せみぬろてひせんゆをそ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void をにきみうはひすうせをの(
    ねさわりくほれぬりそねなちえるみ.app_data_structure ほふらめけゆのみのやおたおそみぬへへかろさか)
  {
    // ISSUE: unable to decompile the method.
  }

  private void うことそろやもおむてたちきらとみりかぬゆいわ(ねさわりくほれぬりそねなちえるみ.user_data_structure てこひまりろへりあか)
  {
    // ISSUE: unable to decompile the method.
  }

  private void あるまちるねかれとさぬさおれまお(ねさわりくほれぬりそねなちえるみ.response_structure あまんうへしりこまのふ)
  {
    // ISSUE: unable to decompile the method.
  }

  [DataContract]
  private class response_structure
  {
    [DataMember]
    public bool success
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string sessionid
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string contents
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string response
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string message
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string download
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(IsRequired = false, EmitDefaultValue = false)]
    public ねさわりくほれぬりそねなちえるみ.user_data_structure info
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(IsRequired = false, EmitDefaultValue = false)]
    public ねさわりくほれぬりそねなちえるみ.app_data_structure appinfo
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public List<ねさわりくほれぬりそねなちえるみ.るとにりむゆやしはにねいあ> messages
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public List<ねさわりくほれぬりそねなちえるみ.らともいすほむふわらるねひやてわぬ> users
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public response_structure()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [DataContract(Name = "msg")]
  public class るとにりむゆやしはにねいあ
  {
    [DataMember(Name = "message")]
    public string うろれそかれわをあ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(Name = "author")]
    public string ぬなとさそつうひれつてはふたい
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(Name = "timestamp")]
    public string るぬぬたをとなしほくこおるはとれて
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public るとにりむゆやしはにねいあ()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [DataContract(Name = "users")]
  public class らともいすほむふわらるねひやてわぬ
  {
    [DataMember(Name = "credential")]
    public string ほむなくおころへふぬみあとゆおめよかこたせやほ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public らともいすほむふわらるねひやてわぬ()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [DataContract]
  private class user_data_structure
  {
    [DataMember]
    public string username
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string ip
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string hwid
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string createdate
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string lastlogin
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public List<ねさわりくほれぬりそねなちえるみ.ねのそよかそめえめててんむけう> subscriptions
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public user_data_structure()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [DataContract]
  private class app_data_structure
  {
    [DataMember]
    public string numUsers
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string numOnlineUsers
    {
      get; set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string numKeys
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string version
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string customerPanelLink
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember]
    public string downloadLink
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public app_data_structure()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public class ををそにてれにのゆ
  {
    [JsonProperty("numUsers")]
    public string ふけよまぬなろらこかううりまよきわろわたむ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("numOnlineUsers")]
    public string こるのなみるけたてはよろからは
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("numKeys")]
    public string のりきなみのいれお
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("version")]
    public string ほしをのふにかきんろかいやうほりめねし
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("customerPanelLink")]
    public string はをふりてえけすやまらへたいさわちりをたよをり
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("downloadLink")]
    public string わぬおおゆらゆのまけおままかきねせり
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public ををそにてれにのゆ()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public class よきるくおよころせうねやこ
  {
    [JsonProperty("username")]
    public string ををにめらろあとりしとねなもたけみいくそなうを
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("ip")]
    public string おにれないえまぬひかたなもれたれ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("hwid")]
    public string つせほもふちにふおつぬへ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("createdate")]
    public string にれんんほちいはてやひろろたとれなやみすあえも
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("lastlogin")]
    public string めねかなりわむけるみまとな
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("subscriptions")]
    public List<ねさわりくほれぬりそねなちえるみ.ねのそよかそめえめててんむけう> すんりめんねうよまいいむほふゆちるてくみ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public よきるくおよころせうねやこ()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [DataContract(Name = "Data")]
  public class ねのそよかそめえめててんむけう
  {
    [DataMember(Name = "subscription")]
    public string まわらりしわみやひらくええもにほ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(Name = "expiry")]
    public string なあへにとけまのくへほさに
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [DataMember(Name = "timeleft")]
    public string うちえるむはささはりはしすくまあんろ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public ねのそよかそめえめててんむけう()
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public class けれよつめのまのかなれとせまみめめゆ
  {
    [JsonProperty("success")]
    public bool わこほりほおめこしよたへもみひへち
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    [JsonProperty("message")]
    public string かそいなきひふりななよせぬ
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public けれよつめのまのかなれとせまみめめゆ()
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
