﻿// Decompiled with JetBrains decompiler
// Type: ねちろうろんやかりほな.なのちひしみつまもしいるて
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ねちろうろんやかりほな;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class なのちひしみつまもしいるて
{
  private static ResourceManager うほしるおましのとふるうろ;
  private static CultureInfo そうおにつきちは;

  internal なのちひしみつまもしいるて()
  {
    // ISSUE: unable to decompile the method.
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager かみなへかいむひぬとのろへすこちかみた
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo にねおんかゆせうとし
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
