﻿// Decompiled with JetBrains decompiler
// Type: ちふきえいたらすほにれさぬりはまもはまてえ
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using Costura;
using System;
using System.Reflection;
using System.Runtime.InteropServices;

#nullable disable
internal static class ちふきえいたらすほにれさぬりはまもはまてえ
{
  internal static MethodBase んつれうもかほまはえみのわんわすれえませ([In] int obj0)
  {
    switch (obj0)
    {
      case 0:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.たまかよちくつんゆとねらくきも), __typeref (れんちてらみつうえまよるにおんを));
      case 1:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.さそきまんちかほくえつへしろに), __typeref (れんちてらみつうえまよるにおんを));
      case 2:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.にとけさあほれをひはひふはむあ), __typeref (れんちてらみつうえまよるにおんを));
      case 3:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.うもほいたゆかをちぬさまとうやほにかるらもうにほ), __typeref (れんちてらみつうえまよるにおんを));
      case 4:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.ろくひめらそやけくたをのはやこはしを), __typeref (れんちてらみつうえまよるにおんを));
      case 5:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.すれひねよかのるちはくつこつわ), __typeref (れんちてらみつうえまよるにおんを));
      case 6:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.をくそおそふんえるもほもゆめひまろあくくちらねゆ), __typeref (れんちてらみつうえまよるにおんを));
      case 7:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.やなはりみまむつ), __typeref (れんちてらみつうえまよるにおんを));
      case 8:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.のふしぬふかとつてすひひわふせよなむえ), __typeref (れんちてらみつうえまよるにおんを));
      case 9:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.ぬいのせえつよえつぬつるりさるほひをせにわれめこ), __typeref (れんちてらみつうえまよるにおんを));
      case 10:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (れんちてらみつうえまよるにおんを.えふひそをぬけやそへしよちういす), __typeref (れんちてらみつうえまよるにおんを));
      case 11:
        // ISSUE: method reference
        // ISSUE: type reference
        return MethodBase.GetMethodFromHandle(__methodref (AssemblyLoader.Attach), __typeref (AssemblyLoader));
      default:
        throw new InvalidOperationException("Invalid method resolver id");
    }
  }

  internal static MethodInfo せすわさてほゆろしよけもへふもけんひめ([In] Module obj0, [In] Type obj1, [In] string obj2, [In] Type[] obj3)
  {
    MethodInfo[] methodInfoArray = (object) obj1 != null ? obj1.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) : obj0.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
label_12:
    for (int index1 = 0; index1 < methodInfoArray.Length; ++index1)
    {
      MethodInfo methodInfo = methodInfoArray[index1];
      if (methodInfo.Name == obj2)
      {
        ParameterInfo[] parameters = methodInfo.GetParameters();
        if (parameters.Length == obj3.Length)
        {
          bool flag = true;
          for (int index2 = 0; index2 < parameters.Length; ++index2)
          {
            if (!object.ReferenceEquals((object) parameters[index2].ParameterType, (object) obj3[index2]))
              flag = false;
            if (!flag)
              goto label_12;
          }
          if (flag)
            return methodInfo;
        }
      }
    }
    throw new MissingMethodException("Resolver could not find method: " + obj2);
  }
}
