﻿// Decompiled with JetBrains decompiler
// Type: しわふせうやりりこたも.よせさむけひゆほをこやはほよさら
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using Guna.UI2.WinForms;
using ShayanUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using いみえそくにふそらちちきふおろつねす;
using むせひなちめいめのねおやしのま;

#nullable disable
namespace しわふせうやりりこたも;

public class よせさむけひゆほをこやはほよさら : Form
{
  public static ねさわりくほれぬりそねなちえるみ のやはめをきやひてけひえほれ;
  private Point らすなゆみるねやたあしいく;
  private float ほしはあねみはけ;
  private float りくにきゆてこはそそとむつつとくぬああさ;
  private bool むおふのもわいうきこやまねひほさめむつか;
  private Timer わめめたすりからあまはわいくう;
  private List<ろてんくめもぬおせくむちほ> ふうなけねけおまうりよゆわもそへかすやつりこ;
  private Random えろこかのさむぬてふちきまろわわ;
  private Bitmap へえすとうそれすちろらもてみんてひつすせ;
  private Bitmap ひなちちてこふへほ;
  private Size けたあもゆろういふそらくせりめあれちめお;
  private static readonly Color まほまうほろうほかそまめさまとつろ;
  private static readonly Color にのちみんさてきぬほて;
  private static readonly Color さるはくねみちむきんんつ;
  private static readonly Color あけなえけせへんくすはけんまとほ;
  private static readonly Color なとしらえゆくうくもいこうにはを;
  private static readonly Color んうわえせたゆせうふん;
  private IContainer ねあろうほははきほろてせあいのひゆおゆあこゆみち;
  private ShayanBorderless ときおにのいけくえほもおきてれんらはえま;
  private ShayanHeader えすゆこねをよんもめたはちさてなまかれ;
  private ShayanTextBox かろつゆぬほむるあつさ;
  private ShayanButton みうちるそすあうちけたろてはゆくぬは;
  private ShayanTextBox なくなのきるんめるし;
  private Guna2PictureBox をつねめりせるのきておらりわふにてろらのつにこ;
  private ShayanCheckBox なしのこあそのきゆなさわとみみぬせをてやた;

  [DllImport("Gdi32.dll")]
  private static extern IntPtr CreateRoundRectRgn(
    int ねのはあいおまかしんますへねまみりるぬによ,
    int ねいやまをりろは,
    int ふらむまよさけりんせよをこに,
    int ふりこああはきねんねい,
    int さつかよこみふうとれららなみいねく,
    int いせはひうおほれ);

  public よせさむけひゆほをこやはほよさら()
  {
    // ISSUE: unable to decompile the method.
  }

  private void ふひはとふゆいめのぬけめす()
  {
    // ISSUE: unable to decompile the method.
  }

  private void やまのらりをいてめほいむしたしとえな(object りにためくゆみわぬるにふすへてゆむ, EventArgs ちはたねほちをぬ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void おほわまふめもおえれめやむてう()
  {
    // ISSUE: unable to decompile the method.
  }

  private void へなひれつそこりれつるのみぬかてもすけん(
    Graphics んまそあけそきめふおくみいやめはへみてや,
    Rectangle きやたえすたさたよんもみうむすくりせせ,
    int るゆみのたそゆふをあ,
    Color ひむうらるんろれんろてゆかてあんうなて,
    float つかほゆたおゆめわのへつゆそけをあるてけろ)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void OnPaintBackground(PaintEventArgs e)
  {
    // ISSUE: unable to decompile the method.
  }

  private void あわかかりをねんりたそけへへをねはえゆなお(
    Graphics せこぬあひきたたもきひしせな,
    PointF しぬゆけこわなせあ,
    float よさいをけうさらをよとそたねまてへゆぬゆはいもれ,
    Color つふんめにりろにあやろせつはおちとそへほろ,
    int すねよそまよさなやぬ)
  {
    // ISSUE: unable to decompile the method.
  }

  private GraphicsPath こらことひやそいとさえろへねにやねちみる(Rectangle けよなさおねをねらた, int もおささつなきむかすりさたにろきけかしは)
  {
    // ISSUE: unable to decompile the method.
  }

  private void いひたえるくれこ(object とくこもまきそよまかえらのやむおととゆそえちるた, EventArgs かもくちやてふややそわあぬめそよれ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void てはめしめすれなつもま(string きやてよむこうやみにしろうする, string のつきなるむぬうやな)
  {
    // ISSUE: unable to decompile the method.
  }

  private void れおかむあにうやはともこむくするちむへとらさ(object えわむぬねくれめひけそうわそあめきねらしま, EventArgs そけろまなひなすたい)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void OnFormClosing(FormClosingEventArgs e)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void Dispose(bool disposing)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ねけちやけるえをわここきぬさつりむりとほを()
  {
    // ISSUE: unable to decompile the method.
  }

  static よせさむけひゆほをこやはほよさら()
  {
    // ISSUE: unable to decompile the method.
  }
}
