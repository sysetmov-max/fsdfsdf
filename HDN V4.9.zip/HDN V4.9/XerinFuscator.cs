﻿// Decompiled with JetBrains decompiler
// Type: XerinFuscator
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using System;
using System.Runtime.InteropServices;

#nullable disable
internal class XerinFuscator : Attribute
{
  public XerinFuscator([In] string obj0)
  {
  }
}
