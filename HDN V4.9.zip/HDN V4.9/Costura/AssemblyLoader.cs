﻿// Decompiled with JetBrains decompiler
// Type: Costura.AssemblyLoader
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;

#nullable disable
namespace Costura;

[CompilerGenerated]
internal static class AssemblyLoader
{
  private static object nullCacheLock;
  private static Dictionary<string, bool> nullCache;
  private static Dictionary<string, string> assemblyNames;
  private static Dictionary<string, string> symbolNames;
  private static int isAttached;

  private static string CultureToString(CultureInfo はゆくきすとえやにうころに)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Assembly ReadExistingAssembly(AssemblyName りやしちきけんあ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string GetAssemblyResourceName(AssemblyName りえすうやしんほもへゆわとけめ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void CopyTo(Stream とへふまうなかけきんらなたにをそ, Stream たせうあちせのぬてなそみえなひのり)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Stream LoadStream(string はてたてとをえろやとはそせほぬつおるみ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Stream LoadStream(Dictionary<string, string> うたえけまあよねうはしろにやてれ, string わるえろなのおろおくま)
  {
    // ISSUE: unable to decompile the method.
  }

  private static byte[] ReadStream(Stream みちむらつほさそきもて)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Assembly ReadFromEmbeddedResources(
    Dictionary<string, string> はるさけへりのしひく,
    Dictionary<string, string> あふはへゆをしはりき,
    AssemblyName ちけはええかけふえけにろち)
  {
    // ISSUE: unable to decompile the method.
  }

  public static Assembly ResolveAssembly(
    object せろせさほとへのこみさよあとちるけ,
    ResolveEventArgs いしのうほはやてうんおをはみけうね)
  {
    // ISSUE: unable to decompile the method.
  }

  static AssemblyLoader()
  {
    // ISSUE: unable to decompile the method.
  }

  public static void Attach(bool わそこむむらんりら)
  {
    // ISSUE: unable to decompile the method.
  }
}
