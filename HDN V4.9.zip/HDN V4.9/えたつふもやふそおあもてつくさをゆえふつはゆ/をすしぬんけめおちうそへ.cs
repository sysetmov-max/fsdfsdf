﻿// Decompiled with JetBrains decompiler
// Type: えたつふもやふそおあもてつくさをゆえふつはゆ.をすしぬんけめおちうそへ
// Assembly: UID BYPASS V1.0, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BAA1DF85-7B9B-4B9B-99E8-8BD4D8BA2B6B
// Assembly location: C:\Users\Systemov\Desktop\HDN UID BYPASS V4.9.exe

using Guna.UI2.WinForms;
using ShayanUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using いみえそくにふそらちちきふおろつねす;

#nullable disable
namespace えたつふもやふそおあもてつくさをゆえふつはゆ;

public class をすしぬんけめおちうそへ : Form
{
  private static readonly HttpClient いろけすくちたせす;
  private static readonly string とそぬせへきちれつ;
  private static readonly string うのえるるせかなへよひれり;
  private static readonly string なうあにろんめいたお;
  private static readonly string ふせけそゆへよみえいぬらせてるされまに;
  private const int ねにたりはかれんつへいけんさすん = 30;
  private static long からこもさゆかわさむううやらちるふききをたやまむ;
  private static bool せなんそりえきるすやらしめせまこれそとりろへ;
  private static readonly string みそつえかあへたくぬろわたきほつほれくぬう;
  private static readonly string へりりにやとなしりれままそんにん;
  private string るまなみやよちそ;
  private Timer しわやわやきめくみ;
  private float さましけるれほいすみらほろほれせ;
  private float へよりうねきむくねぬろかのろきそろやたへに;
  private bool ゆかゆえほさへいきいぬそかたよにめ;
  private Timer のあつとめれもやみたんるはまたう;
  private List<ろてんくめもぬおせくむちほ> もすとねにはにた;
  private Random ほこゆゆぬにうらえにくちてるたりはすうしぬよ;
  private Bitmap うそえこせあえにれえりしはんれりのらめひるるみた;
  private Bitmap おまろせとおてらさめぬてしも;
  private Size あんすせはほやるほてのともさおくへもらこち;
  private static readonly Color くぬをなとそしてにす;
  private static readonly Color ろひるへつゆめそや;
  private static readonly Color るるみほふきはりまとはな;
  private static readonly Color らやそおさにへしわしたらまこのしわおるひるす;
  private static readonly Color せよよけみはよりのにむうりえむねりく;
  private bool わほたゆわろあへ;
  private static string そみるをひくあすとすろみきてよつわきみく;
  private static string ひいとりそをわあるしまろ;
  private IContainer のりひめぬみうとお;
  private ShayanBorderless さたよさのとんやたなぬもほなかしこ;
  private ShayanHeader すのあすもうるをゆ;
  private ShayanThemeManager まんおよぬなこのねめと;
  private Panel るぬたにへゆこかへさぬあくはひをひや;
  private Panel ひへやかたちましこしふもにほ;
  private Panel まのろすとえやまふとねおほろりさわめつ;
  private ShayanTabSelector をかちあかわのんるいぬあちぬれういせたすよを;
  private Panel みよしあそちいほあおゆ;
  private Panel のくろくぬはやゆひわねめくいよこまつおい;
  private Panel ろみけりろさほり;
  private Guna2PictureBox にろひやちれおきらめいくへも;
  private Guna2PictureBox ねりせはよんへあもむへにも;
  private Label ひそきわけにひくてまろお;
  private Label のちあらそわりちえわおいつりれよ;
  private ShayanButton もとちらすとれさと;
  private ShayanButton めちなへほめにおまもるせ;
  private ShayanComboBox るわねついれゆへみちたろぬもみす;
  private ShayanButton おへれまきんへそにそろやしえけなれにれやいりそ;
  private ShayanButton まうあかみきんゆよめほすてりもわるう;
  private ShayanButton ふるらなせきにひすやぬれしせせんえ;
  private ShayanButton ぬほそそきわねとろううめをるをすむめよへめをこは;
  private ShayanButton あたよてをおりみわてとしせめれろりことの;
  private ShayanTextBox よふろをふはけにすねとやへきふむあ;
  private Guna2TextBox をこうあぬはあとあろむりもゆいくけめるとちはまこ;
  private Guna2AnimateWindow るんぬまふせさらしにたねよかつわくのす;

  [DllImport("Gdi32.dll")]
  private static extern IntPtr CreateRoundRectRgn(
    int せにろつそへむねえけいあとつう,
    int つわつゆすうはきはな,
    int まめめかはわしみ,
    int らようきむみみらやちわかにち,
    int ふれわけされやよりふうやちうぬえくむみ,
    int ひるしおふちめつけねるこち);

  private static string えろゆにろろをむうて
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private static void ねたむまつへねに(string のほんえなにうんこ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string あてなすかちもさほとと()
  {
    // ISSUE: unable to decompile the method.
  }

  private static Task まうゆみぬねよとときほせ()
  {
    // ISSUE: unable to decompile the method.
  }

  private static long しせいゆひすせかててかつうぬ()
  {
    // ISSUE: unable to decompile the method.
  }

  private static string やのやけうもりすれんる()
  {
    // ISSUE: unable to decompile the method.
  }

  private static Task<HttpResponseMessage> むいやるやくりるう(string まれたやすせやとやうえめまらふり)
  {
    // ISSUE: unable to decompile the method.
  }

  private Task<string> とえくかきしまみせないふまれつなさほつい()
  {
    // ISSUE: unable to decompile the method.
  }

  private Task<string> よむくふえへねちさけ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string くうおみいわへふへさみとえおつるねそ(string てへちめらてすのりえお)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string こぬいひへつんのえほきたうすととへよみてせいゆ(string さすひみめなみいわかれも, string なそあよをきぬひせまつりゆらね)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string ろかすえぬむもあいそをおきに(string しとこみくはゆねう, string てれらさすめふすつおすむるろふみわふこよろへく)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string そうてのをぬれほくほまもえよれ(params string[] みむむうせれのぬやいもひめうつましのなとゆののす)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string けむへまねおれいつれかせもせそすきた(params string[] にふけそさあゆめる)
  {
    // ISSUE: unable to decompile the method.
  }

  private string ちるぬよれあにかとよわまけか()
  {
    // ISSUE: unable to decompile the method.
  }

  private string ゆてのよわこきつくえちふれりたてへめな()
  {
    // ISSUE: unable to decompile the method.
  }

  private string もみるむほいんにことさろくうねれも()
  {
    // ISSUE: unable to decompile the method.
  }

  private string てけさねそもはとひすおとた()
  {
    // ISSUE: unable to decompile the method.
  }

  private string もひわおのよけれこまくもりととらたとほすたした()
  {
    // ISSUE: unable to decompile the method.
  }

  private string ちかくこにめつやおせけふ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string とつわきぬをはたひれ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string んめわみゆうふぬしむ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string てまをなぬせてほはしらめれいむかりせやれ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string さいさもゆみんいみみたとみんせけいぬしわろ()
  {
    // ISSUE: unable to decompile the method.
  }

  private string りくあいほえろもこにゆわく()
  {
    // ISSUE: unable to decompile the method.
  }

  private string めむむへてへるひぬせこうとわよよのを()
  {
    // ISSUE: unable to decompile the method.
  }

  private string るけえめもいれかわにるへもよまなたやほのそな()
  {
    // ISSUE: unable to decompile the method.
  }

  private bool まむよふまんろてわらおせ(string[] ひあはをぬはやわらけいをれさはひつ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void まをわひねぬわかへみにさもぬぬ()
  {
    // ISSUE: unable to decompile the method.
  }

  private をすしぬんけめおちうそへ.ひやわとをくなれせゆてりそねなあわへにこさ るなのとるていわ(List<string> もけきくなをよせちけ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void しかあうわゆほのさゆつよえあよ(
    をすしぬんけめおちうそへ.ひやわとをくなれせゆてりそねなあわへにこさ あわらりねゆほみはをりあふみえうね)
  {
    // ISSUE: unable to decompile the method.
  }

  private void けういたちろねなつうつひりはしわ()
  {
    // ISSUE: unable to decompile the method.
  }

  public void かすつわうみるら()
  {
    // ISSUE: unable to decompile the method.
  }

  private string ねみかこよとむろむちんふえたへはみれてう()
  {
    // ISSUE: unable to decompile the method.
  }

  private string みのとよわもなひかちきぬまてよたくさを(string わもほへほをむてとひひくけこひてらさけお, string とれるらこれくはにちろせふて)
  {
    // ISSUE: unable to decompile the method.
  }

  private string ろらるわていわもつつゆにゆいよきみてりましちひ()
  {
    // ISSUE: unable to decompile the method.
  }

  private void りおとろよさねまなくもりまにてれよむけもひみむへ(
    string れてそりくかつうかつやほとこり,
    string りとたのりやゆなえのらわさまるふよくぬとれた,
    out string すうらやなとすめちへぬうるするひきふるゆへすと,
    out string なねけよすむとわのぬうにあんちあよよぬためへ,
    string たわひちらいのそんほあそろさななほけはねつこてひ = null)
  {
    // ISSUE: unable to decompile the method.
  }

  private bool まほやちせほはしるおそへあわきりか(string しりんよゆおおらのら)
  {
    // ISSUE: unable to decompile the method.
  }

  private bool へすをぬこあわり(string みたふろあけえよんまとゆちちらくけおへきのあ, string ひくはぬこはろぬてつは)
  {
    // ISSUE: unable to decompile the method.
  }

  private void くらとくてゆちきひもせくのけふやつ(string そふほねこきひひぬらえへなわわれめれむた)
  {
    // ISSUE: unable to decompile the method.
  }

  private string せゆやうれにまえた()
  {
    // ISSUE: unable to decompile the method.
  }

  private Task<string> くなやとなおつとにろれよまゆはからり(string きあもなみりすえけいてゆふのははふてあ)
  {
    // ISSUE: unable to decompile the method.
  }

  private string えつめられまうやか(string とめもおわいしへあもぬみさえくひるうのすそねせゆ, string よりとつちかねむつすてすほねほふまうな)
  {
    // ISSUE: unable to decompile the method.
  }

  private void わねたなもをきんるむとゆくせなけぬきんぬやほゆ()
  {
    // ISSUE: unable to decompile the method.
  }

  public void すさなふりもてたすぬのてひちろよとかわきみすこと(string むひのちんまはりめほろなわとかけら)
  {
    // ISSUE: unable to decompile the method.
  }

  public void むけれやほくそめちけねののき()
  {
    // ISSUE: unable to decompile the method.
  }

  private string そえのまやいへかこく()
  {
    // ISSUE: unable to decompile the method.
  }

  public をすしぬんけめおちうそへ()
  {
    // ISSUE: unable to decompile the method.
  }

  private void まみほせんいあさき(object ほへんをらよやそさのれま, EventArgs なりすをさたうつむひほをもちをそさつな)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ぬはへたこみさくとせるんよよふもの()
  {
    // ISSUE: unable to decompile the method.
  }

  private IEnumerable<Control> たおうみへひねへええこぬねそんはらねろ(Control ととよはももむふみとあをえんにひみにれら)
  {
    // ISSUE: unable to decompile the method.
  }

  private void はちてをゆるこまりよみさぬ()
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void OnPaintBackground(PaintEventArgs e)
  {
    // ISSUE: unable to decompile the method.
  }

  private void るいのゆわうらふふきわわやは(
    Graphics りわうちあえにゆんあきなれさいいめこぬへに,
    PointF すはまれもるつほやぬふをはにやけめまし,
    float みとるねくやとはわしてさそくみぬみかたひて,
    Color さほりろまひすのにらつまあり,
    int くめんならみのおつほつやすねへたまつた)
  {
    // ISSUE: unable to decompile the method.
  }

  private GraphicsPath すんえよこおんむおれめつらもしてをんきなをいうひ(Rectangle さましおりすてやひりま, int らよねつたかひまむは)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ぬをもしありおほまふらふてせするたとれこみん(object すすゆんありぬむすままにぬにれふ, EventArgs すもねのんさわにんしんはよまにまけ)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void OnFormClosing(FormClosingEventArgs e)
  {
    // ISSUE: unable to decompile the method.
  }

  private void たもをわほおいしろねをむかさなおいほめけくて(object ようせてろえくつぬくちあれなのあつをうわせうりの, EventArgs ふねきにあこよそ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ひむるはへふきつけねきてぬいろにはへたろお(object えのするらとつへめやかんたはあよ, EventArgs ねふしみもこもつそひあれ)
  {
    // ISSUE: unable to decompile the method.
  }

  private static string ひきまるたりひをよまわわてしも()
  {
    // ISSUE: unable to decompile the method.
  }

  private void とまやきやこんよをうかくけひらぬむ(object をのむてちんめぬかへひまそえとい, EventArgs わきほめみこえらそたのね)
  {
    // ISSUE: unable to decompile the method.
  }

  private void かめれもしせよさむに(object りちむしゆひすわこあおゆつんまあ, EventArgs かたたいへりすもすたほはいまけ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void のへまむんこみきわまつくらろすも(object ふやこをえせりやたもかのわそこてらるさこけぬしぬ, EventArgs ぬのさへつくちれゆやさにうつら)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ゆしらなしせかあほみてぬたは(object はむりもめよをきしめきなんゆかね, EventArgs ねひもへきをふもほきのんわやねつむへゆつ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void ねたととななけちくちもなもひうよ(object むまはおつまあろれあまむものゆえりともし, EventArgs おみなきそわほうすくそかをよれこのもせひらめかり)
  {
    // ISSUE: unable to decompile the method.
  }

  private void のてとなほいせたはむたねすほへおるほぬねらそわふ(object こしめそりこうかもへんか, EventArgs えむつるほらちひやめるりたまなみきちはひるかむれ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void みおぬらつなふりとをろかうるそかおれもらりる(object とわすあこけろおひみふけをおすねむとねら, EventArgs のはへなふしとのえをんにきこれ)
  {
    // ISSUE: unable to decompile the method.
  }

  private void かたるろはそかさにらひわわよぬけしもま(object ひははをやもをらぬ, EventArgs すすえくみけえすれつほ)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void Dispose(bool disposing)
  {
    // ISSUE: unable to decompile the method.
  }

  private void みむをよやけつもとけやいゆつちぬねねいのせも()
  {
    // ISSUE: unable to decompile the method.
  }

  static をすしぬんけめおちうそへ()
  {
    // ISSUE: unable to decompile the method.
  }

  private class ひやわとをくなれせゆてりそねなあわへにこさ
  {
    public string さゆつてるまうよさこふか;
    public string りへけわたかへとゆそわはるをおろちつにはた;
    public string くいひすゆりにひけすこむひてもまき;

    public ひやわとをくなれせゆてりそねなあわへにこさ()
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
