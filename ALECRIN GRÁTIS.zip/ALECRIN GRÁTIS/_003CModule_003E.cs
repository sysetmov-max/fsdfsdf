﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using Costura;

#nullable disable
internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach(true);
}
