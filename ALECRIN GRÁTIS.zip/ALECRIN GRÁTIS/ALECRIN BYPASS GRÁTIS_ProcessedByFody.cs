﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN BYPASS GRÁTIS_ProcessedByFody
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

#nullable disable
internal class ALECRIN\u0020BYPASS\u0020GRÁTIS_ProcessedByFody
{
  internal const string FodyVersion = "6.8.2.0";
  internal const string Costura = "6.0.0";
}
