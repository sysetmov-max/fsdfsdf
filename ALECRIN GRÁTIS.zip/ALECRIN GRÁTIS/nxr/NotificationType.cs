﻿// Decompiled with JetBrains decompiler
// Type: nxr.NotificationType
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

#nullable disable
namespace nxr;

public enum NotificationType
{
  Apply,
  Success,
  Failed,
  NotFound,
  Error,
  Info,
}
