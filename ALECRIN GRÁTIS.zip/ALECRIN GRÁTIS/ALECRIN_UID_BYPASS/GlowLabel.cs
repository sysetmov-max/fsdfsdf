﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.GlowLabel
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

#nullable disable
namespace ALECRIN_UID_BYPASS;

public class GlowLabel : Label
{
  private int glowSize = 1;
  private int glowStrength = 140;

  public GlowLabel()
  {
    this.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    this.BackColor = Color.Transparent;
  }

  [Category("Appearance")]
  [DefaultValue(typeof (Color), "")]
  public Color GlowColor { get; set; } = Color.Empty;

  [Category("Appearance")]
  [DefaultValue(1)]
  public int GlowSize
  {
    get => this.glowSize;
    set => this.glowSize = Math.Max(0, value);
  }

  [Category("Appearance")]
  [DefaultValue(140)]
  public int GlowStrength
  {
    get => this.glowStrength;
    set => this.glowStrength = Math.Max(0, Math.Min((int) byte.MaxValue, value));
  }

  protected override void OnPaint(PaintEventArgs e)
  {
    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
    e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
    e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
    string text = this.Text ?? string.Empty;
    if (string.IsNullOrEmpty(text))
      return;
    Color baseColor = this.GlowColor.IsEmpty ? this.ForeColor : this.GlowColor;
    Rectangle clientRectangle = this.ClientRectangle;
    TextFormatFlags flags = this.BuildTextFlags();
    for (int index1 = 1; index1 <= this.glowSize; ++index1)
    {
      Color foreColor = Color.FromArgb(Math.Max(10, this.glowStrength / (index1 * index1 + 1)), baseColor);
      for (int index2 = -index1; index2 <= index1; ++index2)
      {
        for (int index3 = -index1; index3 <= index1; ++index3)
        {
          if ((index2 != 0 || index3 != 0) && index2 * index2 + index3 * index3 <= index1 * index1 && Math.Abs(index2) + Math.Abs(index3) >= index1)
          {
            Rectangle bounds = new Rectangle(clientRectangle.X + index2, clientRectangle.Y + index3, clientRectangle.Width, clientRectangle.Height);
            TextRenderer.DrawText((IDeviceContext) e.Graphics, text, this.Font, bounds, foreColor, flags);
          }
        }
      }
    }
    Color foreColor1 = Color.FromArgb(Math.Min(90, this.glowStrength / 2), Color.Black);
    Rectangle bounds1 = new Rectangle(clientRectangle.X + 1, clientRectangle.Y + 1, clientRectangle.Width, clientRectangle.Height);
    TextRenderer.DrawText((IDeviceContext) e.Graphics, text, this.Font, bounds1, foreColor1, flags);
    TextRenderer.DrawText((IDeviceContext) e.Graphics, text, this.Font, clientRectangle, this.ForeColor, flags);
  }

  private TextFormatFlags BuildTextFlags()
  {
    TextFormatFlags textFormatFlags1 = (TextFormatFlags) (268435456 /*0x10000000*/ | (this.AutoSize ? 32 /*0x20*/ : 16 /*0x10*/));
    if (!this.AutoSize)
      textFormatFlags1 |= TextFormatFlags.EndEllipsis;
    TextFormatFlags textFormatFlags2;
    switch (this.TextAlign)
    {
      case ContentAlignment.TopLeft:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Default;
        break;
      case ContentAlignment.TopCenter:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.HorizontalCenter;
        break;
      case ContentAlignment.TopRight:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Right;
        break;
      case ContentAlignment.MiddleLeft:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.VerticalCenter;
        break;
      case ContentAlignment.MiddleCenter:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter;
        break;
      case ContentAlignment.MiddleRight:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Right | TextFormatFlags.VerticalCenter;
        break;
      case ContentAlignment.BottomLeft:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Bottom;
        break;
      case ContentAlignment.BottomCenter:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Bottom | TextFormatFlags.HorizontalCenter;
        break;
      case ContentAlignment.BottomRight:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Bottom | TextFormatFlags.Right;
        break;
      default:
        textFormatFlags2 = textFormatFlags1 | TextFormatFlags.Default;
        break;
    }
    return textFormatFlags2;
  }
}
