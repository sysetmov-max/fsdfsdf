﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.DiscordRpcManager
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

#nullable disable
namespace ALECRIN_UID_BYPASS;

public static class DiscordRpcManager
{
  public static string ClientId = "1520871468408508486";
  public static string DiscordInviteUrl = "https://discord.gg/alecrin";
  public static string CurrentStateText = "Bypass Conectado";
  public static string LargeImage = "perfil";
  public static string LargeText = "ALECRIN BYPASS FREE";
  private static readonly object _pipeLock = new object();
  private static NamedPipeClientStream _pipe;
  private static volatile bool _isConnected;
  private static volatile bool _isConnecting;
  private static long _startTimeUnix;
  private static CancellationTokenSource _readLoopCts;
  private static CancellationTokenSource _reconnectCts;
  private static readonly SemaphoreSlim _writeLock = new SemaphoreSlim(1, 1);
  private const int MaxPayloadSize = 65536 /*0x010000*/;

  private static void Log(string level, string message)
  {
    try
    {
      string str = Path.Combine(Path.GetTempPath(), "AlecrinBypassFreeLogs");
      if (!Directory.Exists(str))
        Directory.CreateDirectory(str);
      File.AppendAllText(Path.Combine(str, "DiscordRpcError.txt"), $"[{DateTime.Now}] [{level}] {message}\n");
    }
    catch
    {
    }
  }

  public static void Initialize()
  {
    if (DiscordRpcManager._reconnectCts != null)
      return;
    DiscordRpcManager._reconnectCts = new CancellationTokenSource();
    DiscordRpcManager._startTimeUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
    CancellationToken token = DiscordRpcManager._reconnectCts.Token;
    Task.Run((Func<Task>) (async () =>
    {
      while (!token.IsCancellationRequested)
      {
        if (!DiscordRpcManager._isConnected && !DiscordRpcManager._isConnecting)
        {
          try
          {
            await DiscordRpcManager.TryConnectAsync();
          }
          catch (Exception ex)
          {
            DiscordRpcManager.Log("ERRO", "Exceção na tarefa de reconexão: " + ex.Message);
          }
        }
        try
        {
          await Task.Delay(10000, token);
        }
        catch (TaskCanceledException ex)
        {
          break;
        }
      }
    }), token);
  }

  private static async Task TryConnectAsync()
  {
    lock (DiscordRpcManager._pipeLock)
    {
      if (DiscordRpcManager._pipe != null || DiscordRpcManager._isConnecting)
        return;
      DiscordRpcManager._isConnecting = true;
    }
    try
    {
      DiscordRpcManager.Log("INFO", "Tentando nova conexão");
      NamedPipeClientStream connectedPipe = (NamedPipeClientStream) null;
      for (int i = 0; i < 10; ++i)
      {
        NamedPipeClientStream testPipe = (NamedPipeClientStream) null;
        try
        {
          DiscordRpcManager.Log("TRAC", $"Tentando conectar em 'discord-ipc-{i}'");
          testPipe = new NamedPipeClientStream(".", $"discord-ipc-{i}", PipeDirection.InOut, PipeOptions.Asynchronous);
          await testPipe.ConnectAsync(2000);
          DiscordRpcManager.Log("INFO", $"Conectado em 'discord-ipc-{i}'");
          connectedPipe = testPipe;
          break;
        }
        catch (Exception ex)
        {
          DiscordRpcManager.Log("TRAC", $"Falha ao conectar em 'discord-ipc-{i}': {ex.Message}");
          testPipe?.Dispose();
        }
        testPipe = (NamedPipeClientStream) null;
      }
      if (connectedPipe == null || !connectedPipe.IsConnected)
      {
        DiscordRpcManager.Log("ERRO", "Não foi possível conectar a nenhum pipe IPC do Discord.");
        connectedPipe?.Dispose();
        DiscordRpcManager._isConnecting = false;
      }
      else
      {
        lock (DiscordRpcManager._pipeLock)
          DiscordRpcManager._pipe = connectedPipe;
        await DiscordRpcManager.WriteFrameAsync(0, $"{{\"v\":1,\"client_id\":\"{DiscordRpcManager.ClientId}\"}}");
        DiscordRpcManager.Log("TRAC", "Enviando Handshake...");
        Tuple<int, string> tuple = await DiscordRpcManager.ReadFrameAsync(CancellationToken.None);
        int num = tuple.Item1;
        string str = tuple.Item2;
        DiscordRpcManager.Log("TRAC", $"Resposta do handshake recebida - OP: {num}, Payload: {str}");
        if (num == 1 && str.Contains("READY"))
        {
          DiscordRpcManager._isConnected = true;
          DiscordRpcManager.Log("INFO", "Discord RPC Handshake bem-sucedido. Conectado.");
          DiscordRpcManager._readLoopCts = new CancellationTokenSource();
          CancellationToken readLoopToken = DiscordRpcManager._readLoopCts.Token;
          Task.Run((Func<Task>) (async () => await DiscordRpcManager.ReadLoopAsync(readLoopToken)), readLoopToken);
          DiscordRpcManager.UpdatePresence(DiscordRpcManager.CurrentStateText);
          Task.Run((Func<Task>) (async () =>
          {
            while (DiscordRpcManager._isConnected)
            {
              if (readLoopToken.IsCancellationRequested)
                break;
              try
              {
                await Task.Delay(4000, readLoopToken);
                if (DiscordRpcManager._isConnected)
                  await DiscordRpcManager.SendPresenceUpdateAsync();
              }
              catch (TaskCanceledException ex)
              {
                break;
              }
              catch (Exception ex)
              {
                DiscordRpcManager.Log("ERRO", "Erro no loop de atualização periódica: " + ex.Message);
              }
            }
          }), readLoopToken);
        }
        else
        {
          DiscordRpcManager.Log("ERRO", $"Discord rejeitou handshake ou enviou resposta inválida. OP: {num}, Payload: {str}");
          DiscordRpcManager.ShutdownConnectionOnly();
        }
        connectedPipe = (NamedPipeClientStream) null;
      }
    }
    catch (Exception ex)
    {
      DiscordRpcManager.Log("ERRO", $"Exceção em TryConnect: {ex.Message}\n{ex.StackTrace}");
      DiscordRpcManager.ShutdownConnectionOnly();
    }
    finally
    {
      DiscordRpcManager._isConnecting = false;
    }
  }

  public static void UpdatePresence(string state)
  {
    DiscordRpcManager.CurrentStateText = state;
    Task.Run((Func<Task>) (async () =>
    {
      try
      {
        await DiscordRpcManager.SendPresenceUpdateAsync();
      }
      catch (Exception ex)
      {
        DiscordRpcManager.Log("ERRO", "Erro ao atualizar presença: " + ex.Message);
      }
    }));
  }

  private static async Task SendPresenceUpdateAsync()
  {
    if (!DiscordRpcManager._isConnected)
      return;
    NamedPipeClientStream pipe;
    lock (DiscordRpcManager._pipeLock)
      pipe = DiscordRpcManager._pipe;
    if (pipe == null)
      return;
    if (!pipe.IsConnected)
      return;
    try
    {
      string str1 = "Alecrin Bypass Free";
      string stateText = DiscordRpcManager.CurrentStateText;
      string str2 = str1.Replace("\\", "\\\\").Replace("\"", "\\\"");
      string str3 = stateText.Replace("\\", "\\\\").Replace("\"", "\\\"");
      string str4 = DiscordRpcManager.LargeImage.Replace("\\", "\\\\").Replace("\"", "\\\"");
      string str5 = DiscordRpcManager.LargeText.Replace("\\", "\\\\").Replace("\"", "\\\"");
      string str6 = DiscordRpcManager.DiscordInviteUrl.Replace("\\", "\\\\").Replace("\"", "\\\"");
      await DiscordRpcManager.WriteFrameAsync(1, $"{{\"cmd\":\"SET_ACTIVITY\",\"args\":{{{$"\"pid\":{Process.GetCurrentProcess().Id},"}\"activity\":{{\"details\":\"{str2}\",\"state\":\"{str3}\",{$"\"timestamps\":{{\"start\":{DiscordRpcManager._startTimeUnix}}},"}\"assets\":{{\"large_image\":\"{str4}\",\"large_text\":\"{str5}\"}},\"buttons\":[{{\"label\":\"DISCORD\",\"url\":\"{str6}\"}}]}}}},{$"\"nonce\":\"{Guid.NewGuid()}\""}}}");
      DiscordRpcManager.Log("TRAC", "Presença atualizada: " + stateText);
      stateText = (string) null;
    }
    catch (Exception ex)
    {
      DiscordRpcManager.Log("ERRO", $"Exceção em SendPresenceUpdate: {ex.Message}\n{ex.StackTrace}");
    }
  }

  private static async Task ReadLoopAsync(CancellationToken token)
  {
    try
    {
      while (!token.IsCancellationRequested)
      {
        NamedPipeClientStream pipe;
        lock (DiscordRpcManager._pipeLock)
          pipe = DiscordRpcManager._pipe;
        if (pipe == null || !pipe.IsConnected)
          break;
        Tuple<int, string> tuple = await DiscordRpcManager.ReadFrameAsync(token);
        int num = tuple.Item1;
        string payload = tuple.Item2;
        switch (num)
        {
          case 2:
            DiscordRpcManager.Log("INFO", "Discord enviou frame de fechamento: " + payload);
            DiscordRpcManager._isConnected = false;
            return;
          case 3:
            await DiscordRpcManager.WriteFrameAsync(4, payload);
            continue;
          default:
            continue;
        }
      }
    }
    catch (OperationCanceledException ex)
    {
      DiscordRpcManager.Log("TRAC", "ReadLoop cancelado.");
    }
    catch (IOException ex)
    {
      DiscordRpcManager.Log("TRAC", "ReadLoop IO encerrado (Discord pode ter fechado): " + ex.Message);
    }
    catch (Exception ex)
    {
      DiscordRpcManager.Log("TRAC", "ReadLoop encerrado: " + ex.Message);
    }
    finally
    {
      DiscordRpcManager._isConnected = false;
      DiscordRpcManager.ShutdownConnectionOnly();
    }
  }

  private static async Task WriteFrameAsync(int op, string payload)
  {
    NamedPipeClientStream currentPipe;
    lock (DiscordRpcManager._pipeLock)
      currentPipe = DiscordRpcManager._pipe;
    if (currentPipe == null)
      currentPipe = (NamedPipeClientStream) null;
    else if (!currentPipe.IsConnected)
    {
      currentPipe = (NamedPipeClientStream) null;
    }
    else
    {
      await DiscordRpcManager._writeLock.WaitAsync();
      try
      {
        byte[] bytes = Encoding.UTF8.GetBytes(payload);
        byte[] numArray = new byte[8 + bytes.Length];
        numArray[0] = (byte) (op & (int) byte.MaxValue);
        numArray[1] = (byte) (op >> 8 & (int) byte.MaxValue);
        numArray[2] = (byte) (op >> 16 /*0x10*/ & (int) byte.MaxValue);
        numArray[3] = (byte) (op >> 24 & (int) byte.MaxValue);
        numArray[4] = (byte) (bytes.Length & (int) byte.MaxValue);
        numArray[5] = (byte) (bytes.Length >> 8 & (int) byte.MaxValue);
        numArray[6] = (byte) (bytes.Length >> 16 /*0x10*/ & (int) byte.MaxValue);
        numArray[7] = (byte) (bytes.Length >> 24 & (int) byte.MaxValue);
        if (bytes.Length != 0)
          Array.Copy((Array) bytes, 0, (Array) numArray, 8, bytes.Length);
        await currentPipe.WriteAsync(numArray, 0, numArray.Length);
        await currentPipe.FlushAsync();
        currentPipe = (NamedPipeClientStream) null;
      }
      catch (IOException ex)
      {
        DiscordRpcManager.Log("ERRO", "Exceção IO no WriteFrame (pipe quebrado): " + ex.Message);
        DiscordRpcManager._isConnected = false;
        currentPipe = (NamedPipeClientStream) null;
      }
      catch (Exception ex)
      {
        DiscordRpcManager.Log("ERRO", "Exceção no WriteFrame: " + ex.Message);
        currentPipe = (NamedPipeClientStream) null;
      }
      finally
      {
        DiscordRpcManager._writeLock.Release();
      }
    }
  }

  private static async Task<Tuple<int, string>> ReadFrameAsync(CancellationToken token)
  {
    NamedPipeClientStream currentPipe;
    lock (DiscordRpcManager._pipeLock)
      currentPipe = DiscordRpcManager._pipe;
    if (currentPipe == null || !currentPipe.IsConnected)
      throw new IOException("Pipe não conectado");
    byte[] header = new byte[8];
    int num1;
    for (int headerRead = 0; headerRead < 8; headerRead += num1)
    {
      num1 = await currentPipe.ReadAsync(header, headerRead, 8 - headerRead, token);
      if (num1 <= 0)
        throw new IOException("Conexão fechada ao ler cabeçalho");
    }
    int op = (int) header[0] | (int) header[1] << 8 | (int) header[2] << 16 /*0x10*/ | (int) header[3] << 24;
    int length = (int) header[4] | (int) header[5] << 8 | (int) header[6] << 16 /*0x10*/ | (int) header[7] << 24;
    byte[] payloadBytes = length >= 0 && length <= 65536 /*0x010000*/ ? new byte[length] : throw new IOException($"Tamanho de payload inválido: {length}. Máximo permitido: {65536 /*0x010000*/}");
    int num2;
    if (length > 0)
    {
      for (int totalRead = 0; totalRead < length; totalRead += num2)
      {
        num2 = await currentPipe.ReadAsync(payloadBytes, totalRead, length - totalRead, token);
        if (num2 <= 0)
          throw new IOException("Conexão fechada ao ler payload");
      }
    }
    Tuple<int, string> tuple = Tuple.Create<int, string>(op, Encoding.UTF8.GetString(payloadBytes));
    currentPipe = (NamedPipeClientStream) null;
    header = (byte[]) null;
    payloadBytes = (byte[]) null;
    return tuple;
  }

  private static void ShutdownConnectionOnly()
  {
    try
    {
      if (DiscordRpcManager._readLoopCts != null)
        DiscordRpcManager._readLoopCts.Cancel();
    }
    catch
    {
    }
    try
    {
      if (DiscordRpcManager._readLoopCts != null)
        DiscordRpcManager._readLoopCts.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._readLoopCts = (CancellationTokenSource) null;
    NamedPipeClientStream pipeClientStream = (NamedPipeClientStream) null;
    lock (DiscordRpcManager._pipeLock)
    {
      pipeClientStream = DiscordRpcManager._pipe;
      DiscordRpcManager._pipe = (NamedPipeClientStream) null;
    }
    try
    {
      pipeClientStream?.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._isConnected = false;
  }

  public static void Shutdown()
  {
    try
    {
      if (DiscordRpcManager._reconnectCts != null)
        DiscordRpcManager._reconnectCts.Cancel();
    }
    catch
    {
    }
    try
    {
      if (DiscordRpcManager._reconnectCts != null)
        DiscordRpcManager._reconnectCts.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._reconnectCts = (CancellationTokenSource) null;
    DiscordRpcManager.ShutdownConnectionOnly();
    DiscordRpcManager.Log("INFO", "Conexão RPC encerrada completamente.");
  }
}
