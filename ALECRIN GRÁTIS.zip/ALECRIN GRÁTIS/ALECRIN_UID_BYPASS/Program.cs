﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.Program
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace ALECRIN_UID_BYPASS;

internal static class Program
{
  public static Font GetHeaderFont() => new Font("Segoe UI", 11.25f, FontStyle.Bold);

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr LoadLibrary(string lpFileName);

  private static async Task DownloadFileAsync(string url, string destPath)
  {
    string requestUriString = url;
    for (int i = 0; i < 10; ++i)
    {
      HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(requestUriString);
      httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)";
      httpWebRequest.AllowAutoRedirect = false;
      httpWebRequest.Timeout = 30000;
      using (HttpWebResponse resp = (HttpWebResponse) await httpWebRequest.GetResponseAsync())
      {
        if (resp.StatusCode >= HttpStatusCode.MultipleChoices && resp.StatusCode < HttpStatusCode.BadRequest)
        {
          requestUriString = resp.Headers["Location"];
        }
        else
        {
          using (Stream stream = resp.GetResponseStream())
          {
            using (FileStream fs = System.IO.File.Create(destPath))
              await stream.CopyToAsync((Stream) fs);
          }
        }
      }
    }
    throw new Exception("Muitos redirecionamentos ao baixar a DLL.");
  }

  [STAThread]
  private static void Main()
  {
    bool createdNew;
    using (new Mutex(true, "AlecrinUidBypassUniqueInstanceMutexName", out createdNew))
    {
      if (!createdNew)
      {
        int num = (int) MessageBox.Show("O Alecrin Bypass já está em execução!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
      }
      else
      {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try
        {
          DiscordRpcManager.Initialize();
        }
        catch
        {
        }
        using (SplashForm splashForm = new SplashForm())
        {
          if (splashForm.ShowDialog() != DialogResult.OK)
            return;
        }
        Form1 mainForm = new Form1();
        mainForm.FormClosed += (FormClosedEventHandler) ((s, e) =>
        {
          try
          {
            DiscordRpcManager.Shutdown();
          }
          catch
          {
          }
        });
        Application.Run((Form) mainForm);
      }
    }
  }
}
