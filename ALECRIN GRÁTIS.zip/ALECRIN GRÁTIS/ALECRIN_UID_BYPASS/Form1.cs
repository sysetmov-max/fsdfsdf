﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.Form1
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using Guna.UI2.WinForms.Suite;
using nxr;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace ALECRIN_UID_BYPASS;

public class Form1 : Form
{
  private static readonly HttpClient httpClient = new HttpClient();
  private const string ProxyUrl = "https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/Ip.txt";
  private const string CertUrl = "https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/c8750f0d.0";
  private const string DiscordIconUrl = "https://cdn-icons-png.flaticon.com/512/5968/5968756.png";
  private const string YoutubeIconUrl = "https://cdn-icons-png.flaticon.com/512/1384/1384060.png";
  private const string EmbeddedResourceName = "ALECRIN_UID_BYPASS.c8750f0d.0";
  private const string CertHash = "c8750f0d";
  private bool dllStatus;
  private string adbPath;
  private System.Windows.Forms.Timer emulatorCheckTimer;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2DragControl guna2DragControl1;
  private Guna2DragControl guna2DragControl2;
  private Guna2DragControl guna2DragControl3;
  private Guna2DragControl guna2DragControl4;
  private Guna2DragControl guna2DragControl5;
  private Guna2DragControl guna2DragControl6;
  private Guna2DragControl guna2DragControl7;
  private Guna2DragControl guna2DragControl8;
  private Guna2DragControl guna2DragControl9;
  private Guna2Panel rootPanel;
  private Guna2Panel headerPanel;
  private Guna2Panel mainContentPanel;
  private Label appTitleLabel;
  private Guna2ControlBox guna2ControlBoxMinimize;
  private Guna2ControlBox guna2ControlBoxClose;
  private Guna2PictureBox guna2PictureBox3;
  private Label lblSettingsTitle;
  private Label lblTargetEmulator;
  private Label lblEncryption;
  private Label lblActionTitle;
  private Label label3;
  private Guna2ComboBox AdbCombo;
  private Guna2TextBox AdbTextBox;
  private Guna2GradientButton shayanButton1;
  private Guna2Button shayanButton2;
  private Guna2Button shayanButton4;
  private Guna2Button shayanButton5;
  private Guna2Button shayanButton3;
  private Guna2Button lblSetTitle;
  private Guna2Button label2;

  private async Task<string> FetchOnlineProxy()
  {
    try
    {
      return (await Form1.httpClient.GetStringAsync("https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/Ip.txt")).Trim();
    }
    catch (Exception ex)
    {
      NotificationForm.ShowNotification("Erro", "Falha ao obter o proxy online", NotificationType.Error);
      return "192.168.0.105:8080";
    }
  }

  private async Task<string> FetchOnlineCert()
  {
    try
    {
      string stringAsync = await Form1.httpClient.GetStringAsync("https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/c8750f0d.0");
      string path = Path.Combine(Path.GetTempPath(), "c8750f0d.0");
      File.WriteAllText(path, stringAsync);
      return path;
    }
    catch (Exception ex)
    {
      NotificationForm.ShowNotification("Erro", "Falha ao obter o certificado online", NotificationType.Error);
      return (string) null;
    }
  }

  private string GetMemuAdbPath()
  {
    string[] strArray = new string[4]
    {
      "C:\\Program Files\\Microvirt\\MEmu\\adb.exe",
      "C:\\Program Files (x86)\\Microvirt\\MEmu\\adb.exe",
      "D:\\Program Files\\Microvirt\\MEmu\\adb.exe",
      "D:\\Program Files (x86)\\Microvirt\\MEmu\\adb.exe"
    };
    foreach (string path in strArray)
    {
      if (File.Exists(path))
        return path;
    }
    return (string) null;
  }

  private bool IsProcessRunning(string[] processNames)
  {
    foreach (string processName in processNames)
    {
      if (Process.GetProcessesByName(processName).Length != 0)
        return true;
    }
    return false;
  }

  private async void DetectRunningEmulator()
  {
    string selected = "";
    bool containsMemu = false;
    if (((Control) this.AdbCombo).InvokeRequired)
    {
      ((Control) this.AdbCombo).Invoke((Delegate) (() =>
      {
        selected = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
        containsMemu = ((ComboBox) this.AdbCombo).Items.Contains((object) "MEMU");
      }));
    }
    else
    {
      selected = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
      containsMemu = ((ComboBox) this.AdbCombo).Items.Contains((object) "MEMU");
    }
    await Task.Run((Action) (() =>
    {
      try
      {
        switch (selected)
        {
          case "MSI":
            if (this.IsProcessRunning(new string[1]
            {
              "HD-Player"
            }) && ((IEnumerable<Process>) Process.GetProcessesByName("HD-Player")).FirstOrDefault<Process>((Func<Process, bool>) (p =>
            {
              try
              {
                return p.MainModule.FileName.Contains("Bluestacks_msi5");
              }
              catch
              {
                return false;
              }
            })) != null)
            {
              this.BeginInvoke((Delegate) (() => this.UpdateEmulatorStatus1()));
              return;
            }
            break;
          case "BLUESTACKS":
            if (this.IsProcessRunning(new string[1]
            {
              "HD-Player"
            }) && ((IEnumerable<Process>) Process.GetProcessesByName("HD-Player")).FirstOrDefault<Process>((Func<Process, bool>) (p =>
            {
              try
              {
                return p.MainModule.FileName.Contains("BlueStacks_nxt");
              }
              catch
              {
                return false;
              }
            })) != null)
            {
              this.BeginInvoke((Delegate) (() => this.UpdateEmulatorStatus()));
              return;
            }
            break;
          default:
            if (selected == "MEMU" || selected == "Memu")
            {
              if (this.IsProcessRunning(new string[2]
              {
                "MEmu",
                "MEmuHeadless"
              }))
              {
                this.BeginInvoke((Delegate) (() => this.label3.Text = "Selecionar Emulador: Executando"));
                return;
              }
              break;
            }
            break;
        }
        if (!this.IsProcessRunning(new string[2]
        {
          "MEmu",
          "MEmuHeadless"
        }) || !containsMemu)
          return;
        this.BeginInvoke((Delegate) (() =>
        {
          ((ComboBox) this.AdbCombo).SelectedItem = (object) "MEMU";
          this.label3.Text = "Selecionar Emulador: Executando";
        }));
      }
      catch
      {
      }
    }));
  }

  private void PopulateAdbCombo()
  {
    ((ComboBox) this.AdbCombo).Items.Clear();
    if (File.Exists("C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe"))
      ((ComboBox) this.AdbCombo).Items.Add((object) "BLUESTACKS");
    if (File.Exists("C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe"))
      ((ComboBox) this.AdbCombo).Items.Add((object) "MSI");
    if (this.GetMemuAdbPath() != null)
      ((ComboBox) this.AdbCombo).Items.Add((object) "MEMU");
    if (((ComboBox) this.AdbCombo).Items.Count > 0)
      ((ListControl) this.AdbCombo).SelectedIndex = 0;
    this.DetectRunningEmulator();
  }

  public void UpdateEmulatorStatus()
  {
    string str = "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  private string ResolveAdbPath(string selectedEmulator)
  {
    string path1 = "C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe";
    string path2 = "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe";
    if (selectedEmulator != null && selectedEmulator.Contains("MSI") && File.Exists(path1))
      return path1;
    if (selectedEmulator != null && selectedEmulator.Contains("BLUESTACKS") && File.Exists(path2))
      return path2;
    if (selectedEmulator != null && selectedEmulator.Contains("MEMU"))
    {
      string memuAdbPath = this.GetMemuAdbPath();
      if (memuAdbPath != null)
        return memuAdbPath;
    }
    throw new FileNotFoundException("No ADB executable found for the selected emulator.");
  }

  private string ExtractEmbeddedCert(string resourceName, string hash)
  {
    string path = Path.Combine(Path.GetTempPath(), hash + ".0");
    using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
    {
      using (FileStream destination = File.Create(path))
        manifestResourceStream.CopyTo((Stream) destination);
    }
    return path;
  }

  private string GetDefaultDeviceID(string selectedEmulator = null)
  {
    if (selectedEmulator != null)
      return selectedEmulator.Contains("MEMU") || selectedEmulator.Contains("Memu") ? "127.0.0.1:21503" : "127.0.0.1:5555";
    object selectedItem1 = ((ComboBox) this.AdbCombo).SelectedItem;
    if ((selectedItem1 != null ? (selectedItem1.ToString().Contains("MEMU") ? 1 : 0) : 0) == 0)
    {
      object selectedItem2 = ((ComboBox) this.AdbCombo).SelectedItem;
      if ((selectedItem2 != null ? (selectedItem2.ToString().Contains("Memu") ? 1 : 0) : 0) == 0)
        return "127.0.0.1:5555";
    }
    return "127.0.0.1:21503";
  }

  private void RunAdb(
    string exe,
    string args,
    out string stdout,
    out string stderr,
    string deviceId = null,
    string selectedEmulator = null)
  {
    if (deviceId == null)
      deviceId = this.GetDefaultDeviceID(selectedEmulator);
    using (Process process = Process.Start(new ProcessStartInfo()
    {
      FileName = exe,
      Arguments = $"-s {deviceId} {args}",
      RedirectStandardOutput = true,
      RedirectStandardError = true,
      UseShellExecute = false,
      CreateNoWindow = true
    }))
    {
      stdout = process.StandardOutput.ReadToEnd();
      stderr = process.StandardError.ReadToEnd();
      process.WaitForExit();
    }
  }

  private bool ConnectAdb(string adbExe, string selectedEmulator = null)
  {
    string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
    string stdout;
    this.RunAdb(adbExe, "connect " + defaultDeviceId, out stdout, out string _, defaultDeviceId, selectedEmulator);
    if (stdout.Contains("connected"))
      return true;
    NotificationForm.ShowNotification("Notificação", "Falha na Conexão ADB!", NotificationType.Failed);
    return false;
  }

  private bool FileExistsOnDevice(string adb, string path, string selectedEmulator)
  {
    string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
    string stdout;
    this.RunAdb(adb, $"shell \"[ -f {path} ] && echo yes || echo no\"", out stdout, out string _, defaultDeviceId, selectedEmulator);
    return stdout.Trim().Equals("yes", StringComparison.OrdinalIgnoreCase);
  }

  private void EditConfigs(string engineRootPath)
  {
    if (!Directory.Exists(engineRootPath))
      throw new Exception("Engine path not found.");
    foreach (string directory in Directory.GetDirectories(engineRootPath))
    {
      string fileName = Path.GetFileName(directory);
      foreach (string path in ((IEnumerable<string>) new string[3]
      {
        Path.Combine(directory, "Android.bstk.in"),
        Path.Combine(directory, fileName + ".bstk"),
        Path.Combine(directory, fileName + ".bstk-prev")
      }).Where<string>(new Func<string, bool>(File.Exists)))
      {
        string contents = Regex.Replace(Regex.Replace(File.ReadAllText(path, Encoding.UTF8), "(<HardDisk\\b[^>]*location\\s*=\\s*\"Root\\.vhd\"[^>]*type\\s*=\\s*\")Readonly(\"\\s*/?>)", "$1Normal$2", RegexOptions.IgnoreCase), "(<HardDisk\\b[^>]*location\\s*=\\s*\"Data\\.vhdx\"[^>]*type\\s*=\\s*\")Readonly(\"\\s*/?>)", "$1Normal$2", RegexOptions.IgnoreCase);
        File.WriteAllText(path, contents, Encoding.UTF8);
      }
    }
  }

  public Form1(bool isDllLoaded)
  {
    this.InitializeComponent();
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.appTitleLabel.Font = Program.GetHeaderFont();
    this.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
    this.dllStatus = isDllLoaded;
    if (this.dllStatus)
      NotificationForm.ShowNotification("Notificação", "DLL Conectada ✅", NotificationType.Success);
    else
      NotificationForm.ShowNotification("Notificação", "Modo Limitado ⚠️", NotificationType.Info);
  }

  private string GetEmulatorIP()
  {
    try
    {
      using (Process process = Process.Start(new ProcessStartInfo()
      {
        FileName = this.adbPath,
        Arguments = "devices",
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false,
        CreateNoWindow = true
      }))
      {
        process.WaitForExit();
        string end = process.StandardOutput.ReadToEnd();
        char[] separator = new char[2]{ '\r', '\n' };
        foreach (string str in end.Split(separator, StringSplitOptions.RemoveEmptyEntries))
        {
          if (str.EndsWith("\tdevice"))
            return str.Split('\t')[0];
        }
      }
    }
    catch
    {
    }
    return "127.0.0.1:" + ((Control) this.AdbTextBox).Text;
  }

  private Task<string> RunAdbCommandAsync(string exe, string arguments)
  {
    return Task.Run<string>((Func<string>) (() =>
    {
      try
      {
        using (Process process = Process.Start(new ProcessStartInfo()
        {
          FileName = exe,
          Arguments = arguments,
          RedirectStandardOutput = true,
          RedirectStandardError = true,
          UseShellExecute = false,
          CreateNoWindow = true
        }))
        {
          process.WaitForExit();
          string end1 = process.StandardOutput.ReadToEnd();
          string end2 = process.StandardError.ReadToEnd();
          return !string.IsNullOrEmpty(end2) ? "Error: " + end2 : end1;
        }
      }
      catch (Exception ex)
      {
        return "Exception: " + ex.Message;
      }
    }));
  }

  private string RunAdbCommand(string exe, string arguments)
  {
    try
    {
      using (Process process = Process.Start(new ProcessStartInfo()
      {
        FileName = exe,
        Arguments = arguments,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false,
        CreateNoWindow = true
      }))
      {
        process.WaitForExit();
        string end1 = process.StandardOutput.ReadToEnd();
        string end2 = process.StandardError.ReadToEnd();
        return !string.IsNullOrEmpty(end2) ? "Error: " + end2 : end1;
      }
    }
    catch (Exception ex)
    {
      return "Exception: " + ex.Message;
    }
  }

  private void PopulateAdbCombo1()
  {
    if (File.Exists("C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe"))
      this.UpdateEmulatorStatus1();
    if (!File.Exists("C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe"))
      return;
    this.UpdateEmulatorStatus();
  }

  public void UpdateEmulatorStatus(string emulatorName = "BlueStacks NXT")
  {
    string str = "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  public void UpdateEmulatorStatus1()
  {
    string str = "C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  private string GetAdbPath()
  {
    string[] strArray = new string[4]
    {
      "C:\\Program Files\\BlueStacks_msi5\\HD-Adb.exe",
      "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe",
      this.GetMemuAdbPath() ?? "",
      "C:\\Android\\platform-tools\\adb.exe"
    };
    foreach (string path in strArray)
    {
      if (File.Exists(path))
        return path;
    }
    return "";
  }

  public Form1()
  {
    try
    {
      this.adbPath = this.GetAdbPath();
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show(ex.Message, "ADB Não Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      this.Close();
    }
    this.InitializeComponent();
    this.Opacity = 0.85;
    System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    timer.Interval = 200;
    timer.Tick += (EventHandler) ((s, e) =>
    {
      if (this.Opacity <= 0.85)
        return;
      this.Opacity = 0.85;
    });
    timer.Start();
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.appTitleLabel.Font = Program.GetHeaderFont();
    this.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
    this.PopulateAdbCombo();
    this.PopulateAdbCombo1();
  }

  private void EmulatorCheckTimer_Tick(object sender, EventArgs e) => this.DetectRunningEmulator();

  private async void shayanButton2_Click(object sender, EventArgs e)
  {
    string selectedEmulator = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
    await Task.Run((Func<Task>) (async () =>
    {
      string str1 = this.ResolveAdbPath(selectedEmulator);
      this.ConnectAdb(str1, selectedEmulator);
      string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
      string str2 = await this.RunAdbCommandAsync(str1, $"-s {defaultDeviceId} shell settings put global http_proxy :0");
      this.Invoke((Delegate) (() =>
      {
        this.lblTargetEmulator.Text = "Status: Offline";
        this.lblTargetEmulator.ForeColor = Color.White;
      }));
      NotificationForm.ShowNotification("Notificação", "Bypass Desconectado!", NotificationType.Success);
      try
      {
        DiscordRpcManager.UpdatePresence("Bypass Desconectado");
      }
      catch
      {
      }
    }));
  }

  private async void shayanButton1_Click(object sender, EventArgs e)
  {
    string selectedEmulator = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
    ((Control) this.shayanButton1).Enabled = false;
    NotificationForm.ShowNotification("Notificação", "Conectando... Aguarde.", NotificationType.Info);
    await Task.Run((Func<Task>) (async () =>
    {
      string str1 = selectedEmulator;
      if ((str1 != null ? (str1.Contains("BLUESTACKS") ? 1 : 0) : 0) == 0)
      {
        string str2 = selectedEmulator;
        if ((str2 != null ? (str2.Contains("MSI") ? 1 : 0) : 0) == 0)
          goto label_8;
      }
      foreach (Process process in Process.GetProcessesByName("HD-Adb"))
      {
        try
        {
          process.Kill();
        }
        catch
        {
        }
      }
label_8:
      string adb = this.ResolveAdbPath(selectedEmulator);
      this.ConnectAdb(adb, selectedEmulator);
      string device = this.GetDefaultDeviceID(selectedEmulator);
      string proxy = await this.FetchOnlineProxy();
      string packageName = "com.dts.freefireth";
      string str3 = await this.RunAdbCommandAsync(adb, $"-s {device} shell am force-stop {packageName}");
      string str4 = await this.RunAdbCommandAsync(adb, $"-s {device} shell settings put global http_proxy {proxy}");
      string str5 = await this.RunAdbCommandAsync(adb, $"-s {device} shell monkey -p {packageName} -c android.intent.category.LAUNCHER 1");
      this.Invoke((Delegate) (() =>
      {
        this.lblTargetEmulator.Text = "Status: Ativo";
        this.lblTargetEmulator.ForeColor = Color.White;
      }));
      NotificationForm.ShowNotification("Notificação", "Bypass conectado com sucesso!", NotificationType.Success);
      try
      {
        DiscordRpcManager.UpdatePresence("Bypass Conectado");
        adb = (string) null;
        device = (string) null;
        proxy = (string) null;
        packageName = (string) null;
      }
      catch
      {
        adb = (string) null;
        device = (string) null;
        proxy = (string) null;
        packageName = (string) null;
      }
    }));
    ((Control) this.shayanButton1).Enabled = true;
  }

  private async Task LoadSocialIcons()
  {
    try
    {
      string discordPath = Path.Combine(Path.GetTempPath(), "discord_icon.png");
      string youtubePath = Path.Combine(Path.GetTempPath(), "youtube_icon.png");
      if (!File.Exists(discordPath))
        File.WriteAllBytes(discordPath, await Form1.httpClient.GetByteArrayAsync("https://cdn-icons-png.flaticon.com/512/5968/5968756.png"));
      if (!File.Exists(youtubePath))
        File.WriteAllBytes(youtubePath, await Form1.httpClient.GetByteArrayAsync("https://cdn-icons-png.flaticon.com/512/1384/1384060.png"));
      if (File.Exists(discordPath))
      {
        this.lblSetTitle.Image = Image.FromFile(discordPath);
        this.lblSetTitle.ImageSize = new Size(20, 20);
        ((Control) this.lblSetTitle).Text = "";
      }
      if (File.Exists(youtubePath))
      {
        this.label2.Image = Image.FromFile(youtubePath);
        this.label2.ImageSize = new Size(20, 20);
        ((Control) this.label2).Text = "";
      }
      discordPath = (string) null;
      youtubePath = (string) null;
    }
    catch
    {
    }
  }

  private async void Form1_Load(object sender, EventArgs e)
  {
    Form1 form1 = this;
    try
    {
      using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ALECRIN_UID_BYPASS.logo.png"))
      {
        if (manifestResourceStream != null)
          ((PictureBox) form1.guna2PictureBox3).Image = Image.FromStream(manifestResourceStream);
      }
    }
    catch
    {
    }
    form1.DetectRunningEmulator();
    await form1.LoadSocialIcons();
    form1.emulatorCheckTimer = new System.Windows.Forms.Timer();
    form1.emulatorCheckTimer.Interval = 1000;
    form1.emulatorCheckTimer.Tick += new EventHandler(form1.EmulatorCheckTimer_Tick);
    form1.emulatorCheckTimer.Start();
  }

  private void Form1_FormClosed(object sender, FormClosedEventArgs e)
  {
    try
    {
      DiscordRpcManager.Shutdown();
    }
    catch
    {
    }
    Environment.Exit(0);
  }

  private void shayanButton4_Click(object sender, EventArgs e)
  {
    try
    {
      object selectedItem1 = ((ComboBox) this.AdbCombo).SelectedItem;
      if ((selectedItem1 != null ? (selectedItem1.ToString().Contains("Memu") ? 1 : 0) : 0) != 0)
      {
        string[] strArray = new string[4]
        {
          "MEmu",
          "MEmuHeadless",
          "MEmuSVC",
          "MEmuManage"
        };
        foreach (string processName in strArray)
        {
          foreach (Process process in Process.GetProcessesByName(processName))
          {
            try
            {
              process.Kill();
              process.WaitForExit(2000);
            }
            catch
            {
            }
          }
        }
        string memuAdbPath = this.GetMemuAdbPath();
        if (memuAdbPath == null)
          return;
        string str = Path.Combine(Path.GetDirectoryName(memuAdbPath), "MEmu.exe");
        if (File.Exists(str))
        {
          Process.Start(str);
          NotificationForm.ShowNotification("Notificação", "MEmu Iniciado!", NotificationType.Success);
        }
        else
          NotificationForm.ShowNotification("Notificação", "Executável do MEmu não encontrado!", NotificationType.Error);
      }
      else
      {
        string[] strArray = new string[4]
        {
          "HD-Player",
          "HD-Adb",
          "HD-MultiInstanceManager",
          "BstkSVC"
        };
        foreach (string processName in strArray)
        {
          foreach (Process process in Process.GetProcessesByName(processName))
          {
            try
            {
              process.Kill();
              process.WaitForExit(2000);
            }
            catch
            {
            }
          }
        }
        object selectedItem2 = ((ComboBox) this.AdbCombo).SelectedItem;
        string str1 = (selectedItem2 != null ? (selectedItem2.ToString().Contains("MSI") ? 1 : 0) : 0) != 0 ? "C:\\ProgramData\\Bluestacks_msi5\\Engine" : "C:\\ProgramData\\BlueStacks_nxt\\Engine";
        this.EditConfigs(str1);
        string path1 = Path.Combine(str1, "Manager");
        if (Directory.Exists(path1))
        {
          foreach (string path2 in ((IEnumerable<string>) Directory.GetFiles(path1, "BstkServer.log")).Concat<string>((IEnumerable<string>) Directory.GetFiles(path1, "BstkServer.log.*")))
          {
            try
            {
              File.Delete(path2);
            }
            catch
            {
              try
              {
                using (new FileStream(path2, FileMode.Create, FileAccess.Write))
                  ;
              }
              catch
              {
              }
            }
          }
        }
        foreach (string directory in Directory.GetDirectories(str1))
        {
          string path3 = Path.Combine(directory, "Logs");
          if (Directory.Exists(path3))
          {
            foreach (string file in Directory.GetFiles(path3, "BstkCore.log*"))
            {
              try
              {
                File.Delete(file);
              }
              catch
              {
              }
            }
          }
        }
        NotificationForm.ShowNotification("Notificação", "Acesso Concedido!", NotificationType.Success);
        try
        {
          object selectedItem3 = ((ComboBox) this.AdbCombo).SelectedItem;
          string str2 = (selectedItem3 != null ? (selectedItem3.ToString().Contains("MSI") ? 1 : 0) : 0) != 0 ? "C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe" : "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
          if (File.Exists(str2))
          {
            Process.Start(str2);
            NotificationForm.ShowNotification("Notificação", "Emulador Iniciado!", NotificationType.Success);
          }
          else
            NotificationForm.ShowNotification("Notificação", "Emulador não encontrado!", NotificationType.Error);
        }
        catch (Exception ex)
        {
        }
      }
    }
    catch (Exception ex)
    {
    }
  }

  private async void shayanButton5_Click(object sender, EventArgs e)
  {
    string selectedEmulator = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
    await Task.Run((Func<Task>) (async () =>
    {
      try
      {
        string adb = this.ResolveAdbPath(selectedEmulator);
        if (!this.ConnectAdb(adb, selectedEmulator))
          return;
        string str1 = await this.FetchOnlineCert();
        if (string.IsNullOrEmpty(str1))
          return;
        string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
        string str2;
        string str3;
        this.RunAdb(adb, $"push \"{str1}\" /sdcard/c8750f0d.0", out str2, out str3, defaultDeviceId, selectedEmulator);
        string str4 = selectedEmulator;
        if ((str4 != null ? (str4.Contains("MEMU") ? 1 : 0) : 0) == 0)
        {
          string str5 = selectedEmulator;
          if ((str5 != null ? (str5.Contains("Memu") ? 1 : 0) : 0) == 0)
          {
            string str6 = "/boot/android/android/system/xbin/bstk/su" + " -c 'mount -o rw,remount /dev/sda1 /system && cp /sdcard/c8750f0d.0 /system/etc/security/cacerts/c8750f0d.0 && chmod 644 /system/etc/security/cacerts/c8750f0d.0 && chcon u:object_r:system_file:s0 /system/etc/security/cacerts/c8750f0d.0 && mount -o ro,remount /dev/sda1 /system && rm /sdcard/c8750f0d.0 && setprop ctl.restart zygote'";
            this.RunAdb(adb, $"shell \"{str6}\"", out str2, out str3, defaultDeviceId, selectedEmulator);
            goto label_9;
          }
        }
        this.RunAdb(adb, "root", out str3, out str2, defaultDeviceId, selectedEmulator);
        this.RunAdb(adb, "remount", out str2, out str3, defaultDeviceId, selectedEmulator);
        string str7 = "mount -o rw,remount /system && mount -o rw,remount / && mkdir -p /system/etc/security/cacerts/ && cp /sdcard/c8750f0d.0 /system/etc/security/cacerts/c8750f0d.0 && chmod 644 /system/etc/security/cacerts/c8750f0d.0 && chown root:root /system/etc/security/cacerts/c8750f0d.0 && mount -o ro,remount /system && rm /sdcard/c8750f0d.0";
        this.RunAdb(adb, $"shell \"{str7}\"", out str3, out str2, defaultDeviceId, selectedEmulator);
label_9:
        if (this.FileExistsOnDevice(adb, "/system/etc/security/cacerts/c8750f0d.0", selectedEmulator))
          NotificationForm.ShowNotification("Notificação", "Certificado instalado", NotificationType.Success);
        else
          NotificationForm.ShowNotification("Notificação", "Falha ao instalar o certificado", NotificationType.Error);
        adb = (string) null;
      }
      catch
      {
        NotificationForm.ShowNotification("Notificação", "Falha ao instalar o certificado", NotificationType.Error);
      }
    }));
  }

  private async void shayanButton3_Click(object sender, EventArgs e)
  {
    string selectedEmulator = ((ComboBox) this.AdbCombo).SelectedItem?.ToString();
    await Task.Run((Action) (() =>
    {
      try
      {
        string str1 = this.ResolveAdbPath(selectedEmulator);
        if (!this.ConnectAdb(str1, selectedEmulator))
          return;
        string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
        string str2 = selectedEmulator;
        if ((str2 != null ? (str2.Contains("MEMU") ? 1 : 0) : 0) == 0)
        {
          string str3 = selectedEmulator;
          if ((str3 != null ? (str3.Contains("Memu") ? 1 : 0) : 0) == 0)
          {
            string str4 = "/boot/android/android/system/xbin/bstk/su" + " -c 'mount -o rw,remount /dev/sda1 /system && rm /system/etc/security/cacerts/c8750f0d.0 && mount -o ro,remount /dev/sda1 /system &'";
            this.RunAdb(str1, $"shell \"{str4}\"", out string _, out string _, defaultDeviceId, selectedEmulator);
            goto label_6;
          }
        }
        string str5;
        string str6;
        this.RunAdb(str1, "root", out str5, out str6, defaultDeviceId, selectedEmulator);
        this.RunAdb(str1, "remount", out str6, out str5, defaultDeviceId, selectedEmulator);
        string str7 = "mount -o rw,remount /system && rm /system/etc/security/cacerts/c8750f0d.0 && mount -o ro,remount /system";
        this.RunAdb(str1, $"shell \"{str7}\"", out str5, out str6, defaultDeviceId, selectedEmulator);
label_6:
        Thread.Sleep(1000);
        if (!this.FileExistsOnDevice(str1, "/system/etc/security/cacerts/c8750f0d.0", selectedEmulator))
          NotificationForm.ShowNotification("Notificação", "Certificado desinstalado", NotificationType.Success);
        else
          NotificationForm.ShowNotification("Notificação", "Falha ao desinstalar o certificado", NotificationType.Error);
      }
      catch
      {
        NotificationForm.ShowNotification("Notificação", "Falha ao desinstalar o certificado", NotificationType.Error);
      }
    }));
  }

  private void AdbCombo_SelectedIndexChanged(object sender, EventArgs e)
  {
    switch (((ComboBox) this.AdbCombo).SelectedItem?.ToString())
    {
      case "MSI":
        this.UpdateEmulatorStatus1();
        break;
      case "BLUESTACKS":
        this.UpdateEmulatorStatus();
        break;
      case "MEMU":
      case "Memu":
        this.label3.Text = "Selecionar Emulador: Executando";
        break;
    }
  }

  private void lblSetTitle_Click(object sender, EventArgs e)
  {
    try
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "https://discord.gg/alecrin",
        UseShellExecute = true
      });
    }
    catch
    {
    }
  }

  private void label2_Click(object sender, EventArgs e)
  {
    try
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "https://www.youtube.com/@alecrinn",
        UseShellExecute = true
      });
    }
    catch
    {
    }
  }

  private void btnTabBypass_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void btnTabInstaller_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void btnTabPremium_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void headerPanel_Paint(object sender, PaintEventArgs e)
  {
  }

  private void appTitleLabel_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr1_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr2_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr3_Click(object sender, EventArgs e)
  {
  }

  private void bypassmenuPanel_Paint(object sender, PaintEventArgs e)
  {
  }

  private void lblActionTitle_Click(object sender, EventArgs e)
  {
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form1));
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2DragControl1 = new Guna2DragControl(this.components);
    this.headerPanel = new Guna2Panel();
    this.appTitleLabel = new Label();
    this.lblSetTitle = new Guna2Button();
    this.label2 = new Guna2Button();
    this.guna2ControlBoxMinimize = new Guna2ControlBox();
    this.guna2ControlBoxClose = new Guna2ControlBox();
    this.rootPanel = new Guna2Panel();
    this.mainContentPanel = new Guna2Panel();
    this.guna2PictureBox3 = new Guna2PictureBox();
    this.lblSettingsTitle = new Label();
    this.lblTargetEmulator = new Label();
    this.lblEncryption = new Label();
    this.lblActionTitle = new Label();
    this.label3 = new Label();
    this.AdbCombo = new Guna2ComboBox();
    this.AdbTextBox = new Guna2TextBox();
    this.shayanButton1 = new Guna2GradientButton();
    this.shayanButton2 = new Guna2Button();
    this.shayanButton4 = new Guna2Button();
    this.shayanButton5 = new Guna2Button();
    this.shayanButton3 = new Guna2Button();
    this.guna2DragControl2 = new Guna2DragControl(this.components);
    this.guna2DragControl3 = new Guna2DragControl(this.components);
    this.guna2DragControl4 = new Guna2DragControl(this.components);
    this.guna2DragControl5 = new Guna2DragControl(this.components);
    this.guna2DragControl6 = new Guna2DragControl(this.components);
    this.guna2DragControl7 = new Guna2DragControl(this.components);
    this.guna2DragControl8 = new Guna2DragControl(this.components);
    this.guna2DragControl9 = new Guna2DragControl(this.components);
    ((Control) this.headerPanel).SuspendLayout();
    ((Control) this.rootPanel).SuspendLayout();
    ((Control) this.mainContentPanel).SuspendLayout();
    ((ISupportInitialize) this.guna2PictureBox3).BeginInit();
    this.SuspendLayout();
    this.guna2BorderlessForm1.BorderRadius = 10;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.ShadowColor = Color.FromArgb(40, 40, 45);
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl1.TargetControl = (Control) this.headerPanel;
    this.guna2DragControl1.UseTransparentDrag = true;
    ((Control) this.headerPanel).BackColor = Color.Transparent;
    ((Control) this.headerPanel).Controls.Add((Control) this.appTitleLabel);
    ((Control) this.headerPanel).Controls.Add((Control) this.lblSetTitle);
    ((Control) this.headerPanel).Controls.Add((Control) this.label2);
    ((Control) this.headerPanel).Controls.Add((Control) this.guna2ControlBoxMinimize);
    ((Control) this.headerPanel).Controls.Add((Control) this.guna2ControlBoxClose);
    ((Control) this.headerPanel).Dock = DockStyle.Top;
    this.headerPanel.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.headerPanel).Location = new Point(0, 0);
    ((Control) this.headerPanel).Name = "headerPanel";
    ((Control) this.headerPanel).Size = new Size(460, 35);
    ((Control) this.headerPanel).TabIndex = 1;
    this.appTitleLabel.AutoSize = true;
    this.appTitleLabel.Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
    this.appTitleLabel.ForeColor = Color.White;
    this.appTitleLabel.Location = new Point(15, 8);
    this.appTitleLabel.Name = "appTitleLabel";
    this.appTitleLabel.Size = new Size(151, 19);
    this.appTitleLabel.TabIndex = 0;
    this.appTitleLabel.Text = "ALECRIN BYPASS FREE";
    this.lblSetTitle.BorderRadius = 5;
    ((Control) this.lblSetTitle).Cursor = Cursors.Hand;
    this.lblSetTitle.FillColor = Color.Transparent;
    ((Control) this.lblSetTitle).Font = new Font("Segoe UI", 9f);
    ((Control) this.lblSetTitle).ForeColor = Color.White;
    this.lblSetTitle.HoverState.FillColor = Color.FromArgb(30, 30, 35);
    ((Control) this.lblSetTitle).Location = new Point(300, 3);
    ((Control) this.lblSetTitle).Name = "lblSetTitle";
    ((Control) this.lblSetTitle).Size = new Size(32 /*0x20*/, 28);
    ((Control) this.lblSetTitle).TabIndex = 11;
    ((Control) this.lblSetTitle).Click += new EventHandler(this.lblSetTitle_Click);
    this.label2.BorderRadius = 5;
    ((Control) this.label2).Cursor = Cursors.Hand;
    this.label2.FillColor = Color.Transparent;
    ((Control) this.label2).Font = new Font("Segoe UI", 9f);
    ((Control) this.label2).ForeColor = Color.White;
    this.label2.HoverState.FillColor = Color.FromArgb(30, 30, 35);
    ((Control) this.label2).Location = new Point(338, 3);
    ((Control) this.label2).Name = "label2";
    ((Control) this.label2).Size = new Size(32 /*0x20*/, 28);
    ((Control) this.label2).TabIndex = 12;
    ((Control) this.label2).Click += new EventHandler(this.label2_Click);
    ((Control) this.guna2ControlBoxMinimize).Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.guna2ControlBoxMinimize.Animated = true;
    this.guna2ControlBoxMinimize.ControlBoxType = (ControlBoxType) 0;
    this.guna2ControlBoxMinimize.FillColor = Color.Transparent;
    this.guna2ControlBoxMinimize.HoverState.FillColor = Color.FromArgb(45, 45, 50);
    this.guna2ControlBoxMinimize.IconColor = Color.White;
    ((Control) this.guna2ControlBoxMinimize).Location = new Point(385, 0);
    ((Control) this.guna2ControlBoxMinimize).Name = "guna2ControlBoxMinimize";
    ((Control) this.guna2ControlBoxMinimize).Size = new Size(35, 35);
    ((Control) this.guna2ControlBoxMinimize).TabIndex = 5;
    ((Control) this.guna2ControlBoxClose).Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.guna2ControlBoxClose.Animated = true;
    this.guna2ControlBoxClose.FillColor = Color.Transparent;
    this.guna2ControlBoxClose.HoverState.FillColor = Color.FromArgb(200, 0, 0);
    this.guna2ControlBoxClose.IconColor = Color.White;
    ((Control) this.guna2ControlBoxClose).Location = new Point(420, 0);
    ((Control) this.guna2ControlBoxClose).Name = "guna2ControlBoxClose";
    ((Control) this.guna2ControlBoxClose).Size = new Size(35, 35);
    ((Control) this.guna2ControlBoxClose).TabIndex = 4;
    ((Control) this.rootPanel).Controls.Add((Control) this.mainContentPanel);
    ((Control) this.rootPanel).Controls.Add((Control) this.headerPanel);
    ((Control) this.rootPanel).Dock = DockStyle.Fill;
    this.rootPanel.FillColor = Color.FromArgb(18, 18, 20);
    ((Control) this.rootPanel).Location = new Point(0, 0);
    ((Control) this.rootPanel).Name = "rootPanel";
    ((Control) this.rootPanel).Size = new Size(460, 240 /*0xF0*/);
    ((Control) this.rootPanel).TabIndex = 0;
    ((Control) this.mainContentPanel).BackColor = Color.Transparent;
    ((Control) this.mainContentPanel).Controls.Add((Control) this.guna2PictureBox3);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.lblSettingsTitle);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.lblTargetEmulator);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.lblEncryption);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.lblActionTitle);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.label3);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.AdbCombo);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.AdbTextBox);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.shayanButton1);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.shayanButton2);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.shayanButton4);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.shayanButton5);
    ((Control) this.mainContentPanel).Controls.Add((Control) this.shayanButton3);
    ((Control) this.mainContentPanel).Dock = DockStyle.Fill;
    ((Control) this.mainContentPanel).Location = new Point(0, 35);
    ((Control) this.mainContentPanel).Name = "mainContentPanel";
    ((Control) this.mainContentPanel).Size = new Size(460, 205);
    ((Control) this.mainContentPanel).TabIndex = 3;
    ((PictureBox) this.guna2PictureBox3).Image = (Image) componentResourceManager.GetObject("guna2PictureBox3.Image");
    this.guna2PictureBox3.ImageRotate = 0.0f;
    ((Control) this.guna2PictureBox3).Location = new Point(15, 30);
    ((Control) this.guna2PictureBox3).Name = "guna2PictureBox3";
    ((Control) this.guna2PictureBox3).Size = new Size(75, 75);
    ((PictureBox) this.guna2PictureBox3).SizeMode = PictureBoxSizeMode.Zoom;
    ((PictureBox) this.guna2PictureBox3).TabIndex = 4;
    ((PictureBox) this.guna2PictureBox3).TabStop = false;
    this.lblSettingsTitle.AutoSize = true;
    this.lblSettingsTitle.Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold);
    this.lblSettingsTitle.ForeColor = Color.White;
    this.lblSettingsTitle.Location = new Point(20, 115);
    this.lblSettingsTitle.Name = "lblSettingsTitle";
    this.lblSettingsTitle.Size = new Size(62, 19);
    this.lblSettingsTitle.TabIndex = 0;
    this.lblSettingsTitle.Text = "Free Fire";
    this.lblTargetEmulator.AutoSize = true;
    this.lblTargetEmulator.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.lblTargetEmulator.ForeColor = Color.White;
    this.lblTargetEmulator.Location = new Point(15, 134);
    this.lblTargetEmulator.Name = "lblTargetEmulator";
    this.lblTargetEmulator.Size = new Size(82, 15);
    this.lblTargetEmulator.TabIndex = 1;
    this.lblTargetEmulator.Text = "Status: Offline";
    this.lblEncryption.AutoSize = true;
    this.lblEncryption.Font = new Font("Segoe UI", 8.5f);
    this.lblEncryption.ForeColor = Color.FromArgb(140, 140, 150);
    this.lblEncryption.Location = new Point(15, 150);
    this.lblEncryption.Name = "lblEncryption";
    this.lblEncryption.Size = new Size(67, 15);
    this.lblEncryption.TabIndex = 2;
    this.lblEncryption.Text = "Expira: Free";
    this.lblActionTitle.AutoSize = true;
    this.lblActionTitle.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.lblActionTitle.ForeColor = Color.FromArgb(0, 208 /*0xD0*/, 80 /*0x50*/);
    this.lblActionTitle.Location = new Point(15, 166);
    this.lblActionTitle.Name = "lblActionTitle";
    this.lblActionTitle.Size = new Size(77, 15);
    this.lblActionTitle.TabIndex = 6;
    this.lblActionTitle.Text = "100% Seguro";
    this.label3.AutoSize = true;
    this.label3.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.label3.ForeColor = Color.FromArgb(130, 130, 140);
    this.label3.Location = new Point(110, 12);
    this.label3.Name = "label3";
    this.label3.Size = new Size(119, 15);
    this.label3.TabIndex = 0;
    this.label3.Text = "Selecionar Emulador:";
    ((Control) this.AdbCombo).BackColor = Color.Transparent;
    this.AdbCombo.BorderColor = Color.FromArgb(40, 40, 45);
    this.AdbCombo.BorderRadius = 5;
    this.AdbCombo.DrawMode = DrawMode.OwnerDrawFixed;
    this.AdbCombo.DropDownStyle = ComboBoxStyle.DropDownList;
    this.AdbCombo.FillColor = Color.FromArgb(26, 26, 30);
    this.AdbCombo.FocusedColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.AdbCombo.FocusedState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    ((Control) this.AdbCombo).Font = new Font("Segoe UI Semibold", 8.5f);
    ((Control) this.AdbCombo).ForeColor = Color.White;
    ((ComboBox) this.AdbCombo).ItemHeight = 22;
    ((Control) this.AdbCombo).Location = new Point(110, 30);
    ((Control) this.AdbCombo).Name = "AdbCombo";
    ((Control) this.AdbCombo).Size = new Size(180, 28);
    ((Control) this.AdbCombo).TabIndex = 1;
    ((ComboBox) this.AdbCombo).SelectedIndexChanged += new EventHandler(this.AdbCombo_SelectedIndexChanged);
    this.AdbTextBox.BorderColor = Color.FromArgb(40, 40, 45);
    this.AdbTextBox.BorderRadius = 5;
    ((Control) this.AdbTextBox).Cursor = Cursors.IBeam;
    this.AdbTextBox.DefaultText = "5555";
    this.AdbTextBox.FillColor = Color.FromArgb(26, 26, 30);
    this.AdbTextBox.FocusedState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    ((Control) this.AdbTextBox).Font = new Font("Segoe UI Semibold", 8.5f);
    ((Control) this.AdbTextBox).ForeColor = Color.White;
    ((Control) this.AdbTextBox).Location = new Point(295, 30);
    ((Control) this.AdbTextBox).Name = "AdbTextBox";
    this.AdbTextBox.PlaceholderText = "";
    this.AdbTextBox.SelectedText = "";
    ((Control) this.AdbTextBox).Size = new Size(150, 28);
    ((Control) this.AdbTextBox).TabIndex = 2;
    this.AdbTextBox.TextAlign = HorizontalAlignment.Center;
    this.shayanButton1.BorderRadius = 6;
    ((Control) this.shayanButton1).Cursor = Cursors.Hand;
    this.shayanButton1.FillColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton1.FillColor2 = Color.FromArgb(85, 0, 180);
    ((Control) this.shayanButton1).Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold);
    ((Control) this.shayanButton1).ForeColor = Color.White;
    ((ButtonState) this.shayanButton1.HoverState).FillColor = Color.FromArgb(140, 20, (int) byte.MaxValue);
    ((Control) this.shayanButton1).Location = new Point(110, 68);
    ((Control) this.shayanButton1).Name = "shayanButton1";
    ((Control) this.shayanButton1).Size = new Size(160 /*0xA0*/, 36);
    ((Control) this.shayanButton1).TabIndex = 4;
    ((Control) this.shayanButton1).Text = "Conectar";
    ((Control) this.shayanButton1).Click += new EventHandler(this.shayanButton1_Click);
    this.shayanButton2.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton2.BorderRadius = 6;
    this.shayanButton2.BorderThickness = 1;
    ((Control) this.shayanButton2).Cursor = Cursors.Hand;
    this.shayanButton2.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.shayanButton2).Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold);
    ((Control) this.shayanButton2).ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton2.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton2.HoverState.ForeColor = Color.White;
    ((Control) this.shayanButton2).Location = new Point(280, 68);
    ((Control) this.shayanButton2).Name = "shayanButton2";
    ((Control) this.shayanButton2).Size = new Size(165, 36);
    ((Control) this.shayanButton2).TabIndex = 5;
    ((Control) this.shayanButton2).Text = "Desconectar";
    ((Control) this.shayanButton2).Click += new EventHandler(this.shayanButton2_Click);
    this.shayanButton4.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton4.BorderRadius = 6;
    this.shayanButton4.BorderThickness = 1;
    ((Control) this.shayanButton4).Cursor = Cursors.Hand;
    this.shayanButton4.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.shayanButton4).Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold);
    ((Control) this.shayanButton4).ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton4.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton4.HoverState.ForeColor = Color.White;
    ((Control) this.shayanButton4).Location = new Point(110, 112 /*0x70*/);
    ((Control) this.shayanButton4).Name = "shayanButton4";
    ((Control) this.shayanButton4).Size = new Size(335, 32 /*0x20*/);
    ((Control) this.shayanButton4).TabIndex = 6;
    ((Control) this.shayanButton4).Text = "Autorizar Emulador / Abrir ou Fechar";
    ((Control) this.shayanButton4).Click += new EventHandler(this.shayanButton4_Click);
    this.shayanButton5.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton5.BorderRadius = 6;
    this.shayanButton5.BorderThickness = 1;
    ((Control) this.shayanButton5).Cursor = Cursors.Hand;
    this.shayanButton5.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.shayanButton5).Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    ((Control) this.shayanButton5).ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton5.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton5.HoverState.ForeColor = Color.White;
    ((Control) this.shayanButton5).Location = new Point(110, 152);
    ((Control) this.shayanButton5).Name = "shayanButton5";
    ((Control) this.shayanButton5).Size = new Size(160 /*0xA0*/, 32 /*0x20*/);
    ((Control) this.shayanButton5).TabIndex = 7;
    ((Control) this.shayanButton5).Text = "Instalar Certificado";
    ((Control) this.shayanButton5).Click += new EventHandler(this.shayanButton5_Click);
    this.shayanButton3.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton3.BorderRadius = 6;
    this.shayanButton3.BorderThickness = 1;
    ((Control) this.shayanButton3).Cursor = Cursors.Hand;
    this.shayanButton3.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.shayanButton3).Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    ((Control) this.shayanButton3).ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton3.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton3.HoverState.ForeColor = Color.White;
    ((Control) this.shayanButton3).Location = new Point(280, 152);
    ((Control) this.shayanButton3).Name = "shayanButton3";
    ((Control) this.shayanButton3).Size = new Size(165, 32 /*0x20*/);
    ((Control) this.shayanButton3).TabIndex = 8;
    ((Control) this.shayanButton3).Text = "Remover Certificado";
    ((Control) this.shayanButton3).Click += new EventHandler(this.shayanButton3_Click);
    this.guna2DragControl2.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl2.TargetControl = (Control) this.rootPanel;
    this.guna2DragControl2.UseTransparentDrag = true;
    this.guna2DragControl3.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl3.TargetControl = (Control) this.mainContentPanel;
    this.guna2DragControl3.UseTransparentDrag = true;
    this.guna2DragControl4.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl4.TargetControl = (Control) this.appTitleLabel;
    this.guna2DragControl4.UseTransparentDrag = true;
    this.guna2DragControl5.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl5.TargetControl = (Control) this.guna2PictureBox3;
    this.guna2DragControl5.UseTransparentDrag = true;
    this.guna2DragControl6.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl6.TargetControl = (Control) this.lblSettingsTitle;
    this.guna2DragControl6.UseTransparentDrag = true;
    this.guna2DragControl7.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl7.TargetControl = (Control) this.lblTargetEmulator;
    this.guna2DragControl7.UseTransparentDrag = true;
    this.guna2DragControl8.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl8.TargetControl = (Control) this.lblEncryption;
    this.guna2DragControl8.UseTransparentDrag = true;
    this.guna2DragControl9.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl9.TargetControl = (Control) this.lblActionTitle;
    this.guna2DragControl9.UseTransparentDrag = true;
    this.AutoScaleMode = AutoScaleMode.None;
    this.BackColor = Color.FromArgb(18, 18, 20);
    this.ClientSize = new Size(460, 240 /*0xF0*/);
    this.Controls.Add((Control) this.rootPanel);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Name = nameof (Form1);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "ALECRIN BYPASS GRÁTIS";
    this.Load += new EventHandler(this.Form1_Load);
    ((Control) this.headerPanel).ResumeLayout(false);
    ((Control) this.headerPanel).PerformLayout();
    ((Control) this.rootPanel).ResumeLayout(false);
    ((Control) this.mainContentPanel).ResumeLayout(false);
    ((Control) this.mainContentPanel).PerformLayout();
    ((ISupportInitialize) this.guna2PictureBox3).EndInit();
    this.ResumeLayout(false);
  }
}
