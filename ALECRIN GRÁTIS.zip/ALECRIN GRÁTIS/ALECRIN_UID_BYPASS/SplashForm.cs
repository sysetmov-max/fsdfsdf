﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.SplashForm
// Assembly: ALECRIN BYPASS GRÁTIS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E16EF7F5-DEBB-47C9-BB97-DCEC9FCE9F7B
// Assembly location: C:\Users\Systemov\Desktop\ALECRIN BYPASS GRÁTIS.exe

using Guna.UI2.WinForms;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace ALECRIN_UID_BYPASS;

public class SplashForm : Form
{
  private string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "mcn");
  private string dllPath;
  private string dllUrl = "https://raw.githubusercontent.com/mmijan330/FOR-IND-ALL/refs/heads/main/UIDBypassDll.dll";
  private float spinnerAngle;
  private System.Windows.Forms.Timer spinnerTimer;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2ProgressBar guna2ProgressBar1;
  private Label lblTitle;
  private Label lblStatus;
  private Guna2PictureBox guna2PictureBox1;
  private Panel panelLoader;

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr LoadLibrary(string lpFileName);

  public SplashForm()
  {
    this.InitializeComponent();
    this.dllPath = Path.Combine(this.folderPath, "alecrinUIDBypassDll.dll");
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.spinnerTimer = new System.Windows.Forms.Timer();
    this.spinnerTimer.Interval = 15;
    this.spinnerTimer.Tick += (EventHandler) ((s, e) =>
    {
      this.spinnerAngle = (float) (((double) this.spinnerAngle + 5.0) % 360.0);
      this.panelLoader.Invalidate();
    });
    this.spinnerTimer.Start();
  }

  private async void SplashForm_Load(object sender, EventArgs e)
  {
    SplashForm splashForm = this;
    try
    {
      try
      {
        using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ALECRIN_UID_BYPASS.logo.png"))
        {
          if (manifestResourceStream != null)
            ((PictureBox) splashForm.guna2PictureBox1).Image = Image.FromStream(manifestResourceStream);
        }
      }
      catch
      {
      }
      splashForm.lblStatus.Text = "Iniciando verificação...";
      splashForm.guna2ProgressBar1.Value = 15;
      await Task.Delay(250);
      splashForm.lblStatus.Text = "Verificando arquivos locais...";
      splashForm.guna2ProgressBar1.Value = 35;
      await Task.Delay(250);
      if (!Directory.Exists(splashForm.folderPath))
        Directory.CreateDirectory(splashForm.folderPath);
      if (System.IO.File.Exists(splashForm.dllPath))
      {
        try
        {
          System.IO.File.Delete(splashForm.dllPath);
        }
        catch
        {
        }
      }
      splashForm.lblStatus.Text = "Baixando atualizações...";
      splashForm.guna2ProgressBar1.Value = 60;
      await splashForm.DownloadFileAsync(splashForm.dllUrl, splashForm.dllPath);
      splashForm.guna2ProgressBar1.Value = 85;
      splashForm.lblStatus.Text = "Verificando integridade da DLL...";
      await Task.Delay(200);
      if (SplashForm.LoadLibrary(splashForm.dllPath) == IntPtr.Zero)
      {
        int lastWin32Error = Marshal.GetLastWin32Error();
        try
        {
          System.IO.File.Delete(splashForm.dllPath);
        }
        catch
        {
        }
        if (lastWin32Error == 225)
        {
          int num1 = (int) MessageBox.Show($"O Windows Defender ou seu Antivírus bloqueou a DLL do bypass (Erro 225)!\n\nPara resolver:\n1. Adicione uma exclusão no seu Antivírus para a pasta:\n   {splashForm.folderPath}\n2. Abra o aplicativo novamente para baixar o arquivo correto.", "Antivírus Bloqueou o Bypass", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        else
        {
          int num2 = (int) MessageBox.Show($"Falha ao carregar DLL! Código: {lastWin32Error.ToString()}\nReinicie para tentar novamente.", "Erro");
        }
        Application.Exit();
      }
      else
      {
        splashForm.guna2ProgressBar1.Value = 100;
        splashForm.lblStatus.Text = "Pronto!";
        splashForm.spinnerTimer.Stop();
        splashForm.panelLoader.Visible = false;
        await Task.Delay(150);
        splashForm.DialogResult = DialogResult.OK;
        splashForm.Close();
      }
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show("Erro ao atualizar:\n" + ex.Message, "Erro");
      Application.Exit();
    }
  }

  private void panelLoader_Paint(object sender, PaintEventArgs e)
  {
    Graphics graphics = e.Graphics;
    graphics.SmoothingMode = SmoothingMode.AntiAlias;
    Rectangle rect1 = new Rectangle(2, 2, this.panelLoader.Width - 5, this.panelLoader.Height - 5);
    using (Pen pen = new Pen(Color.FromArgb(168, 85, 247), 3f))
    {
      pen.StartCap = LineCap.Round;
      pen.EndCap = LineCap.Round;
      graphics.DrawArc(pen, rect1, this.spinnerAngle, 140f);
    }
    Rectangle rect2 = new Rectangle(8, 8, this.panelLoader.Width - 17, this.panelLoader.Height - 17);
    using (Pen pen = new Pen(Color.FromArgb(192 /*0xC0*/, 0, (int) byte.MaxValue), 2f))
    {
      pen.StartCap = LineCap.Round;
      pen.EndCap = LineCap.Round;
      graphics.DrawArc(pen, rect2, (float) (-(double) this.spinnerAngle * 1.5), 100f);
    }
  }

  private async Task DownloadFileAsync(string url, string destPath)
  {
    string requestUriString = url;
    for (int i = 0; i < 10; ++i)
    {
      HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(requestUriString);
      httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)";
      httpWebRequest.AllowAutoRedirect = false;
      httpWebRequest.Timeout = 20000;
      using (HttpWebResponse resp = (HttpWebResponse) await httpWebRequest.GetResponseAsync())
      {
        if (resp.StatusCode >= HttpStatusCode.MultipleChoices && resp.StatusCode < HttpStatusCode.BadRequest)
        {
          requestUriString = resp.Headers["Location"];
        }
        else
        {
          using (Stream stream = resp.GetResponseStream())
          {
            using (FileStream fs = System.IO.File.Create(destPath))
              await stream.CopyToAsync((Stream) fs);
          }
        }
      }
    }
    throw new Exception("Muitos redirecionamentos ao baixar atualizações.");
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2ProgressBar1 = new Guna2ProgressBar();
    this.lblTitle = new Label();
    this.lblStatus = new Label();
    this.guna2PictureBox1 = new Guna2PictureBox();
    this.panelLoader = new Panel();
    ((ISupportInitialize) this.guna2PictureBox1).BeginInit();
    this.SuspendLayout();
    this.guna2BorderlessForm1.BorderRadius = 10;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.ShadowColor = Color.FromArgb(40, 40, 45);
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2ProgressBar1.BorderRadius = 3;
    this.guna2ProgressBar1.FillColor = Color.FromArgb(26, 26, 30);
    ((Control) this.guna2ProgressBar1).Location = new Point(30, 135);
    ((Control) this.guna2ProgressBar1).Name = "guna2ProgressBar1";
    this.guna2ProgressBar1.ProgressColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.guna2ProgressBar1.ProgressColor2 = Color.FromArgb(85, 0, 180);
    ((Control) this.guna2ProgressBar1).Size = new Size(300, 6);
    ((Control) this.guna2ProgressBar1).TabIndex = 0;
    ((Control) this.guna2ProgressBar1).Text = "guna2ProgressBar1";
    this.guna2ProgressBar1.TextRenderingHint = TextRenderingHint.SystemDefault;
    this.lblTitle.AutoSize = true;
    this.lblTitle.Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold);
    this.lblTitle.ForeColor = Color.White;
    this.lblTitle.Location = new Point(130, 35);
    this.lblTitle.Name = "lblTitle";
    this.lblTitle.Size = new Size(183, 21);
    this.lblTitle.TabIndex = 1;
    this.lblTitle.Text = "ALECRIN BYPASS FREE";
    this.lblStatus.AutoSize = true;
    this.lblStatus.Font = new Font("Segoe UI", 9f);
    this.lblStatus.ForeColor = Color.FromArgb(140, 140, 150);
    this.lblStatus.Location = new Point(27, 112 /*0x70*/);
    this.lblStatus.Name = "lblStatus";
    this.lblStatus.Size = new Size(130, 15);
    this.lblStatus.TabIndex = 2;
    this.lblStatus.Text = "Verificando atualizações...";
    this.guna2PictureBox1.ImageRotate = 0.0f;
    ((Control) this.guna2PictureBox1).Location = new Point(30, 20);
    ((Control) this.guna2PictureBox1).Name = "guna2PictureBox1";
    ((Control) this.guna2PictureBox1).Size = new Size(80 /*0x50*/, 80 /*0x50*/);
    ((PictureBox) this.guna2PictureBox1).SizeMode = PictureBoxSizeMode.Zoom;
    ((PictureBox) this.guna2PictureBox1).TabIndex = 3;
    ((PictureBox) this.guna2PictureBox1).TabStop = false;
    this.panelLoader.Location = new Point(201, 63 /*0x3F*/);
    this.panelLoader.Name = "panelLoader";
    this.panelLoader.Size = new Size(40, 40);
    this.panelLoader.TabIndex = 5;
    this.panelLoader.Paint += new PaintEventHandler(this.panelLoader_Paint);
    this.AutoScaleMode = AutoScaleMode.None;
    this.BackColor = Color.FromArgb(18, 18, 20);
    this.ClientSize = new Size(360, 180);
    this.Controls.Add((Control) this.panelLoader);
    this.Controls.Add((Control) this.guna2PictureBox1);
    this.Controls.Add((Control) this.lblStatus);
    this.Controls.Add((Control) this.lblTitle);
    this.Controls.Add((Control) this.guna2ProgressBar1);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Name = nameof (SplashForm);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "Atualização - Alecrin Bypass";
    this.Load += new EventHandler(this.SplashForm_Load);
    ((ISupportInitialize) this.guna2PictureBox1).EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
