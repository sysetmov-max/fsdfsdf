﻿// Decompiled with JetBrains decompiler
// Type: bp3S90 Wj;$*SQ%Bl{s{=&ig$
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using ISP.Engine.Accounts;
using ISP.Tasks.Settings;
using JCS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
internal sealed class bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024 : 
  Form
{
  private IContainer \u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮;
  private TabControl \u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮;
  private TabPage \u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮;
  private TabPage \u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮;
  private TabPage \u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮;
  private TabPage \u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮;
  private TabPage \u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮;
  private TabPage \u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮;
  private MenuStrip \u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮;
  private DateTimePicker \u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮;
  private ToggleSwitch \u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮;
  private Button \u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮;
  private ComboBox \u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮;
  private Label \u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮;
  private Button \u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮;
  private Button \u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮;
  private Button \u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮;
  private TabPage \u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮;
  private PictureBox \u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮;
  private TextBox \u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮;
  private RadioButton \u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮;
  private RadioButton \u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮;
  private RadioButton \u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮;
  private Label \u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮;
  private Label \u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮;
  private NumericUpDown \u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮;
  private Label \u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮;
  private ToggleSwitch \u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮;
  private NumericUpDown \u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮;
  private Label \u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮;
  private ToggleSwitch \u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮;
  private NumericUpDown \u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮;
  private NumericUpDown \u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮;
  private NumericUpDown \u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮;
  private Label \u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮;
  private ToggleSwitch \u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮;
  private Label \u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮;
  private ToggleSwitch \u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮;
  private Label \u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮;
  private ToggleSwitch \u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮;
  private Label \u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮;
  private ToggleSwitch \u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮;
  private NumericUpDown \u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮;
  private Button \u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮;
  private ToolStripMenuItem \u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮;
  private DataGridView \u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮;
  private DataGridView \u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮;
  private DataGridView \u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮;
  private DataGridView \u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮;
  private DataGridView \u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮;
  private DataGridView \u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮;
  private Label \u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮;
  private TextBox \u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮;
  private ToolStripMenuItem \u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮;
  private Label \u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮;
  private RichTextBox \u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮;
  private Button \u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮;
  private Label \u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮;
  private Label \u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮;
  private Label \u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮;
  private Label \u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮;
  private Label \u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮;
  private DataGridViewTextBoxColumn \u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮;
  private DataGridViewComboBoxColumn \u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮;
  private DataGridViewTextBoxColumn \u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮;
  private DataGridViewComboBoxColumn \u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮;
  private DataGridViewTextBoxColumn \u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮;
  private DataGridViewComboBoxColumn \u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮;
  private DataGridViewTextBoxColumn \u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮;
  private DataGridViewComboBoxColumn \u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮;
  private System.Windows.Forms.Timer \u200B⁯‫‬‏⁭‍‭‍‬‮⁭⁮‫‭‎‌‍⁫‏⁯‍⁪‍‫⁫⁪‏‫‮‏⁬⁪⁫⁬‪‍‍‌‫‮;
  private Button \u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮;
  private Button \u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮;
  private Button \u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮;
  private Button \u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮;
  private Button \u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮;
  private Button \u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮;
  private Button \u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮;
  private Button \u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮;
  private Button \u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮;
  private DataGridViewTextBoxColumn \u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮;
  private DataGridViewComboBoxColumn \u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮;
  private DataGridViewTextBoxColumn \u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮;
  private DataGridViewComboBoxColumn \u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮;
  private DataGridViewTextBoxColumn \u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮;
  private DataGridViewTextBoxColumn \u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮;
  private DataGridViewTextBoxColumn \u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮;
  private DataGridViewTextBoxColumn \u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮;
  private NotifyIcon \u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮;
  private Label \u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮;
  private ComboBox \u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮;
  private Label \u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮;
  private ComboBox \u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮;
  private Label \u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮;
  private ComboBox \u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮;
  private System.Windows.Forms.Timer \u202B‫⁬⁪⁭‎‫‮‫⁭⁮​⁫⁪‎‪⁫⁯‫⁭⁮‍⁪‬‍‮‭​‌‏‭⁫​⁪‫⁯‬‪⁫⁮‮;
  private ComboBox \u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮;
  private Label \u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮;
  private ComboBox \u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮;
  private Label \u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮;
  private Label \u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮;
  private Label \u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮;
  private Label \u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮;
  private Label \u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮;
  private Label \u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮;
  private Label \u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮;
  private Label \u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮;
  private ToolStripMenuItem \u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮;
  private ToolStripMenuItem \u206E‮⁪⁫⁪​⁫⁬⁮‎‫‫‭⁪‍⁬⁬⁮⁯⁮⁭⁪⁪‏‌‎⁯⁯‍‫‪⁪‪⁮⁪⁭⁮⁭‪⁯‮;
  private DataGridViewTextBoxColumn \u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮;
  private DataGridViewComboBoxColumn \u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮;
  private DataGridViewTextBoxColumn \u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮;
  private DataGridViewComboBoxColumn \u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮;
  private DataGridViewCheckBoxColumn \u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮;
  private ToolStripMenuItem \u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮;
  private DataGridViewTextBoxColumn \u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮;
  private DataGridViewTextBoxColumn \u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮;
  private DataGridViewTextBoxColumn \u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮;
  private DataGridViewTextBoxColumn \u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮;
  private DataGridViewCheckBoxColumn \u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮;
  private ContextMenuStrip \u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮;
  private ToolStripMenuItem \u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮;
  private ToolStripMenuItem \u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮;
  private TabPage \u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮;
  private LinkLabel \u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮;
  private Label \u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮;
  private TextBox \u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮;
  private Button \u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮;
  private NumericUpDown \u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮;
  private Label \u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮;
  private ComboBox \u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮;
  private Label \u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮;
  private ComboBox \u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮;
  private Label \u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮;
  private Label \u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮;
  private TextBox \u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮;
  private RichTextBox \u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮;
  private Label \u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮;
  private string \u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮;
  private \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022 \u202C‌⁮​⁮⁭‎⁫⁯‭‪‏⁮‍⁭‎⁪​‏⁫‫⁪⁪​‎​‭‫⁯‬​⁫⁪‏⁭⁯‮⁪⁯‫‮;
  private \u202E‏⁮⁪‏⁫‬⁪‏‌‎‍‍‎⁫⁮⁫‫‫⁫‏⁭‭⁫‪‏‪⁫‮⁪‫‭⁮‌‏‎⁮‫⁭‬‮ \u206C‫‮‪‎⁯​⁬‎⁯‏⁬‏⁫⁯‌‍‫‮‮‫‮‬‪‮⁪‬⁬‍​⁮‬⁯‌‪‏‎‌‫‫‮;
  private n\u002Cf1\u005BE\u002F\u005Ez\u0026qh5\u003FUff\u0023\u003DX\u0024\u007B\u003C7\u0024 \u200D⁬⁯‌‪⁬‬⁫⁮‍​⁭⁭⁭⁯‎‮‎⁬‌‬‪‭⁬‌‌‏​⁭⁬‌⁮⁬‮⁮⁬‍​‌⁯‮;
  private \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C \u206A‭‫‪‫​‎‏⁭‬‍​‮‭⁯⁮‏⁪‭⁫‮‫​‌‏⁫⁫‪⁭⁯⁯‭⁯‏‌⁯‎⁫‎⁬‮;
  private \u202B‭‍⁭‍‬‌‪‬⁪⁭⁯‍‫‍‫‏‎⁫‬‍‌⁬⁮⁬‪‌‫‮⁭⁯‪⁯‎⁯​‎⁬⁮⁭‮ \u200B‪‪⁬‏⁭‍‭‫‬⁮⁭⁯‎‌⁮⁭‮‫​⁬‎⁭‫‍⁪‭‭‫‏‏‮‌⁬⁬‏‪⁯‌‪‮;
  private Z_\u003BAJ4d\u007BtrZ\u0029\u002C\u0026U\u003Fh9qF4n0h\u0021 \u206C‫‬‎‮⁫⁫⁫​⁬‬⁮‫‎‬‏‎⁫⁯‫⁬⁭⁮‏⁪​‪‎‭‮⁭⁪⁮‪‬‏⁪⁭‎‏‮;
  private \u007BZ\u003Be\u005E_\u005E\u0023 \u206F‌‏‏⁮​⁯‍‍‍‫‫‮‪‪‫​⁪‎‎​‌⁮‬⁫⁯⁮‎⁫‬⁪‫‬‭⁮‎‮‫​‎‮;
  private bool \u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮;
  private static NotifyIcon \u202B‭⁮‎⁯‌‬‪⁪‏⁬⁫‌‭‮‍⁮⁪⁫‎‍‌‭‏⁪‫​‍‬‬‎⁯‏‏‎‭⁮⁬⁫⁯‮;
  private bool \u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮;
  private int \u206F⁬‮⁮‎‫⁭‍⁭⁮​⁪‮‏‮⁮‍⁬‎⁮‪‮‏‏‮‏‫⁫⁫⁫‭‮‎‏‬⁭‭‍‌⁭‮;

  private void \u202D‬⁬⁯⁮⁪​⁪‮‭‎⁯‬‫⁭‮⁭‮​‎⁭‪⁮‏⁯‌‪⁭⁭‭⁭‪‍‌‫⁭‬‏‮‪‮()
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁮⁪‮⁮⁫‬‫‪‭‌‪‭⁪‏‎‪‬⁬‭⁮⁮⁭‍‌‫⁫‪⁪⁮‪‌⁯⁫‭⁪‬‏‮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮));
label_1:
    int num1 = 1735116200;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1608318302)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁮⁪‮⁮⁫‬‫‪‭‌‪‭⁪‏‎‪‬⁬‭⁮⁮⁭‍‌‫⁫‪⁪⁮‪‌⁯⁫‭⁪‬‏‮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮));
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮), new object[5]
          {
            (object) "",
            (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3697237743U),
            (object) "",
            (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3697237743U),
            (object) false
          });
          num1 = (int) num2 * 1503779425 ^ -175349958;
          continue;
        default:
          goto label_4;
      }
    }
label_4:
    using (List<ChatsTarget>.Enumerator enumerator = AccountsManager.ActiveAccount.ChatsTaskSettings.Targets.GetEnumerator())
    {
label_9:
      int num3 = enumerator.MoveNext() ? 1087687248 : (num3 = 1034732403);
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 1608318302)) % 4U)
        {
          case 0:
            num3 = 1087687248;
            continue;
          case 2:
            ChatsTarget current = enumerator.Current;
            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), new object[5]
            {
              (object) current.Link,
              (object) current.TitleMode,
              (object) current.Title,
              (object) current.AvatarMode,
              (object) current.FloodWithAvatar
            });
            num3 = 915888733;
            continue;
          case 3:
            goto label_9;
          default:
            goto label_11;
        }
      }
    }
label_11:
    this.\u200C‌‬‍‭‏‫‮‏⁭⁭‬⁫‪⁫⁮‭⁯‎‌‪‮‬⁫⁬⁯⁬‪‬‍⁮⁫‪⁪‎‌‫‍‏‌‮((object) null, (EventArgs) null);
  }

  private void \u200C‌‬‍‭‏‫‮‏⁭⁭‬⁫‪⁫⁮‭⁯‎‌‪‮‬⁫⁬⁯⁬‪‬‍⁮⁫‪⁪‎‌‫‍‏‌‮(object _param1, EventArgs _param2)
  {
    int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), DataGridViewElementStates.Selected);
    if (num1 != -1)
      goto label_8;
label_1:
    int num2 = 715893942;
label_2:
    int num3;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num2 ^ 1291071339)) % 7U)
      {
        case 0:
          goto label_8;
        case 1:
          goto label_3;
        case 2:
          goto label_1;
        case 3:
          int num5;
          num2 = num5 = num3 < bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C⁯‍‬⁪‏‌‮⁯​‮‭‭⁮⁯‪‭‍‬‌‫‬⁮‏⁪⁬‍⁬‎⁮​⁯⁫‎‌⁫‭‭‫‎‮((BaseCollection) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮)) ? 816244585 : (num5 = 1883709893);
          continue;
        case 4:
          goto label_7;
        case 5:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D​‬‍‍‎‎‬‫‏⁪‮⁪‪‮⁫​⁯​‌⁬‌⁭⁭‬⁪⁫‬⁬‎⁮‎‭‏‫‬⁫⁫⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, num3, 0), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, num3, num1)));
          num2 = 1585824508;
          continue;
        case 6:
          ++num3;
          num2 = (int) num4 * -1660592849 ^ 605769;
          continue;
        default:
          goto label_9;
      }
    }
label_3:
    return;
label_7:
    return;
label_9:
    return;
label_8:
    num3 = 0;
    num2 = 86263792;
    goto label_2;
  }

  private void \u200C‫⁫⁮‬‏‮‎⁯‏‪‬⁫‪‮‌⁬⁭⁪⁭‏‬‪‎‮⁪⁪⁪‫‬⁭‭‭⁮‎⁮‬⁪⁪⁪‮(object _param1_1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), new object[5]
    {
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 0, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 1, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 2, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 3, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 4, 0))
    });
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.ChatsTaskSettings.AddNewTarget(new ChatsTarget()
    {
      Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 0, 0)) ?? (object) nameof ()),
      TitleMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 1, 0))),
      Title = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 2, 0)) ?? (object) nameof ()),
      AvatarMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 3, 0))),
      FloodWithAvatar = (bool) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 4, 0))
    })));
label_1:
    int num1 = 303654511;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1176578822)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
          num1 = 1697399095;
          continue;
        case 2:
          goto label_3;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private void \u206C⁭⁪‏‪⁬⁫⁪‬​‍‮‪‬‍‏​‌‮‬‫‎​‪‎⁯‎⁭⁫⁬‎‏‮⁫⁮‎⁬‏‍⁬‮(object _param1_1, EventArgs _param2)
  {
    int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), DataGridViewElementStates.Selected);
    if (num1 != -1)
      goto label_5;
label_1:
    int num2 = 548962776;
label_2:
    while (true)
    {
      uint num3;
      switch ((num3 = (uint) (num2 ^ 2079482425)) % 6U)
      {
        case 0:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.ChatsTaskSettings.RemoveTarget(new ChatsTarget()
          {
            Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 0, 0)) ?? (object) nameof ()),
            TitleMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 1, 0))),
            Title = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 2, 0)) ?? (object) nameof ()),
            AvatarMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 3, 0))),
            FloodWithAvatar = (bool) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 4, 0))
          })));
          num2 = (int) num3 * 1617861291 ^ 907705435;
          continue;
        case 1:
          goto label_4;
        case 2:
          goto label_5;
        case 3:
          goto label_1;
        case 4:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
          num2 = 2064909516;
          continue;
        case 5:
          goto label_3;
        default:
          goto label_8;
      }
    }
label_4:
    return;
label_3:
    return;
label_8:
    return;
label_5:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁯​⁫‬‪‪‌⁪⁭​‭‎‭‌‎‫‮‌‮⁪⁮⁮‏‭‫‭‬‏‫‍‪‎⁭‎​‬⁪‍‪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E​‌​‪​⁯⁬‪‎‌‪‌‭‍⁪‭‎‏‍⁭‏⁯‎⁮‫⁫‭⁬‬⁭‪⁫⁭‫‪‎‏⁮‭‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), num1));
    num2 = 115025205;
    goto label_2;
  }

  private void \u202E⁪​⁫​⁪​⁬‭‮⁬‬⁬‎⁬‬‬‪⁬‌‮⁫⁪‏⁭⁫​⁫⁮‎⁪‭⁯‫‮⁯⁯‪‭⁪‮(object _param1_1, EventArgs _param2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‍⁯‏‭⁪​⁭​‮‫‎‭⁫‌‮⁯‮‌‍⁭‭⁭‮‫‏‬‏‮​⁪‌⁯⁫⁯⁮‫‪⁫⁭‮ obj = new bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‍⁯‏‭⁪​⁭​‮‫‎‭⁫‌‮⁯‮‌‍⁭‭⁭‮‫‏‬‏‮​⁪‌⁯⁫⁯⁮‫‪⁫⁭‮();
    int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮), DataGridViewElementStates.Selected);
    if (num1 != -1)
      goto label_8;
label_1:
    int num2 = -1567753577;
label_2:
    int num3;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num2 ^ -332068062)) % 10U)
      {
        case 0:
          goto label_1;
        case 1:
          num3 = 0;
          num2 = (int) num4 * -472058273 ^ -1317885735;
          continue;
        case 2:
          // ISSUE: reference to a compiler-generated method
          AccountsManager.ApplyToCurrent(new Action<Account>(obj.\u202B⁬‭⁬⁫‭‪‮‍⁭‎‏‏‌‪‪⁭‎⁯​​‪⁮‏⁫‪⁭‭‮⁪⁭‌‎​‫‪⁭‭⁬‪‮));
          num2 = (int) num4 * -1801632453 ^ 1416773423;
          continue;
        case 3:
          goto label_8;
        case 4:
          int num5;
          num2 = num5 = num3 < bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C⁯‍‬⁪‏‌‮⁯​‮‭‭⁮⁯‪‭‍‬‌‫‬⁮‏⁪⁬‍⁬‎⁮​⁯⁫‎‌⁫‭‭‫‎‮((BaseCollection) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮)) ? -911294637 : (num5 = -1882915746);
          continue;
        case 5:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D​‬‍‍‎‎‬‫‏⁪‮⁪‪‮⁫​⁯​‌⁬‌⁭⁭‬⁪⁫‬⁬‎⁮‎‭‏‫‬⁫⁫⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, num3, num1), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, num3, 0)));
          num2 = -328231194;
          continue;
        case 6:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B‏⁯⁯‏​‮‪⁮⁮⁭⁪⁮⁫⁪‌‎‫‬⁬‍​‎‏‪‪‎‏⁭‫⁮‎⁮‌‫‎‍⁫‬⁭‮ = new ChatsTarget()
          {
            Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 0, 0)) ?? (object) nameof ()),
            TitleMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 1, 0))),
            Title = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 2, 0)) ?? (object) nameof ()),
            AvatarMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 3, 0))),
            FloodWithAvatar = (bool) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮, 4, 0))
          };
          num2 = -1997778864;
          continue;
        case 8:
          ++num3;
          num2 = (int) num4 * -1122314883 ^ -319371608;
          continue;
        case 9:
          goto label_3;
        default:
          goto label_11;
      }
    }
label_3:
    return;
label_11:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
    return;
label_8:
    // ISSUE: reference to a compiler-generated field
    obj.\u200C‍‬​‬‌⁫‭‌‫⁭‮​⁭​‭‪‭‎‫⁯⁯⁮⁭⁫‮‫‭‬‮⁬‎‍‏⁬‮‎‭⁫‮‮ = new ChatsTarget()
    {
      Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, 0, num1)) ?? (object) nameof ()),
      TitleMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, 1, num1))),
      Title = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, 2, num1)) ?? (object) nameof ()),
      AvatarMode = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, 3, num1))),
      FloodWithAvatar = (bool) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮, 4, 0))
    };
    num2 = -776500615;
    goto label_2;
  }

  virtual void Form.\u202D⁫⁫‍‭​⁪‌‫⁬‎⁮‭‌⁬‌‫‎‭‮‍‭⁫‬‭⁬‪⁪⁪‌⁮⁮‏‭⁯⁬⁮⁬‮‌‮(bool _param1)
  {
    if (!_param1)
      goto label_6;
label_1:
    int num1 = 1895562145;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 365939281)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‌⁭‏‭‫⁪⁮‮⁮‭⁬‮‌⁪​‌​‏‪‬‍⁬‬‍‏⁭⁪‍​‏‏‭‎‍​‎⁬‪‮((IDisposable) this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          num1 = (int) num2 * 1533447177 ^ -1907715337;
          continue;
        case 2:
          int num3 = this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮ == null ? 41310983 : (num3 = 2028447905);
          num1 = num3 ^ (int) num2 * -1185068317;
          continue;
        case 3:
          goto label_1;
        case 4:
          goto label_6;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_7:
    return;
label_6:
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(_param1));
    num1 = 87608537;
    goto label_2;
  }

  private void \u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮()
  {
    this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮ = (IContainer) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁯⁮⁬‬‮⁮‮​‬​‏⁪‎‏⁬‪⁮⁬⁪‮‍‫⁬​⁪‫⁬‏‭‌‭‮‏​‍⁭‎⁭⁬‮();
label_1:
    int num1 = 541673478;
    ComponentResourceManager componentResourceManager;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1012179715)) % 748U)
      {
        case 0:
          this.Controls.Add((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮);
          this.Controls.Add((Control) this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮);
          this.ForeColor = SystemColors.ControlText;
          num1 = (int) num2 * 1538004070 ^ -602114480;
          continue;
        case 1:
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.TabIndex = 27;
          num1 = (int) num2 * 1830550507 ^ 375010817;
          continue;
        case 2:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(89142910U);
          num1 = (int) num2 * -1276623544 ^ 1968884047;
          continue;
        case 3:
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.AutoSize = true;
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.BackColor = Color.Transparent;
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.Location = new Point(458, 3);
          num1 = (int) num2 * -1753198697 ^ -1238591194;
          continue;
        case 4:
          this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮.ReadOnly = true;
          num1 = (int) num2 * -1917613430 ^ 1949522619;
          continue;
        case 5:
          this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * 916495297 ^ 124064809;
          continue;
        case 6:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮);
          num1 = (int) num2 * -1861448064 ^ 78462709;
          continue;
        case 7:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -1547987752 ^ -954011660;
          continue;
        case 8:
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.Size = new Size(210, 26);
          num1 = (int) num2 * 688021655 ^ -1006222012;
          continue;
        case 9:
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2449017194U);
          num1 = (int) num2 * -1963689652 ^ 578313530;
          continue;
        case 10:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.Size = new Size(56, 13);
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.TabIndex = 38;
          num1 = (int) num2 * 2064589821 ^ -1743751532;
          continue;
        case 11:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.BackColor = Color.Transparent;
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.Location = new Point(215, 237);
          num1 = (int) num2 * 1466225272 ^ -1691123767;
          continue;
        case 12:
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‎‮‭‏‍‪⁬⁭⁮​⁫‮‮⁪⁯⁬‌​‫‏‏⁯⁪⁪‭‬‬‮‫‭​⁫‌⁯‎‍‬⁬‏‮();
          num1 = (int) num2 * 662608383 ^ -624446269;
          continue;
        case 13:
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3459576873U);
          num1 = (int) num2 * -2080857221 ^ 1034315918;
          continue;
        case 14:
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‎⁭‫‮⁮‌‌‫‫‮‎‫‫‬⁮‪‫‏‎‪‏‏‍‪⁯‎⁪​⁪⁯‎‫⁭‏‍‏⁭‏‮();
          num1 = (int) num2 * 1490875094 ^ 107608689;
          continue;
        case 15:
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.Location = new Point(7, 369);
          num1 = (int) num2 * 2126720812 ^ -1834374930;
          continue;
        case 16 /*0x10*/:
          this.Controls.Add((Control) this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮);
          num1 = (int) num2 * 779042330 ^ 2130280871;
          continue;
        case 17:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * 818111243 ^ -125810466;
          continue;
        case 18:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮);
          num1 = (int) num2 * -850930569 ^ 197361524;
          continue;
        case 19:
          ((ISupportInitialize) this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮).EndInit();
          num1 = (int) num2 * 190459151 ^ 1841830462;
          continue;
        case 20:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.Size = new Size(140, 13);
          num1 = (int) num2 * -467284237 ^ 1024145825;
          continue;
        case 21:
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.BackColor = Color.Transparent;
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.Location = new Point(330, 95);
          num1 = (int) num2 * -608988337 ^ -772674920;
          continue;
        case 22:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.TabIndex = 25;
          num1 = (int) num2 * -2035777976 ^ 1936100450;
          continue;
        case 23:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.TabIndex = 23;
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u202E​⁮‪‎‎‎⁫‭‪⁯⁭​⁭⁫‌‭‬‪⁬‌⁭⁯⁭‎‭‎‏​⁯‏⁪‪‏‏⁫⁫‎‎⁫‮);
          num1 = (int) num2 * -805853478 ^ -1313869206;
          continue;
        case 24:
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.SortMode = DataGridViewColumnSortMode.NotSortable;
          num1 = (int) num2 * -1462111269 ^ 1147827618;
          continue;
        case 25:
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮.Click += new EventHandler(this.\u202D‫⁫‭‎‫​‫‏⁪‌‪⁪⁪⁬⁯⁮⁪‌‎‪⁫⁯⁪‪⁫⁬⁫⁪⁯⁯⁯⁫‍​⁭⁬‌‪‭‮);
          num1 = (int) num2 * 573261409 ^ -1613076757;
          continue;
        case 26:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.TabIndex = 32 /*0x20*/;
          num1 = (int) num2 * -1664681850 ^ 1055334495;
          continue;
        case 27:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.Location = new Point(167, 143);
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(678695278U);
          num1 = (int) num2 * 354588601 ^ -1007270073;
          continue;
        case 28:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮);
          num1 = (int) num2 * -171943311 ^ -3407415;
          continue;
        case 29:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.OnFont = new Font(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4290614350U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.Size = new Size(45, 19);
          num1 = (int) num2 * 2127137087 ^ 1128352857;
          continue;
        case 30:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2416885284U);
          num1 = (int) num2 * 42282892 ^ -1601225484;
          continue;
        case 31 /*0x1F*/:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 1653480225 ^ -24185227;
          continue;
        case 32 /*0x20*/:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.AutoSize = true;
          num1 = (int) num2 * -1856727552 ^ -1365200684;
          continue;
        case 33:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.Click += new EventHandler(this.\u200D‮⁭‏⁪‍‬‭‭‍‏⁪‫⁬‎‏⁪⁭‮‏⁭‮⁪‭‭‫⁫⁪‏⁪⁪⁫‌⁭⁯⁭‌⁪‬‫‮);
          num1 = (int) num2 * 1296647181 ^ 1150266857;
          continue;
        case 34:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.AutoSize = true;
          num1 = (int) num2 * -1838480781 ^ 1059871152;
          continue;
        case 35:
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(915610125U);
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Size = new Size(120, 20);
          num1 = (int) num2 * 418818211 ^ -888654083;
          continue;
        case 36:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.TabIndex = 21;
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2961962095U);
          num1 = (int) num2 * 352557198 ^ -1885247859;
          continue;
        case 37:
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          num1 = (int) num2 * 111878285 ^ 765469784;
          continue;
        case 38:
          this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          num1 = (int) num2 * -1835363835 ^ 562586673;
          continue;
        case 39:
          this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‏⁪‬⁭‪‏⁫‭‬⁮‪‪‫‌⁮‌⁭‍‮‍‎​⁫‫⁬​⁮‫‭‍⁪‏‮‏⁭‎‭‭‮();
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * 191584416 ^ 1673968891;
          continue;
        case 40:
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.Resizable = DataGridViewTriState.True;
          num1 = (int) num2 * 1418274086 ^ -569100906;
          continue;
        case 41:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.TabIndex = 24;
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2961592997U);
          num1 = (int) num2 * -2021935142 ^ 175537285;
          continue;
        case 42:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.TabIndex = 22;
          num1 = (int) num2 * 999140431 ^ -1480217880;
          continue;
        case 43:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.TabIndex = 27;
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u206B⁬‎⁫⁭‍‮‬⁬​‎⁫‬‎‫⁯⁪​⁮⁫⁭⁬‏​‫⁭‬⁫‏⁭‎⁯‏‬‪‫⁭‪⁭‎‮);
          num1 = (int) num2 * 799365206 ^ 861486323;
          continue;
        case 44:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -524617837 ^ 1894305984;
          continue;
        case 45:
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1361821914U);
          num1 = (int) num2 * -1330685844 ^ 1371593734;
          continue;
        case 46:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -117016925 ^ -522086451;
          continue;
        case 47:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.ReadOnly = true;
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.RowHeadersVisible = false;
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.Size = new Size(662, 291);
          num1 = (int) num2 * 19869290 ^ 919405936;
          continue;
        case 48 /*0x30*/:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.Size = new Size(108, 13);
          num1 = (int) num2 * 89231461 ^ -2110954498;
          continue;
        case 49:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -1560237622 ^ 597602525;
          continue;
        case 50:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮);
          num1 = (int) num2 * 1434365302 ^ 1722463478;
          continue;
        case 51:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮);
          num1 = (int) num2 * 1651980644 ^ -662460909;
          continue;
        case 52:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.Size = new Size(60, 13);
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.TabIndex = 35;
          num1 = (int) num2 * -1942530644 ^ -96303758;
          continue;
        case 53:
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.Width = 132;
          this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1472362983U);
          num1 = (int) num2 * -796011395 ^ 242313073;
          continue;
        case 54:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.Columns.AddRange((DataGridViewColumn) this.\u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮, (DataGridViewColumn) this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮, (DataGridViewColumn) this.\u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮, (DataGridViewColumn) this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮);
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.Location = new Point(7, 303);
          num1 = (int) num2 * -239829176 ^ 819865703;
          continue;
        case 55:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Location = new Point(4, 22);
          num1 = (int) num2 * 1338270656 ^ -1314288683;
          continue;
        case 56:
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.Location = new Point(482, 239);
          num1 = (int) num2 * 1508206564 ^ -88732625;
          continue;
        case 57:
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.Size = new Size(21, 13);
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.TabIndex = 11;
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1052055335U);
          num1 = (int) num2 * 1912531563 ^ 1268917883;
          continue;
        case 58:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.MultiSelect = false;
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2223233211U);
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.RowHeadersVisible = false;
          num1 = (int) num2 * -1282384077 ^ 40369679;
          continue;
        case 59:
          this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮.Size = new Size(148, 48 /*0x30*/);
          num1 = (int) num2 * 1928031115 ^ 997073820;
          continue;
        case 60:
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.Size = new Size(224 /*0xE0*/, 26);
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.TabIndex = 22;
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1323750991U);
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.UseVisualStyleBackColor = true;
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.Click += new EventHandler(this.\u202E⁪​⁫​⁪​⁬‭‮⁬‬⁬‎⁬‬‬‪⁬‌‮⁫⁪‏⁭⁫​⁫⁮‎⁪‭⁯‫‮⁯⁯‪‭⁪‮);
          num1 = (int) num2 * 1417544951 ^ -168793404;
          continue;
        case 61:
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.AutoSize = true;
          num1 = (int) num2 * 718350631 ^ 1086936748;
          continue;
        case 62:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * -998886511 ^ 837801916;
          continue;
        case 63 /*0x3F*/:
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‫‍⁪‭⁯‍​⁪‪⁭⁭⁮‬‍⁭⁭⁬‍‮⁫‏‭‪‍⁭‍‭⁮‬‌‎‍⁬‭⁭⁫⁪​‏‮();
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -1267517136 ^ -1774808528;
          continue;
        case 64 /*0x40*/:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1600703259U);
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.Size = new Size(96 /*0x60*/, 17);
          num1 = (int) num2 * 1649939068 ^ 802635493;
          continue;
        case 65:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.Location = new Point(215, 122);
          num1 = (int) num2 * -280069 ^ 28031410;
          continue;
        case 66:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.BackgroundImageLayout = ImageLayout.Center;
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.Cursor = Cursors.Default;
          num1 = (int) num2 * 1836127063 ^ -123993503;
          continue;
        case 67:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‮‬‎‪​⁮⁯‍⁬‪⁫‬‍⁮​⁯⁬‫⁪‏‏‎‏‎‌‬‎‌⁮‍​‭‏⁮⁬‪‫⁮‍‮();
          num1 = (int) num2 * -1321688519 ^ 644518139;
          continue;
        case 68:
          this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1268504396U);
          num1 = (int) num2 * 1595288730 ^ -254479775;
          continue;
        case 69:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * -1748662627 ^ 1653714388;
          continue;
        case 70:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮);
          num1 = (int) num2 * 1034373184 ^ 1840207219;
          continue;
        case 71:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.BackColor = Color.Transparent;
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.BackgroundImage = (Image) I\u003E42Nl\u002Dn\u0029ew\u005B\u003Dm3w3gT\u003Fj\u0028\u002Fi\u0024.\u202E‮⁭‪‪‮‍‪⁭‎⁬‪‭‪⁮⁯‍​⁯⁫⁫⁮‎​‬‪⁫‎‭‫⁯⁮⁫‮⁭‭⁪⁯⁪‌‮;
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.BackgroundImageLayout = ImageLayout.Center;
          num1 = (int) num2 * 559808099 ^ -1660148421;
          continue;
        case 72:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Size = new Size(686, 402);
          num1 = (int) num2 * -1332477898 ^ 1978837596;
          continue;
        case 73:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1131571468U);
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.AutoSize = true;
          num1 = (int) num2 * 2070697663 ^ 1081559527;
          continue;
        case 74:
          this.Controls.Add((Control) this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮);
          num1 = (int) num2 * -862699751 ^ 1966630186;
          continue;
        case 75:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.MultiSelect = false;
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(915846306U);
          num1 = (int) num2 * 920938603 ^ 623076880;
          continue;
        case 76:
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.TabIndex = 3;
          num1 = (int) num2 * -722707419 ^ 426779143;
          continue;
        case 77:
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 1980991247 ^ -217439926;
          continue;
        case 78:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.TabIndex = 14;
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2338059922U);
          num1 = (int) num2 * 1897250858 ^ 683860963;
          continue;
        case 79:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‮‬‎‪​⁮⁯‍⁬‪⁫‬‍⁮​⁯⁬‫⁪‏‏‎‏‎‌‬‎‌⁮‍​‭‏⁮⁬‪‫⁮‍‮();
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‮‬‎‪​⁮⁯‍⁬‪⁫‬‍⁮​⁯⁬‫⁪‏‏‎‏‎‌‬‎‌⁮‍​‭‏⁮⁬‪‫⁮‍‮();
          num1 = (int) num2 * 402690072 ^ -623717341;
          continue;
        case 80 /*0x50*/:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 370579606 ^ -1208268521;
          continue;
        case 81:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.Location = new Point(7, 274);
          num1 = (int) num2 * -369621354 ^ 371464077;
          continue;
        case 82:
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.SelectedIndexChanged += new EventHandler(this.\u200D‭‌‪‮‍⁯​‭‬‪‫⁫⁮‌‪‎⁭⁯⁪‌‏⁫⁭⁬‬‬‭‬⁬⁮‎‎‍⁬‪⁪⁬⁭‭‮);
          num1 = (int) num2 * 2029719138 ^ -393171096;
          continue;
        case 83:
          this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4042733856U);
          num1 = (int) num2 * 2069704901 ^ 1723668163;
          continue;
        case 84:
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.TabIndex = 1;
          num1 = (int) num2 * 1641386811 ^ 1788410861;
          continue;
        case 85:
          this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮.Items.AddRange((object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(93557901U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1466536141U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1165713363U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4290839076U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(618638409U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(317270681U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2945110555U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2254892473U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3659974517U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(139210907U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(14903056U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2652160263U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2457705766U));
          num1 = (int) num2 * 1428220450 ^ -1143744434;
          continue;
        case 86:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          num1 = (int) num2 * 115821321 ^ -898991187;
          continue;
        case 87:
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.Size = new Size(46, 13);
          num1 = (int) num2 * 468521905 ^ 1690738058;
          continue;
        case 88:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪​‮⁭‍‪‭‍‌⁮‮​⁯‮⁮‫‎‍⁬‌‭​‍‮⁫‭‌‬⁫‮⁭⁯⁮‮‏‫‌​⁬‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮, false);
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.Location = new Point(1, 114);
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3916432119U);
          num1 = (int) num2 * 883118817 ^ -990937622;
          continue;
        case 89:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.TabIndex = 24;
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.TabStop = true;
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2599504557U);
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.LinkClicked += new LinkLabelLinkClickedEventHandler(this.\u200C‎‏‏⁯‬‫⁮‭⁯‭‍⁮‮‪‏⁮‌⁯⁬‎⁪⁫‫⁭‬⁮​‏‎⁮‌‪‭‌‫⁭‮‫‭‮);
          num1 = (int) num2 * -1873503274 ^ -503121610;
          continue;
        case 90:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮);
          num1 = (int) num2 * 371348036 ^ 388465743;
          continue;
        case 91:
          this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮.ResumeLayout(false);
          num1 = (int) num2 * 1705691600 ^ 1706874791;
          continue;
        case 92:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * -1436361534 ^ 547229434;
          continue;
        case 93:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.Size = new Size(662, 60);
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.TabIndex = 1;
          num1 = (int) num2 * 430640859 ^ -321149393;
          continue;
        case 94:
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4144812658U);
          num1 = (int) num2 * 569508372 ^ 1679629851;
          continue;
        case 95:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮);
          num1 = (int) num2 * 2000950761 ^ -911778924;
          continue;
        case 96 /*0x60*/:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.BackgroundImageLayout = ImageLayout.Stretch;
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮);
          num1 = (int) num2 * -1476422905 ^ -1957922256;
          continue;
        case 97:
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3427378163U);
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.Size = new Size(107, 17);
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.TabIndex = 15;
          num1 = (int) num2 * -1518488166 ^ 648157789;
          continue;
        case 98:
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -667174223 ^ 2028741089;
          continue;
        case 99:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.OffFont = new Font(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(356206439U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.OnFont = new Font(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3626873321U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.Size = new Size(45, 19);
          num1 = (int) num2 * 2013788900 ^ 1156779084;
          continue;
        case 100:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.Size = new Size(662, 78);
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.TabIndex = 15;
          this.\u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮.HeaderText = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3667751099U);
          this.\u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3417577936U);
          num1 = (int) num2 * 285495074 ^ 252778938;
          continue;
        case 101:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Controls.Add((Control) this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮);
          num1 = (int) num2 * -1452562111 ^ -1914628504;
          continue;
        case 102:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.TabIndex = 0;
          num1 = (int) num2 * 1257374206 ^ -1729759848;
          continue;
        case 103:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮);
          num1 = (int) num2 * 1996687899 ^ -780788547;
          continue;
        case 104:
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.AutoSize = true;
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -1682833475 ^ 1585126604;
          continue;
        case 105:
          this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮.Width = 165;
          num1 = (int) num2 * -1766414511 ^ -1044374130;
          continue;
        case 106:
          this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮.Items.AddRange((object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(807124952U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3162884620U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2987134080U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1071646757U));
          num1 = (int) num2 * -668531808 ^ -277190756;
          continue;
        case 107:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮);
          num1 = (int) num2 * -1472643062 ^ 313471446;
          continue;
        case 108:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Controls.Add((Control) this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮);
          num1 = (int) num2 * 1436842904 ^ 1605862795;
          continue;
        case 109:
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.Width = 165;
          num1 = (int) num2 * 108550960 ^ 1360147247;
          continue;
        case 110:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * -1773887985 ^ -426709223;
          continue;
        case 111:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Value = new Decimal(new int[4]
          {
            10,
            0,
            0,
            0
          });
          num1 = (int) num2 * -43835861 ^ 1749436407;
          continue;
        case 112 /*0x70*/:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1745674976U);
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Size = new Size(105, 13);
          num1 = (int) num2 * 1838780916 ^ 744852991;
          continue;
        case 113:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮);
          num1 = (int) num2 * -1995682028 ^ 1815867396;
          continue;
        case 114:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.MouseLeave += new EventHandler(this.\u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮);
          num1 = (int) num2 * -1883719600 ^ -1622577941;
          continue;
        case 115:
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.Size = new Size(54, 13);
          num1 = (int) num2 * 2099089673 ^ -786655707;
          continue;
        case 116:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.EndInit();
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.EndInit();
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.EndInit();
          num1 = (int) num2 * 812467 ^ 898636384;
          continue;
        case 117:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4015223773U);
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Size = new Size(120, 20);
          num1 = (int) num2 * 851638047 ^ 48896380;
          continue;
        case 118:
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2522711240U);
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.AutoSize = true;
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.BackColor = Color.Transparent;
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.Location = new Point(7, 182);
          num1 = (int) num2 * 1468358811 ^ -72221740;
          continue;
        case 119:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.BackgroundImageLayout = ImageLayout.Stretch;
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Controls.Add((Control) this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮);
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Controls.Add((Control) this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮);
          num1 = (int) num2 * -1185213442 ^ 263084275;
          continue;
        case 120:
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3517590315U);
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.Size = new Size(109, 13);
          num1 = (int) num2 * -1866857496 ^ -992454280;
          continue;
        case 121:
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.Size = new Size(559, 21);
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.TabIndex = 17;
          num1 = (int) num2 * -1147539118 ^ 1587973757;
          continue;
        case 122:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          num1 = (int) num2 * 580558585 ^ 1781989942;
          continue;
        case 123:
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.TabIndex = 2;
          num1 = (int) num2 * 795971058 ^ -889824547;
          continue;
        case 124:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.Location = new Point(180, 95);
          num1 = (int) num2 * 646040365 ^ -431592796;
          continue;
        case 125:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.TabIndex = 25;
          num1 = (int) num2 * 292355086 ^ 995876198;
          continue;
        case 126:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.AllowUserToResizeRows = false;
          num1 = (int) num2 * 1463892860 ^ -1950624015;
          continue;
        case (uint) sbyte.MaxValue:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          num1 = (int) num2 * -855521384 ^ 21567121;
          continue;
        case 128 /*0x80*/:
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(349126296U);
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -785624884 ^ 1541750218;
          continue;
        case 129:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1648551551U);
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.BackColor = Color.WhiteSmoke;
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.Location = new Point(560, 86);
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1631025117U);
          num1 = (int) num2 * -1192977216 ^ 1866827630;
          continue;
        case 130:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁭‮‬‭​‮‫⁬⁪⁮​⁭⁪‭⁭⁯‎‫‪‮‏⁫​​‫⁮​⁯‪⁫⁯​‭⁬⁫‭‪‌⁪‮();
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -901122428 ^ -238604028;
          continue;
        case 131:
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -1919269606 ^ 2129120863;
          continue;
        case 132:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.CheckedChanged += new EventHandler(this.\u200E‫⁫‍‮‌⁫⁫⁪‎⁬‪‭‍‬‌‭⁬⁮‎⁬⁬‭‎‭⁭⁬⁭‍‫‬⁯‬⁫⁫‍‮‮⁮‭‮);
          num1 = (int) num2 * -1870887814 ^ 2089857186;
          continue;
        case 133:
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.TabIndex = 22;
          num1 = (int) num2 * 83733735 ^ 129273812;
          continue;
        case 134:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮);
          num1 = (int) num2 * -1358347567 ^ -809398726;
          continue;
        case 135:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.TabStop = false;
          this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮.Items.AddRange(new ToolStripItem[2]
          {
            (ToolStripItem) this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮,
            (ToolStripItem) this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮
          });
          this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1246405758U);
          num1 = (int) num2 * -1517965414 ^ -563158670;
          continue;
        case 136:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Size = new Size(142, 20);
          num1 = (int) num2 * 1378782298 ^ 787285890;
          continue;
        case 137:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.Location = new Point(403, 5);
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(452029759U);
          num1 = (int) num2 * -2000761392 ^ -1250036684;
          continue;
        case 138:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * 1398820355 ^ 431071913;
          continue;
        case 139:
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * -1281623367 ^ 837076339;
          continue;
        case 140:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.Click += new EventHandler(this.\u200C‫⁫⁮‬‏‮‎⁯‏‪‬⁫‪‮‌⁬⁭⁪⁭‏‬‪‎‮⁪⁪⁪‫‬⁭‭‭⁮‎⁮‬⁪⁪⁪‮);
          num1 = (int) num2 * -1344165208 ^ 1929722921;
          continue;
        case 141:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(194394863U);
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.AutoSize = true;
          num1 = (int) num2 * -1247880469 ^ 1259215906;
          continue;
        case 142:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          num1 = (int) num2 * 810552156 ^ 1054422420;
          continue;
        case 143:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(393114781U);
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.Size = new Size(21, 13);
          num1 = (int) num2 * 841157763 ^ -1910106655;
          continue;
        case 144 /*0x90*/:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -1196896701 ^ 524455732;
          continue;
        case 145:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2872461212U);
          num1 = (int) num2 * -766895228 ^ -937840674;
          continue;
        case 146:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.AllowUserToResizeRows = false;
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.Columns.AddRange((DataGridViewColumn) this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮, (DataGridViewColumn) this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮, (DataGridViewColumn) this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮, (DataGridViewColumn) this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮);
          num1 = (int) num2 * -1889814086 ^ -1368895725;
          continue;
        case 147:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 1459911395 ^ 419638971;
          continue;
        case 148:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.TabIndex = 33;
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2443678091U);
          num1 = (int) num2 * -959052255 ^ 1361242318;
          continue;
        case 149:
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.TabIndex = 26;
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 147829764 ^ -1697114555;
          continue;
        case 150:
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.Size = new Size(105, 13);
          num1 = (int) num2 * 373044838 ^ 2135746878;
          continue;
        case 151:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮);
          num1 = (int) num2 * -1721052280 ^ -796215104;
          continue;
        case 152:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮);
          num1 = (int) num2 * 685085691 ^ 919520645;
          continue;
        case 153:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.Size = new Size(21, 13);
          num1 = (int) num2 * -49858325 ^ 1121558561;
          continue;
        case 154:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.BackColor = SystemColors.WindowFrame;
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.BackgroundImageLayout = ImageLayout.Stretch;
          num1 = (int) num2 * -1793075463 ^ -1687983800;
          continue;
        case 155:
          this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2019032769U);
          num1 = (int) num2 * 981520074 ^ -1939140734;
          continue;
        case 156:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.Size = new Size(662, 20);
          num1 = (int) num2 * -578474183 ^ -137300530;
          continue;
        case 157:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          num1 = (int) num2 * -1166271167 ^ 1350975139;
          continue;
        case 158:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.TabIndex = 17;
          num1 = (int) num2 * -1778104320 ^ -593282310;
          continue;
        case 159:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          num1 = (int) num2 * 957668982 ^ 502538651;
          continue;
        case 160 /*0xA0*/:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.Size = new Size(66, 17);
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.TabIndex = 13;
          num1 = (int) num2 * 1827044646 ^ 606524408;
          continue;
        case 161:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.MouseLeave += new EventHandler(this.\u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮);
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 2065260315 ^ -1765796748;
          continue;
        case 162:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1749532313U);
          num1 = (int) num2 * 1882366999 ^ -85528947;
          continue;
        case 163:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.ForeColor = SystemColors.ControlText;
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Location = new Point(4, 22);
          num1 = (int) num2 * -1008619164 ^ 177184700;
          continue;
        case 164:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.BackgroundImage = (Image) componentResourceManager.GetObject(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2823444537U));
          num1 = (int) num2 * -505409276 ^ -2016252729;
          continue;
        case 165:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.Location = new Point(7, 369);
          num1 = (int) num2 * -439919461 ^ 60628940;
          continue;
        case 166:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮);
          num1 = (int) num2 * 1592302020 ^ -721056236;
          continue;
        case 167:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.TabIndex = 4;
          num1 = (int) num2 * 328257780 ^ 325812787;
          continue;
        case 168:
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(994399610U);
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.BorderStyle = BorderStyle.FixedSingle;
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.Location = new Point(7, 63 /*0x3F*/);
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2959231456U);
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.ReadOnly = true;
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.Size = new Size(662, 334);
          num1 = (int) num2 * 547939555 ^ 524000534;
          continue;
        case 169:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‮⁫‬‍​‏⁫‫‮‎‭​‮‫‬‎‪⁪‍‫‪⁪⁪‬‎⁭‌⁭‭​‬‌‏‎‍‍‮⁯‮‮();
          this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‪‮⁭​‪‭‌⁯‮⁭⁫⁭‮‌⁬⁪‬‌‫‪⁬⁯⁫​‬‪‪⁫‭⁮‎‫⁮‫‎⁫⁯‮‮(this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * 613248312 ^ -1183512581;
          continue;
        case 170:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(858572000U);
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.RowHeadersVisible = false;
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.SelectionMode = DataGridViewSelectionMode.CellSelect;
          num1 = (int) num2 * 138392784 ^ 2057682718;
          continue;
        case 171:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2017896769U);
          num1 = (int) num2 * -582897427 ^ -464138961;
          continue;
        case 172:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * -1516717996 ^ -254800275;
          continue;
        case 173:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3572609710U);
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -551883459 ^ -928494829;
          continue;
        case 174:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u206E‮⁪⁫⁪​⁫⁬⁮‎‫‫‭⁪‍⁬⁬⁮⁯⁮⁭⁪⁪‏‌‎⁯⁯‍‫‪⁪‪⁮⁪⁭⁮⁭‪⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * 421451057 ^ 226073037;
          continue;
        case 175:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‪‫‬​‎‮‎⁪‮‎⁫‎⁮‮‎‍⁮‫‍‮‪‍⁬⁫‪‮⁭⁪⁪⁫‍⁯‍‭‎⁭‍​⁮‮();
          num1 = (int) num2 * -577314225 ^ 1968496426;
          continue;
        case 176 /*0xB0*/:
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * -733080677 ^ -1648143484;
          continue;
        case 177:
          this.\u202B‫⁬⁪⁭‎‫‮‫⁭⁮​⁫⁪‎‪⁫⁯‫⁭⁮‍⁪‬‍‮‭​‌‏‭⁫​⁪‫⁯‬‪⁫⁮‮.Interval = 1000;
          num1 = (int) num2 * 692560989 ^ -751878885;
          continue;
        case 178:
          this.Controls.Add((Control) this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮);
          this.Controls.Add((Control) this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮);
          num1 = (int) num2 * 1314789649 ^ 859491624;
          continue;
        case 179:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1693445121U);
          num1 = (int) num2 * 269927375 ^ 1575600234;
          continue;
        case 180:
          this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮.Width = 132;
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(696494485U);
          num1 = (int) num2 * 439254919 ^ -150263546;
          continue;
        case 181:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.BackgroundImageLayout = ImageLayout.Stretch;
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Controls.Add((Control) this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮);
          num1 = (int) num2 * 324783714 ^ -1851038312;
          continue;
        case 182:
          this.\u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          num1 = (int) num2 * -270756087 ^ 1691042290;
          continue;
        case 183:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.Location = new Point(451, 50);
          num1 = (int) num2 * -1597669687 ^ -596378170;
          continue;
        case 184:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.AutoSize = true;
          num1 = (int) num2 * 1506023864 ^ -635502061;
          continue;
        case 185:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮);
          num1 = (int) num2 * -305057100 ^ -882365257;
          continue;
        case 186:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2772816939U);
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.OffFont = new Font(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2958081165U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * 1658482719 ^ -1882093823;
          continue;
        case 187:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3185957654U);
          num1 = (int) num2 * 1378401945 ^ 1227912842;
          continue;
        case 188:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.FlatAppearance.BorderSize = 0;
          num1 = (int) num2 * 407365696 ^ 943942784;
          continue;
        case 189:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮);
          num1 = (int) num2 * -557153147 ^ 1826693086;
          continue;
        case 190:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.TextImageRelation = TextImageRelation.TextBeforeImage;
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * 22457583 ^ -267909752;
          continue;
        case 191:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.TabIndex = 3;
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.BackColor = Color.WhiteSmoke;
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.FormattingEnabled = true;
          num1 = (int) num2 * -1585600993 ^ 706479955;
          continue;
        case 192 /*0xC0*/:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.RowHeadersVisible = false;
          num1 = (int) num2 * 1005622429 ^ 829603965;
          continue;
        case 193:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮);
          num1 = (int) num2 * -2145340841 ^ -97472710;
          continue;
        case 194:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u200B⁮⁪⁬‮‎⁯​‪⁯‍‬⁯‭‍‌‪‪⁭⁪⁯⁮‫⁭⁪‪⁫⁮​⁪⁫‮‫⁭‫⁬‎⁯​⁪‮);
          num1 = (int) num2 * 481228778 ^ 2115761744;
          continue;
        case 195:
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.Location = new Point(166, 234);
          num1 = (int) num2 * 206673885 ^ -1199425662;
          continue;
        case 196:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.Size = new Size(45, 19);
          num1 = (int) num2 * 490351018 ^ -1469832747;
          continue;
        case 197:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          num1 = (int) num2 * 187716122 ^ 275534327;
          continue;
        case 198:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Size = new Size(686, 400);
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.TabIndex = 2;
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(106525914U);
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 647670616 ^ -401544181;
          continue;
        case 199:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.Location = new Point(357, 2);
          num1 = (int) num2 * 552753024 ^ -1765695480;
          continue;
        case 200:
          this.\u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3023663859U);
          num1 = (int) num2 * 947052997 ^ 770704465;
          continue;
        case 201:
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -2136115607 ^ -1224059157;
          continue;
        case 202:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 18065581 ^ 744908169;
          continue;
        case 203:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1507961397U);
          num1 = (int) num2 * 453226419 ^ 1020051453;
          continue;
        case 204:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.BackColor = Color.WhiteSmoke;
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.BorderStyle = BorderStyle.FixedSingle;
          num1 = (int) num2 * -1258521686 ^ 1016522752;
          continue;
        case 205:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.TabIndex = 39;
          num1 = (int) num2 * 714502784 ^ -470889403;
          continue;
        case 206:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          num1 = (int) num2 * 20649244 ^ 1465949405;
          continue;
        case 207:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.Location = new Point(450, 384);
          num1 = (int) num2 * 1324245112 ^ 2016601248;
          continue;
        case 208 /*0xD0*/:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.PerformLayout();
          num1 = (int) num2 * -34712828 ^ 2143880392;
          continue;
        case 209:
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.Size = new Size(130, 20);
          num1 = (int) num2 * 494499657 ^ 451403825;
          continue;
        case 210:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.Location = new Point(451, 69);
          num1 = (int) num2 * 1122653238 ^ 717711647;
          continue;
        case 211:
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.Items.AddRange(new object[3]
          {
            (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2947857428U),
            (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1883714541U),
            (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2965291719U)
          });
          num1 = (int) num2 * -2035437324 ^ 735818572;
          continue;
        case 212:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -1713375108 ^ -604964355;
          continue;
        case 213:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 1420185897 ^ -706397005;
          continue;
        case 214:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2068169205U);
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.OffFont = new Font(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1034455148U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * -175313503 ^ 1673120724;
          continue;
        case 215:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1067344654U);
          num1 = (int) num2 * 1824076217 ^ 1854777164;
          continue;
        case 216:
          this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * -1968255317 ^ -976783090;
          continue;
        case 217:
          this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * 1269614231 ^ -1420214;
          continue;
        case 218:
          this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(243880121U);
          num1 = (int) num2 * 1307220408 ^ -1637036937;
          continue;
        case 219:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 214768905 ^ 869143248;
          continue;
        case 221:
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.OffFont = new Font(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2958081165U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * -904228611 ^ 866898057;
          continue;
        case 222:
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 903331679 ^ -1771803221;
          continue;
        case 223:
          this.Controls.Add((Control) this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮);
          this.Controls.Add((Control) this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮);
          num1 = (int) num2 * -321329697 ^ 1145066756;
          continue;
        case 224 /*0xE0*/:
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u200B⁯‫‬‏⁭‍‭‍‬‮⁭⁮‫‭‎‌‍⁫‏⁯‍⁪‍‫⁫⁪‏‫‮‏⁬⁪⁫⁬‪‍‍‌‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‫‎​‫‬‌⁫‪⁬⁮‌⁪⁪‮⁮⁭​‮‌⁬‮‎‭⁫‭⁯​⁬⁮​‏‍‎‪‮‫‎⁪⁫‮(this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‏​​‭⁬‏‮‏⁮⁫⁮⁪⁬‮‌‪‍⁫⁬‍⁯⁮‭‫⁫‫⁬⁪‬⁬‪⁫⁮‫⁪​‬⁭⁫‮(this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          num1 = (int) num2 * 835028658 ^ 961881043;
          continue;
        case 225:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.FlatAppearance.BorderSize = 0;
          num1 = (int) num2 * -837003823 ^ -947178707;
          continue;
        case 226:
          this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          this.\u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‏⁪‬⁭‪‏⁫‭‬⁮‪‪‫‌⁮‌⁭‍‮‍‎​⁫‫⁬​⁮‫‭‍⁪‏‮‏⁭‎‭‭‮();
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * 361873138 ^ -220092345;
          continue;
        case 227:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Location = new Point(311, 234);
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Maximum = new Decimal(new int[4]
          {
            30,
            0,
            0,
            0
          });
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Minimum = new Decimal(new int[4]
          {
            1,
            0,
            0,
            0
          });
          num1 = (int) num2 * 1318616419 ^ 715420667;
          continue;
        case 228:
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(70511297U);
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Size = new Size(120, 20);
          num1 = (int) num2 * -767988502 ^ 1214608270;
          continue;
        case 229:
          this.\u202B‫⁬⁪⁭‎‫‮‫⁭⁮​⁫⁪‎‪⁫⁯‫⁭⁮‍⁪‬‍‮‭​‌‏‭⁫​⁪‫⁯‬‪⁫⁮‮.Tick += new EventHandler(this.\u200C⁬‭⁫‌‏‌⁭‭‫‮⁬⁬⁫⁯⁭‏‫⁪‫‍‫‭‎‬‭‎⁮‪​⁬‫⁫⁬‏⁯‭‏⁭⁪‮);
          num1 = (int) num2 * -1212199552 ^ 1097494352;
          continue;
        case 230:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 956041266 ^ -237688204;
          continue;
        case 231:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Location = new Point(14, 3);
          num1 = (int) num2 * 1027552933 ^ -1127237040;
          continue;
        case 232:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2119857207U);
          num1 = (int) num2 * -1004167997 ^ 1781335901;
          continue;
        case 233:
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.TabIndex = 14;
          num1 = (int) num2 * -1565710176 ^ 877722229;
          continue;
        case 234:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.TabIndex = 0;
          num1 = (int) num2 * -844387430 ^ -1965780611;
          continue;
        case 235:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.TabIndex = 15;
          num1 = (int) num2 * 1546968918 ^ 1749285179;
          continue;
        case 236:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Controls.Add((Control) this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮);
          num1 = (int) num2 * 905801708 ^ -1907862258;
          continue;
        case 237:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * -1170242512 ^ 1171888100;
          continue;
        case 238:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.ValueChanged += new EventHandler(this.\u200F‎⁭‮‌⁫‪⁯⁬⁭‬⁮⁬‏⁮‫‮‫⁮‏‎‫⁯‎​⁫​‍‌‍‬​‪‫‮⁬‫⁮‏‫‮);
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.AutoSize = true;
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -688758092 ^ -436536061;
          continue;
        case 239:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮);
          num1 = (int) num2 * -332231311 ^ -747079106;
          continue;
        case 240 /*0xF0*/:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮);
          num1 = (int) num2 * -1496730316 ^ -466962084;
          continue;
        case 241:
          this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(51463481U);
          num1 = (int) num2 * 1884676109 ^ 128477951;
          continue;
        case 242:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.MultiSelect = false;
          num1 = (int) num2 * -697218830 ^ -149928994;
          continue;
        case 243:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.Size = new Size(662, 273);
          num1 = (int) num2 * -1078387712 ^ -1277574424;
          continue;
        case 244:
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2320090782U);
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.Size = new Size(59, 13);
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.TabIndex = 37;
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1682554799U);
          this.\u200B⁯‫‬‏⁭‍‭‍‬‮⁭⁮‫‭‎‌‍⁫‏⁯‍⁪‍‫⁫⁪‏‫‮‏⁬⁪⁫⁬‪‍‍‌‫‮.Enabled = true;
          num1 = (int) num2 * -1523647349 ^ -791823465;
          continue;
        case 245:
          goto label_1;
        case 246:
          this.BackgroundImageLayout = ImageLayout.Stretch;
          this.ClientSize = new Size(695, 567);
          num1 = (int) num2 * -1343769685 ^ -1797433992;
          continue;
        case 247:
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1286879259U);
          num1 = (int) num2 * 1990453389 ^ -566830602;
          continue;
        case 248:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 416579165 ^ 1939407805;
          continue;
        case 249:
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.TabIndex = 31 /*0x1F*/;
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2521878834U);
          num1 = (int) num2 * -1601683374 ^ -957656582;
          continue;
        case 250:
          this.\u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮.Width = 165;
          this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮.HeaderText = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3375792291U);
          num1 = (int) num2 * 41825137 ^ -413131144;
          continue;
        case 251:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.BackColor = Color.Transparent;
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.Location = new Point(167, 189);
          num1 = (int) num2 * 1596859223 ^ 1804785488;
          continue;
        case 252:
          this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮.Width = 165;
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1765890558U);
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮.Items.AddRange((object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2830984077U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(378924658U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1033060697U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3125484582U));
          num1 = (int) num2 * -1036641976 ^ 1944734989;
          continue;
        case 253:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.ValueChanged += new EventHandler(this.\u206A⁮⁬‭⁬⁮‪‌‭‌⁯⁮‎‫⁪​‮⁯⁬‭‬⁬‌​‫‫⁯⁬⁭⁭​⁮‮‪‏‮⁪⁪​‫‮);
          num1 = (int) num2 * -688941927 ^ 306729705;
          continue;
        case 254:
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮‬‫⁪‎⁬‭‌‬‎⁫‫‬‏‬‏‬⁫‫‮⁬‭‫‌‌‌⁭⁪‫⁭⁫‪‬‍‍​‪‏‮();
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          num1 = (int) num2 * 1820404164 ^ 404617855;
          continue;
        case (uint) byte.MaxValue:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1343720104U);
          num1 = (int) num2 * 214178771 ^ 1918507930;
          continue;
        case 256 /*0x0100*/:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(14124170U);
          num1 = (int) num2 * -178647439 ^ 207848404;
          continue;
        case 257:
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.TabIndex = 28;
          num1 = (int) num2 * -795944075 ^ 499736541;
          continue;
        case 258:
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.ValueChanged += new EventHandler(this.\u202E⁯‫‭‏‏‌⁯‏⁪⁬⁫⁬​⁪‍‬‪⁯‭⁪‌⁬⁫‌‬‭‪‭⁭‍‪⁫‭⁪⁮⁫⁫⁭⁫‮);
          num1 = (int) num2 * 975550446 ^ 632016969;
          continue;
        case 259:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Location = new Point(24, 28);
          num1 = (int) num2 * 114587310 ^ 1728971455;
          continue;
        case 260:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Controls.Add((Control) this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮);
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Controls.Add((Control) this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮);
          num1 = (int) num2 * -1110566644 ^ 476626111;
          continue;
        case 261:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.Location = new Point(451, 369);
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2674520180U);
          num1 = (int) num2 * -424969029 ^ 1301704874;
          continue;
        case 262:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮);
          num1 = (int) num2 * 1239774998 ^ -1855855666;
          continue;
        case 263:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮);
          num1 = (int) num2 * 583141215 ^ -1250467132;
          continue;
        case 264:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.MultiSelect = false;
          num1 = (int) num2 * 230141277 ^ -445981087;
          continue;
        case 265:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪‎‏⁪⁫⁮‎⁮‬‭‍‮‍‌‫⁮​⁫‌‬⁬‌‪⁬⁯⁭⁭‬⁫​‏‫‫‏‫​‌‏⁮‮((Control) this);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮);
          num1 = (int) num2 * 639709606 ^ 1691307449;
          continue;
        case 266:
          this.\u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮.HeaderText = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3930882529U);
          num1 = (int) num2 * 327533686 ^ 1405552919;
          continue;
        case 267:
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.Location = new Point(91, 95);
          num1 = (int) num2 * 1352899171 ^ 545306372;
          continue;
        case 268:
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * -1023256889 ^ -1843669534;
          continue;
        case 269:
          this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2700311628U);
          num1 = (int) num2 * -1703361175 ^ 8711263;
          continue;
        case 270:
          this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮.Click += new EventHandler(this.\u202C‏‬‫⁬⁮‭‏⁮‮‍‎‌‎⁬‮​⁭​‬⁪‏‏‭⁭‌‌‍⁪⁭⁪‍‮‬‏‫‬‮‌‎‮);
          this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3638400687U);
          this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮.Size = new Size(96 /*0x60*/, 20);
          this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2359159407U);
          this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮.Click += new EventHandler(this.\u200E‬⁬⁬‍‍⁫‎‭‍​⁯‪​‮‬⁯⁬⁯⁯⁭‍​​‏‎‫‏⁫‫⁪⁭⁫‪⁯⁮‎‏‮⁮‮);
          num1 = (int) num2 * 2139409252 ^ -1758301955;
          continue;
        case 271:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.AutoSize = true;
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -484599953 ^ -1816716653;
          continue;
        case 272:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.AutoSize = true;
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.BackColor = Color.Transparent;
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Location = new Point(5, 546);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1313837672U);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Size = new Size(112 /*0x70*/, 13);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.TabIndex = 18;
          num1 = (int) num2 * 1837111420 ^ -1160422186;
          continue;
        case 273:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1972707063U);
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.BackColor = Color.WhiteSmoke;
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.FormattingEnabled = true;
          num1 = (int) num2 * 1209087449 ^ 157423197;
          continue;
        case 274:
          this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮.Items.AddRange((object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1187788849U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(789446939U));
          num1 = (int) num2 * -1089492394 ^ -289327640;
          continue;
        case 275:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮);
          num1 = (int) num2 * -780754581 ^ -1541211341;
          continue;
        case 276:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.FlatAppearance.BorderSize = 0;
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.FlatStyle = FlatStyle.Flat;
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.Location = new Point(176 /*0xB0*/, 28);
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2879372732U);
          num1 = (int) num2 * 884013559 ^ 1748232416;
          continue;
        case 277:
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4109706343U);
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.Size = new Size(208 /*0xD0*/, 26);
          num1 = (int) num2 * -2015910483 ^ -778025646;
          continue;
        case 278:
          this.\u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮.Width = 155;
          num1 = (int) num2 * -1996673765 ^ -1335769710;
          continue;
        case 279:
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.FormattingEnabled = true;
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.Items.AddRange(new object[6]
          {
            (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2312631524U),
            (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2596405286U),
            (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4075963465U),
            (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2219283711U),
            (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(986937877U),
            (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(568355075U)
          });
          num1 = (int) num2 * -1745290990 ^ 420831725;
          continue;
        case 280:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Enabled = false;
          num1 = (int) num2 * 809352084 ^ -848529438;
          continue;
        case 281:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮);
          num1 = (int) num2 * 1214013202 ^ -319772558;
          continue;
        case 282:
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(749720193U);
          num1 = (int) num2 * -2018551604 ^ -2030992867;
          continue;
        case 283:
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 377261825 ^ 1215855457;
          continue;
        case 284:
          this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2267339597U);
          num1 = (int) num2 * 576694189 ^ -1120821733;
          continue;
        case 285:
          this.\u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3585591781U);
          num1 = (int) num2 * -1704427655 ^ -1466423458;
          continue;
        case 286:
          this.Controls.Add((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮);
          num1 = (int) num2 * 891106267 ^ 1713258935;
          continue;
        case 287:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.ReadOnly = true;
          num1 = (int) num2 * -1820921557 ^ -1999738142;
          continue;
        case 288:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.Location = new Point(7, 369);
          num1 = (int) num2 * 261268199 ^ 10918029;
          continue;
        case 289:
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.Width = 165;
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1765890558U);
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2231014630U);
          num1 = (int) num2 * -2105657254 ^ -1800677145;
          continue;
        case 290:
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          num1 = (int) num2 * -127885589 ^ -48140328;
          continue;
        case 291:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.FormattingEnabled = true;
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.Location = new Point(579, 19);
          num1 = (int) num2 * 752766506 ^ 243183568;
          continue;
        case 292:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.CheckedChanged += new EventHandler(this.\u202C⁮⁭​⁬​‎‍‍⁮‍‏‫⁮⁮‌‫​​⁬⁪​⁭⁯​⁬‭‏‌⁪‭‍⁪‌‮‌‭⁯⁯⁯‮);
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.AutoSize = true;
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -860865484 ^ -2033702707;
          continue;
        case 293:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.TabIndex = 5;
          this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮.HeaderText = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3366482893U);
          num1 = (int) num2 * 1786556988 ^ -1509659711;
          continue;
        case 294:
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.AutoSize = true;
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1345538179 ^ -174043429;
          continue;
        case 295:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.Size = new Size(237, 13);
          num1 = (int) num2 * 2003340725 ^ 869378897;
          continue;
        case 296:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.OffFont = new Font(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(356206439U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * 1758310145 ^ -817055636;
          continue;
        case 297:
          // ISSUE: type reference
          componentResourceManager = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B⁬‫‮‮‪⁬‪‎‎⁪‬‭‪​⁯⁪‌⁫‎‏‏‭‌⁯‭‍⁯‭​​⁯‎‪⁭‭⁮‪​‍‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‫‭‍‮‭⁫‪​‍⁮⁬‮⁪⁫‫⁬‮‌⁬⁬‏⁭‫⁯‌‭‎⁫‪‭​⁮‎‪‭⁪‏‫‪‮(__typeref (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024)));
          num1 = (int) num2 * 764773548 ^ -1142648221;
          continue;
        case 298:
          this.\u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * 495398719 ^ -358810514;
          continue;
        case 299:
          this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3594935548U);
          this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮.ReadOnly = true;
          this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮.Width = 131;
          num1 = (int) num2 * 2028740728 ^ 1845268970;
          continue;
        case 300:
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.BackColor = Color.Transparent;
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.Location = new Point(451, 87);
          num1 = (int) num2 * 1876563376 ^ -88875054;
          continue;
        case 301:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.FlatStyle = FlatStyle.Flat;
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.Location = new Point(100, 28);
          num1 = (int) num2 * -1711370726 ^ 1737235028;
          continue;
        case 302:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.AllowUserToResizeRows = false;
          num1 = (int) num2 * -84510641 ^ -1523507217;
          continue;
        case 303:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3952218443U);
          num1 = (int) num2 * 2032832045 ^ -548612232;
          continue;
        case 304:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮);
          num1 = (int) num2 * -1585905571 ^ 1912202025;
          continue;
        case 305:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          num1 = (int) num2 * -1289587310 ^ 1210393694;
          continue;
        case 306:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Size = new Size(120, 20);
          num1 = (int) num2 * -1331364658 ^ -1796550475;
          continue;
        case 307:
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1326118426 ^ -1046700171;
          continue;
        case 308:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮);
          num1 = (int) num2 * -1301795133 ^ -1862471252;
          continue;
        case 309:
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.AutoSize = true;
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.BackColor = Color.Transparent;
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.Location = new Point(215, 145);
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2889100455U);
          num1 = (int) num2 * 867491574 ^ -1543951627;
          continue;
        case 310:
          this.Controls.Add((Control) this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮);
          this.Controls.Add((Control) this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮);
          this.Controls.Add((Control) this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮);
          this.Controls.Add((Control) this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮);
          num1 = (int) num2 * 1022253276 ^ 937589799;
          continue;
        case 311:
          this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1115944122U);
          num1 = (int) num2 * -50177426 ^ 515442853;
          continue;
        case 312:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          num1 = (int) num2 * -1095973784 ^ -760849826;
          continue;
        case 313:
          this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * -92204609 ^ -1114833371;
          continue;
        case 314:
          this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮.Click += new EventHandler(this.\u202C​‮⁮‍‫⁯‍⁭‬⁪⁮⁬‭‌‪⁭‫⁯‫‫​‌‏‮‮‮‮⁪⁫⁪‮‌‬‮⁮‎‏‬⁭‮);
          num1 = (int) num2 * -2026812871 ^ 1125922181;
          continue;
        case 315:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.BackColor = Color.WhiteSmoke;
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.Location = new Point(356, 234);
          num1 = (int) num2 * -13865491 ^ -1877966678;
          continue;
        case 316:
          this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮.Width = 155;
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.BackColor = SystemColors.WindowFrame;
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.BackgroundImageLayout = ImageLayout.Stretch;
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Controls.Add((Control) this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮);
          num1 = (int) num2 * -817188337 ^ -1258231985;
          continue;
        case 317:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(207350342U);
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -654387623 ^ -1474712038;
          continue;
        case 318:
          this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2891338381U);
          num1 = (int) num2 * -1831479362 ^ -1783345705;
          continue;
        case 319:
          this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4160635692U);
          this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮.Width = 165;
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.AllowUserToAddRows = false;
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * -1437769290 ^ 1639040827;
          continue;
        case 320:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * -202531241 ^ -980273170;
          continue;
        case 321:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          num1 = (int) num2 * -1835890304 ^ 856619049;
          continue;
        case 322:
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.Location = new Point(7, 218);
          num1 = (int) num2 * 769606201 ^ 1074511546;
          continue;
        case 323:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -1110859846 ^ 102814206;
          continue;
        case 324:
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.Location = new Point(221, 369);
          this.\u202E‍⁫‬⁬⁮‏‏‬⁬‬‫⁭‌⁯‬⁯⁪‌⁪‍​​⁯⁯⁭‫⁭‫‮‮⁮‎‏‏⁪‎⁭‌⁪‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3401636292U);
          num1 = (int) num2 * -172822185 ^ -435608701;
          continue;
        case 325:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.AllowUserToAddRows = false;
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * -1685310164 ^ -934828491;
          continue;
        case 326:
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.BackColor = Color.WhiteSmoke;
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Location = new Point(356, 211);
          num1 = (int) num2 * 381772685 ^ 821104542;
          continue;
        case 327:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.Location = new Point(365, 99);
          num1 = (int) num2 * -2057637181 ^ 1775594247;
          continue;
        case 328:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.BackgroundImageLayout = ImageLayout.Center;
          num1 = (int) num2 * -958494756 ^ -186353151;
          continue;
        case 329:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.Click += new EventHandler(this.\u206C⁭⁪‏‪⁬⁫⁪‬​‍‮‪‬‍‏​‌‮‬‫‎​‪‎⁯‎⁭⁫⁬‎‏‮⁫⁮‎⁬‏‍⁬‮);
          num1 = (int) num2 * -1913101881 ^ 1604379922;
          continue;
        case 330:
          ((ISupportInitialize) this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮).EndInit();
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.ResumeLayout(false);
          num1 = (int) num2 * 982896244 ^ 298112347;
          continue;
        case 331:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.BackColor = Color.Transparent;
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Location = new Point(168, 3);
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3624922903U);
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Size = new Size(84, 13);
          num1 = (int) num2 * -1862682881 ^ 112593631;
          continue;
        case 332:
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(151076496U);
          num1 = (int) num2 * -573513670 ^ -1621938289;
          continue;
        case 333:
          this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮.ReadOnly = true;
          num1 = (int) num2 * 1668739715 ^ -593840126;
          continue;
        case 334:
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3791380500U);
          num1 = (int) num2 * -1527767469 ^ -11851983;
          continue;
        case 335:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.Size = new Size(47, 13);
          num1 = (int) num2 * 1675912119 ^ 836689322;
          continue;
        case 336:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u202A‮‭‬⁫⁪‍⁪​‌⁭‭⁪‪⁫‭‏‍‏‭‫⁮‫‫⁪‫‍‫‪⁪‬⁪⁪‮⁫‎⁫​‌‪‮);
          num1 = (int) num2 * 674712765 ^ -1426770192;
          continue;
        case 337:
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1719830975U);
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮.ReadOnly = true;
          num1 = (int) num2 * 1676179327 ^ 765361054;
          continue;
        case 338:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.ScrollBars = ScrollBars.Vertical;
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.Size = new Size(662, 251);
          num1 = (int) num2 * 2076046034 ^ 1575637889;
          continue;
        case 339:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮);
          num1 = (int) num2 * -1948587508 ^ -989583606;
          continue;
        case 340:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -933433657 ^ 765441528;
          continue;
        case 341:
          this.Controls.Add((Control) this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮);
          num1 = (int) num2 * -936375992 ^ 1386158092;
          continue;
        case 342:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.ResumeLayout(false);
          num1 = (int) num2 * 571782893 ^ 1234550570;
          continue;
        case 343:
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.AutoSize = true;
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -1619920794 ^ -1637786069;
          continue;
        case 344:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3617012U);
          num1 = (int) num2 * 1153918483 ^ 660340650;
          continue;
        case 345:
          this.\u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4274529674U);
          num1 = (int) num2 * 836900548 ^ -1982149607;
          continue;
        case 346:
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮.Width = 165;
          num1 = (int) num2 * 899818196 ^ 1252154669;
          continue;
        case 347:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.Size = new Size(65, 65);
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.TabIndex = 20;
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * 60782571 ^ -1193143197;
          continue;
        case 348:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -800927797 ^ 471778151;
          continue;
        case 349:
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.SortMode = DataGridViewColumnSortMode.NotSortable;
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.Width = 132;
          this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1487248769U);
          num1 = (int) num2 * -1669423113 ^ 1552162300;
          continue;
        case 350:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1173320507 ^ -1397699363;
          continue;
        case 351:
          this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮.Width = 132;
          num1 = (int) num2 * 1277090150 ^ -1804686642;
          continue;
        case 352:
          this.\u202B‫⁬⁪⁭‎‫‮‫⁭⁮​⁫⁪‎‪⁫⁯‫⁭⁮‍⁪‬‍‮‭​‌‏‭⁫​⁪‫⁯‬‪⁫⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‫‎​‫‬‌⁫‪⁬⁮‌⁪⁪‮⁮⁭​‮‌⁬‮‎‭⁫‭⁯​⁬⁮​‏‍‎‪‮‫‎⁪⁫‮(this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          num1 = (int) num2 * -1812792435 ^ 1935645025;
          continue;
        case 353:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2711588147U);
          this.\u206E‮⁪⁫⁪​⁫⁬⁮‎‫‫‭⁪‍⁬⁬⁮⁯⁮⁭⁪⁪‏‌‎⁯⁯‍‫‪⁪‪⁮⁪⁭⁮⁭‪⁯‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2567309045U);
          this.\u206E‮⁪⁫⁪​⁫⁬⁮‎‫‫‭⁪‍⁬⁬⁮⁯⁮⁭⁪⁪‏‌‎⁯⁯‍‫‪⁪‪⁮⁪⁭⁮⁭‪⁯‮.Size = new Size(94, 20);
          num1 = (int) num2 * 130945187 ^ -856512169;
          continue;
        case 354:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2365931000U);
          num1 = (int) num2 * -2145259173 ^ -1383902803;
          continue;
        case 355:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.TabIndex = 16 /*0x10*/;
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1914111056U);
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.AutoSize = true;
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1889225875 ^ -509005758;
          continue;
        case 356:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.AllowUserToResizeRows = false;
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          num1 = (int) num2 * -1466321631 ^ -1870949264;
          continue;
        case 357:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2935040197U);
          num1 = (int) num2 * -1629127835 ^ 59529079;
          continue;
        case 358:
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮.Size = new Size(147, 22);
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(962157115U);
          num1 = (int) num2 * -1848458479 ^ 1169121432;
          continue;
        case 359:
          this.Controls.Add((Control) this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮);
          this.Controls.Add((Control) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮);
          this.Controls.Add((Control) this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮);
          num1 = (int) num2 * 1030805837 ^ 2067047842;
          continue;
        case 360:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.OnFont = new Font(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4290614350U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * -1049393815 ^ -718699865;
          continue;
        case 361:
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1366767982 ^ 1973721015;
          continue;
        case 362:
          this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮.Size = new Size(147, 22);
          this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(501133483U);
          num1 = (int) num2 * -947532704 ^ -164262079;
          continue;
        case 363:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -96112232 ^ -2033867385;
          continue;
        case 364:
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.Location = new Point(7, 234);
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3720863792U);
          num1 = (int) num2 * 43964563 ^ -783543562;
          continue;
        case 365:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.ValueChanged += new EventHandler(this.\u206B‎‬‮‫‌‪⁭⁯‍‭‌⁭‏‮⁭⁭⁯​‮⁭‮‏‭⁮‌⁫‫⁫‬‍‎​⁬‌‫⁯​‮⁪‮);
          num1 = (int) num2 * 1546587555 ^ -902396940;
          continue;
        case 366:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(844086274U);
          num1 = (int) num2 * -1662712157 ^ -1368552705;
          continue;
        case 367:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.BackColor = Color.Transparent;
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.BackgroundImage = (Image) componentResourceManager.GetObject(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2902263835U));
          num1 = (int) num2 * -1852516056 ^ 536913401;
          continue;
        case 368:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.Location = new Point(167, 235);
          num1 = (int) num2 * -1417594265 ^ -1897362407;
          continue;
        case 369:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * 53982041 ^ 1529342113;
          continue;
        case 370:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Location = new Point(356, 119);
          num1 = (int) num2 * -105383489 ^ 1962761359;
          continue;
        case 371:
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.TabIndex = 20;
          num1 = (int) num2 * -1628171244 ^ -2132208799;
          continue;
        case 372:
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1533781956U);
          num1 = (int) num2 * -963543901 ^ 1540839265;
          continue;
        case 373:
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.TabIndex = 26;
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.SelectedIndexChanged += new EventHandler(this.\u202B‫⁪⁫‭⁭⁭⁬‫⁮‌‌‬‏‌⁪‫⁪⁭⁬⁪‪​⁬⁬‫⁫‬‍‪⁬⁫‎⁭‌⁫⁬‫⁯⁯‮);
          num1 = (int) num2 * 1852534409 ^ -317672178;
          continue;
        case 374:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.ValueChanged += new EventHandler(this.\u202D⁮⁭⁫​‫‫⁪‎‭‏‬⁪⁯‬⁯‮‭‬‫‎‍​​⁬⁫⁯⁬‬‏‮​‌‪‏⁭‍‪⁭⁫‮);
          num1 = (int) num2 * 982451632 ^ -1248133668;
          continue;
        case 375:
          this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮.Items.AddRange((object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3697237743U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3907497280U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1024371865U));
          num1 = (int) num2 * -2053368062 ^ -684791435;
          continue;
        case 376:
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2651115275U);
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.ReadOnly = true;
          num1 = (int) num2 * 1698461737 ^ -1165855690;
          continue;
        case 377:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.AllowUserToAddRows = false;
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * 1315137251 ^ -1179223088;
          continue;
        case 378:
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.Size = new Size(120, 13);
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.TabIndex = 25;
          num1 = (int) num2 * -766526519 ^ 432998765;
          continue;
        case 379:
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.Location = new Point(596, 3);
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1191159163U);
          num1 = (int) num2 * -48420701 ^ 1168033217;
          continue;
        case 380:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Location = new Point(4, 22);
          num1 = (int) num2 * 938119640 ^ 830442610;
          continue;
        case 381:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3801662524U);
          num1 = (int) num2 * 1700882290 ^ -58000896;
          continue;
        case 382:
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1233314748 ^ -1081508248;
          continue;
        case 383:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.SelectionChanged += new EventHandler(this.\u200C‬⁬⁬‮‮⁯⁮⁮⁭‎‍‍⁭‍‬​‫‏‭‭‍‌‌‪⁪‏‭‎‍⁪⁮‏⁭‏⁪⁭‌‍⁮‮);
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.HeaderText = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3201966565U);
          num1 = (int) num2 * -185022724 ^ -1440216929;
          continue;
        case 384:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          this.\u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          num1 = (int) num2 * -1842567827 ^ 1961916789;
          continue;
        case 385:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          num1 = (int) num2 * -478483056 ^ -1898969776;
          continue;
        case 386:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3801283407U);
          num1 = (int) num2 * 1113250517 ^ 1515177644;
          continue;
        case 387:
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(642719705U);
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.Size = new Size(218, 26);
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.TabIndex = 21;
          num1 = (int) num2 * -2102507141 ^ -159514051;
          continue;
        case 388:
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1683236399U);
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.Size = new Size(21, 13);
          num1 = (int) num2 * -1555720215 ^ 347440281;
          continue;
        case 389:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3187043099U);
          num1 = (int) num2 * -1458288255 ^ -1213547359;
          continue;
        case 390:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮);
          num1 = (int) num2 * 1591738224 ^ 1312029732;
          continue;
        case 391:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.MouseEnter += new EventHandler(this.\u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮);
          num1 = (int) num2 * 1150412235 ^ -1708170853;
          continue;
        case 392:
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.EndInit();
          num1 = (int) num2 * 307438032 ^ 521618088;
          continue;
        case 393:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮);
          num1 = (int) num2 * -252505058 ^ 1308451443;
          continue;
        case 394:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.Click += new EventHandler(this.\u206B‮‮‪‌‬‪⁭​⁯‫⁯‪‭‏‮⁭⁪‭‬​⁯‮⁮​⁭⁭‭⁪⁬‮‌‪⁪⁭‫‪⁪‫‌‮);
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.MouseEnter += new EventHandler(this.\u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮);
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.MouseLeave += new EventHandler(this.\u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮);
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -547557183 ^ 1061134866;
          continue;
        case 395:
          this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2670515535U);
          this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮.Width = 132;
          this.\u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1816509827U);
          this.\u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4294782736U);
          num1 = (int) num2 * -534764649 ^ -1789094686;
          continue;
        case 396:
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.Location = new Point(215, 191);
          num1 = (int) num2 * 126315791 ^ -549993317;
          continue;
        case 397:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * -839914443 ^ 704508956;
          continue;
        case 398:
          this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          this.\u200D‮‏‎‌‌⁫‌⁮‭⁮‫‮‌‍‎⁯‫‏⁯‬‌‍⁮⁯‮‮⁬‍‪⁬‍⁫‫⁪‬⁪⁭‫‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * -797851656 ^ -395220035;
          continue;
        case 399:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.TabIndex = 10;
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.SelectionChanged += new EventHandler(this.\u200C‌‬‍‭‏‫‮‏⁭⁭‬⁫‪⁫⁮‭⁯‎‌‪‮‬⁫⁬⁯⁬‪‬‍⁮⁫‪⁪‎‌‫‍‏‌‮);
          num1 = (int) num2 * -2039549191 ^ 1111881569;
          continue;
        case 400:
          this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * -277811929 ^ 838571227;
          continue;
        case 401:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -1138752458 ^ -2083881148;
          continue;
        case 402:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.AutoSize = true;
          num1 = (int) num2 * 1465029481 ^ -1755644591;
          continue;
        case 403:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.Columns.AddRange((DataGridViewColumn) this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮, (DataGridViewColumn) this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮, (DataGridViewColumn) this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮, (DataGridViewColumn) this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮, (DataGridViewColumn) this.\u200F‪‏⁮‎⁮⁪⁪‫‏‭‍‫⁬‪‭​⁮‌⁫​‍⁫‌⁮⁪‫‫​⁯⁬‏⁪‬​​⁫⁫⁯⁪‮);
          num1 = (int) num2 * -1060034145 ^ -1375152135;
          continue;
        case 404:
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4237221009U);
          num1 = (int) num2 * -565155486 ^ 2090418537;
          continue;
        case 405:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.TabIndex = 18;
          num1 = (int) num2 * -1096661609 ^ 579955813;
          continue;
        case 406:
          this.\u200B‭‪‪‏⁪⁬‬‭‮⁮⁭‎⁬‪‫‎⁪‪⁬‭⁮‮⁯⁬⁭⁮⁮⁭⁪​‍‎⁪⁪‮⁬⁮⁮‎‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(731645299U);
          num1 = (int) num2 * -23207471 ^ 1610117783;
          continue;
        case 407:
          this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮.Width = 155;
          num1 = (int) num2 * 1987220795 ^ -1847229167;
          continue;
        case 408:
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.AutoSize = true;
          this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -598118597 ^ -264867480;
          continue;
        case 409:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Controls.Add((Control) this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮);
          num1 = (int) num2 * 666650040 ^ 597304619;
          continue;
        case 410:
          this.\u202B​‮‌‌‭‭‏‮​‫‪‏‪‌⁮⁮⁪‍‪⁯‌‭​‪⁫​⁯‎‏‭‌⁫⁯⁮​‌⁮‌‪‮.ReadOnly = true;
          num1 = (int) num2 * -683554242 ^ -2104310932;
          continue;
        case 411:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.TabIndex = 20;
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3692104285U);
          num1 = (int) num2 * 656640236 ^ 629374815;
          continue;
        case 412:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * -334681962 ^ 374366822;
          continue;
        case 413:
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          num1 = (int) num2 * 70437248 ^ -947170915;
          continue;
        case 414:
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1774309379U);
          num1 = (int) num2 * 616302776 ^ 1903122720;
          continue;
        case 415:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.BackColor = Color.WhiteSmoke;
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Location = new Point(356, 165);
          num1 = (int) num2 * -1733719482 ^ -1710603280;
          continue;
        case 416:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.OnFont = new Font(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(356206439U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * -131309924 ^ -466231501;
          continue;
        case 417:
          this.Controls.Add((Control) this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮);
          num1 = (int) num2 * 1011226123 ^ -736989786;
          continue;
        case 418:
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2859505733U);
          num1 = (int) num2 * 1254152004 ^ -1986252967;
          continue;
        case 419:
          this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          num1 = (int) num2 * -1493142178 ^ 1764313201;
          continue;
        case 420:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Size = new Size(686, 402);
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.TabIndex = 7;
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(82488455U);
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.AutoSize = true;
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 2128392864 ^ 943178824;
          continue;
        case 421:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2767289142U);
          num1 = (int) num2 * 558237330 ^ 934108206;
          continue;
        case 422:
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.Location = new Point(451, 369);
          num1 = (int) num2 * -1796845848 ^ 2009602044;
          continue;
        case 423:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.AutoSize = true;
          num1 = (int) num2 * -1554910512 ^ -1619553107;
          continue;
        case 424:
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‪‫‬​‎‮‎⁪‮‎⁫‎⁮‮‎‍⁮‫‍‮‪‍⁬⁫‪‮⁭⁪⁪⁫‍⁯‍‭‎⁭‍​⁮‮();
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‫‍⁪‭⁯‍​⁪‪⁭⁭⁮‬‍⁭⁭⁬‍‮⁫‏‭‪‍⁭‍‭⁮‬‌‎‍⁬‭⁭⁫⁪​‏‮();
          num1 = (int) num2 * 565426832 ^ -2101277931;
          continue;
        case 425:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * -449098263 ^ 1395362271;
          continue;
        case 426:
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -163564981 ^ -1680896071;
          continue;
        case 427:
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.ResumeLayout(false);
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.PerformLayout();
          ((ISupportInitialize) this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮).EndInit();
          num1 = (int) num2 * -1741784541 ^ -818252643;
          continue;
        case 428:
          this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮.Size = new Size(65, 20);
          num1 = (int) num2 * 1544181091 ^ -2013260310;
          continue;
        case 429:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.AllowUserToResizeRows = false;
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          num1 = (int) num2 * 1810158522 ^ -1049314804;
          continue;
        case 430:
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.AutoSize = true;
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.BackColor = Color.Transparent;
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.Location = new Point(245, 8);
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(34080477U);
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.Size = new Size(177, 13);
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.TabIndex = 23;
          this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1016093366U);
          num1 = (int) num2 * -702926124 ^ -1287500712;
          continue;
        case 431:
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.FormattingEnabled = true;
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.Location = new Point(134, 19);
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3922898114U);
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.Size = new Size(152, 21);
          num1 = (int) num2 * 109882798 ^ 833669320;
          continue;
        case 432:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * -1336051811 ^ 899469606;
          continue;
        case 433:
          this.AutoScaleDimensions = new SizeF(6f, 13f);
          this.AutoScaleMode = AutoScaleMode.Font;
          this.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * 658415095 ^ -474104886;
          continue;
        case 434:
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.Location = new Point(159, 260);
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1465559351U);
          num1 = (int) num2 * -1384725580 ^ 490157481;
          continue;
        case 435:
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.ReadOnly = true;
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.Resizable = DataGridViewTriState.True;
          num1 = (int) num2 * 1150115264 ^ 1614596843;
          continue;
        case 436:
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.TabIndex = 9;
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u200B‪‏‎‏‎‪‪‏‭‏‫⁯‎⁯‏⁬‭⁭‪⁫‭‮⁫⁯‫‬​‏‫⁮‮‍⁮⁯⁫⁭‌‬‎‮);
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.AutoSize = true;
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.BackColor = Color.Transparent;
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.Location = new Point(482, 147);
          num1 = (int) num2 * -1907403540 ^ 932989435;
          continue;
        case 437:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.FlatAppearance.BorderSize = 0;
          num1 = (int) num2 * -1031810492 ^ 1213020900;
          continue;
        case 438:
          this.\u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * 131536821 ^ -1237017045;
          continue;
        case 439:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‪‫‬​‎‮‎⁪‮‎⁫‎⁮‮‎‍⁮‫‍‮‪‍⁬⁫‪‮⁭⁪⁪⁫‍⁯‍‭‎⁭‍​⁮‮();
          num1 = (int) num2 * -675091197 ^ 1748278296;
          continue;
        case 440:
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1420198282U);
          this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮.Items.AddRange((object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1116281321U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2175540835U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1466536141U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4198414774U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4162195662U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1397004125U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3196968477U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2165967171U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3838398893U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2027116491U));
          num1 = (int) num2 * 994330335 ^ -1116807010;
          continue;
        case 441:
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.Size = new Size(153, 21);
          num1 = (int) num2 * 869411461 ^ -1028002531;
          continue;
        case 442:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1500239682U);
          num1 = (int) num2 * 1865461378 ^ 444878213;
          continue;
        case 443:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮);
          num1 = (int) num2 * -1161865963 ^ 275141630;
          continue;
        case 444:
          ((ISupportInitialize) this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮).EndInit();
          ((ISupportInitialize) this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮).EndInit();
          num1 = (int) num2 * -1302023504 ^ 1935748921;
          continue;
        case 445:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.Columns.AddRange((DataGridViewColumn) this.\u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮, (DataGridViewColumn) this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮, (DataGridViewColumn) this.\u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮, (DataGridViewColumn) this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮, (DataGridViewColumn) this.\u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮);
          num1 = (int) num2 * 881923150 ^ -1877754500;
          continue;
        case 446:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -1340019658 ^ -780129390;
          continue;
        case 447:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(839832873U);
          num1 = (int) num2 * -322332601 ^ -1290536361;
          continue;
        case 448:
          this.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2555080081U);
          num1 = (int) num2 * 1465818764 ^ 1768319923;
          continue;
        case 449:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.Click += new EventHandler(this.\u200F⁫⁮‌‫‬⁮​‪⁪‭⁯‌‎⁮⁬⁪⁬⁮‪‮‏‪⁯⁯‬⁬‬‬⁭⁬⁮‭‌⁪‮‮‭⁪⁪‮);
          num1 = (int) num2 * 276123399 ^ -1511169501;
          continue;
        case 450:
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(119726047U);
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.UseVisualStyleBackColor = true;
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.Click += new EventHandler(this.\u206F⁫⁯​⁮‫‬⁬⁪‮⁫‭​⁮‌⁮⁪‪​⁪⁭‎⁭⁪⁮​‭‬‭‮⁭⁭​⁯‪⁭⁬‫‭‏‮);
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -785130131 ^ -1648288062;
          continue;
        case 451:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.PerformLayout();
          num1 = (int) num2 * 354504502 ^ -816588103;
          continue;
        case 452:
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1484491827 ^ -1468331777;
          continue;
        case 453:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.TabIndex = 25;
          num1 = (int) num2 * 373860979 ^ 1436453961;
          continue;
        case 454:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Location = new Point(4, 22);
          num1 = (int) num2 * 1248227716 ^ -1379315130;
          continue;
        case 455:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 546883031 ^ 290679369;
          continue;
        case 456:
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3460778336U);
          num1 = (int) num2 * -2113799553 ^ -1431342316;
          continue;
        case 457:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          num1 = (int) num2 * 475458066 ^ 1462551856;
          continue;
        case 458:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(696491900U);
          num1 = (int) num2 * -1763034877 ^ 501634548;
          continue;
        case 459:
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.TabIndex = 29;
          this.\u200E​⁫‏‪‌‪⁯⁯‬‮‭⁬‬⁪⁫‌⁮‭⁪⁭⁫‪‌‏‏⁫‮‍‭​⁬‌‬‏‎‎‫‫⁮‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2880054332U);
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.BackColor = Color.WhiteSmoke;
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.FormattingEnabled = true;
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.Location = new Point(293, 19);
          num1 = (int) num2 * -1390184291 ^ 95474459;
          continue;
        case 460:
          this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮.Visible = true;
          num1 = (int) num2 * 1335327698 ^ -1302101975;
          continue;
        case 461:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1148759149 ^ -163797225;
          continue;
        case 462:
          this.Controls.Add((Control) this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮);
          this.Controls.Add((Control) this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮);
          num1 = (int) num2 * 1665819186 ^ 1735068913;
          continue;
        case 463:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.TabIndex = 11;
          num1 = (int) num2 * 922800435 ^ -813416891;
          continue;
        case 464:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.MultiSelect = false;
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(418578941U);
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.ReadOnly = true;
          num1 = (int) num2 * -69953372 ^ -1666426196;
          continue;
        case 465:
          this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(315750578U);
          num1 = (int) num2 * 1379276445 ^ -594799851;
          continue;
        case 466:
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * -1744229149 ^ 9810937;
          continue;
        case 467:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.AutoSize = true;
          num1 = (int) num2 * 1515644153 ^ 376590440;
          continue;
        case 468:
          this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮.Width = 164;
          this.\u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2459227436U);
          num1 = (int) num2 * -694813336 ^ 728029962;
          continue;
        case 469:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 304223390 ^ -865010581;
          continue;
        case 470:
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.CalendarMonthBackground = Color.WhiteSmoke;
          num1 = (int) num2 * 350088799 ^ -778184359;
          continue;
        case 471:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮);
          num1 = (int) num2 * 1117582580 ^ -530915680;
          continue;
        case 472:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4091069123U);
          num1 = (int) num2 * -2145938033 ^ 876172947;
          continue;
        case 473:
          this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮.Items.AddRange((object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(93557901U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2333834420U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2643370043U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3402045356U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1037202021U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(456057195U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3974871253U), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2165967171U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(139210907U), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(14903056U));
          num1 = (int) num2 * -1846552426 ^ -841496310;
          continue;
        case 474:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1783816270U);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Size = new Size(686, 400);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.TabIndex = 8;
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2244069451U);
          num1 = (int) num2 * -671339985 ^ 790893270;
          continue;
        case 475:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -227648816 ^ -455460430;
          continue;
        case 476:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮);
          num1 = (int) num2 * 22861460 ^ 1303835573;
          continue;
        case 477:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.MouseEnter += new EventHandler(this.\u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮);
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.MouseLeave += new EventHandler(this.\u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮);
          num1 = (int) num2 * 1710280818 ^ -1608325399;
          continue;
        case 478:
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          num1 = (int) num2 * 1910327812 ^ 200823522;
          continue;
        case 479:
          this.\u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * -199442149 ^ -2107186232;
          continue;
        case 480:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.MouseEnter += new EventHandler(this.\u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮);
          num1 = (int) num2 * -694335521 ^ -1550751419;
          continue;
        case 481:
          this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮.Click += new EventHandler(this.\u200C‍‮⁭​⁫​⁪‬⁬⁭⁫‭‌⁯⁯‏‫‭⁮⁪‏‏⁭⁯⁮‪⁮⁪‮⁯‬‌‍⁫⁪‪‎‍⁬‮);
          num1 = (int) num2 * -2101390560 ^ 11680049;
          continue;
        case 482:
          this.\u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮.HeaderText = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2171624014U);
          this.\u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4067696545U);
          num1 = (int) num2 * 1913990013 ^ 637907488;
          continue;
        case 483:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.OnFont = new Font(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1034455148U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.Size = new Size(45, 19);
          num1 = (int) num2 * -986714355 ^ 1491881230;
          continue;
        case 484:
          this.\u206B‪⁯⁪⁪‎⁭‌‭‫⁯⁫‬⁮⁫‭‮‮⁯⁮‎‬‮‏⁮‏⁭​⁬‭‪⁮⁮‌‎⁮⁭‭​‭‮.Width = 131;
          num1 = (int) num2 * -904181759 ^ -417292486;
          continue;
        case 485:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(880729600U);
          num1 = (int) num2 * -615097451 ^ -1742308040;
          continue;
        case 486:
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * -951432747 ^ -1609791848;
          continue;
        case 487:
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(71686463U);
          this.\u200D⁭‬⁭‮‭‏⁬⁪‍‏‬‭⁯​⁫⁮‬‌⁬⁫‮‮‬⁭‎‌‭‬‏⁪⁯⁪⁪⁭‍⁪⁪‏‍‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2279827217U);
          num1 = (int) num2 * -734510793 ^ -753646671;
          continue;
        case 488:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.PerformLayout();
          num1 = (int) num2 * 253165593 ^ -920067811;
          continue;
        case 489:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮);
          num1 = (int) num2 * 542017841 ^ 2000389669;
          continue;
        case 490:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.BackgroundImageLayout = ImageLayout.Center;
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.Cursor = Cursors.Default;
          num1 = (int) num2 * -2054663878 ^ -1468180929;
          continue;
        case 491:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.AutoSize = true;
          num1 = (int) num2 * 464028911 ^ -334814841;
          continue;
        case 492:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -1456399430 ^ 1516479668;
          continue;
        case 493:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.Size = new Size(208 /*0xD0*/, 26);
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.TabIndex = 20;
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2650219110U);
          num1 = (int) num2 * -1903704360 ^ -2115892476;
          continue;
        case 494:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮);
          num1 = (int) num2 * -1809537736 ^ 102070206;
          continue;
        case 495:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -1567174224 ^ 459574181;
          continue;
        case 496:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.Location = new Point(482, 216);
          num1 = (int) num2 * -732581578 ^ 883273050;
          continue;
        case 497:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Controls.Add((Control) this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮);
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Controls.Add((Control) this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮);
          num1 = (int) num2 * 324035279 ^ 1925972473;
          continue;
        case 498:
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.TabIndex = 5;
          num1 = (int) num2 * -814519853 ^ -947676343;
          continue;
        case 499:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -198332145 ^ -157632274;
          continue;
        case 500:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.TextChanged += new EventHandler(this.\u200E‎‬‮‮⁮‫​⁫‌⁭⁪⁭‪‎⁭​⁯⁮⁪⁮⁪‮‫⁮⁯‮‏‌‎‍‪‍​‏‬⁭‫⁪‭‮);
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.FlatStyle = FlatStyle.Flat;
          this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮.Location = new Point(459, 228);
          num1 = (int) num2 * -1788927666 ^ -1781200795;
          continue;
        case 501:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 1342804209 ^ -1764391938;
          continue;
        case 502:
          this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2014600926U);
          num1 = (int) num2 * 1916305577 ^ -729604906;
          continue;
        case 503:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.ValueChanged += new EventHandler(this.\u206C‮‍‌⁭‫⁪‭‪​‍‌‬⁭‬⁯⁪‌‍⁭‎‭⁯⁭‏‪‌‎⁮‬⁯‌⁫⁯⁭⁬‏‮‍‬‮);
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.BackColor = Color.WhiteSmoke;
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Location = new Point(356, 142);
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          num1 = (int) num2 * 896910137 ^ 675483659;
          continue;
        case 504:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.TabIndex = 31 /*0x1F*/;
          num1 = (int) num2 * -1521903614 ^ 1166141874;
          continue;
        case 505:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1340976320 ^ 1298621939;
          continue;
        case 506:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(935484632U);
          num1 = (int) num2 * -891447344 ^ -217846608;
          continue;
        case 507:
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.Location = new Point(269, 47);
          this.\u200E⁮⁫‎⁭‪⁯⁯⁪‭‎⁪⁪⁪‎‬‏‮‮⁪⁮⁭‬‫⁭‏‮⁪⁫‌‎⁯⁮‏⁮⁭⁪‪​‍‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(860093670U);
          num1 = (int) num2 * -1950995813 ^ 477112224;
          continue;
        case 508:
          this.\u206E⁬‮‮‭‮‎​​‬‫⁬‬‮‫⁮⁬⁬‭⁭‭​⁬⁪‎⁪‮‮⁮⁫‭‎‫⁮‎⁯⁬‌⁬‭‮.TabIndex = 30;
          num1 = (int) num2 * -260873744 ^ -1387759214;
          continue;
        case 509:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮);
          num1 = (int) num2 * 872777048 ^ 340983009;
          continue;
        case 510:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.Click += new EventHandler(this.\u206E⁪‏⁯‎‏⁪⁭‪‬‎‫‬⁪⁮⁫‎‎‏‮​‬⁮⁫‎⁭⁭⁯​⁭‮‮‪‏⁯⁫‮‫‌‌‮);
          num1 = (int) num2 * -442163872 ^ 383462298;
          continue;
        case 511 /*0x01FF*/:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.FlatStyle = FlatStyle.Flat;
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.Location = new Point(328, 28);
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2699450542U);
          num1 = (int) num2 * 693524901 ^ 1743181839;
          continue;
        case 512 /*0x0200*/:
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.Location = new Point(482, 124);
          num1 = (int) num2 * -1738410307 ^ 676765533;
          continue;
        case 513:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1989638237U);
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Size = new Size(686, 402);
          num1 = (int) num2 * 1942734089 ^ 2012730463;
          continue;
        case 514:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4143980252U);
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.Size = new Size(208 /*0xD0*/, 26);
          num1 = (int) num2 * 1059221171 ^ -1654712246;
          continue;
        case 515:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮);
          num1 = (int) num2 * -1341131972 ^ -170720164;
          continue;
        case 516:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.FormattingEnabled = true;
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.Items.AddRange(new object[2]
          {
            (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(386363888U),
            (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1564766969U)
          });
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.Location = new Point(7, 19);
          num1 = (int) num2 * -1749414450 ^ 1480881432;
          continue;
        case 517:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.ResumeLayout(false);
          num1 = (int) num2 * 269268737 ^ 1978700846;
          continue;
        case 518:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(352236238U);
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.OffFont = new Font(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4290614350U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * 1347565077 ^ -1003330587;
          continue;
        case 519:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          num1 = (int) num2 * 68209154 ^ -1379536349;
          continue;
        case 520:
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.Location = new Point(25, 95);
          num1 = (int) num2 * -687898223 ^ -1347323542;
          continue;
        case 521:
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.Location = new Point(451, 369);
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(207540074U);
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.Size = new Size(218, 26);
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.TabIndex = 21;
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2055190961U);
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮.UseVisualStyleBackColor = true;
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -178024650 ^ -1651213390;
          continue;
        case 522:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Maximum = new Decimal(new int[4]
          {
            1000000,
            0,
            0,
            0
          });
          num1 = (int) num2 * 1821965759 ^ -388592008;
          continue;
        case 523:
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4229919803U);
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.Size = new Size(37, 13);
          num1 = (int) num2 * 1886474906 ^ -563782028;
          continue;
        case 524:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.Location = new Point(7, 258);
          num1 = (int) num2 * -465116964 ^ -1061618582;
          continue;
        case 525:
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1213185213U);
          num1 = (int) num2 * 781050068 ^ 194468025;
          continue;
        case 526:
          this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * 1356667957 ^ -296703307;
          continue;
        case 527:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u200C‬⁮‫⁫⁮‮‮‬⁪‪‌‮⁫‏⁪⁮‌‍‬⁬⁯⁮⁬⁬‪​‫‪‏⁯‏⁪​⁬​‮⁮‏⁬‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮);
          num1 = (int) num2 * -690731806 ^ -1768645888;
          continue;
        case 528:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.SelectedIndexChanged += new EventHandler(this.\u206C‬⁫‭⁯⁭‭‮‮‪⁮⁪‏‍⁬‭‌‍⁬‬⁯‬⁬‬⁬⁭⁮‪‏‎‭⁫‮​⁫⁯‫⁮⁭‮‮);
          num1 = (int) num2 * 1720627276 ^ 1261019691;
          continue;
        case 529:
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.Location = new Point(451, 19);
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(936624439U);
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.Size = new Size(122, 21);
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.TabIndex = 30;
          num1 = (int) num2 * 1547839346 ^ -1825459361;
          continue;
        case 530:
          this.Controls.Add((Control) this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮);
          this.Controls.Add((Control) this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮);
          num1 = (int) num2 * -1854495931 ^ 838961463;
          continue;
        case 531:
          this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮();
          num1 = (int) num2 * -805605768 ^ -1393398710;
          continue;
        case 532:
          this.\u200B⁯‫‬‏⁭‍‭‍‬‮⁭⁮‫‭‎‌‍⁫‏⁯‍⁪‍‫⁫⁪‏‫‮‏⁬⁪⁫⁬‪‍‍‌‫‮.Interval = 1000;
          num1 = (int) num2 * -1673964571 ^ -29636594;
          continue;
        case 533:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮);
          num1 = (int) num2 * -1275450543 ^ -1765161755;
          continue;
        case 534:
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.TabIndex = 36;
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1738482994U);
          this.\u206C⁮⁬⁫⁭⁪‌‎⁯‪⁫⁮⁭‍‏⁯‭‪‏⁫‌‭‭‏‌‬⁭‫‌⁫‌‫‭⁬‍⁫⁭‏‎⁬‮.AutoSize = true;
          num1 = (int) num2 * 378041017 ^ -1918789380;
          continue;
        case 535:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.Location = new Point(7, 6);
          num1 = (int) num2 * 1935878112 ^ -259504025;
          continue;
        case 536:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮.Size = new Size(662, 20);
          num1 = (int) num2 * 1378820918 ^ 220498351;
          continue;
        case 537:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Click += new EventHandler(this.\u202B‪⁭‪‫⁫‫‪⁬⁭⁭⁭⁪⁫⁪‌⁮‏‬‫⁮⁮‏⁮⁯‫⁬⁪‍⁯‏‎‍‮​​‭‭⁫⁮‮);
          num1 = (int) num2 * -160980262 ^ -54596747;
          continue;
        case 538:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.EndInit();
          num1 = (int) num2 * 766254143 ^ 748182480;
          continue;
        case 539:
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.SelectedIndexChanged += new EventHandler(this.\u202C​⁪‬‍‮‍‬‪‪‭‪⁫‭⁫⁪‫‌⁯‌⁭‬‫⁯⁬⁯‭‮​⁭‮⁬‏⁭⁪⁫⁯⁯⁫⁫‮);
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.AutoSize = true;
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.BackColor = Color.Transparent;
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.Location = new Point(317, 3);
          this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3114480912U);
          num1 = (int) num2 * 1572178028 ^ 471749129;
          continue;
        case 540:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * -939128830 ^ 1018181201;
          continue;
        case 541:
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3066775846U);
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.AutoSize = true;
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1054472454 ^ -1877744718;
          continue;
        case 542:
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.ValueChanged += new EventHandler(this.\u202B‮⁮‬‫‬‭‫‪‮⁪‍‌‌⁬​‏⁯⁭‎‏⁫⁭⁬‏⁫‎⁯⁭⁬‫⁯‍‫⁮⁭⁮‎⁪‍‮);
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.AutoSize = true;
          num1 = (int) num2 * -878034213 ^ -285832815;
          continue;
        case 543:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮);
          num1 = (int) num2 * -1261727967 ^ 1058165151;
          continue;
        case 544:
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.Size = new Size(76, 13);
          num1 = (int) num2 * -1182501289 ^ -2083936998;
          continue;
        case 545:
          this.\u206F‭‪‍‫‪‫‬‌‬‫‏⁭⁭⁯⁫⁬⁯‎​‍⁯⁭‎‭‫‏⁭‭‌⁮⁭⁭⁪‮‪⁭‌​‌‮.AutoSize = true;
          num1 = (int) num2 * 1305743258 ^ -1237545879;
          continue;
        case 546:
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.Location = new Point(482, 170);
          this.\u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2258220904U);
          num1 = (int) num2 * 653133096 ^ 701591646;
          continue;
        case 547:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮.Location = new Point(7, 24);
          num1 = (int) num2 * 690572965 ^ 1267698742;
          continue;
        case 548:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.Location = new Point(7, 46);
          num1 = (int) num2 * 1463498183 ^ 1787517393;
          continue;
        case 549:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮);
          num1 = (int) num2 * 1135380915 ^ -1515000475;
          continue;
        case 550:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮);
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Controls.Add((Control) this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮);
          num1 = (int) num2 * -1070500021 ^ 1138961211;
          continue;
        case 551:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.PerformLayout();
          num1 = (int) num2 * -13182592 ^ 1696321527;
          continue;
        case 552:
          this.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4256602336U);
          this.Shown += new EventHandler(this.\u206F‬‍⁭​⁯‫‌⁮‪‎‫‏‪‌‏‌​‎⁪⁮⁮‍⁯⁯⁯‍‍⁫‍‭‮‫‪‬⁪⁭⁮⁫‎‮);
          num1 = (int) num2 * 2072773286 ^ -1416959373;
          continue;
        case 553:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2015508577U);
          num1 = (int) num2 * -495094028 ^ -1224868745;
          continue;
        case 554:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.AutoSize = true;
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Location = new Point(2, 384);
          num1 = (int) num2 * -1257036817 ^ 950091514;
          continue;
        case 555:
          this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮.AutoSize = true;
          num1 = (int) num2 * -1224418283 ^ -1197418005;
          continue;
        case 556:
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.TabIndex = 20;
          num1 = (int) num2 * 1660732772 ^ -688264120;
          continue;
        case 557:
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮.ReadOnly = true;
          num1 = (int) num2 * 1737496541 ^ 805852351;
          continue;
        case 558:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.SelectionMode = DataGridViewSelectionMode.CellSelect;
          num1 = (int) num2 * -858408369 ^ -168462631;
          continue;
        case 559:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.Size = new Size(121, 21);
          num1 = (int) num2 * -1533864878 ^ 955438044;
          continue;
        case 560:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮);
          num1 = (int) num2 * -1420639417 ^ 1722104097;
          continue;
        case 561:
          this.\u202E‍‮⁯‌⁭‌⁭​‌‪‬‮⁯‏⁮‏‍⁫​‫‏‪⁮‫‭‮‍⁭⁪‌‎‌‏‭‍‮‮​‏‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3140965271U);
          num1 = (int) num2 * -657929733 ^ -1502638868;
          continue;
        case 562:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.BackgroundImage = (Image) componentResourceManager.GetObject(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4290770635U));
          num1 = (int) num2 * 183606858 ^ 1956983192;
          continue;
        case 563:
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -217689673 ^ -1142458172;
          continue;
        case 564:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.TabIndex = 23;
          num1 = (int) num2 * 860661698 ^ -1309372845;
          continue;
        case 565:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 871926196 ^ -545100964;
          continue;
        case 566:
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.TabIndex = 7;
          this.\u200E‫⁬⁯‫⁫⁯​‮‮‏⁪⁫​‫‭⁫‎‬‬‏​​⁫​⁬⁫‍⁭⁬‭‌⁪‫⁪‫⁯​⁭‬‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3064555534U);
          num1 = (int) num2 * 1284385941 ^ 1109866691;
          continue;
        case 567:
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.Size = new Size(662, 170);
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.TabIndex = 11;
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.Text = "";
          num1 = (int) num2 * -1677224182 ^ -2112243865;
          continue;
        case 568:
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.CustomFormat = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1323973129U);
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.Format = DateTimePickerFormat.Custom;
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.Location = new Point(483, 1);
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(568570412U);
          this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮.Size = new Size(200, 20);
          num1 = (int) num2 * 3291883 ^ 1356801352;
          continue;
        case 569:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.Location = new Point(7, 6);
          num1 = (int) num2 * -600412317 ^ -1267405920;
          continue;
        case 570:
          this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮.Columns.AddRange((DataGridViewColumn) this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮, (DataGridViewColumn) this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮, (DataGridViewColumn) this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮, (DataGridViewColumn) this.\u206A⁪⁫‪‌⁪‏‎​‫‌​⁬‍‫‏⁭​⁯⁯⁯‪‏‭​‌‎⁭⁬‬‌‌‪⁮⁫‏‭⁬⁪‪‮);
          num1 = (int) num2 * 1065828495 ^ 1312105280;
          continue;
        case 571:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.BackColor = SystemColors.WindowFrame;
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.BackgroundImageLayout = ImageLayout.Stretch;
          num1 = (int) num2 * 1591122188 ^ 474618091;
          continue;
        case 572:
          this.\u200C‌‭⁬‭‮‌⁯⁬‭‌‬‫‮‍‎⁯⁬⁬⁬⁬⁫‫‏‍⁬⁫‌‮⁯‬⁫‬‫⁫‫‫⁭‏‫‮.Width = 132;
          this.\u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4119933541U);
          num1 = (int) num2 * -673373571 ^ 1391582218;
          continue;
        case 573:
          this.\u206E‬‎⁭‏‍‪⁮​‮‭⁫‪‏⁬‭‮⁯⁫‬‮‭​‪‫⁬‏⁭‌‬‬‬‎‭‪⁬‌‭‮⁬‮.Width = 132;
          num1 = (int) num2 * 1654646726 ^ -209506654;
          continue;
        case 574:
          this.\u200F​‍‫‎​​⁪‪‬⁭‭⁫⁪⁯‪⁬⁪‍‎‌‪⁯⁮⁭‫⁬⁮⁯⁬​‫‭⁮‌⁯⁮⁭⁯‫‮.Size = new Size(218, 26);
          num1 = (int) num2 * 497855955 ^ -951679775;
          continue;
        case 575:
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.BackColor = Color.Transparent;
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.Location = new Point(167, 166);
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1739164594U);
          num1 = (int) num2 * 190929560 ^ -1036207226;
          continue;
        case 576:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.Location = new Point(215, 168);
          num1 = (int) num2 * -2133898157 ^ -662126803;
          continue;
        case 577:
          this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3613666251U);
          num1 = (int) num2 * -810933949 ^ -2137611314;
          continue;
        case 578:
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.BackColor = SystemColors.WindowFrame;
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.BackgroundImageLayout = ImageLayout.Stretch;
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.Location = new Point(4, 22);
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2387068296U);
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.Size = new Size(686, 402);
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.TabIndex = 6;
          num1 = (int) num2 * -1739648551 ^ -1546587289;
          continue;
        case 579:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1967787329U);
          num1 = (int) num2 * 281223048 ^ -1383101243;
          continue;
        case 580:
          this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * 1586379046 ^ -679929077;
          continue;
        case 581:
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.TabIndex = 1;
          this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1764974036U);
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.FlatStyle = FlatStyle.Flat;
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.Location = new Point(221, 369);
          num1 = (int) num2 * -1192650319 ^ 1870996190;
          continue;
        case 582:
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4162611865U);
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.Size = new Size(21, 13);
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.TabIndex = 3;
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1052055335U);
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.BackColor = Color.Transparent;
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.Location = new Point(167, 120);
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3314794891U);
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.OffFont = new Font(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2958081165U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.OnFont = new Font(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(356206439U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * 133382053 ^ 826126707;
          continue;
        case 583:
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.TabIndex = 15;
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.SelectedIndexChanged += new EventHandler(this.\u202A‪​⁬⁪‌⁫‍⁮⁯‫⁬⁬⁮‍‭‎⁫⁪​⁫‎‏⁫⁪‮⁮⁪‎‫‫‍‏‍​⁬‮‎⁮‏‮);
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.AutoSize = true;
          this.\u200D​‪‏⁬‭‫‬‬‍‌‬‌⁯‪‌‌‍⁫⁯⁪‎⁪‪‬‭⁯⁬⁪‬⁬⁭‍⁪‪‪⁪⁭‮⁯‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 2134399617 ^ 1511570918;
          continue;
        case 584:
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮();
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‪‫‬​‎‮‎⁪‮‎⁫‎⁮‮‎‍⁮‫‍‮‪‍⁬⁫‪‮⁭⁪⁪⁫‍⁯‍‭‎⁭‍​⁮‮();
          num1 = (int) num2 * -77404482 ^ 1643843772;
          continue;
        case 585:
          this.\u200B⁯‫‬‏⁭‍‭‍‬‮⁭⁮‫‭‎‌‍⁫‏⁯‍⁪‍‫⁫⁪‏‫‮‏⁬⁪⁫⁬‪‍‍‌‫‮.Tick += new EventHandler(this.\u206C‮⁪​‫‮⁪⁯‬⁯‌⁯⁯​‫‎⁬‭​‎‎⁯‫⁭‭‬⁪⁯⁭‬‌⁬‎‌‍⁯‭‬‌‌‮);
          this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮.BalloonTipIcon = ToolTipIcon.Info;
          num1 = (int) num2 * 907200856 ^ -101717544;
          continue;
        case 586:
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(766611646U);
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.Size = new Size(78, 13);
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.TabIndex = 34;
          num1 = (int) num2 * 1397858489 ^ 1117376111;
          continue;
        case 587:
          this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮.Size = new Size(145, 20);
          this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3125689053U);
          num1 = (int) num2 * -672843694 ^ -1077573480;
          continue;
        case 588:
          this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(590205983U));
          num1 = (int) num2 * -1689549816 ^ -322441808;
          continue;
        case 589:
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.SelectedIndex = 0;
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.Size = new Size(694, 426);
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.TabIndex = 0;
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * 293412034 ^ -725991547;
          continue;
        case 590:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1398347374U);
          num1 = (int) num2 * 1122275889 ^ -1717837942;
          continue;
        case 591:
          this.\u200D⁬‫‭⁭⁭⁯‫⁭‏⁬⁯⁫‏‭‫‏​⁭‬‌⁬⁫‍‮⁫⁭⁬⁬‌‪⁭⁪​‬‌⁬⁮‬‮.RowHeadersVisible = false;
          num1 = (int) num2 * 440334354 ^ -2134585662;
          continue;
        case 592:
          this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * 199171602 ^ 1170720628;
          continue;
        case 593:
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮.Size = new Size(662, 20);
          num1 = (int) num2 * -717039489 ^ -1050939455;
          continue;
        case 594:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -1855729943 ^ -162390432;
          continue;
        case 595:
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.OnFont = new Font(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1034455148U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.Size = new Size(45, 19);
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          num1 = (int) num2 * -1505757528 ^ 1362235715;
          continue;
        case 596:
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.Size = new Size(45, 19);
          num1 = (int) num2 * -1868883060 ^ -354915747;
          continue;
        case 597:
          this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮.HeaderText = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1070674131U);
          this.\u206A‪⁯‍​⁬‍⁭​⁬‪‮⁯⁯⁮‭‏​‮​‫⁪‬⁪‮⁬⁯‌‬‎⁬‌‏‮​⁯‪‮⁫‭‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2559974466U);
          num1 = (int) num2 * -999552601 ^ 1477421948;
          continue;
        case 598:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          num1 = (int) num2 * -1610031864 ^ 1797531167;
          continue;
        case 599:
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.SelectedIndexChanged += new EventHandler(this.\u200B⁭‮‫⁭‪⁬⁫⁬‫‭‫‏⁫⁭‏⁮‏‮‍‭⁬‪⁪‪⁭‮‪⁭‪‮‏‪⁮‬‫‫​​‮‮);
          num1 = (int) num2 * 114636407 ^ -848518610;
          continue;
        case 600:
          this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.ResumeLayout(false);
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.ResumeLayout(false);
          num1 = (int) num2 * -841027186 ^ 1714480480;
          continue;
        case 601:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮);
          num1 = (int) num2 * -772862250 ^ 633153696;
          continue;
        case 602:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * -594626706 ^ 507648102;
          continue;
        case 603:
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -2143119439 ^ -1115824229;
          continue;
        case 604:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.BackColor = Color.Transparent;
          num1 = (int) num2 * -175707600 ^ -887229844;
          continue;
        case 605:
          this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮.Click += new EventHandler(this.\u202C⁯‭‌‮​‏‬‮‪‫⁮‍‎⁭‭‪​⁭⁯‮‭‫‍⁯‫‮‫‌⁪​‮‬⁯‪⁪‮‪‭⁬‮);
          num1 = (int) num2 * 2056619358 ^ -1323149172;
          continue;
        case 606:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮);
          num1 = (int) num2 * -1079244796 ^ -90346301;
          continue;
        case 607:
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1971517962U);
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -340576875 ^ -1681681536;
          continue;
        case 608:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.BackColor = Color.Transparent;
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮.Location = new Point(215, 214);
          num1 = (int) num2 * -838984789 ^ 897076164;
          continue;
        case 609:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮);
          num1 = (int) num2 * 219810455 ^ 353871588;
          continue;
        case 610:
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.Location = new Point(166, 218);
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1290682945U);
          num1 = (int) num2 * 1773825773 ^ 438197560;
          continue;
        case 611:
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.AutoSize = true;
          this.\u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 1837763114 ^ 256256465;
          continue;
        case 612:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮), (Control) this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮);
          num1 = (int) num2 * 188237246 ^ 475777770;
          continue;
        case 613:
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.Location = new Point(123, 542);
          this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(186933130U);
          num1 = (int) num2 * -1305885605 ^ -228958511;
          continue;
        case 614:
          this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮.Width = 155;
          this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1420198282U);
          num1 = (int) num2 * -672751045 ^ 1426274588;
          continue;
        case 615:
          this.FormBorderStyle = FormBorderStyle.FixedSingle;
          num1 = (int) num2 * -1769106453 ^ -251572014;
          continue;
        case 616:
          this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮.SelectedIndexChanged += new EventHandler(this.\u200F⁮⁭⁫⁪​⁪⁫‌​‮‪‎⁮​⁯‎⁯‬‍⁮‎‌‏‏‏⁮​‍⁮⁪⁪‬‫​‌‏‮‎⁪‮);
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.AutoSize = true;
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 786882678 ^ 1730723536;
          continue;
        case 617:
          this.\u206B‎​⁫‭‭​‏​⁬⁭⁯‫⁯‎‬‭‭‏​‍⁯‎‏‭⁬⁬‎‌‏‫‏‮‎⁫⁫‫⁬‍‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -1505895798 ^ 1082469860;
          continue;
        case 618:
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.Size = new Size(64 /*0x40*/, 13);
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮.TabIndex = 33;
          num1 = (int) num2 * -1183049899 ^ 1129576636;
          continue;
        case 619:
          this.\u206E‮‬⁮⁪⁫‏⁪‌‫⁪⁭‌‎‌⁬⁪‭⁬​‏‬‏‬‏⁮⁪‭⁬⁮⁮⁯⁬‭‫‭⁫‏‎‏‮.BackgroundImage = (Image) componentResourceManager.GetObject(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(201348791U));
          num1 = (int) num2 * 103862653 ^ -118836518;
          continue;
        case 620:
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮();
          num1 = (int) num2 * 1573804213 ^ 628814842;
          continue;
        case 621:
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2690115199U);
          this.\u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮.Size = new Size(94, 13);
          num1 = (int) num2 * -1933236755 ^ 1680913794;
          continue;
        case 622:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202E‭‏⁮‫‫‭‮⁪‪‭⁬‎⁯‮⁯​⁬‮‎‮​‌‍⁯‫‫⁮‫‫‬⁬‪‏‎⁪‫⁬⁪⁯‮);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮);
          num1 = (int) num2 * -1487704816 ^ 350418890;
          continue;
        case 623:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.Size = new Size(120, 20);
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.TabIndex = 0;
          num1 = (int) num2 * 709721076 ^ -252079468;
          continue;
        case 624:
          this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮.TabIndex = 22;
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.BackColor = Color.Transparent;
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.Items.AddRange(new ToolStripItem[4]
          {
            (ToolStripItem) this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮,
            (ToolStripItem) this.\u206C​⁯‮‪‌⁪‎‬⁬⁬⁫‌⁫‮‮‫‎⁫​‍⁫⁪‪‎‌‭​⁫‎⁬‎‏⁬‮⁪⁯‮​‎‮,
            (ToolStripItem) this.\u200B‪⁬⁫‮​‬‬‭‎‏‎‫⁭‏‭‍‫⁮‪​‎‭‫​⁮⁯‏⁯​‫‏‌‏‫‌‏⁯‬⁭‮,
            (ToolStripItem) this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮
          });
          num1 = (int) num2 * -408770093 ^ -1816516109;
          continue;
        case 625:
          this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3535380068U);
          this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮.ReadOnly = true;
          num1 = (int) num2 * 66988262 ^ -1166990755;
          continue;
        case 626:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.Cursor = Cursors.Default;
          num1 = (int) num2 * 984984192 ^ 1206499462;
          continue;
        case 627:
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1797746562 ^ 304834086;
          continue;
        case 628:
          this.\u200D​⁯⁪⁮⁮⁭‭⁮⁮‏⁬‫‪⁯‌⁬‪⁫‭‍‮⁬​‏⁫⁪‏⁯‎‪‫⁫⁬⁫⁬⁯‌⁭‮.Width = 132;
          this.\u202C‪‮‫⁮‫‎‎​‮‬‎⁫⁫‮⁯⁫‪⁮‭​⁮⁫‌‏⁮⁭⁫‍​⁯‍‍‮‪‌⁪‎‏⁬‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2952189213U);
          num1 = (int) num2 * -359224740 ^ -1013846419;
          continue;
        case 629:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.Location = new Point(7, 285);
          num1 = (int) num2 * -1078727374 ^ -1570918357;
          continue;
        case 630:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.RowHeadersVisible = false;
          num1 = (int) num2 * 847457721 ^ -1074354388;
          continue;
        case 631:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.BackColor = Color.WhiteSmoke;
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Location = new Point(356, 188);
          num1 = (int) num2 * 1247438788 ^ 356434877;
          continue;
        case 632:
          this.\u206D‬‌‍⁬‮‪⁫‏‌⁫⁪‬⁪‪‌‎‌‫‬⁮‎‫‪‌‬‍‏‌‭‎⁯‍‍‏‫⁯‎⁭‫‮.Size = new Size(39, 20);
          num1 = (int) num2 * 237185084 ^ 116891942;
          continue;
        case 633:
          this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮.TabIndex = 34;
          num1 = (int) num2 * -337921042 ^ 1145346931;
          continue;
        case 634:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2454954610U);
          num1 = (int) num2 * 1801155079 ^ 230574822;
          continue;
        case 635:
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.TabIndex = 1;
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.CheckedChanged += new ToggleSwitch.CheckedChangedDelegate(this.\u206B‏⁪​‫⁮⁬⁯‬‏‭‮⁬⁮‏‭⁫‭‭⁮‬‭​‍‌⁯‫‌⁪‎⁪​⁫‪⁫⁭‌​⁫‎‮);
          num1 = (int) num2 * 1381831348 ^ -1560338994;
          continue;
        case 636:
          this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4181584536U);
          num1 = (int) num2 * -810166132 ^ 473428741;
          continue;
        case 637:
          this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮.TabIndex = 19;
          num1 = (int) num2 * 1867568175 ^ -1417019645;
          continue;
        case 638:
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.ReadOnly = true;
          num1 = (int) num2 * -2087046801 ^ 1325250992;
          continue;
        case 639:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.BackgroundImageLayout = ImageLayout.Center;
          num1 = (int) num2 * 1753525089 ^ -1871830084;
          continue;
        case 640:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.AutoSize = true;
          num1 = (int) num2 * -792623733 ^ 554042393;
          continue;
        case 641:
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.Size = new Size(46, 13);
          this.\u202E⁬‫⁮‮‭‏‎‌​‍‎‬‏‫⁮⁮⁪‏​⁪‌‌⁬‍‬⁬‪⁮‬‎⁭‫⁭⁮⁭‬⁭⁬‌‮.TabIndex = 16 /*0x10*/;
          num1 = (int) num2 * -1917899577 ^ -716658666;
          continue;
        case 642:
          this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * -675439903 ^ -1000157730;
          continue;
        case 643:
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3998163832U);
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮.UseVisualStyleBackColor = true;
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.AllowUserToAddRows = false;
          num1 = (int) num2 * 459573425 ^ 801068490;
          continue;
        case 644:
          this.\u200C‏‬⁮‌⁪​⁮⁫‪‫⁭‫‍‭‬‮⁬⁬⁬⁪‮⁫​⁭⁬‫‫‏⁯⁯‬‏‮‪‫‪⁬‫‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 1371135851 ^ 993566313;
          continue;
        case 645:
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮.TabIndex = 12;
          num1 = (int) num2 * 316080694 ^ -1384684706;
          continue;
        case 646:
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.Size = new Size(45, 19);
          num1 = (int) num2 * -1351254492 ^ 1893609128;
          continue;
        case 647:
          this.\u206B‬‬‏‬‮‍‏⁬‬⁭‎⁯⁫‫‎‭⁭⁭​‏⁭‌‪⁯⁭‎⁪​⁪⁫⁯⁫‬​⁪⁭‪⁭‬‮.Click += new EventHandler(this.\u202A‭‍‎‫‫‎‫‌​​‍‪‏‬‌⁫‏⁮‭⁬⁭‏‫‬⁫⁪‏‫‬‭‭‎‬⁬‭‎‫⁮⁬‮);
          num1 = (int) num2 * -1853361574 ^ -2042651160;
          continue;
        case 648:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮);
          num1 = (int) num2 * 511939006 ^ -163285955;
          continue;
        case 649:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Size = new Size(208 /*0xD0*/, 13);
          num1 = (int) num2 * 1285376857 ^ 1237440144;
          continue;
        case 650:
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.Style = ToggleSwitch.ToggleSwitchStyle.Modern;
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.TabIndex = 13;
          num1 = (int) num2 * -1699993989 ^ 130303775;
          continue;
        case 651:
          this.MainMenuStrip = this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮;
          num1 = (int) num2 * 398381147 ^ 2093110398;
          continue;
        case 652:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.Location = new Point(221, 369);
          num1 = (int) num2 * 1772220354 ^ -36022309;
          continue;
        case 653:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3409331288U);
          num1 = (int) num2 * -1335830441 ^ -945652973;
          continue;
        case 654:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.Size = new Size(125, 13);
          num1 = (int) num2 * -198200056 ^ 237467610;
          continue;
        case 655:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮((Control) this.\u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮);
          num1 = (int) num2 * -1532310975 ^ 515525480;
          continue;
        case 656:
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3092490593U);
          num1 = (int) num2 * 2049979573 ^ -69124655;
          continue;
        case 657:
          this.Controls.Add((Control) this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮);
          num1 = (int) num2 * 1407096260 ^ 1411996586;
          continue;
        case 658:
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1381198358U);
          num1 = (int) num2 * 1533110834 ^ 289918238;
          continue;
        case 659:
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮.EndInit();
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.ResumeLayout(false);
          num1 = (int) num2 * -2130235224 ^ -1905247716;
          continue;
        case 660:
          this.\u206A⁫‪‮‌‪‮⁫⁬⁯⁬⁯⁯‏​​‎‌⁪⁮⁮‌‪⁯⁫⁪⁫‬‪‭‌⁫‫⁮‎⁫‏‭‍‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2060944000U);
          num1 = (int) num2 * 712102024 ^ -254567734;
          continue;
        case 661:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮);
          num1 = (int) num2 * -1455896907 ^ -792129975;
          continue;
        case 662:
          this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2445953330U);
          num1 = (int) num2 * -1651320748 ^ -304274782;
          continue;
        case 663:
          this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(788474313U);
          this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮.Width = 165;
          num1 = (int) num2 * -219733782 ^ 707720907;
          continue;
        case 664:
          this.\u202C‎​‪‌⁪‮⁫⁬⁬​‫‌⁮⁯‏‏​​‬‬‫⁮‮⁮⁮⁯‬‮‌​⁫‮‭‫⁭‌⁭⁯⁪‮.Click += new EventHandler(this.\u202E‏‮‬⁪‫‪‍‪⁫⁫​‌⁫⁫‬‮⁫‮⁬⁯‫‪⁪‎‏‮⁬‏⁭‌‪⁮⁪⁬⁯⁮⁫‫⁯‮);
          num1 = (int) num2 * -1528790101 ^ -1647780811;
          continue;
        case 665:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.Size = new Size(65, 65);
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.TabIndex = 19;
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.UseVisualStyleBackColor = false;
          num1 = (int) num2 * 1095869680 ^ -208861763;
          continue;
        case 666:
          this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮.Size = new Size(152, 21);
          num1 = (int) num2 * 1418593383 ^ 521758180;
          continue;
        case 667:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.Size = new Size(130, 50);
          num1 = (int) num2 * -1191799144 ^ 1803182816;
          continue;
        case 668:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮);
          num1 = (int) num2 * 1723980220 ^ -229198892;
          continue;
        case 669:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3187622466U);
          num1 = (int) num2 * 730880435 ^ 731097311;
          continue;
        case 670:
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.BackColor = Color.Transparent;
          this.\u202E⁪‍‌‮⁭⁫‏‎‬‬‭‏‍‮‭⁫​‏‪⁯‏⁪‌‮‍‫‍⁪⁪‎‮⁮‍‫‫‏‬‎⁭‮.Location = new Point(308, 220);
          num1 = (int) num2 * 508026413 ^ -674185334;
          continue;
        case 671:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮((ISupportInitialize) this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮);
          num1 = (int) num2 * 393968546 ^ -2070005108;
          continue;
        case 672:
          this.\u206E‌⁬⁭⁭⁭‌‌⁬‬⁫‮‪⁬‎​⁪‭​‫⁭​​⁫⁯‎⁫‎‪‭‎‮⁯‎‍‮⁫‭⁫⁭‮.Size = new Size(224 /*0xE0*/, 26);
          num1 = (int) num2 * -484727789 ^ -2034765054;
          continue;
        case 673:
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.TabIndex = 24;
          this.\u202D⁯‪‍‫⁫‏‪⁪⁮​⁮‮⁬⁭‏‬‪‭⁪⁫⁯⁮‫‫⁯⁪⁬⁪⁪‌⁮‫⁯‎‎‮‬⁫⁯‮.Text = "";
          num1 = (int) num2 * 1285162886 ^ 421185043;
          continue;
        case 674:
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.Size = new Size(21, 13);
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.TabIndex = 29;
          this.\u206F⁫‍⁬‍⁭‫‎‍‪‏⁬‪⁬⁮⁬‬⁫‭‎‬⁪⁮​⁬⁪⁪⁫⁪⁭‬‌‎⁮⁯⁭‎‭‌‏‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(571417487U);
          num1 = (int) num2 * -1244237397 ^ -366776200;
          continue;
        case 675:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.AutoSize = true;
          num1 = (int) num2 * 1666204298 ^ -405765562;
          continue;
        case 676:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.MouseLeave += new EventHandler(this.\u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮);
          num1 = (int) num2 * -404255353 ^ -201609148;
          continue;
        case 677:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1120277940U);
          num1 = (int) num2 * 499406830 ^ -500306170;
          continue;
        case 678:
          this.\u200C‬​‬⁫‬⁮‏‮‬⁭‬​​‭⁬⁬‎⁭‫⁪‍‫‏​‫‎‬⁬⁭⁮‫⁬‬‬‫‍‌‮‫‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3368527957U);
          num1 = (int) num2 * 1610473481 ^ 1158611691;
          continue;
        case 679:
          this.\u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(225169432U);
          this.\u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1014571696U);
          this.\u200F‍⁬⁮⁬‌​​‮⁬​⁯‪⁯‭⁭‬‍⁮‎⁬⁬‫⁭​​‪‮‏‮⁯‬‪⁯‬‬‍‭⁮⁮‮.Width = 184;
          num1 = (int) num2 * -1465058346 ^ -1702494637;
          continue;
        case 680:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.UseVisualStyleBackColor = false;
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.Click += new EventHandler(this.\u202B⁬‪⁭‭‍‌⁭‎⁮​⁮‪⁬‌‫‪‭⁮‮‬​‫⁭‏‏⁬⁭‏⁮⁬‬‍‪⁮‍‎⁭‫‍‮);
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.MouseEnter += new EventHandler(this.\u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮);
          num1 = (int) num2 * -1373571640 ^ 1884286647;
          continue;
        case 681:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * -427366129 ^ -1348768675;
          continue;
        case 682:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Size = new Size(65, 65);
          num1 = (int) num2 * -2010511835 ^ -469401;
          continue;
        case 683:
          this.\u200C⁪‌⁮⁪⁮‮‍‎‭‮‌‭‪⁬‮‏‭⁫‪‮⁪⁪‮‏‌⁭⁯‮‭‬‬‪‫⁯⁫‍⁭‭‮.ReadOnly = true;
          num1 = (int) num2 * -1541963869 ^ -165022378;
          continue;
        case 684:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.TabIndex = 6;
          num1 = (int) num2 * -1280258878 ^ -733801323;
          continue;
        case 685:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Location = new Point(4, 22);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3035840452U);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Padding = new Padding(3);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Size = new Size(686, 400);
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.TabIndex = 0;
          num1 = (int) num2 * 1212755914 ^ -321494693;
          continue;
        case 686:
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.BackColor = Color.Transparent;
          this.\u202C‎⁮⁯⁬‪‏⁪‪⁬⁬‍⁪‎⁯‌‭‮​‌⁭‭⁮‬‍‪‭‪‌⁯⁯⁫‬‬⁮‍⁪‎‪‭‮.Location = new Point(261, 95);
          num1 = (int) num2 * 522176029 ^ 2085183091;
          continue;
        case 687:
          this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮.Location = new Point(560, 33);
          num1 = (int) num2 * -479048931 ^ -1053752919;
          continue;
        case 688:
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮.Enabled = false;
          num1 = (int) num2 * 1408458170 ^ -1599513342;
          continue;
        case 689:
          this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮.TabIndex = 21;
          num1 = (int) num2 * -341106132 ^ -2083965669;
          continue;
        case 690:
          this.\u202D‎‬‫‮⁯‭​⁬​‪​‍‫‬‏⁯‭⁭‫‫⁯‌‬‏‫⁫⁯‭‌⁯⁫⁮⁯‮⁮⁪⁬‏⁭‮.HeaderText = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1844668501U);
          num1 = (int) num2 * 1908017848 ^ 1417224209;
          continue;
        case 691:
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.Size = new Size(76, 13);
          this.\u206C⁫‪⁯​⁬‪⁯‫⁬⁮‏‏‎​⁪⁯⁫‭⁭⁪‏​⁬‍​⁭‮‫⁯‪⁬‮‫⁮‍⁭‍⁬⁫‮.TabIndex = 40;
          num1 = (int) num2 * -1811727549 ^ 2036703303;
          continue;
        case 692:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮);
          num1 = (int) num2 * 1388944916 ^ -1051109917;
          continue;
        case 693:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.Size = new Size(46, 13);
          num1 = (int) num2 * -740344114 ^ -191022099;
          continue;
        case 694:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.Size = new Size(224 /*0xE0*/, 26);
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.TabIndex = 22;
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1738489677U);
          num1 = (int) num2 * 459389696 ^ -1433800271;
          continue;
        case 695:
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.BackColor = Color.WhiteSmoke;
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.Location = new Point(7, 8);
          this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(863762799U);
          num1 = (int) num2 * -741205902 ^ 2065570430;
          continue;
        case 696:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(715158401U);
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 602862208 ^ 1357554639;
          continue;
        case 697:
          this.\u206B⁫‫⁬‬‬⁬‎‮‍‭‌‬‪‌⁬⁬‪⁯‎⁭‭⁭⁮‭⁪‫⁫‏‏‫‬⁪‭⁬⁫‮‫‍‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 1012164482 ^ -841080372;
          continue;
        case 698:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.Columns.AddRange((DataGridViewColumn) this.\u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮, (DataGridViewColumn) this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮, (DataGridViewColumn) this.\u202B⁬‌⁯‮‌⁪‪​⁬⁫‮​‎‮⁪⁮⁬⁯‭‍⁫⁪‬‮‮‮‭⁪‫‌‌‍⁭‮‮⁮⁫‌‍‮, (DataGridViewColumn) this.\u206B‪⁯‍‏‌⁫‏⁯‍⁬⁬⁪⁮‪⁫​⁮⁯‮‎‪​‬‬‏⁬⁯‌‬‬‪‌‭‌‭‎​‌‬‮);
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.Location = new Point(7, 303);
          num1 = (int) num2 * -77049809 ^ -1140791126;
          continue;
        case 699:
          this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮.EndInit();
          num1 = (int) num2 * 957085415 ^ -760113970;
          continue;
        case 700:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.TabIndex = 35;
          num1 = (int) num2 * 466210919 ^ 133950307;
          continue;
        case 701:
          this.\u206E⁭⁫‪‎‌⁯​⁮⁮‭‫⁪‏⁬⁯‪‮‏⁬‎‌‭‮‬⁮⁪​‏⁯​‮‎​‪⁮⁫⁯‍‭‮.ReadOnly = true;
          num1 = (int) num2 * -953565309 ^ 506708452;
          continue;
        case 702:
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.Size = new Size(344, 23);
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.TabIndex = 32 /*0x20*/;
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4283389145U);
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.UseVisualStyleBackColor = true;
          this.\u202A⁮‍⁮‬‍‭⁫⁯‭‏⁫‬⁫⁫‪⁯⁭‎‌​‭‫‬⁫‮‌⁪‬‍‌⁫⁭‏⁭⁮‫⁯‏⁪‮.Click += new EventHandler(this.\u206C‬‌‍⁬‮⁭‌⁭⁭⁫⁫‎⁫‎‎⁮‎‫⁭⁯‍‬⁯‍⁪⁬​‎⁭⁬‫‪⁬⁯‮⁯‍⁪‌‮);
          num1 = (int) num2 * 1229492418 ^ -1748238621;
          continue;
        case 703:
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.AutoSize = true;
          this.\u202A‏‏‌‫⁫‎​‍⁯‌‌‭‌⁭⁭⁬⁮⁬‌‍⁯‫‮⁪‎‬​‮‏⁯‭‫⁪⁫‏⁪⁪⁪⁮‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 334532302 ^ -1242668151;
          continue;
        case 704:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.AllowUserToResizeRows = false;
          num1 = (int) num2 * -1817776923 ^ -1319342152;
          continue;
        case 705:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * -1130304084 ^ 1020414028;
          continue;
        case 706:
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3885447106U);
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.Size = new Size(139, 21);
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.TabIndex = 17;
          this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮.SelectedIndexChanged += new EventHandler(this.\u206A⁯⁫‪‍‬​⁮‭‏‏‏⁭‌⁪‌⁫‫‪⁮⁬⁫‌⁫⁯‫‭‍‫​‍‪‮⁪⁫⁮‬‭​‏‮);
          num1 = (int) num2 * 2003147818 ^ 697818053;
          continue;
        case 707:
          this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮.Size = new Size(90, 21);
          num1 = (int) num2 * -1021101756 ^ -2104858495;
          continue;
        case 708:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          this.\u206A‎⁭​⁭‍‮‫‭‍‮⁪⁫⁪‍⁪⁬‭⁭‎⁫‪‫⁬⁫​‏⁪‍⁪‭‏​⁭‏⁮‫⁫‬‫‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1828887677 ^ -3375084;
          continue;
        case 709:
          this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2832095644U);
          num1 = (int) num2 * -640020209 ^ -418677154;
          continue;
        case 710:
          this.\u206E‌⁪‫‎‍⁮⁮⁪‮‌‏⁫‏⁬​​‏⁯‌⁭​‮​⁯‫‮‫⁪⁬‬⁭‬⁬‏‬⁬‪‍‫‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * 1275173201 ^ -222053684;
          continue;
        case 711:
          this.\u202A⁬⁭‍‭⁬⁭⁬‫‭⁭‌⁮⁬⁯‪‫‌⁬‪‍‭‍‬⁫‏⁭⁪‬⁫‌‫⁫‌‫‏‍‏⁫⁪‮.Location = new Point(482, 193);
          num1 = (int) num2 * 2115270977 ^ 251304339;
          continue;
        case 712:
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮();
          this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮();
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮();
          num1 = (int) num2 * -630514577 ^ 1114801522;
          continue;
        case 713:
          this.\u202B‬‮‬‏‭‎‌​⁯‌⁫‏‎‭⁮‎​‎⁬⁬​⁭‬⁭‍‍​‬⁭‏⁭‌⁭⁪‪⁭‮‭⁭‮.Width = 165;
          this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(381169128U);
          this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮.Items.AddRange((object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2833812256U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3103874497U), (object) \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1033060697U), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3125484582U));
          this.\u200E​⁬‪⁯⁭⁯⁬‪‎‮⁯⁫‏‮‏⁪‏‫‏‎⁫‍⁪⁮⁮‭​⁭‭⁯‍⁫‫‪‍⁮‌‏⁫‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3434293977U);
          num1 = (int) num2 * 276608950 ^ 842147129;
          continue;
        case 714:
          this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮.AllowUserToAddRows = false;
          num1 = (int) num2 * 250391920 ^ -1443772466;
          continue;
        case 715:
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.TabIndex = 16 /*0x10*/;
          this.\u202B‬⁭‫‏‭‬‫⁯⁮‍⁭​‭⁬‍⁭​⁬‍⁭‬⁭​‎‎⁯⁮​‌‎‎⁪‫‍‌‬⁪⁮‍‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 1405022622 ^ 636899491;
          continue;
        case 716:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.BackColor = Color.Transparent;
          num1 = (int) num2 * 979043723 ^ -1708010629;
          continue;
        case 717:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.Location = new Point(252, 28);
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4198631937U);
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.Size = new Size(65, 65);
          num1 = (int) num2 * -2064903670 ^ -1290372975;
          continue;
        case 718:
          this.\u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1140980929U);
          num1 = (int) num2 * 1281381384 ^ 796981318;
          continue;
        case 719:
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.Location = new Point(4, 22);
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3087293697U);
          num1 = (int) num2 * -1931463239 ^ 1140997303;
          continue;
        case 720:
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(295626443U);
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.UseVisualStyleBackColor = false;
          this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮.CheckedChanged += new EventHandler(this.\u202A⁯⁫⁯⁫​⁫‫⁯‏‭‍⁬⁮‏‭‭‍‍‌⁮‮⁮⁯‬‭‍⁬‎‮‍‬⁬⁭⁭⁫‏​⁬‮);
          num1 = (int) num2 * 722969036 ^ 1779144316;
          continue;
        case 721:
          this.\u202D⁭⁬‬⁪‎‌⁬‬⁮‎⁭⁫⁪‏‭‍⁪‫⁬‍‎‌​‫⁮⁭⁬‍⁯⁯‪‬‮‮⁭‮⁪‎‮‮.FlatAppearance.BorderSize = 0;
          num1 = (int) num2 * 1186604076 ^ 1938406666;
          continue;
        case 722:
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Controls.Add((Control) this.\u202C‪‍‪‪⁪⁭​⁮⁪‪​‏⁫‪‪‎⁭⁬⁬‏‍‭‬‭‬‏‬⁪⁯‎‏‬‬⁪‪‪⁮⁮‮‮);
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Controls.Add((Control) this.\u202D‬‌‎‪⁮⁫‏⁫‫⁭‪⁪‎⁮⁪‍‏⁫⁯⁯‬‎‎‪‮‫‫‬​‎‪‬‬‭‏‪‭‭⁮‮);
          this.\u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮.Location = new Point(4, 22);
          num1 = (int) num2 * 845902153 ^ 1952264947;
          continue;
        case 723:
          this.\u206D⁯​⁬‪​⁬‭‭‫⁫‌‭⁯‌⁫⁭‫⁪‭⁮‮‎‭‪⁬‪‭⁪⁯‍‌‏‮‍‫⁬​‎⁭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2454954610U);
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.BackColor = Color.Transparent;
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.Location = new Point(167, 212);
          num1 = (int) num2 * -1126129919 ^ 1749438658;
          continue;
        case 724:
          ((ISupportInitialize) this.\u200C‏⁫‬⁫​‪⁮⁫‏⁬‏‪​‮⁯⁫‬‎⁪⁮‍⁮​⁭⁫⁯⁭‮‏⁮‪​‪‭‮⁬‫‭‮).EndInit();
          this.\u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮.ResumeLayout(false);
          ((ISupportInitialize) this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮).EndInit();
          num1 = (int) num2 * 1098558629 ^ -150640523;
          continue;
        case 725:
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Size = new Size(120, 20);
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.TabIndex = 18;
          this.\u206B​⁬⁫‬⁮‮⁬‍​⁯‎‪‬‫‍‏‏⁬‏⁬‪​‮⁯‌‎⁫⁬‭⁫⁯‪⁮​‫‏⁭‏‫‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 165623727 ^ -902263450;
          continue;
        case 726:
          this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮.FormattingEnabled = true;
          num1 = (int) num2 * 607564449 ^ 860861932;
          continue;
        case 727:
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.Size = new Size(686, 402);
          num1 = (int) num2 * -116843852 ^ -129211485;
          continue;
        case 728:
          this.\u200D‮‮‬⁬‭‮‏⁯‮⁯⁪‬⁭‭‬‫‍⁫‫⁫‌‪‮⁬‮⁮⁪‬‮⁫‍​‏‎​⁭‎⁫‌‮.TabIndex = 21;
          num1 = (int) num2 * 1487947859 ^ -200545525;
          continue;
        case 729:
          this.\u202C⁪⁫‪‫‎​⁫‌⁯‭⁬‍‪⁫⁪‪⁫‮‌‫‬‫⁭​‏‫‮​⁯‎‏‫⁬‭⁪‍‎‬‫‮.Width = 164;
          this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮.HeaderText = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(36509369U);
          this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1286463056U);
          this.\u200B‎⁬‍⁫​‏‎‬⁯‍⁪‮‌⁪‬⁯‫‬⁪‍‭‍⁭⁭‬​‏‍⁪⁫‍‎‌⁯⁮‍‮⁯‪‮.ReadOnly = true;
          num1 = (int) num2 * 352043921 ^ 2098219103;
          continue;
        case 730:
          this.\u206A⁭‬‎‏⁫‪‌‪‪⁪‏⁭‬⁫⁪‏⁯‮‬‏‏‬‭​‬⁪‬‍⁮‎⁭‪‎⁭⁯⁮‭⁫‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮();
          num1 = (int) num2 * 1447074766 ^ 2004180859;
          continue;
        case 731:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.AllowUserToAddRows = false;
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * -325958624 ^ 1480491477;
          continue;
        case 732:
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.Location = new Point(0, 0);
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(293765496U);
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.Size = new Size(695, 24);
          num1 = (int) num2 * 1417649672 ^ 1263229719;
          continue;
        case 733:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Location = new Point(448, 34);
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2327344488U);
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Size = new Size(60, 13);
          num1 = (int) num2 * -1450416560 ^ 1411785944;
          continue;
        case 734:
          this.\u202B‫⁬⁪⁭‎‫‮‫⁭⁮​⁫⁪‎‪⁫⁯‫⁭⁮‍⁪‬‍‮‭​‌‏‭⁫​⁪‫⁯‬‪⁫⁮‮.Enabled = true;
          num1 = (int) num2 * 288416230 ^ 1409142178;
          continue;
        case 735:
          this.\u200C​‌‮​⁫⁪‪‮‏⁭‪‬‎‪​‪‌‭⁫‫⁫‌⁬‌‪⁭‎⁯⁪⁬‭‎‭‌⁫⁯‬‭‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮();
          num1 = (int) num2 * 1888351373 ^ 583239243;
          continue;
        case 736:
          this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮.HeaderText = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2459227436U);
          num1 = (int) num2 * 63287535 ^ -1215300358;
          continue;
        case 737:
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3909683643U);
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.Size = new Size(75, 13);
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.TabIndex = 13;
          this.\u200D⁮‭‮⁪​‪‭‪⁮‌‫‫‮‮‮⁬‫⁭‏​‮‪‍⁫‭‎⁯​‌⁪⁬‭‭‏‬​⁭‮⁫‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1711660531U);
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮.BackColor = Color.WhiteSmoke;
          this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮.Location = new Point(7, 195);
          num1 = (int) num2 * -1081326790 ^ -347849560;
          continue;
        case 738:
          this.\u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮.Controls.Add((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮);
          num1 = (int) num2 * -1200095442 ^ 718533662;
          continue;
        case 739:
          this.\u206C‭⁭‎‮‎‪⁫‏‍‏⁮⁭⁭‮‬⁮⁮⁭‮⁪⁯⁬⁪⁬⁯⁬⁪‬⁭​‫​⁭⁪‭⁮⁫​⁮‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2947259046U);
          num1 = (int) num2 * 1554837206 ^ -1385428552;
          continue;
        case 740:
          this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮();
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u202E⁬⁪‌‪‎⁯⁬⁮‬⁫⁫‎‎‭‎‭‮‭‎‍⁯‎‬⁪‍‎⁭⁯‌‬‌​⁬⁬⁬⁮‮⁫‌‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          this.\u206D‭‍‎‏‎⁮⁭‏‍‏⁬‍⁬‫⁭⁪⁫‫‫‏⁮‍‎⁮‬⁫⁬‌⁫‌‭⁮‏‭‌⁫⁮⁯⁬‮ = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮();
          num1 = (int) num2 * 617707728 ^ 238834249;
          continue;
        case 741:
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.BackColor = SystemColors.WindowFrame;
          this.\u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮.BackgroundImageLayout = ImageLayout.Stretch;
          num1 = (int) num2 * 882072265 ^ 1900737801;
          continue;
        case 742:
          this.\u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮.Controls.Add((Control) this.\u200F⁬‎‍​⁯‭⁪⁮‫‎⁪⁮‭‪‫‭‬⁭⁭‌⁮‫‫⁯‮‏⁫‬⁭⁮‌‭⁭‭‮‮‫‍‏‮);
          num1 = (int) num2 * -1313121383 ^ -899059693;
          continue;
        case 743:
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.Size = new Size(65, 65);
          this.\u206B⁭‎​‍⁪‮‭‌⁪‪‌⁯‌⁪⁮⁪⁫⁭⁪​‬⁫‏⁫​⁯‎‬⁫‎‎‭‍‮⁫‪‎⁫⁯‮.TabIndex = 26;
          num1 = (int) num2 * 1914863146 ^ 2125147945;
          continue;
        case 744:
          this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮.MultiSelect = false;
          num1 = (int) num2 * 1017784634 ^ -954772495;
          continue;
        case 745:
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.SelectionMode = DataGridViewSelectionMode.CellSelect;
          this.\u206C‌‫‪‌‍‪⁮‏‬‫‏‍⁯⁫‬‬​⁬⁭‬‭⁪⁮⁯‎⁫‫⁮⁪‫‭⁯⁬⁭‭⁯‪‭⁮‮.Size = new Size(662, 60);
          num1 = (int) num2 * -115316073 ^ -575683604;
          continue;
        case 746:
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.Size = new Size(114, 13);
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.TabIndex = 36;
          this.\u200B‌‎‬⁯‫‭⁪⁪⁪⁯‎‮‌⁮‮‮‎⁮⁮⁪⁯‮⁯‪‬‌‭‪‪⁫‫⁮⁬‬​‭​‌‬‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3864208804U);
          num1 = (int) num2 * 2136192642 ^ 1603800648;
          continue;
        case 747:
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.TabIndex = 12;
          this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮.KeyDown += new KeyEventHandler(this.\u202E​‫⁮‪⁯‭⁭⁬‍‭⁫​‭⁭⁮​‮⁫⁮‏⁮​‍⁬⁯⁪‏‍‪​‪⁮⁪⁯‬⁪⁬​⁪‮);
          num1 = (int) num2 * 1606080049 ^ -226259388;
          continue;
        default:
          goto label_749;
      }
    }
label_749:
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  public bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024()
  {
    this.\u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮();
    LinkLabel.LinkCollection linkCollection = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁫‍⁬⁭‌‬‫‎⁪‌⁬⁪​‏​‭‎‮⁪‮⁯‎‭‫⁬⁭⁫⁮​‏⁬⁫‎⁬‮⁪⁮‏⁮‮(this.\u202E‎‍⁮‏‍‭‮‎‎⁮‍⁭‍‪‎⁯‏‬‪‮​‫‍‪‪⁬​⁫‪‍‬‪⁪‎‭⁭⁯​⁪‮);
    LinkLabel.Link link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206F⁭⁯‭⁪⁭⁯‍‪‍⁭‎‍⁪‮‫‮‬‮‌⁪⁮‬‪‌⁫‏‌‪‪⁫‬‫‎⁭‫‌‫‫‍‮();
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‬⁯⁮‍‍‭‎⁭⁬‮‫⁯‍⁮‭‌⁭‍‍‪⁬‭‮‪‪‎⁬⁫‌‏‫‭⁯⁪‭‬​⁫‍‮(link, (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3088451461U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁫⁪⁭⁫⁭‬‌⁫‪‫⁪‍‎⁮‮⁬​‏⁯‪​‏‫‬‏‍‎‮‭‌⁬⁭⁫⁪​‭⁮​‮‮(linkCollection, link);
    \u202E‏⁮⁪‏⁫‬⁪‏‌‎‍‍‎⁫⁮⁫‫‫⁫‏⁭‭⁫‪‏‪⁫‮⁪‫‭⁮‌‏‎⁮‫⁭‬‮.\u206C‌‫‭⁯‌⁫‌⁪‭‌⁬‍⁬⁫​‎‎⁬‮​​⁮⁮⁯‬‬‏‫‏⁮‪‪‭‏‏⁫​‌‪‮ = this;
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C⁫‪‎⁪⁯‪⁪‪⁬⁬‮⁫‮‬‮⁪‏‬‫⁪‫⁪‌‪‮⁮‌⁪⁭‎⁯‫⁯‍⁫⁬‪‭⁭‮(this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮, bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A⁯⁮⁬‭‏⁪‮‬‍‍‎⁭​‮⁪​⁫‏‍⁮‮‮⁪‭‍‬⁭⁯‬‬⁪‌‌​⁬⁯‬⁬‎‮((Form) this));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‭⁮‎⁯‌‬‪⁪‏⁬⁫‌‭‮‍⁮⁪⁫‎‍‌‭‏⁪‫​‍‬‬‎⁯‏‏‎‭⁮⁬⁫⁯‮ = this.\u206B‍‏​‮⁪⁫‎‬⁯⁫⁪⁭‏‏‎‏⁭⁭⁪‭​⁯‪⁮‮‭⁮‎‬‪‪⁯‌‍‏⁪⁫⁬⁫‮;
    this.\u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮ = false;
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(275042837U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3024831479U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(530615742U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(541210661U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(933117354U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3981458964U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1645948583U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1133755724U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(510442881U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2032400927U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2733459585U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1530586196U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(162796930U));
    foreach (string str in bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(510442881U)))
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A⁭⁭‎⁫‮⁬⁮⁮‍‮‮⁬‭‫‏‏‏​⁭⁯⁭⁪‎‌​‮⁭‍‮​⁬‪‏‌‪​⁫‌⁮‮(str);
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3922545757U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1346290162U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1079018095U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2555396233U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(359331875U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3695288219U));
    ConfigController.Load();
    try
    {
      this.\u202C⁯‌‪‍⁫⁯⁮⁬‫​‪⁮‭⁮​‍‮‍‪⁯‎⁯‍‮‍⁬⁭‌⁫‫‮⁯‭​​‬‏⁬‏‮(ConfigController.InterfaceConfig.PathToBackgroundImgTabs);
    }
    catch
    {
    }
    try
    {
      this.\u202D⁮‌‏​​⁪⁯‌‪‭​⁯⁫⁭‭​‍‍‭‏​‌‫‪⁮‬⁮⁪⁯‭⁯⁭‭​‬⁮⁯‬‌‮(ConfigController.InterfaceConfig.PathToBackgroundImgGeneral);
    }
    catch
    {
    }
    try
    {
      this.\u200F⁫‪‏​⁬‭‫‌‏‎‏⁬⁯​⁪⁮‬⁬‮‫‮‬⁭‏⁮‮‫⁯‮⁭⁪‭‏‌‮‬⁬‎‪‮(Color.FromArgb(ConfigController.InterfaceConfig.ForColorAsArgb));
    }
    catch
    {
    }
    switch (ConfigController.AnticapConfig.SelectedMode)
    {
      case SelectedMode.Rucaptcha:
        bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‍‫​‬⁭​‎⁫‎⁮​‏‍‭‏‏⁮⁪‏‬⁫‪‪⁬‮⁪‬⁬⁫‫⁭⁫‭‌⁯‎‮‏‮(this.\u206A‫⁮‌‎‏⁯‌⁬‬⁯​⁯‮⁬⁭‬⁬⁭⁪⁪‪⁭⁭‮⁫⁫‏‫‍‌‎‎‪⁮‏‎‍⁮‮, true);
        break;
      case SelectedMode.Anticaptcha:
        bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‍‫​‬⁭​‎⁫‎⁮​‏‍‭‏‏⁮⁪‏‬⁫‪‪⁬‮⁪‬⁬⁫‫⁭⁫‭‌⁯‎‮‏‮(this.\u206F‌⁯⁫‭⁫⁫‍‭‪⁮‬​⁮⁪⁯​⁮‌‫‏⁬‌⁭‮‮​​‫⁮⁯⁪⁮‭⁫‪‭⁯⁮‮‮, true);
        break;
      case SelectedMode.Manual:
        bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‍‫​‬⁭​‎⁫‎⁮​‏‍‭‏‏⁮⁪‏‬⁫‪‪⁬‮⁪‬⁬⁫‫⁭⁫‭‌⁯‎‮‏‮(this.\u206B‮‮‎‏​⁪​‪​‍‌‪⁬‌‫‍‏‬‪‬‮‍‎​‌⁭‌‍‎‍⁭‫⁯‭‌‮‎​⁮‮, true);
        break;
    }
    this.\u206C‎‮‪‭⁯‭⁯⁯‍⁫‎‫‍⁪⁫‍‌‬‬‏‪‮‍⁭⁭‎⁫‌‫⁯⁪‏‭​‫​‬⁪⁫‮();
  }

  private void \u206C‎‮‪‭⁯‭⁯⁯‍⁫‎‫‍⁪⁫‍‌‬‬‏‪‮‍⁭⁭‎⁫‌‫⁯⁪‏‭​‫​‬⁪⁫‮()
  {
    List<string> stringList1 = new List<string>((IEnumerable<string>) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3046827944U)));
label_1:
    int num1 = 98117580;
    List<string> stringList2;
    List<string> stringList3;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 344227443)) % 7U)
      {
        case 0:
          stringList2 = new List<string>((IEnumerable<string>) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3845458241U)));
          num1 = (int) num2 * -1445075165 ^ 2011447124;
          continue;
        case 1:
          stringList1 = stringList1.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * -1445787553 ^ 851322543;
          continue;
        case 2:
          stringList2 = stringList2.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * 680120777 ^ 1515920993;
          continue;
        case 3:
          goto label_1;
        case 5:
          stringList3 = new List<string>((IEnumerable<string>) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(324694631U)));
          num1 = (int) num2 * -930164334 ^ 1430121537;
          continue;
        case 6:
          stringList3 = stringList3.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * -300069894 ^ 1873622349;
          continue;
        default:
          goto label_8;
      }
    }
label_8:
    List<string> stringList4 = new List<string>((IEnumerable<string>) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2609781659U))).ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮), (object[]) stringList1.ToArray());
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮), (object[]) stringList3.ToArray());
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮), (object[]) stringList2.ToArray());
    DataGridViewComboBoxColumn viewComboBoxColumn = (DataGridViewComboBoxColumn) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‏⁯⁭⁪‌⁭‬‬⁯⁫‮‌⁬‌‍‍‮‬⁭‎‪‫⁭‌⁯‭​​‍⁭⁫‫⁬‬‮‌​‪⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(this.\u202B⁯⁫‪⁮‎‌⁯‏‏⁫‍⁭‮⁬⁮‏‫‏‮‮‏⁮‎‭⁬‮​⁪‎‌⁮‍‌​​‬‌‍‎‮), 3);
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‫‍⁮⁫⁭⁫‌⁮‎‭‭⁪⁮⁫‫‌⁪‎⁯‭​‬‮‮‍⁮​‬​⁭​‌⁭​‭⁮⁬‪‭‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‌‫⁮⁫‏‌‎‪⁬‌⁪⁫‎‎‭⁭‬⁬‬​‮‮‫‮‎‪‮‭‎‍⁪⁫‮‌⁬‌‏‫⁪‮(viewComboBoxColumn));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‭‍‎‭‭⁬‍‎⁯‎⁯⁫‫⁬‌‍‮⁬‫‬⁭‍​⁭‎⁭⁬‍‬⁪‪⁭‌​​⁭‏‫‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‌‫⁮⁫‏‌‎‪⁬‌⁪⁫‎‎‭⁭‬⁬‬​‮‮‫‮‎‪‮‭‎‍⁪⁫‮‌⁬‌‏‫⁪‮(viewComboBoxColumn), (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1187788849U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‭‍‎‭‭⁬‍‎⁯‎⁯⁫‫⁬‌‍‮⁬‫‬⁭‍​⁭‎⁭⁬‍‬⁪‪⁭‌​​⁭‏‫‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‌‫⁮⁫‏‌‎‪⁬‌⁪⁫‎‎‭⁭‬⁬‬​‮‮‫‮‎‪‮‭‎‍⁪⁫‮‌⁬‌‏‫⁪‮(viewComboBoxColumn), (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2111983348U));
    using (List<string>.Enumerator enumerator = stringList4.GetEnumerator())
    {
label_13:
      int num3 = enumerator.MoveNext() ? 1175718805 : (num3 = 1706534650);
      string current;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 344227443)) % 5U)
        {
          case 0:
            num3 = 1175718805;
            continue;
          case 1:
            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‭‍‎‭‭⁬‍‎⁯‎⁯⁫‫⁬‌‍‮⁬‫‬⁭‍​⁭‎⁭⁬‍‬⁪‪⁭‌​​⁭‏‫‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‌‫⁮⁫‏‌‎‪⁬‌⁪⁫‎‎‭⁭‬⁬‬​‮‮‫‮‎‪‮‭‎‍⁪⁫‮‌⁬‌‏‫⁪‮(viewComboBoxColumn), (object) current);
            num3 = (int) num4 * 2043429229 ^ 1444542766;
            continue;
          case 2:
            goto label_16;
          case 3:
            current = enumerator.Current;
            num3 = 757104015;
            continue;
          case 4:
            goto label_13;
          default:
            goto label_12;
        }
      }
label_16:
      return;
label_12:;
    }
  }

  public static void \u200B​⁭‌‏‎⁭‏‮⁯⁭​⁮‍‮‍⁫‬‏‪‭‏‪‎‏‭‌​⁯‮‍‌‌‮​​​‍‮⁮‮(string _param0)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁮⁫⁫​⁮⁭⁬‎⁫⁬‫​⁭‪⁬‍‬⁭​‌‬‭⁪⁪‏‍​‍‏‏‏⁮⁬‬⁭⁯​‌‌‮();
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁪‭‭‪‍‮⁬‍⁭​‍‌‌⁬‭​​​​​​⁪‌⁬⁭‌⁫⁬⁯‏‫‍‎⁬‏​‎⁪⁭‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‭⁮‎⁯‌‬‪⁪‏⁬⁫‌‭‮‍⁮⁪⁫‎‍‌‭‏⁪‫​‍‬‬‎⁯‏‏‎‭⁮⁬⁫⁯‮, _param0);
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‌⁭‫⁪⁭⁪‫​‮⁭‎⁫‫​⁭‍⁫‮‬⁬​⁭‏‭‮‏‏‌⁮‮‮⁯‭​⁮⁬⁫‏‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B‭⁮‎⁯‌‬‪⁪‏⁬⁫‌‭‮‍⁮⁪⁫‎‍‌‭‏⁪‫​‍‬‬‎⁯‏‏‎‭⁮⁬⁫⁯‮, 5000);
  }

  public void \u202C⁯‌‪‍⁫⁯⁮⁬‫​‪⁮‭⁮​‍‮‍‪⁯‎⁯‍‮‍⁬⁭‌⁫‫‮⁯‭​​‬‏⁬‏‮(string _param1)
  {
    IEnumerator enumerator = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‫‎‭​⁫‍⁪‍‬‎⁯‭‭⁬‮⁯‏​‌‭⁬⁯‮‌⁪⁬‌‏⁪‏​‫‬‍⁭⁫‪‍‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‌‏⁯‮​⁯‎‍⁪‪‌⁫‬‍‌⁮⁭‍‬‫⁮‍⁪‮‍⁫​​⁬⁯⁮⁮‍‌‫‎‍⁬⁬‮(this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮));
    try
    {
label_5:
      int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‬‌‌‭‬⁫⁪⁬⁮‭‎​⁪‏⁫‮⁫‪‎⁬​⁯‌⁭‬‍‏⁬​⁪⁬​‏‌⁫‬⁯⁪⁯‮(enumerator) ? 1826659983 : (num1 = 1900937141);
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1394739569)) % 4U)
        {
          case 1:
            goto label_5;
          case 2:
            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁬⁫‍‪​⁫‮‬‍⁫⁮‫⁬⁬‭‬​⁮⁫‭‭​‬‫‫‫⁪‪‎⁪⁬⁪‪⁪⁬⁫‭‌⁮‮((Control) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁬⁮⁫⁯⁭⁮‫⁭‍​​⁮⁭​⁬‌⁯‪⁯‪⁫⁯‫​⁬‍⁭​‭‫‎‬‌‏⁪‎‬‬‏‮(enumerator), _param1 == null ? (Image) null : bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‬⁪⁭⁪‌⁮⁬‭‮⁫⁪⁭⁯‬‪⁭‭‪‭‮‌⁬‮⁪‫​⁯‍‬‮⁬‏‪⁯⁫⁬⁮‍‪‮(_param1));
            num1 = 1977137452;
            continue;
          case 3:
            num1 = 1826659983;
            continue;
          default:
            goto label_12;
        }
      }
    }
    finally
    {
      IDisposable disposable = enumerator as IDisposable;
label_7:
      int num3 = 609682798;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 1394739569)) % 4U)
        {
          case 0:
            goto label_7;
          case 1:
            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‌⁭‏‭‫⁪⁮‮⁮‭⁬‮‌⁪​‌​‏‪‬‍⁬‬‍‏⁭⁪‍​‏‏‭‎‍​‎⁬‪‮(disposable);
            num3 = (int) num4 * 1507971860 ^ 1490909071;
            continue;
          case 3:
            int num5 = disposable != null ? 906946744 : (num5 = 226592543);
            num3 = num5 ^ (int) num4 * -2083238996;
            continue;
          default:
            goto label_11;
        }
      }
label_11:;
    }
label_12:
    ConfigController.InterfaceConfig.PathToBackgroundImgTabs = _param1;
    ConfigController.InterfaceConfig.Save();
  }

  public void \u202D⁮‌‏​​⁪⁯‌‪‭​⁯⁫⁭‭​‍‍‭‏​‌‫‪⁮‬⁮⁪⁯‭⁯⁭‭​‬⁮⁯‬‌‮(string _param1)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁬⁫‍‪​⁫‮‬‍⁫⁮‫⁬⁬‭‬​⁮⁫‭‭​‬‫‫‫⁪‪‎⁪⁬⁪‪⁪⁬⁫‭‌⁮‮((Control) this, _param1 == null ? (Image) null : bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‬⁪⁭⁪‌⁮⁬‭‮⁫⁪⁭⁯‬‪⁭‭‪‭‮‌⁬‮⁪‫​⁯‍‬‮⁬‏‪⁯⁫⁬⁮‍‪‮(_param1));
label_1:
    int num1 = -1688951063;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -737869710)) % 4U)
      {
        case 0:
          goto label_1;
        case 1:
          ConfigController.InterfaceConfig.Save();
          num1 = (int) num2 * -1225342643 ^ 1325427437;
          continue;
        case 2:
          goto label_3;
        case 3:
          ConfigController.InterfaceConfig.PathToBackgroundImgGeneral = _param1;
          num1 = (int) num2 * 1839670003 ^ 1512885658;
          continue;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  public void \u200F⁫‪‏​⁬‭‫‌‏‎‏⁬⁯​⁪⁮‬⁬‮‫‮‬⁭‏⁮‮‫⁯‮⁭⁪‭‏‌‮‬⁬‎‪‮(Color _param1)
  {
    if (_param1.ToArgb() == Color.Black.ToArgb())
      goto label_9;
label_1:
    int num1 = 1152736853;
label_2:
    ToggleSwitchModernRenderer switchModernRenderer;
    Color color1;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 2001701433)) % 8U)
      {
        case 0:
          switchModernRenderer = new ToggleSwitchModernRenderer()
          {
            LeftSideBackColor1 = color1,
            LeftSideBackColor2 = color1,
            ArrowNormalColor = color1,
            ArrowHoverColor = Color.White,
            ArrowPressedColor = Color.White
          };
          this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          this.\u206E⁪‮‭‭⁪​⁪‮⁮⁮‬‎⁯‌⁮​‫‪⁯​⁮‬​‮⁬‏⁫⁪‍⁪‪‍⁮‫‫⁫‍‎‫‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          num1 = (int) num2 * -465298016 ^ 1481226227;
          continue;
        case 2:
          this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          num1 = (int) num2 * -1403631782 ^ 1068869243;
          continue;
        case 3:
          goto label_1;
        case 4:
          goto label_8;
        case 5:
          this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          this.\u200B⁭⁪‎‍⁫⁮⁬⁪​⁯⁬⁯‫⁯‫⁪⁪‍‎‏‎⁯⁬⁫⁮⁬‏‌⁭‍⁪‪‍⁪‎⁯⁯⁯‮‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          num1 = (int) num2 * -1308081769 ^ -287294627;
          continue;
        case 6:
          this.\u200B⁫⁭‏​⁯‬⁪‎⁯‌⁮‬‫‍‎⁭⁯⁪‎‌‎⁭‫‭⁮‪‭⁭‫‭⁮​‪‮‌‬⁪⁬‫‮.SetRenderer((ToggleSwitchRendererBase) \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<ToggleSwitchModernRenderer>(switchModernRenderer));
          num1 = (int) num2 * 206994962 ^ -2080325432;
          continue;
        case 7:
          this.ForeColor = _param1;
          this.\u206D⁪⁭‭‌‪⁬⁭⁬⁭​​‏⁮⁬⁮⁫‌‏‎​⁮‬⁬⁫​‎‌‫⁮‫⁫⁯‌‍‮‏⁭‍⁪‮.ForeColor = _param1;
          num1 = (int) num2 * -912968183 ^ 1111368183;
          continue;
        default:
          goto label_11;
      }
    }
label_8:
    Color color2 = _param1;
    goto label_10;
label_11:
    IEnumerator enumerator = this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮.TabPages.GetEnumerator();
    try
    {
label_16:
      int num3 = !enumerator.MoveNext() ? 675596909 : (num3 = 1255089944);
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 2001701433)) % 4U)
        {
          case 1:
            ((Control) enumerator.Current).ForeColor = _param1;
            num3 = 364920914;
            continue;
          case 2:
            num3 = 1255089944;
            continue;
          case 3:
            goto label_16;
          default:
            goto label_24;
        }
      }
    }
    finally
    {
      IDisposable disposable = enumerator as IDisposable;
label_18:
      int num5 = 605045391;
      while (true)
      {
        uint num6;
        switch ((num6 = (uint) (num5 ^ 2001701433)) % 4U)
        {
          case 1:
            disposable.Dispose();
            num5 = (int) num6 * 206911641 ^ -769780488;
            continue;
          case 2:
            int num7 = disposable != null ? 402286700 : (num7 = 1981095013);
            num5 = num7 ^ (int) num6 * 748503804;
            continue;
          case 3:
            goto label_18;
          default:
            goto label_23;
        }
      }
label_23:;
    }
label_24:
    ConfigController.InterfaceConfig.ForColorAsArgb = _param1.ToArgb();
label_25:
    int num8 = 1260228625;
    while (true)
    {
      uint num9;
      switch ((num9 = (uint) (num8 ^ 2001701433)) % 3U)
      {
        case 0:
          goto label_27;
        case 1:
          ConfigController.InterfaceConfig.Save();
          num8 = (int) num9 * 1311178732 ^ 1653381159;
          continue;
        case 2:
          goto label_25;
        default:
          goto label_20;
      }
    }
label_27:
    return;
label_20:
    return;
label_9:
    color2 = Color.Gray;
label_10:
    color1 = color2;
    num1 = 1166062129;
    goto label_2;
  }

  private string \u206C‍‭⁫⁯⁮​‍‮⁫⁯‮‫‏​‎‬‮⁯‪⁬‬‪⁫‏‎⁬‭‫⁯‏‫⁯​⁫‬‬⁮‬‌‮()
  {
    return (string) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁫⁮⁬‬‫⁫⁬⁫⁭‪​⁫⁮⁮‌‪‌‌⁮⁮‏‎⁫‎‎⁮⁫​⁭⁬‬‫⁪​‪​‭⁮⁯‮((Control) this, (Delegate) (() =>
    {
      MB\u0029Bz\u0024\u005C0V\u002C\u00284bIV\u0022y7tT_GM\u005D6 mbBz0V4bIvY7tTGm6 = new MB\u0029Bz\u0024\u005C0V\u002C\u00284bIV\u0022y7tT_GM\u005D6();
      string str;
      try
      {
        if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‌‪‬‏‍⁮‍‪‍⁮‭‮⁭‏‫‪‎‫‎​​⁫⁯⁭‫‪⁫‫‪⁫⁬​‌‏‫‬⁯‪‌‮((Form) mbBz0V4bIvY7tTGm6, (IWin32Window) this) != DialogResult.OK)
          goto label_5;
label_2:
        int num1 = -431764224;
label_3:
        uint num2;
        switch ((num2 = (uint) (num1 ^ -770870121)) % 4U)
        {
          case 0:
            goto label_2;
          case 2:
            break;
          case 3:
            str = mbBz0V4bIvY7tTGm6.\u200B⁮‬⁪‌⁭‭⁬‪‍⁪⁫​‏⁭​⁭⁯‎⁭‭⁪⁬⁯‍⁬‏‎⁫‫‬‪‪​‭‬‏‫‏‮‮();
            goto label_11;
          default:
            goto label_11;
        }
label_5:
        str = (string) null;
        num1 = -604645438;
        goto label_3;
      }
      finally
      {
        if (mbBz0V4bIvY7tTGm6 != null)
        {
label_7:
          int num3 = -153990205;
          while (true)
          {
            uint num4;
            switch ((num4 = (uint) (num3 ^ -770870121)) % 3U)
            {
              case 0:
                goto label_7;
              case 1:
                bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‌⁭‏‭‫⁪⁮‮⁮‭⁬‮‌⁪​‌​‏‪‬‍⁬‬‍‏⁭⁪‍​‏‏‭‎‍​‎⁬‪‮((IDisposable) mbBz0V4bIvY7tTGm6);
                num3 = (int) num4 * 873953767 ^ 207202524;
                continue;
              default:
                goto label_10;
            }
          }
        }
label_10:;
      }
label_11:
      return str;
    }));
  }

  private static void \u202A‏‭⁬‫‪‎⁪⁭⁬⁭‫‪‏​‏‬⁫‬​⁫⁫‎⁬⁮‫⁯‪‫⁯⁯‬⁯⁮⁬‬⁪⁪⁭‭‮(string _param0)
  {
    if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(_param0))
      return;
label_1:
    int num1 = -287667189;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -400522353)) % 3U)
      {
        case 0:
          goto label_5;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B⁬‫⁯‮‬‌⁫‫⁮⁮‎‍‏⁮‫‫‍⁮⁪‏⁬‬‪‏⁫⁪‎⁪‫‪‌‍‌‍⁮‮‪‌‏‮(_param0, nameof ());
          num1 = (int) num2 * -5246621 ^ -1632437547;
          continue;
        case 2:
          goto label_1;
        default:
          goto label_6;
      }
    }
label_5:
    return;
label_6:;
  }

  virtual CreateParams Form.\u206C⁫‎‫⁮‌⁬⁬⁬‮⁯‌‬‮⁫⁫‪⁭‍⁫‎‏⁬⁭⁭‪‫‏⁭⁭⁪‪⁫​⁫⁯⁪‌‎‮
  {
    get
    {
      CreateParams createParams = __nonvirtual (((Form) this).CreateParams);
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‍‫‪‌⁬‍‏​‭‪‮‍⁮‎⁪‫⁬‏‪‍‍​‮‍⁪‬⁯⁭‭⁭⁭⁭‭‪⁫‫‫‎‏‮(createParams, bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‭⁭‌‬⁫⁪⁪​‌⁭⁬‮‏‮‏⁬⁭‎‪‏⁮‍⁫⁯⁭‏‮‬​‪⁮‭‮⁪​⁭⁭‬‮(createParams) | 33554432 /*0x02000000*/);
      return createParams;
    }
  }

  private void \u206F‬‍⁭​⁯‫‌⁮‪‎‫‏‪‌‏‌​‎⁪⁮⁮‍⁯⁯⁯‍‍⁫‍‭‮‫‪‬⁪⁭⁮⁫‎‮(object _param1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁭‮‍‬‏‫‪⁫‮⁯‭‎⁯‫⁮‭‭‍⁭‌⁬‭⁬‫‍‏‫‭‪​⁬‏⁭‏‍⁮⁭‫‍‮((Form) this, false);
label_1:
    int num1 = 1981025479;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 74377524)) % 11U)
      {
        case 0:
          int num3 = !bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2490413687U)) ? 1157361212 : (num3 = 1310967257);
          num1 = num3 ^ (int) num2 * 1987167575;
          continue;
        case 1:
          int num4 = !bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(182717178U)) ? 1218665674 : (num4 = 2033355331);
          num1 = num4 ^ (int) num2 * 1439957801;
          continue;
        case 2:
          int num5 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1417716753U)) ? 1963720248 : (num5 = 1301454707);
          num1 = num5 ^ (int) num2 * -1769714458;
          continue;
        case 3:
          goto label_3;
        case 4:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(167294804U));
          num1 = 1989359452;
          continue;
        case 5:
          goto label_1;
        case 6:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁪​‏‍‪‌‌‎⁪‌⁬​⁫‪‮⁯⁪‮‪‭⁬‭​‪‏⁯‎‭‌‪‮⁬‮‪⁭‏‬⁪‍‮(1);
          num1 = (int) num2 * -405907904 ^ 730179652;
          continue;
        case 7:
          int num6 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2867249043U)) ? -1650984025 : (num6 = -376941287);
          num1 = num6 ^ (int) num2 * 1918795458;
          continue;
        case 8:
          int num7 = !bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2832077660U)) ? -561550601 : (num7 = -1934024687);
          num1 = num7 ^ (int) num2 * -1350193275 /*0xAF85AF85*/;
          continue;
        case 9:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‏‪‮‏‪​‮‎‎‫‎‪‎‭​⁯‎‪‌‏‬‬‎​⁭‭‏‪⁮⁫‏⁮‮‫‏‪‎‍⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‭‎‎⁮‪⁫‏‬‪‫‏‮‌‭‮‍⁬⁫⁮‫⁫​‎⁪‬‬‌⁭​‮⁯‬‮⁪‮​‌⁭‬‮((Action) (() =>
          {
            AccountsManager.LoadAndPrepareAccounts(new Func<string>(this.\u206C‍‭⁫⁯⁮​‍‮⁫⁯‮‫‏​‎‬‮⁯‪⁬‬‪⁫‏‎⁬‭‫⁯‏‫⁯​⁫‬‬⁮‬‌‮));
label_1:
            int num12 = 1936691840;
            while (true)
            {
              uint num13;
              switch ((num13 = (uint) (num12 ^ 1193329237)) % 3U)
              {
                case 0:
                  goto label_3;
                case 1:
                  bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‍‪‪⁪⁭⁭‮​⁮​⁯⁪‬‍‍‮⁬⁮⁫‍​‎‍⁫‏⁪‏‫⁮‮⁭⁮‏‬‍‌⁫⁫⁬‮((Control) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮, (Delegate) (() =>
                  {
                    using (List<string>.Enumerator enumerator = AccountsManager.GetAccountsList().GetEnumerator())
                    {
label_5:
                      int num14 = enumerator.MoveNext() ? -1010156800 : (num14 = -261739054);
                      string current;
                      while (true)
                      {
                        uint num15;
                        switch ((num15 = (uint) (num14 ^ -1440758959)) % 5U)
                        {
                          case 1:
                            goto label_5;
                          case 2:
                            current = enumerator.Current;
                            num14 = -1421178123;
                            continue;
                          case 3:
                            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‫‪‭⁯⁮‎⁮‫‎‭​⁮‪⁪⁯⁫⁪⁪‏⁪​‭‮⁮‍‏‍‫⁭⁬‏‏‭⁭‬‫⁬⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮), (object) current);
                            num14 = (int) num15 * -1239151690 ^ 1273147819;
                            continue;
                          case 4:
                            num14 = -1010156800;
                            continue;
                          default:
                            goto label_9;
                        }
                      }
                    }
label_9:
                    if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A⁮‪⁭‌⁬⁪⁫⁮⁫‍⁭‬‎‎‮⁯‪⁯‎⁬‫‍‭‬⁪‫‌⁮​⁯‎⁭‪‮‎‫‌⁪‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮)) == 0)
                      goto label_14;
label_10:
                    int num16 = -404957196;
label_11:
                    while (true)
                    {
                      uint num17;
                      switch ((num17 = (uint) (num16 ^ -1440758959)) % 7U)
                      {
                        case 0:
                          goto label_10;
                        case 1:
                          goto label_14;
                        case 2:
                          goto label_12;
                        case 3:
                          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁭⁯‫⁫⁫‏‫‏⁭‫⁯‌⁬​‌⁫‭⁪⁯‏⁬‭‭‏‎‫⁬‭‭⁬‫‬‭⁬‌‍‫‪‌‮((ToolStripItem) this.\u206D⁪⁬⁭‭⁮⁫⁯‌⁮‫‪‌‫‫‌‌⁮⁬‮‮‬‍‏⁪‍‫‪‮‪⁪‭‎⁪⁭​‬‏‍‏‮, true);
                          num16 = (int) num17 * -1632062640 ^ 623200872;
                          continue;
                        case 4:
                          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3942778336U));
                          num16 = -408681333;
                          continue;
                        case 5:
                          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁯‪‫‏‮‭‪‫‬‮⁯⁫‭‏‍‌‮‮⁮‏‪‌⁫‎‮‌‮‭⁭⁬⁮​‎‌⁭‍‭‮‪‮((ListControl) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮, 0);
                          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪​‮⁭‍‪‭‍‌⁮‮​⁯‮⁮‫‎‍⁬‌‭​‍‮⁫‭‌‬⁫‮⁭⁯⁮‮‏‫‌​⁬‮((Control) this.\u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮, true);
                          num16 = (int) num17 * -1460312108 ^ 1556123786;
                          continue;
                        case 6:
                          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‪​‮⁭‍‪‭‍‌⁮‮​⁯‮⁮‫‎‍⁬‌‭​‍‮⁫‭‌‬⁫‮⁭⁯⁮‮‏‫‌​⁬‮((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮, true);
                          num16 = (int) num17 * -1532837255 ^ -158317647;
                          continue;
                        default:
                          goto label_7;
                      }
                    }
label_12:
                    return;
label_7:
                    return;
label_14:
                    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3595389948U));
                    num16 = -2095913872;
                    goto label_11;
                  }));
                  num12 = (int) num13 * 1093684442 ^ 1666356462;
                  continue;
                case 2:
                  goto label_1;
                default:
                  goto label_5;
              }
            }
label_3:
            return;
label_5:;
          })));
          num1 = (int) num2 * -1898046607 ^ 1762784194;
          continue;
        case 10:
          int num18 = (int) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‭⁯⁯‬⁮‌‏‍‎⁫‎⁫‫⁮⁮‪​​‬⁯⁭‮‎‮‭‏‮‭‎‎‪​‍⁭‭⁪‬‮‌‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4221649412U), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2726410374U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
          num1 = 1834996070;
          continue;
        default:
          goto label_13;
      }
    }
label_3:
    return;
label_13:;
  }

  private void \u202C‏‬‫⁬⁮‭‏⁮‮‍‎‌‎⁬‮​⁭​‬⁪‏‏‭⁭‌‌‍⁪⁭⁪‍‮‬‏‫‬‮‌‎‮(object _param1, EventArgs _param2)
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C vYAwojWqshZnr9Ul = this.\u206A‭‫‪‫​‎‏⁭‬‍​‮‭⁯⁮‏⁪‭⁫‮‫​‌‏⁫⁫‪⁭⁯⁯‭⁯‏‌⁯‎⁫‎⁬‮;
    if (vYAwojWqshZnr9Ul != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) vYAwojWqshZnr9Ul);
    else
      goto label_4;
label_2:
    int num1 = 1274940586;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 1670718005)) % 3U)
    {
      case 1:
        break;
      case 2:
        goto label_2;
      default:
        this.\u206A‭‫‪‫​‎‏⁭‬‍​‮‭⁯⁮‏⁪‭⁫‮‫​‌‏⁫⁫‪⁭⁯⁯‭⁯‏‌⁯‎⁫‎⁬‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
        return;
    }
label_4:
    this.\u206A‭‫‪‫​‎‏⁭‬‍​‮‭⁯⁮‏⁪‭⁫‮‫​‌‏⁫⁫‪⁭⁯⁯‭⁯‏‌⁯‎⁫‎⁬‮ = new \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C();
    num1 = 584083090;
    goto label_3;
  }

  private void \u202C⁯‭‌‮​‏‬‮‪‫⁮‍‎⁭‭‪​⁭⁯‮‭‫‍⁯‫‮‫‌⁪​‮‬⁯‪⁪‮‪‭⁬‮(object _param1, EventArgs _param2)
  {
    n\u002Cf1\u005BE\u002F\u005Ez\u0026qh5\u003FUff\u0023\u003DX\u0024\u007B\u003C7\u0024 nF1EZQh5UffX7 = this.\u200D⁬⁯‌‪⁬‬⁫⁮‍​⁭⁭⁭⁯‎‮‎⁬‌‬‪‭⁬‌‌‏​⁭⁬‌⁮⁬‮⁮⁬‍​‌⁯‮;
    if (nF1EZQh5UffX7 != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) nF1EZQh5UffX7);
    else
      goto label_5;
label_2:
    int num1 = 1051806309;
label_3:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 868212100)) % 4U)
      {
        case 0:
          goto label_4;
        case 1:
          goto label_5;
        case 2:
          this.\u200D⁬⁯‌‪⁬‬⁫⁮‍​⁭⁭⁭⁯‎‮‎⁬‌‬‪‭⁬‌‌‏​⁭⁬‌⁮⁬‮⁮⁬‍​‌⁯‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
          num1 = (int) num2 * 657648654 ^ -603953548;
          continue;
        case 3:
          goto label_2;
        default:
          goto label_7;
      }
    }
label_4:
    return;
label_7:
    return;
label_5:
    this.\u200D⁬⁯‌‪⁬‬⁫⁮‍​⁭⁭⁭⁯‎‮‎⁬‌‬‪‭⁬‌‌‏​⁭⁬‌⁮⁬‮⁮⁬‍​‌⁯‮ = new n\u002Cf1\u005BE\u002F\u005Ez\u0026qh5\u003FUff\u0023\u003DX\u0024\u007B\u003C7\u0024();
    num1 = 1105183966;
    goto label_3;
  }

  private void \u200E‬⁬⁬‍‍⁫‎‭‍​⁯‪​‮‬⁯⁬⁯⁯⁭‍​​‏‎‫‏⁫‫⁪⁭⁫‪⁯⁮‎‏‮⁮‮(object _param1, EventArgs _param2)
  {
    Z_\u003BAJ4d\u007BtrZ\u0029\u002C\u0026U\u003Fh9qF4n0h\u0021 aj4dTrZUH9qF4n0h = this.\u206C‫‬‎‮⁫⁫⁫​⁬‬⁮‫‎‬‏‎⁫⁯‫⁬⁭⁮‏⁪​‪‎‭‮⁭⁪⁮‪‬‏⁪⁭‎‏‮;
    if (aj4dTrZUH9qF4n0h != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) aj4dTrZUH9qF4n0h);
    else
      goto label_4;
label_2:
    int num1 = -595065578;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -371694077)) % 3U)
    {
      case 0:
        goto label_2;
      case 1:
        break;
      default:
        this.\u206C‫‬‎‮⁫⁫⁫​⁬‬⁮‫‎‬‏‎⁫⁯‫⁬⁭⁮‏⁪​‪‎‭‮⁭⁪⁮‪‬‏⁪⁭‎‏‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
        return;
    }
label_4:
    this.\u206C‫‬‎‮⁫⁫⁫​⁬‬⁮‫‎‬‏‎⁫⁯‫⁬⁭⁮‏⁪​‪‎‭‮⁭⁪⁮‪‬‏⁪⁭‎‏‮ = new Z_\u003BAJ4d\u007BtrZ\u0029\u002C\u0026U\u003Fh9qF4n0h\u0021();
    num1 = -602263114;
    goto label_3;
  }

  private void \u200D‮⁭‏⁪‍‬‭‭‍‏⁪‫⁬‎‏⁪⁭‮‏⁭‮⁪‭‭‫⁫⁪‏⁪⁪⁫‌⁭⁯⁭‌⁪‬‫‮(object _param1, EventArgs _param2)
  {
    \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022 vBnaqZpYx8v1OW = this.\u202C‌⁮​⁮⁭‎⁫⁯‭‪‏⁮‍⁭‎⁪​‏⁫‫⁪⁪​‎​‭‫⁯‬​⁫⁪‏⁭⁯‮⁪⁯‫‮;
    if (vBnaqZpYx8v1OW != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) vBnaqZpYx8v1OW);
    else
      goto label_4;
label_2:
    int num1 = -414884744;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -117264238)) % 3U)
    {
      case 1:
        break;
      case 2:
        goto label_2;
      default:
        this.\u202C‌⁮​⁮⁭‎⁫⁯‭‪‏⁮‍⁭‎⁪​‏⁫‫⁪⁪​‎​‭‫⁯‬​⁫⁪‏⁭⁯‮⁪⁯‫‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
        return;
    }
label_4:
    this.\u202C‌⁮​⁮⁭‎⁫⁯‭‪‏⁮‍⁭‎⁪​‏⁫‫⁪⁪​‎​‭‫⁯‬​⁫⁪‏⁭⁯‮⁪⁯‫‮ = new \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022();
    num1 = -560454272;
    goto label_3;
  }

  private void \u206B‮‮‪‌‬‪⁭​⁯‫⁯‪‭‏‮⁭⁪‭‬​⁯‮⁮​⁭⁭‭⁪⁬‮‌‪⁪⁭‫‪⁪‫‌‮(object _param1, EventArgs _param2)
  {
    \u202E‏⁮⁪‏⁫‬⁪‏‌‎‍‍‎⁫⁮⁫‫‫⁫‏⁭‭⁫‪‏‪⁫‮⁪‫‭⁮‌‏‎⁮‫⁭‬‮ obj = this.\u206C‫‮‪‎⁯​⁬‎⁯‏⁬‏⁫⁯‌‍‫‮‮‫‮‬‪‮⁪‬⁬‍​⁮‬⁯‌‪‏‎‌‫‫‮;
    if (obj != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) obj);
    else
      goto label_4;
label_2:
    int num1 = -1581052757;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -94371740)) % 3U)
    {
      case 0:
        goto label_2;
      case 2:
        break;
      default:
        this.\u206C‫‮‪‎⁯​⁬‎⁯‏⁬‏⁫⁯‌‍‫‮‮‫‮‬‪‮⁪‬⁬‍​⁮‬⁯‌‪‏‎‌‫‫‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
        return;
    }
label_4:
    this.\u206C‫‮‪‎⁯​⁬‎⁯‏⁬‏⁫⁯‌‍‫‮‮‫‮‬‪‮⁪‬⁬‍​⁮‬⁯‌‪‏‎‌‫‫‮ = new \u202E‏⁮⁪‏⁫‬⁪‏‌‎‍‍‎⁫⁮⁫‫‫⁫‏⁭‭⁫‪‏‪⁫‮⁪‫‭⁮‌‏‎⁮‫⁭‬‮();
    num1 = -1386579027;
    goto label_3;
  }

  private void \u202B⁬‪⁭‭‍‌⁭‎⁮​⁮‪⁬‌‫‪‭⁮‮‬​‫⁭‏‏⁬⁭‏⁮⁬‬‍‪⁮‍‎⁭‫‍‮(object _param1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁭‌‬‌⁭⁬‫⁬‏‏‎‌​⁪⁮‎⁯⁫‏‍‮‎⁯‏‌⁪⁬⁪‬⁯‌​‮⁮‫⁬⁬⁭‬‮((ToolStripDropDown) this.\u202A​‏⁬‭‏⁮‎⁭‎⁯⁭‍⁯⁮‫‭​‬⁫⁫⁪⁬‮⁮⁭⁯⁯‬‭‏‫⁭⁫‮⁫‮‪‏‮, bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D⁮‎⁯‬⁭‫‍‬⁯‎‫⁯⁮‬‬⁫⁯⁯⁭‏‮⁫‫‎⁯‏‎⁫⁭⁮‭⁯‌‪⁮‫‪⁬‮());
  }

  private void \u200B‭⁪‍⁪‍⁫​‪‬⁯​‌‎⁭‪⁭‎‬‭‮‭‬⁫⁮⁭​‍⁬​⁪‪⁭‭‌‮‫⁭⁪‎‮(object _param1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁫⁬⁬⁬‭‍‪‭‮⁮‎‫⁬⁮‮‎‫⁫‏‮‪​⁮‎‬‌⁫‬‮⁬⁮​⁯⁫⁫⁮⁭⁫‪‮((ButtonBase) _param1, false);
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‫‏‍⁪‎‭⁪⁬​‭‫‫⁯‪‌⁭‏‪‌⁭‮‏‪⁮‭‫‌⁭‭⁫‎‏‪‬⁫⁫‬⁬‎‮((Control) _param1, Color.Silver);
  }

  private void \u202B⁭‭⁭⁮‍⁪⁫⁯‏‍‭‮‎‬‪‍‭⁫‫⁯‭‭⁯‮‭⁯‎⁬⁯‪⁮‭‬‍‍‪⁮‏‭‮(object _param1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁫⁬⁬⁬‭‍‪‭‮⁮‎‫⁬⁮‮‎‫⁫‏‮‪​⁮‎‬‌⁫‬‮⁬⁮​⁯⁫⁫⁮⁭⁫‪‮((ButtonBase) _param1, true);
label_1:
    int num1 = 2534424;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 172314860)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‫‏‍⁪‎‭⁪⁬​‭‫‫⁯‪‌⁭‏‪‌⁭‮‏‪⁮‭‫‌⁭‭⁫‎‏‪‬⁫⁫‬⁬‎‮((Control) _param1, Color.Transparent);
          num1 = (int) num2 * 371737385 ^ 1515871286;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private void \u200C‌‍‎⁪‭‌‭‬‍‎‏‫‭⁪‮‎⁯⁭⁯‮‪‌‌‍⁪⁪⁪‪⁪⁮​‍‏‬‎‬⁪‪‭‮()
  {
    ++this.\u206F⁬‮⁮‎‫⁭‍⁭⁮​⁪‮‏‮⁮‍⁬‎⁮‪‮‏‏‮‏‫⁫⁫⁫‭‮‎‏‬⁭‭‍‌⁭‮;
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‏‪‮‏‪​‮‎‎‫‎‪‎‭​⁯‎‪‌‏‬‬‎​⁭‭‏‪⁮⁫‏⁮‮‫‏‪‎‍⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‭‎‎⁮‪⁫‏‬‪‫‏‮‌‭‮‍⁬⁫⁮‫⁫​‎⁪‬‬‌⁭​‮⁯‬‮⁪‮​‌⁭‬‮((Action) (() =>
    {
      this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ = true;
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C⁪‌⁫‏‌‌‏‎‮⁬‪​‎‎‭‌⁫‭‬‍⁯‮⁬‏‫​‪‮​‎‍⁫⁯‏⁭‭⁭‏‍‮(100);
      --this.\u206F⁬‮⁮‎‫⁭‍⁭⁮​⁪‮‏‮⁮‍⁬‎⁮‪‮‏‏‮‏‫⁫⁫⁫‭‮‎‏‬⁭‭‍‌⁭‮;
label_1:
      int num1 = -1509731802;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -960317199)) % 4U)
        {
          case 0:
            goto label_1;
          case 1:
            goto label_3;
          case 2:
            this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ = false;
            num1 = (int) num2 * 1373589437 ^ -1367190182;
            continue;
          case 3:
            int num3 = this.\u206F⁬‮⁮‎‫⁭‍⁭⁮​⁪‮‏‮⁮‍⁬‎⁮‪‮‏‏‮‏‫⁫⁫⁫‭‮‎‏‬⁭‭‍‌⁭‮ == 0 ? 2135151225 : (num3 = 559114378);
            num1 = num3 ^ (int) num2 * -174134538;
            continue;
          default:
            goto label_6;
        }
      }
label_3:
      return;
label_6:;
    })));
  }

  private void \u200B⁭‮‫⁭‪⁬⁫⁬‫‭‫‏⁫⁭‏⁮‏‮‍‭⁬‪⁪‪⁭‮‪⁭‪‮‏‪⁮‬‫‫​​‮‮(object _param1, EventArgs _param2)
  {
    if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮((ListControl) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮) != -1)
      goto label_5;
label_1:
    int num1 = 653987400;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 232299112)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          this.\u200C‌‍‎⁪‭‌‭‬‍‎‏‫‭⁪‮‎⁯⁭⁯‮‪‌‌‍⁪⁪⁪‪⁪⁮​‍‏‬‎‬⁪‪‭‮();
          this.\u200B⁯​‌‌‏‬⁯‎‎‬⁪⁯‎‍⁫⁪‍⁬‮​‎‫​⁮‬‫⁪⁫‪‏⁪⁭⁪⁫⁫‎⁬⁭⁪‮();
          this.\u200C‮‍‫‎‍‬‫‍‍‪‪​‪‮‭‬‍⁭⁫‫‏‮⁭‭‭‭‪‬‌‏‮⁬⁬‏⁫‎​‫‫‮();
          this.\u202D‬⁬⁯⁮⁪​⁪‮‭‎⁯‬‫⁭‮⁭‮​‎⁭‪⁮‏⁯‌‪⁭⁭‭⁭‪‍‌‫⁭‬‏‮‪‮();
          num1 = (int) num2 * -35814618 ^ 1861166498;
          continue;
        case 2:
          goto label_5;
        case 3:
          goto label_3;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:
    this.\u202C‪​‬‭⁯‎‌‎‬‍‪‭‏​⁬‫‎‫⁬‍‪‌‮⁯⁪⁫⁫‍⁭‮‬​‮‭‫⁯⁯​⁫‮();
    this.\u206C‍‌⁯⁭‏⁮‫‎⁯‬‏⁬‏‬‌‬⁬⁬‪‬‏‮‌⁮‏‌‪‭⁮⁪⁪​‬‫⁮‬‪‎⁯‮();
    return;
label_5:
    AccountsManager.SetActiveAccount(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁬⁮‪⁯‮‭‎⁪⁯⁯‏⁪‌‮‎⁯‫‫‭‌⁭‪‬‎‌⁪‌⁯‪⁯⁯‍⁫⁫‪‭‪​⁯‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮((ListControl) this.\u206F‭‍⁯‫‮‮‎‪‍‭⁫‮​‭‪⁪​⁬‮‌‌‭⁫⁮‮⁪‎⁮⁬‬‮‏‏‭⁪⁪‮‬⁮‮))));
    num1 = 1218443871;
    goto label_2;
  }

  private void \u202C⁮⁭​⁬​‎‍‍⁮‍‏‫⁮⁮‌‫​​⁬⁪​⁭⁯​⁬‭‏‌⁪‭‍⁪‌‮‌‭⁯⁯⁯‮(object _param1, EventArgs _param2)
  {
    ConfigController.AnticapConfig.SelectedMode = SelectedMode.Manual;
    ConfigController.AnticapConfig.Save();
  }

  private void \u200E‫⁫‍‮‌⁫⁫⁪‎⁬‪‭‍‬‌‭⁬⁮‎⁬⁬‭‎‭⁭⁬⁭‍‫‬⁯‬⁫⁫‍‮‮⁮‭‮(object _param1, EventArgs _param2)
  {
    ConfigController.AnticapConfig.SelectedMode = SelectedMode.Rucaptcha;
    ConfigController.AnticapConfig.Save();
  }

  private void \u202A⁯⁫⁯⁫​⁫‫⁯‏‭‍⁬⁮‏‭‭‍‍‌⁮‮⁮⁯‬‭‍⁬‎‮‍‬⁬⁭⁭⁫‏​⁬‮(object _param1, EventArgs _param2)
  {
    ConfigController.AnticapConfig.SelectedMode = SelectedMode.Anticaptcha;
label_1:
    int num1 = 1984865395;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 933769731)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          ConfigController.AnticapConfig.Save();
          num1 = (int) num2 * 690771764 ^ -1735224893;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private void \u206C‮⁪​‫‮⁪⁯‬⁯‌⁯⁯​‫‎⁬‭​‎‎⁯‫⁭‭‬⁪⁯⁭‬‌⁬‎‌‍⁯‭‬‌‌‮(object _param1, EventArgs _param2)
  {
    if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‮⁪⁮⁪‪‍‌⁯‎⁯‪‭‌‎‏‪⁯​‪‫‪‪‌‏⁫‫⁪⁯⁬‍⁯‎⁪⁬​⁫‮‫‪‮(this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮) != null)
      return;
label_1:
    int num1 = -965173977;
    FileStream fileStream;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1108513804)) % 8U)
      {
        case 0:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A⁭⁭‎⁫‮⁬⁮⁮‍‮‮⁬‭‫‏‏‏​⁭⁯⁭⁪‎‌​‮⁭‍‮​⁬‪‏‌‪​⁫‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206F‮‌‏‫‭‎⁭​​​⁪⁮⁭⁫‍‏‪⁫‭‮⁮⁫‌‫⁮‎⁮⁭‎⁯‫‎‍⁪⁪‪‭‍‏‮(this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3302428674U)));
          num1 = (int) num2 * 98534363 ^ 1518308744;
          continue;
        case 1:
          fileStream = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D⁪‬‌‪⁮‫⁮⁮‭⁮‪⁬⁯⁯‪​‬‪‫‌‍⁮⁬⁯⁬​⁪‮‌⁪‎⁯‍‎‍‌‫⁫⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‍⁫‎‌‎⁫⁬⁮⁭‬‎‭⁬​⁮‍‮‭‍‭⁯‬‪‭‍⁮‍⁫⁮‏⁬‌‬‫‬⁭‭​⁭‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1955483803U), (object) this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮), FileMode.Open);
          num1 = (int) num2 * -2008906574 ^ 181989331;
          continue;
        case 2:
          this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮ = \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200E‫⁫‎‭‭‍‎⁯⁬⁮⁬⁭‬⁬⁪‏⁪‬​‏‬⁭‌‮​‫​⁮‏‎‪‫⁪‏​‎⁯‮⁬‮.Dequeue();
          num1 = (int) num2 * -1502640296 ^ -900470955;
          continue;
        case 3:
          int num3 = \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200E‫⁫‎‭‭‍‎⁯⁬⁮⁬⁭‬⁬⁪‏⁪‬​‏‬⁭‌‮​‫​⁮‏‎‪‫⁪‏​‎⁯‮⁬‮.Count != 0 ? 1052579926 : (num3 = 188786872);
          num1 = num3 ^ (int) num2 * -529623968;
          continue;
        case 4:
          goto label_10;
        case 5:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‮‌‌‮‏⁭⁫‌⁪⁫​‭​⁯⁯‏‮‪‫⁬⁯‫​‌⁫⁯⁮⁪⁬⁪⁫‌⁬‪‮‍‎‏‎‮(this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮, bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A‪‍⁬⁪​⁯‌⁮‌‪⁭‭‌‫⁭‪‌⁯‫⁪‮‮⁯⁯⁬‏‏⁫​⁪‪⁭⁭⁮‎‭⁮‪‎‮((Stream) fileStream));
          num1 = (int) num2 * 1866941160 ^ 1510339394;
          continue;
        case 6:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌‎‍‪‪​‍⁭⁯‫⁫‏​⁭‫‪⁬‭​‎‎‮‭‬‍‌⁯‬​‍‍‮⁯‮⁯⁬‭‪‎‮((Stream) fileStream);
          num1 = (int) num2 * -902709455 ^ -1371923814;
          continue;
        case 7:
          goto label_1;
        default:
          goto label_11;
      }
    }
label_10:
    return;
label_11:;
  }

  private void \u202E​‫⁮‪⁯‭⁭⁬‍‭⁫​‭⁭⁮​‮⁫⁮‏⁮​‍⁬⁯⁪‏‍‪​‪⁮⁪⁯‬⁪⁬​⁪‮(object _param1, KeyEventArgs _param2)
  {
    if (bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B⁫‫⁫⁮‌⁬‪‪‪‬‎‮‎‫‪‌‍⁭‭‌⁬‪‬⁮‪‎⁯⁭‬⁭‬‮‫‏⁮‫⁭‍‮(_param2) != Keys.Return)
      return;
label_1:
    int num1 = -2044879226;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1120219911)) % 9U)
      {
        case 0:
          goto label_1;
        case 1:
          int num3 = this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮ == null ? -1400526187 : (num3 = -776854081);
          num1 = num3 ^ (int) num2 * -1238701286;
          continue;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‮‌‌‮‏⁭⁫‌⁪⁫​‭​⁯⁯‏‮‪‫⁬⁯‫​‌⁫⁯⁮⁪⁬⁪⁫‌⁬‪‮‍‎‏‎‮(this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮, (Image) null);
          num1 = (int) num2 * -866602154 ^ 1861925745;
          continue;
        case 3:
          \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200B​‭⁮⁯‎‌‌⁬⁯‪‬‪‎‍‭⁬‎‬‮‮‪⁮⁭‭‎⁫⁯‭⁫⁪‪‎⁬‍​⁫‍‬⁭‮(this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮, bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮));
          num1 = -1248433945;
          continue;
        case 4:
          int num4 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202A⁪‍⁪⁪⁫‫⁯‌⁬‌⁬‪‪‭⁭⁮⁫⁮⁫‫‪‏‫‎⁬⁫⁯‭⁯‭⁫‏⁬⁭⁭‪⁮⁫⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮), nameof ()) ? 626971852 : (num4 = 1350761828);
          num1 = num4 ^ (int) num2 * 1457251071;
          continue;
        case 6:
          goto label_11;
        case 7:
          this.\u200E⁯⁫‫‬⁫‫⁪‏‌⁭​‏‮​⁬‍‬⁪​⁮⁯‌‎‍‬‬‫‫‎‮⁫⁪‌⁫​‬‌⁪‬‮ = (string) null;
          num1 = (int) num2 * -1381064290 ^ 747273843;
          continue;
        case 8:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B‌​‍‎‌‌⁮‭​⁮⁬⁭⁮‫⁭⁯⁫‮⁪‌‭‌⁮​‪‌‎‎‏⁫‏‎⁪⁮⁪‪⁬‌‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‮⁪⁮⁪‪‍‌⁯‎⁯‪‭‌‎‏‪⁯​‪‫‪‪‌‏⁫‫⁪⁯⁬‍⁯‎⁪⁬​⁫‮‫‪‮(this.\u202E⁭⁮‏‎⁯‌‫⁯‏‍‌‬⁫⁭⁭⁭‫⁭‮‮⁮⁬‎‏⁪‏‌⁪‪⁪​⁫‎‪⁪⁯‌⁯‪‮));
          num1 = (int) num2 * -808148061 ^ 475197366;
          continue;
        default:
          goto label_10;
      }
    }
label_11:
    return;
label_10:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‎‫⁮⁮‭⁫‫⁮‭​‭⁯‭‌‎⁭⁯‪⁬⁪‌⁯⁬⁭⁭⁮‮‪⁮‭‌‮‫​‍‎​‬‎‮((TextBoxBase) this.\u206B‪‎⁯​​‪‌⁯⁪‪‭‫‏‎‭‬‍‍⁭‬‌⁪‪‏‫⁯⁭‌⁬‮‌‏⁪‫‍‏‌‭⁫‮);
  }

  private void \u202B‪⁭‪‫⁫‫‪⁬⁭⁭⁭⁪⁫⁪‌⁮‏‬‫⁮⁮‏⁮⁯‫⁬⁪‍⁯‏‎‍‮​​‭‭⁫⁮‮(object _param1, EventArgs _param2)
  {
    if (this.\u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮)
      goto label_6;
label_1:
    int num1 = -1510401567;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -852967070)) % 7U)
      {
        case 0:
          goto label_6;
        case 1:
          num1 = (int) num2 * -2135251731 ^ -1876104251;
          continue;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁬⁫‍‪​⁫‮‬‍⁫⁮‫⁬⁬‭‬​⁮⁫‭‭​‬‫‫‫⁪‪‎⁪⁬⁪‪⁪⁬⁫‭‌⁮‮((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮, (Image) I\u003E42Nl\u002Dn\u0029ew\u005B\u003Dm3w3gT\u003Fj\u0028\u002Fi\u0024.\u200B‌‍⁭⁪‍‎⁭‮‏‬⁬⁮‫⁬⁮‍⁫‬‌‫‏⁯‌‍‎‌‌⁮​‪‎‮‌‫‬‍⁮‮‮);
          num1 = (int) num2 * 63446986 ^ 1129741125;
          continue;
        case 4:
          AccountsManager.StopAllTasks();
          num1 = (int) num2 * -167622625 ^ 1528864940;
          continue;
        case 5:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1410698886U));
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁭⁯‫⁫⁫‏‫‏⁭‫⁯‌⁬​‌⁫‭⁪⁯‏⁬‭‭‏‎‫⁬‭‭⁬‫‬‭⁬‌‍‫‪‌‮((ToolStripItem) this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮, false);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F⁬⁫‍‪​⁫‮‬‍⁫⁮‫⁬⁬‭‬​⁮⁫‭‭​‬‫‫‫⁪‪‎⁪⁬⁪‪⁪⁬⁫‭‌⁮‮((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮, (Image) I\u003E42Nl\u002Dn\u0029ew\u005B\u003Dm3w3gT\u003Fj\u0028\u002Fi\u0024.\u206A‌‌⁭⁮​‮​‬⁭‫⁫‌⁯‎⁪‭‫‪⁫‍‪⁫⁮⁭‏‬‍‪‬‭⁮⁪​‬⁭⁪‍‍‮);
          AccountsManager.StartAllTasks();
          num1 = (int) num2 * -1389485793 ^ -2038644063;
          continue;
        case 6:
          goto label_1;
        default:
          goto label_8;
      }
    }
label_8:
    this.\u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮ = !this.\u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮;
    return;
label_6:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2854790873U));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁭⁯‫⁫⁫‏‫‏⁭‫⁯‌⁬​‌⁫‭⁪⁯‏⁬‭‭‏‎‫⁬‭‭⁬‫‬‭⁬‌‍‫‪‌‮((ToolStripItem) this.\u202A‮‏‎‫‭‭⁫‏⁫⁪‮⁯⁬‏‏⁫⁬‪‮‏‌⁯⁯‪⁪‌‪⁮‍⁬‎‪⁭⁪​⁭⁫‏‏‮, true);
    num1 = -195056723;
    goto label_2;
  }

  private void \u200C⁬‭⁫‌‏‌⁭‭‫‮⁬⁬⁫⁯⁭‏‫⁪‫‍‫‭‎‬‭‎⁮‪​⁬‫⁫⁬‏⁯‭‏⁭⁪‮(object _param1, EventArgs _param2)
  {
    if (!bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪‬‮⁪​‬‭⁫⁬‮⁮‬‭⁮‍‏⁯⁮⁪⁯‭⁪‫⁫‮‪⁫‭‫⁭⁫‭‪⁮‎⁭‭‌‮‮(this.\u200E‌‬‍⁪⁪⁭‫‮⁪⁭‌​‭‎‎⁬‍‌‫⁮⁬‪​‭⁫‎⁮⁯⁫‎⁯‏⁮‏⁫‎⁭‏⁯‮))
      return;
label_1:
    int num1 = 742480571;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1275568401)) % 5U)
      {
        case 0:
          this.\u202B‪⁭‪‫⁫‫‪⁬⁭⁭⁭⁪⁫⁪‌⁮‏‬‫⁮⁮‏⁮⁯‫⁬⁪‍⁯‏‎‍‮​​‭‭⁫⁮‮((object) null, (EventArgs) null);
          num1 = (int) num2 * -1318763615 ^ 1843018898;
          continue;
        case 1:
          int num3 = !this.\u202E‮‪​‫⁯‎⁭​‬‏‪‭‭‭‌‫‪‎⁬‭⁪‎‬‪‬‬‮⁫⁯⁯⁬⁮⁮‭⁪⁯‭⁪‫‮ ? -1365612210 : (num3 = -1217156531);
          num1 = num3 ^ (int) num2 * -1156147628;
          continue;
        case 2:
          int num4 = !(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200C‍‏​‭‎‮‬‬‬‏‬‬‌‍⁯⁫⁬‏‮⁮​⁭‬⁯‏‭⁬‮‮⁬⁭‌⁪‍‮⁬​⁭⁪‮(this.\u200F‏‭‎‫⁬‍‭‌‪‫‬‍⁫‌⁫‍‭‪​⁬⁪⁯⁬⁬‬⁮‍‪‎⁫⁫⁭‫​‍‏‪⁬⁭‮) <= DateTime.Now) ? 619674058 : (num4 = 1172281341);
          num1 = num4 ^ (int) num2 * 1931981642;
          continue;
        case 3:
          goto label_1;
        case 4:
          goto label_7;
        default:
          goto label_8;
      }
    }
label_7:
    return;
label_8:;
  }

  private void \u206E⁪‏⁯‎‏⁪⁭‪‬‎‫‬⁪⁮⁫‎‎‏‮​‬⁮⁫‎⁭⁭⁯​⁭‮‮‪‏⁯⁫‮‫‌‌‮(object _param1, EventArgs _param2)
  {
    if (!AccountsManager.ToggleToAll())
      goto label_4;
label_1:
    int num1 = -38255049;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1740429287)) % 7U)
      {
        case 0:
          goto label_6;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4165957190U));
          num1 = (int) num2 * 195612544 ^ 494146580;
          continue;
        case 2:
          goto label_4;
        case 3:
          goto label_1;
        case 4:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(274626634U));
          num1 = (int) num2 * 1862155510 ^ -1832742831;
          continue;
        case 5:
          goto label_3;
        case 6:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206A‮‫‍​⁫‌⁯‫‍⁭‬‫⁪⁬‭⁫⁫‌​​⁪⁫⁫⁫⁯⁪‌⁬‪​⁭⁭‌‬‫‏⁫⁪‮‮, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2245734263U));
          num1 = (int) num2 * -810148342 ^ 642297447;
          continue;
        default:
          goto label_9;
      }
    }
label_6:
    return;
label_3:
    return;
label_9:
    return;
label_4:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1441799543U));
    num1 = -901878812;
    goto label_2;
  }

  private void \u200C‍‮⁭​⁫​⁪‬⁬⁭⁫‭‌⁯⁯‏‫‭⁮⁪‏‏⁭⁯⁮‪⁮⁪‮⁯‬‌‍⁫⁪‪‎‍⁬‮(object _param1, EventArgs _param2)
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1554439800U));
    ChatsTaskSettings.ReloadFromTxts();
    FlooderTaskSettings.ReloadFromTxts();
    this.\u206C‎‮‪‭⁯‭⁯⁯‍⁫‎‫‍⁪⁫‍‌‬‬‏‪‮‍⁭⁭‎⁫‌‫⁯⁪‏‭​‫​‬⁪⁫‮();
    this.\u200B⁭‮‫⁭‪⁬⁫⁬‫‭‫‏⁫⁭‏⁮‏‮‍‭⁬‪⁪‪⁭‮‪⁭‪‮‏‪⁮‬‫‫​​‮‮((object) null, (EventArgs) null);
  }

  private void \u202C​‮⁮‍‫⁯‍⁭‬⁪⁮⁬‭‌‪⁭‫⁯‫‫​‌‏‮‮‮‮⁪⁫⁪‮‌‬‮⁮‎‏‬⁭‮(object _param1, EventArgs _param2)
  {
    \u202B‭‍⁭‍‬‌‪‬⁪⁭⁯‍‫‍‫‏‎⁫‬‍‌⁬⁮⁬‪‌‫‮⁭⁯‪⁯‎⁯​‎⁬⁮⁭‮ obj = this.\u200B‪‪⁬‏⁭‍‭‫‬⁮⁭⁯‎‌⁮⁭‮‫​⁬‎⁭‫‍⁪‭‭‫‏‏‮‌⁬⁬‏‪⁯‌‪‮;
    if (obj != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) obj);
    else
      goto label_5;
label_2:
    int num1 = -1960108561;
label_3:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -199392308)) % 4U)
      {
        case 0:
          goto label_2;
        case 1:
          goto label_4;
        case 2:
          this.\u200B‪‪⁬‏⁭‍‭‫‬⁮⁭⁯‎‌⁮⁭‮‫​⁬‎⁭‫‍⁪‭‭‫‏‏‮‌⁬⁬‏‪⁯‌‪‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
          num1 = (int) num2 * 2071480198 ^ 1794189045;
          continue;
        case 3:
          goto label_5;
        default:
          goto label_7;
      }
    }
label_4:
    return;
label_7:
    return;
label_5:
    this.\u200B‪‪⁬‏⁭‍‭‫‬⁮⁭⁯‎‌⁮⁭‮‫​⁬‎⁭‫‍⁪‭‭‫‏‏‮‌⁬⁬‏‪⁯‌‪‮ = new \u202B‭‍⁭‍‬‌‪‬⁪⁭⁯‍‫‍‫‏‎⁫‬‍‌⁬⁮⁬‪‌‫‮⁭⁯‪⁯‎⁯​‎⁬⁮⁭‮();
    num1 = -1630561362;
    goto label_3;
  }

  private void \u202D‫⁫‭‎‫​‫‏⁪‌‪⁪⁪⁬⁯⁮⁪‌‎‪⁫⁯⁪‪⁫⁬⁫⁪⁯⁯⁯⁫‍​⁭⁬‌‪‭‮(object _param1, EventArgs _param2)
  {
    \u007BZ\u003Be\u005E_\u005E\u0023 obj = this.\u206F‌‏‏⁮​⁯‍‍‍‫‫‮‪‪‫​⁪‎‎​‌⁮‬⁫⁯⁮‎⁫‬⁪‫‬‭⁮‎‮‫​‎‮;
    if (obj != null)
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮((Form) obj);
    else
      goto label_5;
label_2:
    int num1 = 217084039;
label_3:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 587678876)) % 4U)
      {
        case 0:
          goto label_2;
        case 1:
          goto label_4;
        case 2:
          this.\u206F‌‏‏⁮​⁯‍‍‍‫‫‮‪‪‫​⁪‎‎​‌⁮‬⁫⁯⁮‎⁫‬⁪‫‬‭⁮‎‮‫​‎‮.\u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮((IWin32Window) this);
          num1 = (int) num2 * -1761220691 ^ 1070268859;
          continue;
        case 3:
          goto label_5;
        default:
          goto label_7;
      }
    }
label_4:
    return;
label_7:
    return;
label_5:
    this.\u206F‌‏‏⁮​⁯‍‍‍‫‫‮‪‪‫​⁪‎‎​‌⁮‬⁫⁯⁮‎⁫‬⁪‫‬‭⁮‎‮‫​‎‮ = new \u007BZ\u003Be\u005E_\u005E\u0023();
    num1 = 1030930350;
    goto label_3;
  }

  private void \u200C‎‏‏⁯‬‫⁮‭⁯‭‍⁮‮‪‏⁮‌⁯⁬‎⁪⁫‫⁭‬⁮​‏‎⁮‌‪‭‌‫⁭‮‫‭‮(
    object _param1,
    LinkLabelLinkClickedEventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E​‎⁯‫‮⁫​‫‎⁯‎⁬‌‎⁫‪‭‍⁫‭‭⁭‭‍⁬‍‌⁬‍⁫⁮‎‬⁪​‏‮⁯‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‭⁯‍‬⁪⁫⁬‭⁮‍⁭⁬⁪‬⁬‎‫⁫⁯‭‎‮⁭⁫⁬⁮‬‍‏‫‏‎​‫‏⁫⁮⁬‪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‌⁮‪‏⁪‭‪⁫‭‌‫‎‫⁯‭⁬​⁪⁭⁯‬⁪⁫⁪⁯‭‭‭‏‮⁭‎‬‫‫⁬‭⁯‮‮(_param2)) as string);
  }

  private void \u200C‮‍‫‎‍‬‫‍‍‪‪​‪‮‭‬‍⁭⁫‫‏‮⁭‭‭‭‪‬‌‏‮⁬⁬‏⁫‎​‫‫‮()
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁮⁪‮⁮⁫‬‫‪‭‌‪‭⁪‏‎‪‬⁬‭⁮⁮⁭‍‌‫⁫‪⁪⁮‪‌⁯⁫‭⁪‬‏‮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁮⁪‮⁮⁫‬‫‪‭‌‪‭⁪‏‎‪‬⁬‭⁮⁮⁭‍‌‫⁫‪⁪⁮‪‌⁯⁫‭⁪‬‏‮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮), new object[4]
    {
      (object) "",
      (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1929494437U),
      (object) "",
      (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(757960812U)
    });
    using (List<FlooderTarget>.Enumerator enumerator = AccountsManager.ActiveAccount.FlooderTaskSettings.Targets.GetEnumerator())
    {
label_4:
      int num1 = enumerator.MoveNext() ? 2039647056 : (num1 = 2058277827);
      FlooderTarget current;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 458193047)) % 5U)
        {
          case 0:
            goto label_4;
          case 1:
            current = enumerator.Current;
            num1 = 1258572510;
            continue;
          case 3:
            bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), new object[4]
            {
              (object) current.Link,
              (object) current.NamePlace,
              (object) current.Name,
              (object) current.Contains
            });
            num1 = (int) num2 * 1777244208 ^ 1140828985;
            continue;
          case 4:
            num1 = 2039647056;
            continue;
          default:
            goto label_8;
        }
      }
    }
label_8:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮, AccountsManager.ActiveAccount.FlooderTaskSettings.PhrasesFile);
label_9:
    int num3 = 1496370617;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num3 ^ 458193047)) % 7U)
      {
        case 0:
          int num5 = !bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁬‭‭‎‏⁫‮​⁭⁮‍‏⁬⁯‭‎‏‪‌‪⁯‬⁯‫​‌⁪⁫‎​‏⁯⁯‍​‏⁪⁭⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮)) ? 1705197161 : (num5 = 6319921);
          num3 = num5 ^ (int) num4 * 1979030375;
          continue;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‫‪‭⁯⁮‎⁮‫‎‭​⁮‪⁪⁯⁫⁪⁪‏⁪​‭‮⁮‍‏‍‫⁭⁬‏‏‭⁭‬‫⁬⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3876679623U));
          num3 = (int) num4 * 1972261087 ^ 1817051526;
          continue;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮));
          num3 = (int) num4 * -531213187 ^ 1836779460;
          continue;
        case 3:
          goto label_9;
        case 4:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮), (object[]) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‬‫‌‫⁪‮⁫‪‌‭‬⁭‫‏⁪‮‎‪‭⁪‪⁯‌‮‭‪‎⁬​⁪⁭‌‌‫⁫‎‪⁬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‍⁫‎‌‎⁫⁬⁮⁭‬‎‭⁬​⁮‍‮‭‍‭⁯‬‪‭‍⁮‍⁫⁮‏⁬‌‬‫‬⁭‭​⁭‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2033988432U), (object) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮)), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‬‏⁯⁪‬‏‮‪⁪‏⁯‮‫⁮‫‮⁮‌‎⁪⁯⁬‭⁮‎‫⁬‌‪⁭‬⁫⁯‌‫⁪⁫‌‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3438476176U))));
          num3 = (int) num4 * -1807755882 ^ -1587811197;
          continue;
        case 5:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮, AccountsManager.ActiveAccount.FlooderTaskSettings.PhrasesWithDotsFile);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁯‪‫‏‮‭‪‫‬‮⁯⁫‭‏‍‌‮‮⁮‏‪‌⁫‎‮‌‮‭⁭⁬⁮​‎‌⁭‍‭‮‪‮((ListControl) this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮, AccountsManager.ActiveAccount.FlooderTaskSettings.ImagesFromFolder ? 1 : 0);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮, AccountsManager.ActiveAccount.FlooderTaskSettings.StickersFile);
          num3 = 1544103017;
          continue;
        default:
          goto label_16;
      }
    }
label_16:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮, AccountsManager.ActiveAccount.FlooderTaskSettings.StickerId);
    this.\u200C‬⁬⁬‮‮⁯⁮⁮⁭‎‍‍⁭‍‬​‫‏‭‭‍‌‌‪⁪‏‭‎‍⁪⁮‏⁭‏⁪⁭‌‍⁮‮((object) null, (EventArgs) null);
  }

  private void \u200F⁮⁭⁫⁪​⁪⁫‌​‮‪‎⁮​⁯‎⁯‬‍⁮‎‌‏‏‏⁮​‍⁮⁪⁪‬‫​‌‏‮‎⁪‮(object _param1_1, EventArgs _param2)
  {
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.ImagesFromFolder = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮((ListControl) this.\u202D⁪‪⁫‎‏‏⁯⁫⁫⁪⁯‎​‎‎‬⁯‪‭‏​‫⁬‮‮‪‌⁭‍⁪‮⁮⁯⁭‌‎​⁯⁫‮) == 1));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u202B‫⁪⁫‭⁭⁭⁬‫⁮‌‌‬‏‌⁪‫⁪⁭⁬⁪‪​⁬⁬‫⁫‬‍‪⁬⁫‎⁭‌⁫⁬‫⁯⁯‮(object _param1_1, EventArgs _param2)
  {
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.PhrasesFile = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u200E‏⁬‪‏⁮⁯‫‫‎‎⁭‍‭‌⁯‫⁯⁪‪⁭​‪‫⁮‌‭⁫‍‌⁭‬⁪‭⁯⁮‪⁪⁯‮‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u202C​⁪‬‍‮‍‬‪‪‭‪⁫‭⁫⁪‫‌⁯‌⁭‬‫⁯⁬⁯‭‮​⁭‮⁬‏⁭⁪⁫⁯⁯⁫⁫‮(object _param1_1, EventArgs _param2)
  {
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.PhrasesWithDotsFile = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206E‬‌‮⁬⁫‏⁮‎⁫‮‬‌‮⁪‫‫⁪⁬​⁫⁭⁯‌‬‮⁪‫‮‍‍​⁪⁬‫‪‭‍‏⁬‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u202A‭‍‎‫‫‎‫‌​​‍‪‏‬‌⁫‏⁮‭⁬⁭‏‫‬⁫⁪‏‫‬‭‭‎‬⁬‭‎‫⁮⁬‮(object _param1_1, EventArgs _param2)
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), new object[4]
    {
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 0, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 1, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 2, 0)),
      bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 3, 0))
    });
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.AddNewTarget(new FlooderTarget()
    {
      Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 0, 0)) ?? (object) nameof ()),
      NamePlace = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 1, 0))),
      Name = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 2, 0)) ?? (object) nameof ()),
      Contains = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 3, 0)))
    })));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u202E‏‮‬⁪‫‪‍‪⁫⁫​‌⁫⁫‬‮⁫‮⁬⁯‫‪⁪‎‏‮⁬‏⁭‌‪⁮⁪⁬⁯⁮⁫‫⁯‮(object _param1_1, EventArgs _param2)
  {
    int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), DataGridViewElementStates.Selected);
    if (num1 != -1)
      goto label_4;
label_1:
    int num2 = -720547757;
label_2:
    uint num3;
    switch ((num3 = (uint) (num2 ^ -969560474)) % 4U)
    {
      case 1:
        return;
      case 2:
        goto label_1;
      case 3:
        break;
      default:
        AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.RemoveTarget(new FlooderTarget()
        {
          Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 0, 0)) ?? (object) nameof ()),
          NamePlace = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 1, 0))),
          Name = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 2, 0)) ?? (object) nameof ()),
          Contains = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 3, 0)))
        })));
        AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
        return;
    }
label_4:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206B⁯​⁫‬‪‪‌⁪⁭​‭‎‭‌‎‫‮‌‮⁪⁮⁮‏‭‫‭‬‏‫‍‪‎⁭‎​‬⁪‍‪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E​‌​‪​⁯⁬‪‎‌‪‌‭‍⁪‭‎‏‍⁭‏⁯‎⁮‫⁫‭⁬‬⁭‪⁫⁭‫‪‎‏⁮‭‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), num1));
    num2 = -1112463590;
    goto label_2;
  }

  private void \u200F⁫⁮‌‫‬⁮​‪⁪‭⁯‌‎⁮⁬⁪⁬⁮‪‮‏‪⁯⁯‬⁬‬‬⁭⁬⁮‭‌⁪‮‮‭⁪⁪‮(object _param1_1, EventArgs _param2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎⁬⁪⁬⁪‮‭‭⁫⁮​‎⁯⁫‏⁮​‫​⁭‎⁮⁭‎‮‭‪⁯‪‎‭‍‪‍⁬‎⁭‏‫‮ obj = new bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‎⁬⁪⁬⁪‮‭‭⁫⁮​‎⁯⁫‏⁮​‫​⁭‎⁮⁭‎‮‭‪⁯‪‎‭‍‪‍⁬‎⁭‏‫‮();
label_1:
    int num1 = 493345768;
    int num2;
    int num3;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num1 ^ 1962777727)) % 10U)
      {
        case 0:
          goto label_3;
        case 1:
          num3 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), DataGridViewElementStates.Selected);
          int num5 = num3 != -1 ? 338871227 : (num5 = 324098613);
          num1 = num5 ^ (int) num4 * -108114990;
          continue;
        case 2:
          // ISSUE: reference to a compiler-generated field
          obj.\u200C‍‬​‬‌⁫‭‌‫⁭‮​⁭​‭‪‭‎‫⁯⁯⁮⁭⁫‮‫‭‬‮⁬‎‍‏⁬‮‎‭⁫‮‮ = new FlooderTarget()
          {
            Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, 0, num3)) ?? (object) nameof ()),
            NamePlace = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, 1, num3))),
            Name = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, 2, num3)) ?? (object) nameof ()),
            Contains = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, 3, num3)))
          };
          num1 = 1530259842;
          continue;
        case 3:
          // ISSUE: reference to a compiler-generated method
          AccountsManager.ApplyToCurrent(new Action<Account>(obj.\u200E‮⁮‪⁮⁪⁭⁫‎‪⁪‫‏⁫⁮‬‮‪‌‭‍‪​‍‬⁪‍‬‪⁭‪‌‬​‫‭⁪⁬‪‭‮));
          num1 = (int) num4 * -442376020 ^ 1840727713;
          continue;
        case 4:
          goto label_1;
        case 5:
          int num6;
          num1 = num6 = num2 >= bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C⁯‍‬⁪‏‌‮⁯​‮‭‭⁮⁯‪‭‍‬‌‫‬⁮‏⁪⁬‍⁬‎⁮​⁯⁫‎‌⁫‭‭‫‎‮((BaseCollection) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮)) ? 236943636 : (num6 = 1662718807);
          continue;
        case 6:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D​‬‍‍‎‎‬‫‏⁪‮⁪‪‮⁫​⁯​‌⁬‌⁭⁭‬⁪⁫‬⁬‎⁮‎‭‏‫‬⁫⁫⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, num2, num3), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, num2, 0)));
          ++num2;
          num1 = 1959386382;
          continue;
        case 7:
          num2 = 0;
          num1 = (int) num4 * -643943809 ^ 1449799565;
          continue;
        case 9:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B‏⁯⁯‏​‮‪⁮⁮⁭⁪⁮⁫⁪‌‎‫‬⁬‍​‎‏‪‪‎‏⁭‫⁮‎⁮‌‫‎‍⁫‬⁭‮ = new FlooderTarget()
          {
            Link = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 0, 0)) ?? (object) nameof ()),
            NamePlace = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 1, 0))),
            Name = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 2, 0)) ?? (object) nameof ()),
            Contains = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, 3, 0)))
          };
          num1 = 1063136682;
          continue;
        default:
          goto label_11;
      }
    }
label_3:
    return;
label_11:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
  }

  private void \u200C‬⁬⁬‮‮⁯⁮⁮⁭‎‍‍⁭‍‬​‫‏‭‭‍‌‌‪⁪‏‭‎‍⁪⁮‏⁭‏⁪⁭‌‍⁮‮(object _param1, EventArgs _param2)
  {
    int num1 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮), DataGridViewElementStates.Selected);
label_1:
    int num2 = 965395354;
    int num3;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num2 ^ 823073359)) % 9U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_10;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D​‬‍‍‎‎‬‫‏⁪‮⁪‪‮⁫​⁯​‌⁬‌⁭⁭‬⁪⁫‬⁬‎⁮‎‭‏‫‬⁫⁫⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u200D⁪‎‫⁮‎‌‮‍‮‌‏‎⁪⁯⁯‫​⁪⁯⁯‌⁪‏‫‌‎⁫⁮‭‏‍⁬⁫‌‬‌‎​⁪‮, num3, 0), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮, num3, num1)));
          num2 = 1449991836;
          continue;
        case 3:
          goto label_3;
        case 4:
          int num5 = num1 != -1 ? 732732175 : (num5 = 1406997482);
          num2 = num5 ^ (int) num4 * -1315548235;
          continue;
        case 5:
          num3 = 0;
          num2 = 164859192;
          continue;
        case 6:
          num2 = (int) num4 * 817337609 ^ -870866410;
          continue;
        case 7:
          int num6;
          num2 = num6 = num3 < bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C⁯‍‬⁪‏‌‮⁯​‮‭‭⁮⁯‪‭‍‬‌‫‬⁮‏⁪⁬‍⁬‎⁮​⁯⁫‎‌⁫‭‭‫‎‮((BaseCollection) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(this.\u202E⁭‍⁮⁭‎‮‏‫‌⁪‬⁭‮‫⁫‪⁮‭‬‌⁬‌‏‪⁮‎⁭⁯‬‬⁫⁭⁯‏‍‍‫‫‍‮)) ? 169535941 : (num6 = 1842776812);
          continue;
        case 8:
          ++num3;
          num2 = (int) num4 * 511738253 ^ 1292357390;
          continue;
        default:
          goto label_11;
      }
    }
label_10:
    return;
label_3:
    return;
label_11:;
  }

  private void \u200D‭‌‪‮‍⁯​‭‬‪‫⁫⁮‌‪‎⁭⁯⁪‌‏⁫⁭⁬‬‬‭‬⁬⁮‎‎‍⁬‪⁪⁬⁭‭‮(object _param1_1, EventArgs _param2)
  {
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.StickersFile = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮)));
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮));
label_1:
    int num1 = 1496433231;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 2136004274)) % 6U)
      {
        case 0:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮, nameof ());
          num1 = (int) num2 * -1097238501 ^ -430491755;
          continue;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‫‪‭⁯⁮‎⁮‫‎‭​⁮‪⁪⁯⁫⁪⁪‏⁪​‭‮⁮‍‏‍‫⁭⁬‏‏‭⁭‬‫⁬⁯‌‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮), (object) \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3876679623U));
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮), (object[]) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206E‬‫‌‫⁪‮⁫‪‌‭‬⁭‫‏⁪‮‎‪‭⁪‪⁯‌‮‭‪‎⁬​⁪⁭‌‌‫⁫‎‪⁬‎‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202C‍⁫‎‌‎⁫⁬⁮⁭‬‎‭⁬​⁮‍‮‭‍‭⁯‬‪‭‍⁮‍⁫⁮‏⁬‌‬‫‬⁭‭​⁭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(877816179U), (object) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮)), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206A‬‏⁯⁪‬‏‮‪⁪‏⁯‮‫⁮‫‮⁮‌‎⁪⁯⁬‭⁮‎‫⁬‌‪⁭‬⁫⁯‌‫⁪⁫‌‮‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(844754735U))));
          num1 = (int) num2 * -841920201 ^ -1181639664;
          continue;
        case 2:
          goto label_1;
        case 3:
          int num3 = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁬‭‭‎‏⁫‮​⁭⁮‍‏⁬⁯‭‎‏‪‌‪⁯‬⁯‫​‌⁪⁫‎​‏⁯⁯‍​‏⁪⁭⁪‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206D‫⁫‫⁬⁫⁫⁮‍‏​‭‪‍‏‪​‏⁭‏‮‫⁭⁭⁪⁫⁭‍⁭‭⁭⁬​‭‎⁬⁮‎⁬⁬‮)) ? 857006606 : (num3 = 2035578217);
          num1 = num3 ^ (int) num2 * -1043210091;
          continue;
        case 4:
          goto label_3;
        case 5:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
          num1 = 154741108;
          continue;
        default:
          goto label_8;
      }
    }
label_3:
    return;
label_8:;
  }

  private void \u206C‬⁫‭⁯⁭‭‮‮‪⁮⁪‏‍⁬‭‌‍⁬‬⁯‬⁬‬⁬⁭⁮‪‏‎‭⁫‮​⁫⁯‫⁮⁭‮‮(object _param1_1, EventArgs _param2)
  {
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.StickerId = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u200F​‏‬‏‌⁬‪⁮⁬⁭‏‏‮‪‬⁯⁭​⁭‍‮‎‭⁪‏‫⁭‎⁬⁮⁭⁫‍⁪‮‏‏‮⁬‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u200B⁯​‌‌‏‬⁯‎‎‬⁪⁯‎‍⁫⁪‍⁬‮​‎‫​⁮‬‫⁪⁫‪‏⁪⁭⁪⁫⁫‎⁬⁭⁪‮()
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E​⁪‍‪‬⁯‫‍‎‌‭⁬⁮⁮‮⁭‫⁭‬⁮‍​‪‮‎⁯⁪‎⁯‮‫⁬‏‬‪‌⁭​‪‮(this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮, AccountsManager.ActiveAccount.FlooderTaskSettings.Enabled);
label_1:
    int num1 = -178349314;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -2120852935)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E​⁪‍‪‬⁯‫‍‎‌‭⁬⁮⁮‮⁭‫⁭‬⁮‍​‪‮‎⁯⁪‎⁯‮‫⁬‏‬‪‌⁭​‪‮(this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮, AccountsManager.ActiveAccount.ChatsTaskSettings.Enabled);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E​⁪‍‪‬⁯‫‍‎‌‭⁬⁮⁮‮⁭‫⁭‬⁮‍​‪‮‎⁯⁪‎⁯‮‫⁬‏‬‪‌⁭​‪‮(this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮, AccountsManager.ActiveAccount.InviteTaskSettings.Enabled);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‍​‫‬⁫⁪‎⁬‬‪‮‍⁬‍‏‬⁭‌⁪‮⁭⁫‫‭‫‭‪⁭​‭‍⁯‌⁭‭⁫⁭‪‮(this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮, (Decimal) AccountsManager.ActiveAccount.FlooderTaskSettings.Delay);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‍​‫‬⁫⁪‎⁬‬‪‮‍⁬‍‏‬⁭‌⁪‮⁭⁫‫‭‫‭‪⁭​‭‍⁯‌⁭‭⁫⁭‪‮(this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮, (Decimal) AccountsManager.ActiveAccount.ChatsTaskSettings.Delay);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‍​‫‬⁫⁪‎⁬‬‪‮‍⁬‍‏‬⁭‌⁪‮⁭⁫‫‭‫‭‪⁭​‭‍⁯‌⁭‭⁫⁭‪‮(this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮, (Decimal) AccountsManager.ActiveAccount.InviteTaskSettings.Delay);
          num1 = (int) num2 * 1422125411 ^ -1304467138;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private void \u206B‏⁪​‫⁮⁬⁯‬‏‭‮⁬⁮‏‭⁫‭‭⁮‬‭​‍‌⁯‫‌⁪‎⁪​⁫‪⁫⁭‌​⁫‎‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = 1025312718;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1644363187)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
          num1 = 1783592117;
          continue;
        case 3:
          goto label_6;
        case 4:
          goto label_5;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_6:
    return;
label_7:
    return;
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.FlooderTaskSettings.Enabled = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪‬‮⁪​‬‭⁫⁬‮⁮‬‭⁮‍‏⁯⁮⁪⁯‭⁪‫⁫‮‪⁫‭‫⁭⁫‭‪⁮‎⁭‭‌‮‮(this.\u206B‭⁪⁮‮⁯‮‬‬‮⁫⁭‌‏‮‎‎⁯⁮​⁪‌‏‌‌​‬⁮⁮⁬⁮‌⁭⁮‬‎‬‏‮⁯‮)));
    num1 = 1132516293;
    goto label_2;
  }

  private void \u202A‮‭‬⁫⁪‍⁪​‌⁭‭⁪‪⁫‭‏‍‏‭‫⁮‫‫⁪‫‍‫‪⁪‬⁪⁪‮⁫‎⁫​‌‪‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u200B‪‏‎‏‎‪‪‏‭‏‫⁯‎⁯‏⁬‭⁭‪⁫‭‮⁫⁯‫‬​‏‫⁮‮‍⁮⁯⁫⁭‌‬‎‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = -1968653306;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1216862616)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
          num1 = -539319258;
          continue;
        case 2:
          goto label_5;
        case 3:
          goto label_3;
        case 4:
          goto label_4;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_4:
    return;
label_7:
    return;
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.ChatsTaskSettings.Enabled = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪‬‮⁪​‬‭⁫⁬‮⁮‬‭⁮‍‏⁯⁮⁪⁯‭⁪‫⁫‮‪⁫‭‫⁭⁫‭‪⁮‎⁭‭‌‮‮(this.\u206D‫‎‮‍‪‎‬‎‪⁭⁭⁭⁪⁯‫⁯‎⁯‎‪⁮⁪‏⁫‎⁯​‫⁮‪⁪‭‍⁮⁯​⁬⁮⁪‮)));
    num1 = -2095363012;
    goto label_2;
  }

  private void \u200B⁮⁪⁬‮‎⁯​‪⁯‍‬⁯‭‍‌‪‪⁭⁪⁯⁮‫⁭⁪‪⁫⁮​⁪⁫‮‫⁭‫⁬‎⁯​⁪‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u202E​⁮‪‎‎‎⁫‭‪⁯⁭​⁭⁫‌‭‬‪⁬‌⁭⁯⁭‎‭‎‏​⁯‏⁪‪‏‏⁫⁫‎‎⁫‮(object _param1_1, EventArgs _param2)
  {
    if (this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
    {
label_1:
      uint num;
      switch ((num = (uint) (679721179 ^ 2059220781)) % 3U)
      {
        case 0:
          goto label_1;
        case 2:
          return;
      }
    }
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.InviteTaskSettings.Enabled = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E‪‬‮⁪​‬‭⁫⁬‮⁮‬‭⁮‍‏⁯⁮⁪⁯‭⁪‫⁫‮‪⁫‭‫⁭⁫‭‪⁮‎⁭‭‌‮‮(this.\u206C‬‍‪⁫‏⁫‬​‫‌‫‏⁬‮‮⁮‍⁭‌‏‏‏⁪‬‮⁪⁫⁯‭‭⁮⁬‪⁫‪‫‎‪‪‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u206B⁬‎⁫⁭‍‮‬⁬​‎⁫‬‎‫⁯⁪​⁮⁫⁭⁬‏​‫⁭‬⁫‏⁭‎⁯‏‬‪‫⁭‪⁭‎‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u206A⁮⁬‭⁬⁮‪‌‭‌⁯⁮‎‫⁪​‮⁯⁬‭‬⁬‌​‫‫⁯⁬⁭⁭​⁮‮‪‏‮⁪⁪​‫‮(object _param1_1, EventArgs _param2)
  {
    if (this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
    {
label_1:
      uint num;
      switch ((num = (uint) (1648236506 ^ 940722418)) % 3U)
      {
        case 0:
          goto label_1;
        case 2:
          return;
      }
    }
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.FlooderTaskSettings.Delay = (int) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁯⁬⁯⁭⁪⁪‫‮⁯‏⁮⁭‬‪⁫⁬‪​⁫‏⁪⁫⁮‏⁯‏⁭‎⁪⁪⁭‫⁭‫⁯⁭⁯‬‮(this.\u202A⁪⁬‏‍⁪‬‬​‎‫‪‌​‍⁭‬⁪‪‍‎⁯‌‍⁮⁮‪⁮‌‌‮⁫‏‌‪‭‬⁯‬⁯‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u202B‮⁮‬‫‬‭‫‪‮⁪‍‌‌⁬​‏⁯⁭‎‏⁫⁭⁬‏⁫‎⁯⁭⁬‫⁯‍‫⁮⁭⁮‎⁪‍‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u206C‮‍‌⁭‫⁪‭‪​‍‌‬⁭‬⁯⁪‌‍⁭‎‭⁯⁭‏‪‌‎⁮‬⁯‌⁫⁯⁭⁬‏‮‍‬‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = 1130839291;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 251189222)) % 4U)
    {
      case 0:
        goto label_1;
      case 1:
        return;
      case 2:
        return;
      case 3:
        break;
      default:
        return;
    }
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.ChatsTaskSettings.Delay = (int) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁯⁬⁯⁭⁪⁪‫‮⁯‏⁮⁭‬‪⁫⁬‪​⁫‏⁪⁫⁮‏⁯‏⁭‎⁪⁪⁭‫⁭‫⁯⁭⁯‬‮(this.\u202B‎‌‬‭⁯‮‏‫‎​‌‌‪⁯‍⁪⁯‏‫‎‪‮‫⁪‪‬‫⁭‎⁯⁫⁭‫‍‎‬⁬‬⁮‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
    num1 = 1156962556;
    goto label_2;
  }

  private void \u202D⁮⁭⁫​‫‫⁪‎‭‏‬⁪⁯‬⁯‮‭‬‫‎‍​​⁬⁫⁯⁬‬‏‮​‌‪‏⁭‍‪⁭⁫‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u202E⁯‫‭‏‏‌⁯‏⁪⁬⁫⁬​⁪‍‬‪⁯‭⁪‌⁬⁫‌‬‭‪‭⁭‍‪⁫‭⁪⁮⁫⁫⁭⁫‮(object _param1_1, EventArgs _param2)
  {
    if (this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
    {
label_1:
      uint num;
      switch ((num = (uint) (1789280434 ^ 1383619089)) % 3U)
      {
        case 0:
          goto label_1;
        case 2:
          return;
      }
    }
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.InviteTaskSettings.Delay = (int) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁯⁬⁯⁭⁪⁪‫‮⁯‏⁮⁭‬‪⁫⁬‪​⁫‏⁪⁫⁮‏⁯‏⁭‎⁪⁪⁭‫⁭‫⁯⁭⁯‬‮(this.\u206D‭‮⁭⁬‬⁫‍⁫‭⁬‌‫⁫‮‮‫⁫‎‎⁬⁮‪‭⁫⁯⁮⁮⁭‍‌‍‪​⁬‎⁪‎⁬⁮‮)));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
  }

  private void \u200F‎⁭‮‌⁫‪⁯⁬⁭‬⁮⁬‏⁮‫‮‫⁮‏‎‫⁯‎​⁫​‍‌‍‬​‪‫‮⁬‫⁮‏‫‮(object _param1, EventArgs _param2)
  {
    int num = this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮ ? 1 : 0;
  }

  private void \u206C‬‌‍⁬‮⁭‌⁭⁭⁫⁫‎⁫‎‎⁮‎‫⁭⁯‍‬⁯‍⁪⁬​‎⁭⁬‫‪⁬⁯‮⁯‍⁪‌‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = -134077165;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1004712768)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_5;
        case 2:
          goto label_3;
        case 3:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
          num1 = -1186477525;
          continue;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:
    this.\u200B⁭‮‫⁭‪⁬⁫⁬‫‭‫‏⁫⁭‏⁮‏‮‍‭⁬‪⁪‪⁭‮‪⁭‪‮‏‪⁮‬‫‫​​‮‮((object) null, (EventArgs) null);
    return;
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.ResetSettings()));
    num1 = -343580346;
    goto label_2;
  }

  private void \u206C‍‌⁯⁭‏⁮‫‎⁯‬‏⁬‏‬‌‬⁬⁬‪‬‏‮‌⁮‏‌‪‭⁮⁪⁪​‬‫⁮‬‪‎⁯‮()
  {
  }

  private void \u202C‪​‬‭⁯‎‌‎‬‍‪‭‏​⁬‫‎‫⁬‍‪‌‮⁯⁪⁫⁫‍⁭‮‬​‮‭‫⁯⁯​⁫‮()
  {
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮, AccountsManager.ActiveAccount.VoiceTaskSettings.Voice);
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮, AccountsManager.ActiveAccount.VoiceTaskSettings.Emotion);
label_1:
    int num1 = -2052166771;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1516258673)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200F‍​‫‬⁫⁪‎⁬‬‪‮‍⁬‍‏‬⁭‌⁪‮⁭⁫‫‭‫‭‪⁭​‭‍⁯‌⁭‭⁫⁭‪‮(this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮, (Decimal) AccountsManager.ActiveAccount.VoiceTaskSettings.Speed);
          num1 = (int) num2 * -910817644 ^ 1294426436;
          continue;
        default:
          goto label_4;
      }
    }
label_4:
    bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮((Control) this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮, AccountsManager.ActiveAccount.VoiceTaskSettings.Yandexapi);
  }

  private void \u202A‪​⁬⁪‌⁫‍⁮⁯‫⁬⁬⁮‍‭‎⁫⁪​⁫‎‏⁫⁪‮⁮⁪‎‫‫‍‏‍​⁬‮‎⁮‏‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = -579462273;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -301857914)) % 4U)
    {
      case 0:
        return;
      case 1:
        return;
      case 2:
        goto label_1;
      case 3:
        break;
      default:
        return;
    }
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.VoiceTaskSettings.Voice = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁬⁮‪⁯‮‭‎⁪⁯⁯‏⁪‌‮‎⁯‫‫‭‌⁭‪‬‎‌⁪‌⁯‪⁯⁯‍⁫⁫‪‭‪​⁯‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮((ListControl) this.\u206E‭⁯‏‍‎‮‌⁫‌‭‮⁫⁭⁫⁭‪⁬⁫‮‪​⁭‍⁮‌⁮‭‍⁬‏⁯⁫‏‮‪‍‬‍⁬‮)))));
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.SaveToDisk()));
    num1 = -1891904342;
    goto label_2;
  }

  private void \u206A⁯⁫‪‍‬​⁮‭‏‏‏⁭‌⁪‌⁫‫‪⁮⁬⁫‌⁫⁯‫‭‍‫​‍‪‮⁪⁫⁮‬‭​‏‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_4;
label_1:
    int num1 = 106524835;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 961497057)) % 4U)
    {
      case 0:
        goto label_1;
      case 1:
        break;
      case 2:
        return;
      default:
        AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
        return;
    }
label_4:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.VoiceTaskSettings.Emotion = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206D⁬⁮‪⁯‮‭‎⁪⁯⁯‏⁪‌‮‎⁯‫‫‭‌⁭‪‬‎‌⁪‌⁯‪⁯⁯‍⁫⁫‪‭‪​⁯‮(bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮(this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮), bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮((ListControl) this.\u202E⁬⁫‏​‌‌⁪⁯‮‍‍‌⁭‌‪‎‏‌⁮⁯⁬‬⁫‭⁯⁭⁪‍‏⁪⁮‪‭⁭‌‬⁬⁬⁭‮)))));
    num1 = 29847338;
    goto label_2;
  }

  private void \u206B‎‬‮‫‌‪⁭⁯‍‭‌⁭‏‮⁭⁭⁯​‮⁭‮‏‭⁮‌⁫‫⁫‬‍‎​⁬‌‫⁯​‮⁪‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = 1630283735;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1220169437)) % 5U)
      {
        case 0:
          goto label_5;
        case 1:
          goto label_3;
        case 2:
          goto label_1;
        case 3:
          goto label_6;
        case 4:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
          num1 = 752132150;
          continue;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_6:
    return;
label_7:
    return;
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.VoiceTaskSettings.Speed = (int) bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200E⁯⁬⁯⁭⁪⁪‫‮⁯‏⁮⁭‬‪⁫⁬‪​⁫‏⁪⁫⁮‏⁯‏⁭‎⁪⁪⁭‫⁭‫⁯⁭⁯‬‮(this.\u200C‬‭⁪⁬‭‮‫‭⁯‍⁯​‍‮⁯‫‮‭‫‬⁭‌⁫‪⁯⁮⁮⁫‫‌‭‪⁬‮​⁫‫‏‬‮)));
    num1 = 293484955;
    goto label_2;
  }

  private void \u200E‎‬‮‮⁮‫​⁫‌⁭⁪⁭‪‎⁭​⁯⁮⁪⁮⁪‮‫⁮⁯‮‏‌‎‍‪‍​‏‬⁭‫⁪‭‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_4;
label_1:
    int num1 = 134426084;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 1871366003)) % 4U)
    {
      case 0:
        goto label_1;
      case 2:
        break;
      case 3:
        return;
      default:
        AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => _param1_2.SaveToDisk()));
        return;
    }
label_4:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.VoiceTaskSettings.Yandexapi = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u202A‎‪‏‭‌‮⁯‮⁪​‌⁯‫⁫‬⁪⁮‮⁫‮‮‬⁬⁪‭⁫⁬⁫​‪⁪‎‌‍⁫⁯⁭⁯⁯‮)));
    num1 = 1963622838;
    goto label_2;
  }

  private void \u206F⁫⁯​⁮‫‬⁬⁪‮⁫‭​⁮‌⁮⁪‪​⁪⁭‎⁭⁪⁮​‭‬‭‮⁭⁭​⁯‪⁭⁬‫‭‏‮(object _param1_1, EventArgs _param2)
  {
    if (!this.\u202B⁮⁮⁫​⁫⁪⁭‪‎⁪⁫‍‬⁯‪‪⁮‏⁬‭‎⁯‬‬‫‬​‎⁫‪‮‭‍⁯‍⁪‌​⁭‮)
      goto label_5;
label_1:
    int num1 = 1441912352;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1502907738)) % 6U)
      {
        case 0:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_2 => ((\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮) new \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮()).\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(_param1_2)));
          num1 = 521422803;
          continue;
        case 1:
          goto label_5;
        case 2:
          goto label_3;
        case 3:
          goto label_7;
        case 4:
          goto label_1;
        case 5:
          AccountsManager.ApplyToCurrent((Action<Account>) (_param1_3 => _param1_3.VoiceTaskSettings.Target = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u202E​⁮‭⁪‪‭‪‫‬‎‮⁭⁮‪​‪‫‪‭‪‌⁫‌⁬‏‎⁯⁫⁭⁭⁫‌​‮⁯‎‏⁪‮)));
          num1 = (int) num2 * -487817470 ^ -1811401876;
          continue;
        default:
          goto label_8;
      }
    }
label_3:
    return;
label_7:
    return;
label_8:
    return;
label_5:
    AccountsManager.ApplyToCurrent((Action<Account>) (_param1_4 => _param1_4.VoiceTaskSettings.Message = bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮((Control) this.\u206B‫‭‪‍⁭‭‏⁫⁬‏‏‬‮⁬‬‫‮‏‍‏‍‮‮‏‫⁭⁮‎‎‎‍‌‎‫⁮​⁬‫‎‮)));
    num1 = 591075895;
    goto label_2;
  }

  static DataGridViewRowCollection \u206E⁯⁫‍‭‬⁯‮‍‬⁭⁬‌⁮​​⁯‫‎⁭⁫‪⁭‮‮‪⁭‎​‍⁬⁬⁬‬‎⁮‬‪‌⁪‮([In] DataGridView obj0)
  {
    return obj0.Rows;
  }

  static void \u202D‫⁮⁪‮⁮⁫‬‫‪‭‌‪‭⁪‏‎‪‬⁬‭⁮⁮⁭‍‌‫⁫‪⁪⁮‪‌⁯⁫‭⁪‬‏‮‮([In] DataGridViewRowCollection obj0)
  {
    obj0.Clear();
  }

  static int \u202D‫⁭‮‬⁭‪‬‎​‏⁭⁫​‌⁫⁫‍⁬⁪‍⁯‫⁭⁪⁭‪⁫‮‎​‌‏‭‭⁪⁯​⁮‎‮(
    [In] DataGridViewRowCollection obj0,
    [In] object[] obj1)
  {
    return obj0.Add(obj1);
  }

  static int \u200E‪⁪⁪‬‫⁮‎‎‌‭‍⁯‫‍⁫‪​⁮​⁯‎​⁯⁪⁮‏‪‏​‫‏‭‍⁭‭⁪⁭‌⁮‮(
    [In] DataGridViewRowCollection obj0,
    [In] DataGridViewElementStates obj1)
  {
    return obj0.GetFirstRow(obj1);
  }

  static DataGridViewCell \u206D‍⁫‮‏⁯‌⁬‬‫⁫⁪‏‎⁫‏​‮⁯‏⁬‎‬‪⁭⁯​⁯‪‎‭‏⁪⁫⁪‬⁫‬​⁯‮(
    [In] DataGridView obj0,
    [In] int obj1,
    [In] int obj2)
  {
    return obj0[obj1, obj2];
  }

  static object \u202B​‮‌⁭‮‮‍‌⁬‫⁯⁬‮⁯‪⁯‍‌⁮⁭​⁫‍‏⁮⁬⁬⁬‮‬‫⁮‏‬‏‮‪‬‎‮([In] DataGridViewCell obj0)
  {
    return obj0.Value;
  }

  static void \u206D​‬‍‍‎‎‬‫‏⁪‮⁪‪‮⁫​⁯​‌⁬‌⁭⁭‬⁪⁫‬⁬‎⁮‎‭‏‫‬⁫⁫⁯‌‮([In] DataGridViewCell obj0, [In] object obj1)
  {
    obj0.Value = obj1;
  }

  static DataGridViewColumnCollection \u202D‭‮⁬⁭‌⁪⁫⁫‫⁭‌‫⁯⁭‍‬‏⁮​‪⁭⁬‬​‏‭⁫‬‮‮‪⁫​⁭‪⁮‬‍‌‮(
    [In] DataGridView obj0)
  {
    return obj0.Columns;
  }

  static int \u202C⁯‍‬⁪‏‌‮⁯​‮‭‭⁮⁯‪‭‍‬‌‫‬⁮‏⁪⁬‍⁬‎⁮​⁯⁫‎‌⁫‭‭‫‎‮([In] BaseCollection obj0) => obj0.Count;

  static DataGridViewRow \u206E​‌​‪​⁯⁬‪‎‌‪‌‭‍⁪‭‎‏‍⁭‏⁯‎⁮‫⁫‭⁬‬⁭‪⁫⁭‫‪‎‏⁮‭‮(
    [In] DataGridViewRowCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static void \u206B⁯​⁫‬‪‪‌⁪⁭​‭‎‭‌‎‫‮‌‮⁪⁮⁮‏‭‫‭‬‏‫‍‪‎⁭‎​‬⁪‍‪‮(
    [In] DataGridViewRowCollection obj0,
    [In] DataGridViewRow obj1)
  {
    obj0.Remove(obj1);
  }

  static string \u200D‏⁯​‎⁬⁯⁬‎⁯‌‍‫⁭⁪⁪‍‎‮‭‭⁪​‮‎‍‮⁫⁪⁬⁭​⁬⁭‎‪⁮‬‌‏‮([In] object obj0) => obj0.ToString();

  static void \u202E‌⁭‏‭‫⁪⁮‮⁮‭⁬‮‌⁪​‌​‏‪‬‍⁬‬‍‏⁭⁪‍​‏‏‭‎‍​‎⁬‪‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static System.ComponentModel.Container \u200C⁯⁮⁬‬‮⁮‮​‬​‏⁪‎‏⁬‪⁮⁬⁪‮‍‫⁬​⁪‫⁬‏‭‌‭‮‏​‍⁭‎⁭⁬‮()
  {
    return new System.ComponentModel.Container();
  }

  static System.Type \u200D‫‭‍‮‭⁫‪​‍⁮⁬‮⁪⁫‫⁬‮‌⁬⁬‏⁭‫⁯‌‭‎⁫‪‭​⁮‎‪‭⁪‏‫‪‮([In] RuntimeTypeHandle obj0)
  {
    return System.Type.GetTypeFromHandle(obj0);
  }

  static ComponentResourceManager \u202B⁬‫‮‮‪⁬‪‎‎⁪‬‭‪​⁯⁪‌⁫‎‏‏‭‌⁯‭‍⁯‭​​⁯‎‪⁭‭⁮‪​‍‮([In] System.Type obj0)
  {
    return new ComponentResourceManager(obj0);
  }

  static TabControl \u206D‎‮‭‏‍‪⁬⁭⁮​⁫‮‮⁪⁯⁬‌​‫‏‏⁯⁪⁪‭‬‬‮‫‭​⁫‌⁯‎‍‬⁬‏‮() => new TabControl();

  static TabPage \u206B‌​‏⁭​‎⁫‮‍⁪⁬⁪‭‫‌‏⁭‫‏‌‌‫‪‎‬‫‮⁮‏‮⁯‪‍⁬​‭⁬‬‬‮() => new TabPage();

  static Label \u206C⁮⁮‪⁯‬⁯⁫‏‬‏‏‫​⁫‌⁬‎‬‌⁮‌⁫⁪‪‍‏‎‎‭​​‬‍⁯‏⁯⁪‏⁬‮() => new Label();

  static Button \u206C⁮⁮‬‍⁫‎‭‍⁮‮‎‮‪‍⁪⁮‏⁬⁮‎‎⁬‫‌‎⁪⁮‍‫⁮‍‬‫⁮⁯‫‭‬⁯‮() => new Button();

  static NumericUpDown \u202E‍‬​‭⁮​⁪‪‪‪⁭‌‭‏‪⁯⁪‎⁬‭⁭‮‍‎⁬‎‭‍‬‌⁯‭⁭‬⁮‏‏⁮⁬‮() => new NumericUpDown();

  static ToggleSwitch \u200F⁫‎⁮⁪⁮‏‏⁮⁬⁬‍⁫‮⁪‌⁫‏​‫‮‏⁬⁮‌‪‌⁫‎⁫⁪‌‮⁫⁭⁮‫⁪‏‪‮() => new ToggleSwitch();

  static ComboBox \u206B⁪‍‭‫⁬​⁫‮‎⁯‫⁯‭‬‌‪‫⁯‭‫‍‌‪‭‌​⁯⁯‎⁮⁯​⁪‫⁪‏⁫⁪‬‮() => new ComboBox();

  static DataGridView \u200F⁭‎⁭‮⁭⁪⁯‍‎‏‮‮‏‏‏‮⁫⁮‎‌​‬⁮‬⁭⁯​‌⁫⁪⁪⁬‮‏‎‏⁫⁫‭‮() => new DataGridView();

  static DataGridViewTextBoxColumn \u206C‏⁮‮⁯‬⁪‭⁪​‬‬⁯⁭​‌‏‮‫‍⁪‫‬​​‍‎‎⁮‫⁯‪​⁬‪‫‌⁬‬⁬‮()
  {
    return new DataGridViewTextBoxColumn();
  }

  static DataGridViewComboBoxColumn \u206E⁭‏‬‍​⁯‎‏‎⁮‏⁬⁬​⁫​‮‫⁬‏‬‎‪⁫‍‌‮⁬‏⁫‭⁫‮⁯⁪‪‏⁬⁪‮()
  {
    return new DataGridViewComboBoxColumn();
  }

  static DataGridViewCheckBoxColumn \u200D‌‏⁪‬⁭‪‏⁫‭‬⁮‪‪‫‌⁮‌⁭‍‮‍‎​⁫‫⁬​⁮‫‭‍⁪‏‮‏⁭‎‭‭‮()
  {
    return new DataGridViewCheckBoxColumn();
  }

  static LinkLabel \u200C⁭‮‬‭​‮‫⁬⁪⁮​⁭⁪‭⁭⁯‎‫‪‮‏⁫​​‫⁮​⁯‪⁫⁯​‭⁬⁫‭‪‌⁪‮() => new LinkLabel();

  static TextBox \u200D‪‫‬​‎‮‎⁪‮‎⁫‎⁮‮‎‍⁮‫‍‮‪‍⁬⁫‪‮⁭⁪⁪⁫‍⁯‍‭‎⁭‍​⁮‮() => new TextBox();

  static RichTextBox \u206A‫‍⁪‭⁯‍​⁪‪⁭⁭⁮‬‍⁭⁭⁬‍‮⁫‏‭‪‍⁭‍‭⁮‬‌‎‍⁬‭⁭⁫⁪​‏‮() => new RichTextBox();

  static MenuStrip \u200F‎⁭‫‮⁮‌‌‫‫‮‎‫‫‬⁮‪‫‏‎‪‏‏‍‪⁯‎⁪​⁪⁯‎‫⁭‏‍‏⁭‏‮() => new MenuStrip();

  static ToolStripMenuItem \u202C‮‫⁫​⁮‪⁪⁬‬⁪⁯‫‌‪⁬‌⁫‮⁪‏‌‏‫‌​‫‏⁬‫‌‌‏‪‍‏‭‮‎‭‮()
  {
    return new ToolStripMenuItem();
  }

  static DateTimePicker \u202D‭‮‬‫⁪‎⁬‭‌‬‎⁫‫‬‏‬‏‬⁫‫‮⁬‭‫‌‌‌⁭⁪‫⁭⁫‪‬‍‍​‪‏‮() => new DateTimePicker();

  static RadioButton \u200D‮‬‎‪​⁮⁯‍⁬‪⁫‬‍⁮​⁯⁬‫⁪‏‏‎‏‎‌‬‎‌⁮‍​‭‏⁮⁬‪‫⁮‍‮() => new RadioButton();

  static System.Windows.Forms.Timer \u200E‫‎​‫‬‌⁫‪⁬⁮‌⁪⁪‮⁮⁭​‮‌⁬‮‎‭⁫‭⁯​⁬⁮​‏‍‎‪‮‫‎⁪⁫‮([In] IContainer obj0)
  {
    return new System.Windows.Forms.Timer(obj0);
  }

  static NotifyIcon \u200F‏​​‭⁬‏‮‏⁮⁫⁮⁪⁬‮‌‪‍⁫⁬‍⁯⁮‭‫⁫‫⁬⁪‬⁬‪⁫⁮‫⁪​‬⁭⁫‮([In] IContainer obj0)
  {
    return new NotifyIcon(obj0);
  }

  static PictureBox \u206C‮⁫‬‍​‏⁫‫‮‎‭​‮‫‬‎‪⁪‍‫‪⁪⁪‬‎⁭‌⁭‭​‬‌‏‎‍‍‮⁯‮‮() => new PictureBox();

  static ContextMenuStrip \u206C⁭‪‮⁭​‪‭‌⁯‮⁭⁫⁭‮‌⁬⁪‬‌‫‪⁬⁯⁫​‬‪‪⁫‭⁮‎‫⁮‫‎⁫⁯‮‮([In] IContainer obj0)
  {
    return new ContextMenuStrip(obj0);
  }

  static void \u206A‪⁫​‪⁭‬‌⁬‮‎​⁪⁭​‭⁭⁫‍‪‪⁮⁯⁮‫‍​‪⁭⁫‏⁮​​‮‍‮⁮‫‪‮([In] Control obj0)
  {
    obj0.SuspendLayout();
  }

  static void \u200D‌‫‍‮‫‌⁪‬‍⁭‪‫‮‫‪‍‎‪⁮‏⁬⁮⁯⁪‌‮‏⁫‍‎⁬‮‬‪‌‍​‪⁭‮([In] ISupportInitialize obj0)
  {
    obj0.BeginInit();
  }

  static void \u200E‪‎‏⁪⁫⁮‎⁮‬‭‍‮‍‌‫⁮​⁫‌‬⁬‌‪⁬⁯⁭⁭‬⁫​‏‫‫‏‫​‌‏⁮‮([In] Control obj0)
  {
    obj0.SuspendLayout();
  }

  static Control.ControlCollection \u200F‪⁫⁬⁪⁫⁭‍​⁯⁬⁯⁬‭‎‎⁬‫‎‍‭⁯‮​⁯‮‭‍⁪​‭⁪​‫⁪‎⁮‫‬⁫‮([In] Control obj0)
  {
    return obj0.Controls;
  }

  static void \u206E‍‌⁮‭⁫⁮⁮⁮‭⁮‪‎⁯‏⁪⁪⁯⁭‮‏‍⁬⁬‍⁯⁭⁯⁯‬‍⁮⁯‬⁮⁫‎‍⁮‌‮(
    [In] Control.ControlCollection obj0,
    [In] Control obj1)
  {
    obj0.Add(obj1);
  }

  static void \u202C‪​‮⁭‍‪‭‍‌⁮‮​⁯‮⁮‫‎‍⁬‌‭​‍‮⁫‭‌‬⁫‮⁭⁯⁮‮‏‫‌​⁬‮([In] Control obj0, [In] bool obj1)
  {
    obj0.Enabled = obj1;
  }

  static LinkLabel.LinkCollection \u200C⁫‍⁬⁭‌‬‫‎⁪‌⁬⁪​‏​‭‎‮⁪‮⁯‎‭‫⁬⁭⁫⁮​‏⁬⁫‎⁬‮⁪⁮‏⁮‮([In] LinkLabel obj0)
  {
    return obj0.Links;
  }

  static LinkLabel.Link \u206F⁭⁯‭⁪⁭⁯‍‪‍⁭‎‍⁪‮‫‮‬‮‌⁪⁮‬‪‌⁫‏‌‪‪⁫‬‫‎⁭‫‌‫‫‍‮() => new LinkLabel.Link();

  static void \u200D‬⁯⁮‍‍‭‎⁭⁬‮‫⁯‍⁮‭‌⁭‍‍‪⁬‭‮‪‪‎⁬⁫‌‏‫‭⁯⁪‭‬​⁫‍‮([In] LinkLabel.Link obj0, [In] object obj1)
  {
    obj0.LinkData = obj1;
  }

  static int \u200E⁫⁪⁭⁫⁭‬‌⁫‪‫⁪‍‎⁮‮⁬​‏⁯‪​‏‫‬‏‍‎‮‭‌⁬⁭⁫⁪​‭⁮​‮‮(
    [In] LinkLabel.LinkCollection obj0,
    [In] LinkLabel.Link obj1)
  {
    return obj0.Add(obj1);
  }

  static Icon \u202A⁯⁮⁬‭‏⁪‮‬‍‍‎⁭​‮⁪​⁫‏‍⁮‮‮⁪‭‍‬⁭⁯‬‬⁪‌‌​⁬⁯‬⁬‎‮([In] Form obj0) => obj0.Icon;

  static void \u202C⁫‪‎⁪⁯‪⁪‪⁬⁬‮⁫‮‬‮⁪‏‬‫⁪‫⁪‌‪‮⁮‌⁪⁭‎⁯‫⁯‍⁫⁬‪‭⁭‮([In] NotifyIcon obj0, [In] Icon obj1)
  {
    obj0.Icon = obj1;
  }

  static DirectoryInfo \u202C‪‪‎‮‬‪⁭‌⁭‍⁮‬⁫​‎‪‎⁯‮‭⁪​⁫⁬‫‌‎⁫‬‍‏‭⁭‏⁭⁭‬⁭‬‮([In] string obj0)
  {
    return Directory.CreateDirectory(obj0);
  }

  static string[] \u206A​‬‏⁪⁫‫‭‍‍‏‌​⁫⁯‭‪‏⁬‫⁪‎‬‍⁪‍‭‍‪⁬‪‍‮⁪⁭‪‏⁬⁭‫‮([In] string obj0)
  {
    return Directory.GetFiles(obj0);
  }

  static void \u206A⁭⁭‎⁫‮⁬⁮⁮‍‮‮⁬‭‫‏‏‏​⁭⁯⁭⁪‎‌​‮⁭‍‮​⁬‪‏‌‪​⁫‌⁮‮([In] string obj0) => File.Delete(obj0);

  static void \u200D‍‫​‬⁭​‎⁫‎⁮​‏‍‭‏‏⁮⁪‏‬⁫‪‪⁬‮⁪‬⁬⁫‫⁭⁫‭‌⁯‎‮‏‮([In] RadioButton obj0, [In] bool obj1)
  {
    obj0.Checked = obj1;
  }

  static ComboBox.ObjectCollection \u206C⁭‏‏⁭‍‫‬⁯‭‎⁫‎‫‎‭‍‎⁮‌⁮​‍‍‏⁬‌‏‪​⁭⁯⁯‎‍⁭‭⁭‭⁯‮([In] ComboBox obj0)
  {
    return obj0.Items;
  }

  static void \u200D⁮⁯‎‭⁪‭‭⁬⁬‮‪‌⁪‫‭⁭‪⁫‏‎⁬⁭‮⁭⁮‫⁪‪⁫⁪‪⁭⁮⁬‭⁭‬‌‫‮([In] ComboBox.ObjectCollection obj0)
  {
    obj0.Clear();
  }

  static void \u200B‮⁬‪⁭‏‌⁭⁪​​⁬⁪⁮‌⁫‬⁯⁮⁫​⁮⁫‫‮⁬‍‮⁭‌‪‭‫⁯‏⁮‭‍‌⁪‮(
    [In] ComboBox.ObjectCollection obj0,
    [In] object[] obj1)
  {
    obj0.AddRange(obj1);
  }

  static DataGridViewColumn \u202D‏⁯⁭⁪‌⁭‬‬⁯⁫‮‌⁬‌‍‍‮‬⁭‎‪‫⁭‌⁯‭​​‍⁭⁫‫⁬‬‮‌​‪⁮‮(
    [In] DataGridViewColumnCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static DataGridViewComboBoxCell.ObjectCollection \u202B‌‫⁮⁫‏‌‎‪⁬‌⁪⁫‎‎‭⁭‬⁬‬​‮‮‫‮‎‪‮‭‎‍⁪⁫‮‌⁬‌‏‫⁪‮(
    [In] DataGridViewComboBoxColumn obj0)
  {
    return obj0.Items;
  }

  static void \u202B‫‍⁮⁫⁭⁫‌⁮‎‭‭⁪⁮⁫‫‌⁪‎⁯‭​‬‮‮‍⁮​‬​⁭​‌⁭​‭⁮⁬‪‭‮(
    [In] DataGridViewComboBoxCell.ObjectCollection obj0)
  {
    obj0.Clear();
  }

  static int \u206B‭‍‎‭‭⁬‍‎⁯‎⁯⁫‫⁬‌‍‮⁬‫‬⁭‍​⁭‎⁭⁬‍‬⁪‪⁭‌​​⁭‏‫‎‮(
    [In] DataGridViewComboBoxCell.ObjectCollection obj0,
    [In] object obj1)
  {
    return obj0.Add(obj1);
  }

  static void \u206D⁮⁫⁫​⁮⁭⁬‎⁫⁬‫​⁭‪⁬‍‬⁭​‌‬‭⁪⁪‏‍​‍‏‏‏⁮⁬‬⁭⁯​‌‌‮() => Console.Beep();

  static void \u206B⁪‭‭‪‍‮⁬‍⁭​‍‌‌⁬‭​​​​​​⁪‌⁬⁭‌⁫⁬⁯‏‫‍‎⁬‏​‎⁪⁭‮([In] NotifyIcon obj0, [In] string obj1)
  {
    obj0.BalloonTipText = obj1;
  }

  static void \u200E‌⁭‫⁪⁭⁪‫​‮⁭‎⁫‫​⁭‍⁫‮‬⁬​⁭‏‭‮‏‏‌⁮‮‮⁯‭​⁮⁬⁫‏‫‮([In] NotifyIcon obj0, [In] int obj1)
  {
    obj0.ShowBalloonTip(obj1);
  }

  static TabControl.TabPageCollection \u200C‌‏⁯‮​⁯‎‍⁪‪‌⁫‬‍‌⁮⁭‍‬‫⁮‍⁪‮‍⁫​​⁬⁯⁮⁮‍‌‫‎‍⁬⁬‮([In] TabControl obj0)
  {
    return obj0.TabPages;
  }

  static IEnumerator \u206B‫‎‭​⁫‍⁪‍‬‎⁯‭‭⁬‮⁯‏​‌‭⁬⁯‮‌⁪⁬‌‏⁪‏​‫‬‍⁭⁫‪‍‮([In] TabControl.TabPageCollection obj0)
  {
    return obj0.GetEnumerator();
  }

  static object \u206D⁬⁮⁫⁯⁭⁮‫⁭‍​​⁮⁭​⁬‌⁯‪⁯‪⁫⁯‫​⁬‍⁭​‭‫‎‬‌‏⁪‎‬‬‏‮([In] IEnumerator obj0)
  {
    return obj0.Current;
  }

  static Image \u200E‬⁪⁭⁪‌⁮⁬‭‮⁫⁪⁭⁯‬‪⁭‭‪‭‮‌⁬‮⁪‫​⁯‍‬‮⁬‏‪⁯⁫⁬⁮‍‪‮([In] string obj0)
  {
    return Image.FromFile(obj0);
  }

  static void \u200F⁬⁫‍‪​⁫‮‬‍⁫⁮‫⁬⁬‭‬​⁮⁫‭‭​‬‫‫‫⁪‪‎⁪⁬⁪‪⁪⁬⁫‭‌⁮‮([In] Control obj0, [In] Image obj1)
  {
    obj0.BackgroundImage = obj1;
  }

  static bool \u202C‬‌‌‭‬⁫⁪⁬⁮‭‎​⁪‏⁫‮⁫‪‎⁬​⁯‌⁭‬‍‏⁬​⁪⁬​‏‌⁫‬⁯⁪⁯‮([In] IEnumerator obj0)
  {
    return obj0.MoveNext();
  }

  static object \u206C⁫⁮⁬‬‫⁫⁬⁫⁭‪​⁫⁮⁮‌‪‌‌⁮⁮‏‎⁫‎‎⁮⁫​⁭⁬‬‫⁪​‪​‭⁮⁯‮([In] Control obj0, [In] Delegate obj1)
  {
    return obj0.Invoke(obj1);
  }

  static bool \u202C‎‮‍⁭‏‪‬⁭‌⁫‫‍‬⁬⁬‭⁯⁮⁯‌‮⁮⁬⁫‌⁫‏⁭⁯‪‪⁪‪‪⁯⁭⁬‬⁫‮([In] string obj0) => File.Exists(obj0);

  static void \u202B⁬‫⁯‮‬‌⁫‫⁮⁮‎‍‏⁮‫‫‍⁮⁪‏⁬‬‪‏⁫⁪‎⁪‫‪‌‍‌‍⁮‮‪‌‏‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }

  static int \u206B‭⁭‌‬⁫⁪⁪​‌⁭⁬‮‏‮‏⁬⁭‎‪‏⁮‍⁫⁯⁭‏‮‬​‪⁮‭‮⁪​⁭⁭‬‮([In] CreateParams obj0) => obj0.ExStyle;

  static void \u200C‍‫‪‌⁬‍‏​‭‪‮‍⁮‎⁪‫⁬‏‪‍‍​‮‍⁪‬⁯⁭‭⁭⁭⁭‭‪⁫‫‫‎‏‮([In] CreateParams obj0, [In] int obj1)
  {
    obj0.ExStyle = obj1;
  }

  static void \u200E⁭‮‍‬‏‫‪⁫‮⁯‭‎⁯‫⁮‭‭‍⁭‌⁬‭⁬‫‍‏‫‭‪​⁬‏⁭‏‍⁮⁭‫‍‮([In] Form obj0, [In] bool obj1)
  {
    obj0.MaximizeBox = obj1;
  }

  static DialogResult \u200B‭⁯⁯‬⁮‌‏‍‎⁫‎⁫‫⁮⁮‪​​‬⁯⁭‮‎‮‭‏‮‭‎‎‪​‍⁭‭⁪‬‮‌‮(
    [In] string obj0,
    [In] string obj1,
    [In] MessageBoxButtons obj2,
    [In] MessageBoxIcon obj3)
  {
    return MessageBox.Show(obj0, obj1, obj2, obj3);
  }

  static void \u206E⁪​‏‍‪‌‌‎⁪‌⁬​⁫‪‮⁯⁪‮‪‭⁬‭​‪‏⁯‎‭‌‪‮⁬‮‪⁭‏‬⁪‍‮([In] int obj0)
  {
    Environment.Exit(obj0);
  }

  static Task \u200C‭‎‎⁮‪⁫‏‬‪‫‏‮‌‭‮‍⁬⁫⁮‫⁫​‎⁪‬‬‌⁭​‮⁯‬‮⁪‮​‌⁭‬‮([In] Action obj0) => new Task(obj0);

  static void \u206D‏‪‮‏‪​‮‎‎‫‎‪‎‭​⁯‎‪‌‏‬‬‎​⁭‭‏‪⁮⁫‏⁮‮‫‏‪‎‍⁮‮([In] Task obj0) => obj0.Start();

  static void \u200D⁪⁬‍⁪⁮⁫⁯‌⁪‫‭‬‏⁯‏⁯‏​⁭⁬​‏​‌⁫‪‪​‮⁪​⁬‌⁬‏‭⁪‏⁮‮([In] Form obj0) => obj0.Close();

  static Point \u202D⁮‎⁯‬⁭‫‍‬⁯‎‫⁯⁮‬‬⁫⁯⁯⁭‏‮⁫‫‎⁯‏‎⁫⁭⁮‭⁯‌‪⁮‫‪⁬‮() => Control.MousePosition;

  static void \u206E⁭‌‬‌⁭⁬‫⁬‏‏‎‌​⁪⁮‎⁯⁫‏‍‮‎⁯‏‌⁪⁬⁪‬⁯‌​‮⁮‫⁬⁬⁭‬‮([In] ToolStripDropDown obj0, [In] Point obj1)
  {
    obj0.Show(obj1);
  }

  static void \u200C⁫⁬⁬⁬‭‍‪‭‮⁮‎‫⁬⁮‮‎‫⁫‏‮‪​⁮‎‬‌⁫‬‮⁬⁮​⁯⁫⁫⁮⁭⁫‪‮([In] ButtonBase obj0, [In] bool obj1)
  {
    obj0.UseVisualStyleBackColor = obj1;
  }

  static void \u200F‫‏‍⁪‎‭⁪⁬​‭‫‫⁯‪‌⁭‏‪‌⁭‮‏‪⁮‭‫‌⁭‭⁫‎‏‪‬⁫⁫‬⁬‎‮([In] Control obj0, [In] Color obj1)
  {
    obj0.BackColor = obj1;
  }

  static int \u200D⁬‭‭‪‍‭‍‬⁭⁯‬⁬⁮‭⁬‪⁮‬⁫⁮‮‮‎⁫⁪‪‮‌⁪‭‪⁭⁭‍⁫‪‮‮‏‮([In] ListControl obj0)
  {
    return obj0.SelectedIndex;
  }

  static object \u206D⁬⁮‪⁯‮‭‎⁪⁯⁯‏⁪‌‮‎⁯‫‫‭‌⁭‪‬‎‌⁪‌⁯‪⁯⁯‍⁫⁫‪‭‪​⁯‮(
    [In] ComboBox.ObjectCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static Image \u206A‮⁪⁮⁪‪‍‌⁯‎⁯‪‭‌‎‏‪⁯​‪‫‪‪‌‏⁫‫⁪⁯⁬‍⁯‎⁪⁬​⁫‮‫‪‮([In] PictureBox obj0) => obj0.Image;

  static string \u202C‍⁫‎‌‎⁫⁬⁮⁭‬‎‭⁬​⁮‍‮‭‍‭⁯‬‪‭‍⁮‍⁫⁮‏⁬‌‬‫‬⁭‭​⁭‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static FileStream \u202D⁪‬‌‪⁮‫⁮⁮‭⁮‪⁬⁯⁯‪​‬‪‫‌‍⁮⁬⁯⁬​⁪‮‌⁪‎⁯‍‎‍‌‫⁫⁮‮([In] string obj0, [In] FileMode obj1)
  {
    return new FileStream(obj0, obj1);
  }

  static Image \u202A‪‍⁬⁪​⁯‌⁮‌‪⁭‭‌‫⁭‪‌⁯‫⁪‮‮⁯⁯⁬‏‏⁫​⁪‪⁭⁭⁮‎‭⁮‪‎‮([In] Stream obj0)
  {
    return Image.FromStream(obj0);
  }

  static void \u206B‮‌‌‮‏⁭⁫‌⁪⁫​‭​⁯⁯‏‮‪‫⁬⁯‫​‌⁫⁯⁮⁪⁬⁪⁫‌⁬‪‮‍‎‏‎‮([In] PictureBox obj0, [In] Image obj1)
  {
    obj0.Image = obj1;
  }

  static void \u206B‌‎‍‪‪​‍⁭⁯‫⁫‏​⁭‫‪⁬‭​‎‎‮‭‬‍‌⁯‬​‍‍‮⁯‮⁯⁬‭‪‎‮([In] Stream obj0) => obj0.Close();

  static string \u206F‮‌‏‫‭‎⁭​​​⁪⁮⁭⁫‍‏‪⁫‭‮⁮⁫‌‫⁮‎⁮⁭‎⁯‫‎‍⁪⁪‪‭‍‏‮([In] string obj0, [In] string obj1)
  {
    return obj0 + obj1;
  }

  static Keys \u202B⁫‫⁫⁮‌⁬‪‪‪‬‎‮‎‫‪‌‍⁭‭‌⁬‪‬⁮‪‎⁯⁭‬⁭‬‮‫‏⁮‫⁭‍‮([In] KeyEventArgs obj0) => obj0.KeyCode;

  static string \u202E⁮‭‭‌‮‮​‍⁫⁫‬‎⁮‍‬​⁭‫⁪‏⁮⁪‫⁮⁭⁫​‪‪‏‎‪​‫‮‍​‭‌‮([In] Control obj0) => obj0.Text;

  static bool \u202A⁪‍⁪⁪⁫‫⁯‌⁬‌⁬‪‪‭⁭⁮⁫⁮⁫‫‪‏‫‎⁬⁫⁯‭⁯‭⁫‏⁬⁭⁭‪⁮⁫⁮‮([In] string obj0, [In] string obj1)
  {
    return obj0 == obj1;
  }

  static void \u206B‌​‍‎‌‌⁮‭​⁮⁬⁭⁮‫⁭⁯⁫‮⁪‌‭‌⁮​‪‌‎‎‏⁫‏‎⁪⁮⁪‪⁬‌‌‮([In] Image obj0) => obj0.Dispose();

  static void \u206E‎‫⁮⁮‭⁫‫⁮‭​‭⁯‭‌‎⁭⁯‪⁬⁪‌⁯⁬⁭⁭⁮‮‪⁮‭‌‮‫​‍‎​‬‎‮([In] TextBoxBase obj0) => obj0.Clear();

  static void \u206D⁭⁯‫⁫⁫‏‫‏⁭‫⁯‌⁬​‌⁫‭⁪⁯‏⁬‭‭‏‎‫⁬‭‭⁬‫‬‭⁬‌‍‫‪‌‮([In] ToolStripItem obj0, [In] bool obj1)
  {
    obj0.Enabled = obj1;
  }

  static bool \u200E‪‬‮⁪​‬‭⁫⁬‮⁮‬‭⁮‍‏⁯⁮⁪⁯‭⁪‫⁫‮‪⁫‭‫⁭⁫‭‪⁮‎⁭‭‌‮‮([In] ToggleSwitch obj0)
  {
    return obj0.Checked;
  }

  static DateTime \u200C‍‏​‭‎‮‬‬‬‏‬‬‌‍⁯⁫⁬‏‮⁮​⁭‬⁯‏‭⁬‮‮⁬⁭‌⁪‍‮⁬​⁭⁪‮([In] DateTimePicker obj0)
  {
    return obj0.Value;
  }

  static void \u202E‏⁯‏‮‬⁭⁬‬‏‫⁫​‍‍⁮‫​⁭⁪‫‌⁬​‍‎‫‍⁫‏‌‭‍‮⁬⁬⁮‭‪‮([In] Control obj0, [In] string obj1)
  {
    obj0.Text = obj1;
  }

  static LinkLabel.Link \u200B‌⁮‪‏⁪‭‪⁫‭‌‫‎‫⁯‭⁬​⁪⁭⁯‬⁪⁫⁪⁯‭‭‭‏‮⁭‎‬‫‫⁬‭⁯‮‮(
    [In] LinkLabelLinkClickedEventArgs obj0)
  {
    return obj0.Link;
  }

  static object \u206E‭⁯‍‬⁪⁫⁬‭⁮‍⁭⁬⁪‬⁬‎‫⁫⁯‭‎‮⁭⁫⁬⁮‬‍‏‫‏‎​‫‏⁫⁮⁬‪‮([In] LinkLabel.Link obj0)
  {
    return obj0.LinkData;
  }

  static Process \u200E​‎⁯‫‮⁫​‫‎⁯‎⁬‌‎⁫‪‭‍⁫‭‭⁭‭‍⁬‍‌⁬‍⁫⁮‎‬⁪​‏‮⁯‫‮([In] string obj0)
  {
    return Process.Start(obj0);
  }

  static void \u206C⁯‪‫‏‮‭‪‫‬‮⁯⁫‭‏‍‌‮‮⁮‏‪‌⁫‎‮‌‮‭⁭⁬⁮​‎‌⁭‍‭‮‪‮([In] ListControl obj0, [In] int obj1)
  {
    obj0.SelectedIndex = obj1;
  }

  static bool \u202E⁬‭‭‎‏⁫‮​⁭⁮‍‏⁬⁯‭‎‏‪‌‪⁯‬⁯‫​‌⁪⁫‎​‏⁯⁯‍​‏⁪⁭⁪‮([In] string obj0)
  {
    return string.IsNullOrEmpty(obj0);
  }

  static int \u202C‫‪‭⁯⁮‎⁮‫‎‭​⁮‪⁪⁯⁫⁪⁪‏⁪​‭‮⁮‍‏‍‫⁭⁬‏‏‭⁭‬‫⁬⁯‌‮(
    [In] ComboBox.ObjectCollection obj0,
    [In] object obj1)
  {
    return obj0.Add(obj1);
  }

  static Encoding \u206A‬‏⁯⁪‬‏‮‪⁪‏⁯‮‫⁮‫‮⁮‌‎⁪⁯⁬‭⁮‎‫⁬‌‪⁭‬⁫⁯‌‫⁪⁫‌‮‮([In] string obj0)
  {
    return Encoding.GetEncoding(obj0);
  }

  static string[] \u206E‬‫‌‫⁪‮⁫‪‌‭‬⁭‫‏⁪‮‎‪‭⁪‪⁯‌‮‭‪‎⁬​⁪⁭‌‌‫⁫‎‪⁬‎‮([In] string obj0, [In] Encoding obj1)
  {
    return File.ReadAllLines(obj0, obj1);
  }

  static void \u200E​⁪‍‪‬⁯‫‍‎‌‭⁬⁮⁮‮⁭‫⁭‬⁮‍​‪‮‎⁯⁪‎⁯‮‫⁬‏‬‪‌⁭​‪‮([In] ToggleSwitch obj0, [In] bool obj1)
  {
    obj0.Checked = obj1;
  }

  static void \u200F‍​‫‬⁫⁪‎⁬‬‪‮‍⁬‍‏‬⁭‌⁪‮⁭⁫‫‭‫‭‪⁭​‭‍⁯‌⁭‭⁫⁭‪‮([In] NumericUpDown obj0, [In] Decimal obj1)
  {
    obj0.Value = obj1;
  }

  static DialogResult \u206E‌‪‬‏‍⁮‍‪‍⁮‭‮⁭‏‫‪‎‫‎​​⁫⁯⁭‫‪⁫‫‪⁫⁬​‌‏‫‬⁯‪‌‮([In] Form obj0, [In] IWin32Window obj1)
  {
    return obj0.ShowDialog(obj1);
  }

  static object \u200C‍‪‪⁪⁭⁭‮​⁮​⁯⁪‬‍‍‮⁬⁮⁫‍​‎‍⁫‏⁪‏‫⁮‮⁭⁮‏‬‍‌⁫⁫⁬‮([In] Control obj0, [In] Delegate obj1)
  {
    return obj0.Invoke(obj1);
  }

  static int \u202A⁮‪⁭‌⁬⁪⁫⁮⁫‍⁭‬‎‎‮⁯‪⁯‎⁬‫‍‭‬⁪‫‌⁮​⁯‎⁭‪‮‎‫‌⁪‎‮([In] ComboBox.ObjectCollection obj0)
  {
    return obj0.Count;
  }

  static void \u200C⁪‌⁫‏‌‌‏‎‮⁬‪​‎‎‭‌⁫‭‬‍⁯‮⁬‏‫​‪‮​‎‍⁫⁯‏⁭‭⁭‏‍‮([In] int obj0) => Thread.Sleep(obj0);

  static Decimal \u200E⁯⁬⁯⁭⁪⁪‫‮⁯‏⁮⁭‬‪⁫⁬‪​⁫‏⁪⁫⁮‏⁯‏⁭‎⁪⁪⁭‫⁭‫⁯⁭⁯‬‮([In] NumericUpDown obj0)
  {
    return obj0.Value;
  }
}
