﻿// Decompiled with JetBrains decompiler
// Type: 0*L2uE892Amo:r>C+{Z;e^_^#
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using ISP.Engine.Accounts;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using VkNet.Enums.Filters;
using VkNet.Enums.SafetyEnums;

#nullable disable
internal sealed class \u0030\u002AL2uE892Amo\u003Ar\u003EC\u002B\u007BZ\u003Be\u005E_\u005E\u0023 : 
  \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮
{
  private static \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮ \u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮;
  private IContainer \u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮;
  private Label \u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮;
  private Label \u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮;
  private ComboBox \u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮;
  private Button \u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮;
  private Button \u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮;
  private Button \u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮;
  private Button \u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮;
  private Button \u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮;
  private Button \u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮;
  private TextBox \u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮;
  private Label \u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮;
  private Label \u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮;
  private ListBox \u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮;
  private Button \u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮;
  private NumericUpDown \u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮;
  private Label \u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮;
  private Label \u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮;
  private DataGridView \u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮;
  private DataGridViewTextBoxColumn \u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮;
  private DataGridViewTextBoxColumn \u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮;
  private Label \u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮;
  private Label \u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮;
  private NumericUpDown \u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮;

  public \u0030\u002AL2uE892Amo\u003Ar\u003EC\u002B\u007BZ\u003Be\u005E_\u005E\u0023()
  {
label_1:
    int num1 = 1562636996;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 210651146)) % 4U)
      {
        case 0:
          goto label_1;
        case 1:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u206B⁬⁬⁪‫‏⁬⁫‪‍⁫⁬⁬‌‪⁮​‫‌‏⁮⁫​⁪‎⁫⁫‏‪‎‮⁭‍⁯⁬‫‪⁫‏⁫‮((Form) this, false);
          num1 = (int) num2 * -160962066 ^ -348443549;
          continue;
        case 2:
          this.\u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮();
          \u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁪⁮‫‍‭‏‭‌⁭​‍‍⁫‫‮​‎⁫⁮⁯‏‭‮⁬‮⁭⁮⁪‪‪​⁯‫‏‬⁬‭‏⁪‮((Control) this, Color.FromArgb(ConfigController.InterfaceConfig.ForColorAsArgb));
          num1 = (int) num2 * -1848475175 ^ -881631251;
          continue;
        case 3:
          goto label_3;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  private static void \u200C‮⁪‏⁯⁫‭‎‍‎⁯⁯​‏‪⁭⁪‫⁫⁬‍⁯‎⁬‮‮⁮⁭‫‏⁫⁯‮‎‌‏⁫⁭‎⁯‮(AntikickTarget _param0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u007BZ\u003Be\u005E_\u005E\u0023.\u202C‪‍‭‏​‌‪⁯‪‭‭‌‬⁫⁯‏‏‌‫​‬‫⁯‫‫‫⁫‍⁪‬‌⁬⁫⁯‎⁪‮⁭‮ obj1 = new \u007BZ\u003Be\u005E_\u005E\u0023.\u202C‪‍‭‏​‌‪⁯‪‭‭‌‬⁫⁯‏‏‌‫​‬‫⁯‫‫‫⁫‍⁪‬‌⁬⁫⁯‎⁪‮⁭‮();
    // ISSUE: reference to a compiler-generated field
    obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮ = _param0;
label_1:
    int num1 = 1212992613;
    while (true)
    {
      uint num2;
      List<long> list;
      \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ obj2;
      string code;
      DateTime now;
      DateTime? whenToRejoin;
      int num3;
      switch ((num2 = (uint) (num1 ^ 816604274)) % 27U)
      {
        case 0:
          code += \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2878691132U);
          // ISSUE: reference to a compiler-generated field
          obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.VkApi.Execute.Execute(code);
          num1 = (int) num2 * -1337305352 ^ 778618924;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          int num4 = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.WhenToRejoin.HasValue ? -146479212 : (num4 = -1147955274);
          num1 = num4 ^ (int) num2 * -383015168;
          continue;
        case 2:
          // ISSUE: reference to a compiler-generated field
          obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.WhenToRejoin = new DateTime?();
          // ISSUE: reference to a compiler-generated method
          code = list.Aggregate<long, string>(nameof (), new Func<string, long, string>(obj1.\u200F⁯⁪‬‏‪⁯⁫‫‌⁯⁯‏⁪‎‭⁭⁫‌‌⁬‭⁭‌​‌‬‮‪⁭⁯‬⁯​‪‮‮‪‏⁫‮));
          int num5;
          // ISSUE: reference to a compiler-generated field
          num1 = num5 = !ConfigController.AntikickConfig.LeavedIntentionallyFrom.ContainsKey(obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Login) ? 328216505 : (num5 = 713904554);
          continue;
        case 3:
          goto label_1;
        case 4:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          code = string.Format(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1485751006U), (object) obj1.\u202C‭‍‫⁪⁮‫⁫⁭‮‮‎‭⁯‫⁮​‪‫‎‭⁯⁮⁭‬‍‍‮‮⁯‏‏⁪​‏‌‏‍‭‫‮, (object) obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Myself.Id) + code;
          num1 = 1520256234;
          continue;
        case 5:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = AccountsManager.GetAccount(obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts[obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc].Name);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj2 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮, \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‏‌‮⁬‬⁯⁭‭‌⁯‫⁪​⁯‬⁮​⁬⁪‏⁮‌‎⁪‍‎⁪​⁬‍‫⁫‪⁭⁬​⁫⁬⁯‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2962288275U), obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Name));
          int num6;
          num1 = num6 = obj2.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ == \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat ? 861169510 : (num6 = 1039382723);
          continue;
        case 6:
          if (whenToRejoin.HasValue)
          {
            num3 = whenToRejoin.GetValueOrDefault() <= now ? 1 : 0;
            break;
          }
          num1 = (int) num2 * 377653828 ^ -2078757460;
          continue;
        case 7:
          // ISSUE: reference to a compiler-generated field
          int num7 = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Count != 0 ? 1136960318 : (num7 = 107123072);
          num1 = num7 ^ (int) num2 * 1551696810;
          continue;
        case 8:
          goto label_10;
        case 9:
          int num8;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          num1 = num8 = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc < obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Count ? 189849472 : (num8 = 441474446);
          continue;
        case 10:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = AccountsManager.GetAccount(obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts[obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc].Name);
          num1 = (int) num2 * -824438130 ^ -244484157;
          continue;
        case 11:
          goto label_7;
        case 12:
          int num9;
          // ISSUE: reference to a compiler-generated field
          num1 = num9 = list.Count == obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Count - 1 ? 478745208 : (num9 = 1009924270);
          continue;
        case 13:
          // ISSUE: reference to a compiler-generated field
          obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.WhenToRejoin = new DateTime?(DateTime.Now + new TimeSpan(0, 0, 0, 0, ConfigController.AntikickConfig.PartialRejoinDelay));
          num1 = (int) num2 * -565777687 ^ -2115222800;
          continue;
        case 14:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated method
          list = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Select<AntikickAccountData, \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>>((Func<AntikickAccountData, \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>>) (_param1 => new \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>(_param1, AccountsManager.GetAccount(_param1.Name)))).Where<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>>(new Func<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, bool>(obj1.\u206F‎⁭‍‍⁬‎‍‍‮‬‎‎⁬⁫‪⁭‍‭​​‪​⁫‏‭‫‮⁫⁮⁯‭​⁪‪‭⁮​⁫‏‮)).Select<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>>(new Func<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>>(obj1.\u206B‫‍⁭⁬‬‌‌‭‎‎⁫‪‌‎‌⁬‭⁬⁪‭‭​​‎‮‌‌⁬‬‍⁮⁬‪‍‌⁬‏⁬‭‮)).Where<\u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>>((Func<\u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>, bool>) (_param1 =>
          {
            if (_param1.searchResult.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ == \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat)
            {
label_1:
              uint num10;
              switch ((num10 = (uint) (-1135405663 ^ -918391361)) % 3U)
              {
                case 0:
                  goto label_1;
                case 2:
                  // ISSUE: reference to a compiler-generated method
                  // ISSUE: reference to a compiler-generated method
                  // ISSUE: reference to a compiler-generated method
                  return \u007BZ\u003Be\u005E_\u005E\u0023.\u202C‌⁭⁪⁭⁮⁭⁬‮⁪‎‬‍‌⁭‏‫‍⁬‌‍‎⁫⁫‎⁯‫⁫⁬⁫‏⁭⁫‫⁬‌⁯​⁬‮.\u202A‎‬‮⁯⁫⁮‎‭‍⁪‫‎⁮‍⁫⁫⁪⁪‎​‫‮⁪‫‏​‮⁬‫‬‬⁮‫‮⁫‮‪‮‫‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202C‌⁭⁪⁭⁮⁭⁬‮⁪‎‬‍‌⁭‏‫‍⁬‌‍‎⁫⁫‎⁯‫⁫⁬⁫‏⁭⁫‫⁬‌⁯​⁬‮.\u206D‬​‫⁮⁫⁯​⁬⁮‬⁬⁯‏​‪‪⁫‌‍⁬‫‍‎‬⁪⁭⁮⁭‫‫‬‏⁭‌⁮‮⁮‪‎‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202C‌⁭⁪⁭⁮⁭⁬‮⁪‎‬‍‌⁭‏‫‍⁬‌‍‎⁫⁫‎⁯‫⁫⁬⁫‏⁭⁫‫⁬‌⁯​⁬‮.\u206A‎‬⁪⁫⁬‮‌‬‪‫⁪‎‫‬⁬‌⁮‭‌‏⁯⁫‮‎‌​‌⁮‭‍⁯‪⁪⁪‎‪⁪‫⁯‮(_param1.\u003C\u003Eh__TransparentIdentifier0.currAcc.VkApi), _param1.searchResult.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value, (ProfileFields) null, (NameCase) null));
              }
            }
            return false;
          })).Select<\u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>, long>((Func<\u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<AntikickAccountData, Account>, \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>, long>) (_param1 => \u007BZ\u003Be\u005E_\u005E\u0023.\u202C‌⁭⁪⁭⁮⁭⁬‮⁪‎‬‍‌⁭‏‫‍⁬‌‍‎⁫⁫‎⁯‫⁫⁬⁫‏⁭⁫‫⁬‌⁯​⁬‮.\u202C‮‎⁭‫‪⁭‏‏‫⁪⁬‬‭‮‭⁫⁪‎⁮‫‎⁪‫‪​​⁬⁪⁫​‪⁯​‫‬‍​‬‍‮(_param1.\u003C\u003Eh__TransparentIdentifier0.currAcc.Myself))).ToList<long>();
          int num11;
          num1 = num11 = list.Count <= 0 ? 1044381588 : (num11 = 142429018);
          continue;
        case 16 /*0x10*/:
          // ISSUE: reference to a compiler-generated field
          obj1.\u202C‭‍‫⁪⁮‫⁫⁭‮‮‎‭⁯‫⁮​‪‫‎‭⁯⁮⁭‬‍‍‮‮⁯‏‏⁪​‏‌‏‍‭‫‮ = obj2.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = (int) num2 * -1020728188 ^ 1284982910;
          continue;
        case 17:
          // ISSUE: reference to a compiler-generated field
          whenToRejoin = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.WhenToRejoin;
          num1 = (int) num2 * 93196739 ^ -1548057064;
          continue;
        case 18:
          // ISSUE: reference to a compiler-generated field
          obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc = 0;
          num1 = (int) num2 * 477875102 ^ -18202104;
          continue;
        case 19:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ConfigController.AntikickConfig.LeavedIntentionallyFrom[obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Login].Remove(obj1.\u202C‭‍‫⁪⁮‫⁫⁭‮‮‎‭⁯‫⁮​‪‫‎‭⁯⁮⁭‬‍‍‮‮⁯‏‏⁪​‏‌‏‍‭‫‮.Value);
          num1 = (int) num2 * 1483997860 ^ -1241382439;
          continue;
        case 20:
          num1 = (int) num2 * 2087923681 ^ 468127387;
          continue;
        case 21:
          now = DateTime.Now;
          num1 = (int) num2 * -1787994966 ^ -521186327;
          continue;
        case 22:
          num3 = 0;
          break;
        case 23:
          // ISSUE: reference to a compiler-generated field
          int num12 = !obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.WhenToRejoin.HasValue ? -1505492325 : (num12 = -1239919487);
          num1 = num12 ^ (int) num2 * -1129252606;
          continue;
        case 24:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc = (obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.IndexOfActiveAcc + 1) % obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Count;
          num1 = 85209186;
          continue;
        case 25:
          goto label_41;
        case 26:
          // ISSUE: reference to a compiler-generated field
          int num13 = obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Accounts.Count == 0 ? 287403712 : (num13 = 1355528924);
          num1 = num13 ^ (int) num2 * -150598300;
          continue;
        default:
          goto label_32;
      }
      if (num3 != 0)
        num1 = 478745208;
      else
        goto label_32;
    }
label_10:
    return;
label_7:
    return;
label_41:
    return;
label_32:
    try
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ obj3 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3975879532U) + obj1.\u202B⁭⁫‭⁮‏‭‫‮‍‫​​​‎‪​⁮⁮⁫⁬‎‫‎‮⁬‭⁭⁮‌‮⁬‭​​⁬⁭​‎⁫‮.Name);
label_34:
      int num14 = 1026528944;
      long chatId;
      while (true)
      {
        uint num15;
        switch ((num15 = (uint) (num14 ^ 816604274)) % 6U)
        {
          case 0:
            goto label_36;
          case 1:
            // ISSUE: reference to a compiler-generated field
            ConfigController.AntikickConfig.LeavedIntentionallyFrom[obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Login].Add(chatId);
            num14 = 317039016;
            continue;
          case 2:
            // ISSUE: reference to a compiler-generated field
            ConfigController.AntikickConfig.LeavedIntentionallyFrom.TryAdd(obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Login, new List<long>());
            num14 = (int) num15 * 7322326 ^ -1170043207;
            continue;
          case 3:
            // ISSUE: reference to a compiler-generated field
            int num16 = ConfigController.AntikickConfig.LeavedIntentionallyFrom.ContainsKey(obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Login) ? 515268261 : (num16 = 621509266);
            num14 = num16 ^ (int) num15 * -316125844;
            continue;
          case 4:
            chatId = obj3.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.VkApi.Messages.RemoveChatUser(chatId, obj1.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.Myself.Id);
            num14 = (int) num15 * -1568756057 ^ -2020249585;
            continue;
          case 5:
            goto label_34;
          default:
            goto label_3;
        }
      }
label_36:
      return;
label_3:;
    }
    catch
    {
    }
  }

  private static void \u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u007BZ\u003Be\u005E_\u005E\u0023.\u200C‭‬⁯‫⁭‮‪⁯⁪‌‫⁮‮‪⁭‫‎⁫‬‎‎‎‍⁭⁪⁮​⁮‫⁬‬‮⁯⁫⁪‬‎⁬⁬‮ obj = new \u007BZ\u003Be\u005E_\u005E\u0023.\u200C‭‬⁯‫⁭‮‪⁯⁪‌‫⁮‮‪⁭‫‎⁫‬‎‎‎‍⁭⁪⁮​⁮‫⁬‬‮⁯⁫⁪‬‎⁬⁬‮();
    AntikickConfig antikickConfig = ConfigController.AntikickConfig;
    // ISSUE: reference to a compiler-generated field
    obj.\u206C⁫⁪‍​‬⁯‍​⁭⁮‬⁯‬‎‮⁪⁫‌⁫⁬⁯‍‭⁪‍⁮‪⁪⁯‍⁫‮‎​‍⁪‫⁭⁭‮ = antikickConfig.Targets;
    // ISSUE: reference to a compiler-generated field
    obj.\u206D⁪‌⁬‌‭‌‍⁯⁭‍‫‏‭‮⁯⁭⁭⁭⁭‬⁯‬⁫‌‍⁯‮‪‭‭‮‮‏‪⁯​⁮‫⁫‮ = -1;
    // ISSUE: reference to a compiler-generated method
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮ = new \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮(new Action(obj.\u200D‎⁯⁯‫⁪⁪‎⁮⁬‭‏‮‍‭‏⁮‍‍‎‏⁯‌⁭‮‬‎⁫‌⁯⁭‏‮‏‬‏⁮⁬⁫⁫‮), antikickConfig.Delay);
  }

  private void \u200B‏​‫⁮‫⁯⁫‍‮⁬‬‍‮⁭‎⁭‏‏‭⁪​‍‬⁫‎⁬⁬‬‌‫‪‏‎⁪‎‮‭⁯‮(object _param1, EventArgs _param2)
  {
    int index = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E​⁬⁭‏⁬⁪⁭​‮‍‮‭‍‌‏⁯‫‫⁮⁫‌⁮‫‪‎⁫‫⁯‬‏‭‏⁯‬⁭⁭​‫‭‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮);
label_1:
    int num1 = 959810250;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1404294512)) % 5U)
      {
        case 0:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D⁬‫‬‎‫⁯‍‮‌​‭‫‏‏⁪⁪⁪⁫‎‫​‫‎‬‏‏‪‌‎‌‪⁪‌‭⁭​⁮‮‌‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮));
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D‪⁫​⁮‭‫‬⁬⁯‫‪‫‮‫‪‎⁪‎‫⁯‌⁭‮⁯‭‮‌‮‬‬‌‬‎‌‫‌⁬⁯‍‮((Control) this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮, \u007BZ\u003Be\u005E_\u005E\u0023.\u206F⁪‮‏⁬‫⁭‬‫⁮​​‮⁫⁬‭‮‍⁭​⁭‮⁬⁬​‎⁪⁬‌‬⁯⁪⁮⁮⁮⁬‏‮‬⁪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁮‌‍⁫‌‭⁮‪‎⁪‌‭​⁭⁯⁪‮‬‮⁫‮⁬⁯‎​‭‎⁬‫‏‭‎‭⁫⁯⁯‪⁪‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮), index)));
          num1 = 1769954619;
          continue;
        case 1:
          int num3 = index != -1 ? -1385966844 : (num3 = -1647616750);
          num1 = num3 ^ (int) num2 * 135100032;
          continue;
        case 2:
          goto label_14;
        case 4:
          goto label_1;
        default:
          goto label_6;
      }
    }
label_14:
    return;
label_6:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u202E‮⁪⁯⁯⁮‪‬​‭‫⁯‭⁭⁪⁭⁮‫⁪‪⁯⁮⁯​‌⁯‪⁬⁮​‍⁬‫‎‬⁮⁯‎⁮‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮, (object) ConfigController.AntikickConfig.Targets[index].Accounts);
    using (List<AntikickAccountData>.Enumerator enumerator = ConfigController.AntikickConfig.Targets[index].Accounts.GetEnumerator())
    {
label_13:
      int num4 = !enumerator.MoveNext() ? 781893316 : (num4 = 1640394825);
      AntikickAccountData current;
      while (true)
      {
        uint num5;
        switch ((num5 = (uint) (num4 ^ 1404294512)) % 5U)
        {
          case 0:
            num4 = 1640394825;
            continue;
          case 1:
            goto label_13;
          case 2:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u202E‪⁮‭⁬‎⁮‎‭​⁪​⁮⁫‪⁭‭⁭​⁬⁪‮‫‎‪‬‪‌‍‏‭⁯⁪‎⁪‪‭⁮⁪‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), new object[2]
            {
              (object) current.Name,
              (object) current.ChatId
            });
            num4 = (int) num5 * -232812624 ^ -665148919;
            continue;
          case 3:
            goto label_4;
          case 4:
            current = enumerator.Current;
            num4 = 87325616;
            continue;
          default:
            goto label_10;
        }
      }
label_4:
      return;
label_10:;
    }
  }

  private void \u206E⁪⁬⁭⁯‮⁫⁫‬⁮⁭‬‭⁬‎‎‮‎‮⁫⁬‬‏⁬‮⁯‌‮⁬​⁮⁪‫‎‪‫‬‍⁬‭‮(object _param1, EventArgs _param2)
  {
    if (ConfigController.AntikickConfig.AddNewTarget(new AntikickTarget(\u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮))))
      goto label_4;
label_1:
    int num1 = 692182344;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 1828387455)) % 4U)
    {
      case 0:
        goto label_1;
      case 1:
        break;
      case 3:
        return;
      default:
        \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁫‮‬‎⁮‎⁪‭‌​‫‏⁭‪⁫‎‫‍‮⁭‪⁪‫⁪‌‬‭⁭‭⁬‫‭⁮‫‭⁫⁭⁮‍‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮, \u007BZ\u003Be\u005E_\u005E\u0023.\u200F⁪‍‏‬‍⁬⁬‬‫⁯⁫‪⁬‍⁭‬‭‎⁭​‪⁪‏‭⁪‬⁫⁭⁭⁪⁪​‫⁬⁫⁬‎⁬‬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮)) - 1);
        ConfigController.AntikickConfig.Save();
        return;
    }
label_4:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‏‍‍⁫‎‮‬⁭​‫⁬‎‏‍​‌‌⁯⁪⁫‌‬‫‭‫‏‎‬‫‭​⁪​⁮‮⁫⁫‭⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮), (object) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮));
    num1 = 873668293;
    goto label_2;
  }

  private void \u206A‮⁯‫‏‬⁮‏⁮‏⁪​⁪⁮‪⁮​⁭‍‏‍‍⁯‎‌⁭⁬‍​‭‍‮‍⁫‌⁮⁮‫‭⁬‮(object _param1, EventArgs _param2)
  {
    int num1 = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E​⁬⁭‏⁬⁪⁭​‮‍‮‭‍‌‏⁯‫‫⁮⁫‌⁮‫‪‎⁫‫⁯‬‏‭‏⁯‬⁭⁭​‫‭‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮);
label_1:
    int num2 = -495962557;
    while (true)
    {
      uint num3;
      switch ((num3 = (uint) (num2 ^ -1019853209)) % 7U)
      {
        case 0:
          goto label_1;
        case 1:
          ConfigController.AntikickConfig.Save();
          num2 = (int) num3 * 1506919297 ^ -694147596;
          continue;
        case 2:
          goto label_8;
        case 3:
          ConfigController.AntikickConfig.SetChatsList(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮).Cast<string>());
          num2 = (int) num3 * -1373036055 ^ -1485147316;
          continue;
        case 4:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u206F⁯‌‏​⁪‍‍⁮‏⁪⁭​‎‭‍‪⁬‫⁯‎⁭⁫‪‍‎‬​⁪​⁯‎⁮⁪​‪‪⁯‪⁪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮), num1, (object) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮));
          num2 = -1421941359;
          continue;
        case 5:
          goto label_3;
        case 6:
          int num4 = num1 == -1 ? 1181916849 : (num4 = 1223888394);
          num2 = num4 ^ (int) num3 * 918091847;
          continue;
        default:
          goto label_9;
      }
    }
label_8:
    return;
label_3:
    return;
label_9:;
  }

  private void \u206C⁫‬⁭⁮‌⁪⁪‫‏‬‌‫‪​⁫‍‫‎‏‎​⁯⁭‎⁭‍⁭⁬‭‍‌​‫⁫‭‬‎‫‮‮(object _param1, EventArgs _param2)
  {
    int num1 = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E​⁬⁭‏⁬⁪⁭​‮‍‮‭‍‌‏⁯‫‫⁮⁫‌⁮‫‪‎⁫‫⁯‬‏‭‏⁯‬⁭⁭​‫‭‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮);
    if (num1 != -1)
      goto label_9;
label_1:
    int num2 = 1367457348;
label_2:
    while (true)
    {
      uint num3;
      switch ((num3 = (uint) (num2 ^ 836450949)) % 8U)
      {
        case 0:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202E‮⁪⁯⁯⁮‪‬​‭‫⁯‭⁭⁪⁭⁮‫⁪‪⁯⁮⁯​‌⁯‪⁬⁮​‍⁬‫‎‬⁮⁯‎⁮‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮, (object) null);
          num2 = (int) num3 * -1260447179 ^ 2040238314;
          continue;
        case 1:
          goto label_3;
        case 2:
          goto label_1;
        case 3:
          goto label_9;
        case 4:
          ConfigController.AntikickConfig.Save();
          num2 = (int) num3 * 1915699919 ^ 1286793204;
          continue;
        case 5:
          goto label_7;
        case 6:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D⁬‫‬‎‫⁯‍‮‌​‭‫‏‏⁪⁪⁪⁫‎‫​‫‎‬‏‏‪‌‎‌‪⁪‌‭⁭​⁮‮‌‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮));
          num2 = (int) num3 * 740252995 ^ -6734737;
          continue;
        case 7:
          ConfigController.AntikickConfig.SetChatsList(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮).Cast<string>());
          num2 = 2112556993;
          continue;
        default:
          goto label_10;
      }
    }
label_3:
    return;
label_7:
    return;
label_10:
    return;
label_9:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u200C‍⁮‫‭⁪‎‬⁮‮⁬‎​‍‪‭‎⁭‌‬​⁬‏‮‬‬‎‌‌​‏⁬⁮‪⁯⁬⁯⁭‬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮), num1);
    \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁫‮‬‎⁮‎⁪‭‌​‫‏⁭‪⁫‎‫‍‮⁭‪⁪‫⁪‌‬‭⁭‭⁬‫‭⁮‫‭⁫⁭⁮‍‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮, \u007BZ\u003Be\u005E_\u005E\u0023.\u200F⁪‍‏‬‍⁬⁬‬‫⁯⁫‪⁬‍⁭‬‭‎⁭​‪⁪‏‭⁪‬⁫⁭⁭⁪⁪​‫⁬⁫⁬‎⁬‬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮)) == 0 ? -1 : \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‎⁬‬⁬‏⁫‏​⁪​‍‌⁪‪​⁪‫‌⁮⁮‌‬‮⁬⁯‮‎‫‍‎‎⁬⁮‫‪‌‪‮⁪‮(0, num1 - 1));
    num2 = \u007BZ\u003Be\u005E_\u005E\u0023.\u200F⁪‍‏‬‍⁬⁬‬‫⁯⁫‪⁬‍⁭‬‭‎⁭​‪⁪‏‭⁪‬⁫⁭⁭⁪⁪​‫⁬⁫⁬‎⁬‬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮)) == 0 ? 418363627 : (num2 = 1719594058);
    goto label_2;
  }

  private void \u202B‬‮‮⁭‭‌‏‌‎​⁯‌‍⁮⁭‬⁯‍‫⁬‫​‭⁮‪‭⁬⁭‏‍‌‫​⁪⁮⁪⁬‎‮(object _param1, EventArgs _param2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u007BZ\u003Be\u005E_\u005E\u0023.\u202A⁯‫⁫⁭‬​⁮⁫⁬⁫⁮⁬⁯⁬‏⁭⁬⁭⁯‭⁯‎⁭⁪⁪⁬⁮‫⁫⁫⁫⁭⁪‌‬‫‪‬‬‮ obj = new \u007BZ\u003Be\u005E_\u005E\u0023.\u202A⁯‫⁫⁭‬​⁮⁫⁬⁫⁮⁬⁯⁬‏⁭⁬⁭⁯‭⁯‎⁭⁪⁪⁬⁮‫⁫⁫⁫⁭⁪‌‬‫‪‬‬‮();
    // ISSUE: reference to a compiler-generated field
    obj.\u206F⁬‭‬⁬⁪⁮⁭⁮‬​⁭​⁪⁫‫‮‍​⁫‫‪‍‮‬⁫‏‌​‎‍⁪‫​​‌⁮⁪‪‫‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮);
label_1:
    int num1 = 1724114591;
    List<AntikickAccountData> source;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 565740362)) % 4U)
      {
        case 1:
          source = (List<AntikickAccountData>) \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
          int num3 = source != null ? -1762166026 : (num3 = -193265455);
          num1 = num3 ^ (int) num2 * -434486360;
          continue;
        case 2:
          goto label_1;
        case 3:
          goto label_19;
        default:
          goto label_5;
      }
    }
label_19:
    return;
label_5:
    List<AntikickAccountData> antikickAccountDataList = source;
    bool flag = false;
    try
    {
      \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‎‎⁯⁫‎‎‏‪​‭‫‭⁮⁬⁯⁭‮‫⁮‭⁪⁮‍‬‮‏⁭‎‌⁬‭‌‍‍⁭‎‬⁭‮‮((object) antikickAccountDataList, ref flag);
label_7:
      int num4 = 1633960145;
      while (true)
      {
        uint num5;
        switch ((num5 = (uint) (num4 ^ 565740362)) % 8U)
        {
          case 0:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u202E‪⁮‭⁬‎⁮‎‭​⁪​⁮⁫‪⁭‭⁭​⁬⁪‮‫‎‪‬‪‌‍‏‭⁯⁪‎⁪‪‭⁮⁪‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), new object[2]
            {
              (object) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮),
              null
            });
            num4 = (int) num5 * 263819247 ^ 1180269399;
            continue;
          case 1:
            // ISSUE: reference to a compiler-generated field
            source.Add(new AntikickAccountData(obj.\u206F⁬‭‬⁬⁪⁮⁭⁮‬​⁭​⁪⁫‫‮‍​⁫‫‪‍‮‬⁫‏‌​‎‍⁪‫​​‌⁮⁪‪‫‮));
            num4 = 281631842;
            continue;
          case 2:
            goto label_4;
          case 3:
            int num6 = source.Count <= 20 ? -1312268850 : (num6 = -1571018624);
            num4 = num6 ^ (int) num5 * 66298888;
            continue;
          case 4:
            // ISSUE: reference to a compiler-generated method
            int num7 = source.Where<AntikickAccountData>(new Func<AntikickAccountData, bool>(obj.\u202E⁫‍⁬‌‭‪‬⁫‬‮‍‮⁫‬‫⁯⁯⁪⁬‪‍‍‎‪‏‏‮‪‭‭‍⁬‭‌‭​⁮‭‪‮)).Any<AntikickAccountData>() ? -1939607428 : (num7 = -588843625);
            num4 = num7 ^ (int) num5 * -2120800417;
            continue;
          case 5:
            ConfigController.AntikickConfig.Save();
            num4 = (int) num5 * -1415591825 ^ 376632823;
            continue;
          case 6:
            goto label_15;
          case 7:
            goto label_7;
          default:
            goto label_12;
        }
      }
label_4:
      return;
label_15:
      return;
label_12:;
    }
    finally
    {
      if (flag)
      {
label_17:
        int num8 = 1706002345;
        while (true)
        {
          uint num9;
          switch ((num9 = (uint) (num8 ^ 565740362)) % 3U)
          {
            case 1:
              \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‭‬⁯‮​​⁫‮‮‪‬⁭‫⁫‌⁫‫⁭‍‫⁭‮⁮⁪‫⁯⁮‍⁫⁪​‪‫‮‌‌‎⁮‮((object) antikickAccountDataList);
              num8 = (int) num9 * 1773165497 ^ -252162698;
              continue;
            case 2:
              goto label_17;
            default:
              goto label_21;
          }
        }
      }
label_21:;
    }
  }

  private void \u200D⁬⁮​‬⁮⁮‮⁮​‏‎⁪‌⁭⁪⁯⁬‭‮‍‍‌‎⁬‮‭⁯⁯‫‮‍⁫‍‎‭‫‬‍‏‮(object _param1, EventArgs _param2)
  {
    int index = \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‎⁯‭‫‪⁯‫‪‌‌⁯‎⁬⁭‎‬‎⁯‪​‪⁮⁫⁮⁬⁪‏‮‎‭‌‭‏‭‍⁪‏⁮⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), DataGridViewElementStates.Selected);
    if (index != -1)
      goto label_5;
label_1:
    int num1 = -822133220;
label_2:
    List<AntikickAccountData> antikickAccountDataList1;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -69575023)) % 6U)
      {
        case 0:
          goto label_5;
        case 1:
          goto label_17;
        case 2:
          goto label_1;
        case 3:
          goto label_3;
        case 4:
          int num3 = antikickAccountDataList1 != null ? 1594608086 : (num3 = 276256226);
          num1 = num3 ^ (int) num2 * 764654893;
          continue;
        default:
          goto label_7;
      }
    }
label_17:
    return;
label_3:
    return;
label_7:
    List<AntikickAccountData> antikickAccountDataList2 = antikickAccountDataList1;
    bool flag = false;
    try
    {
      \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‎‎⁯⁫‎‎‏‪​‭‫‭⁮⁬⁯⁭‮‫⁮‭⁪⁮‍‬‮‏⁭‎‌⁬‭‌‍‍⁭‎‬⁭‮‮((object) antikickAccountDataList2, ref flag);
label_9:
      int num4 = -649706757;
      while (true)
      {
        uint num5;
        switch ((num5 = (uint) (num4 ^ -69575023)) % 4U)
        {
          case 0:
            goto label_9;
          case 1:
            goto label_6;
          case 2:
            antikickAccountDataList1[index].Name = \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮);
            num4 = (int) num5 * 134347961 ^ -1522633640;
            continue;
          case 3:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‍‏‌⁮⁭⁭⁪‪⁯⁫‮‮‮​​‌⁪⁬⁪‪‬​‏‌‪‎⁮⁫‍⁯‭⁬‎⁯⁫‏⁬‫⁭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), index)), 0), (object) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮));
            ConfigController.AntikickConfig.Save();
            num4 = (int) num5 * -1701867239 ^ -2060096529;
            continue;
          default:
            goto label_13;
        }
      }
label_6:
      return;
label_13:
      return;
    }
    finally
    {
      if (flag)
      {
label_15:
        int num6 = -1561696208;
        while (true)
        {
          uint num7;
          switch ((num7 = (uint) (num6 ^ -69575023)) % 3U)
          {
            case 0:
              goto label_15;
            case 1:
              \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‭‬⁯‮​​⁫‮‮‪‬⁭‫⁫‌⁫‫⁭‍‫⁭‮⁮⁪‫⁯⁮‍⁫⁪​‪‫‮‌‌‎⁮‮((object) antikickAccountDataList2);
              num6 = (int) num7 * 1082213137 ^ -334965212;
              continue;
            default:
              goto label_19;
          }
        }
      }
label_19:;
    }
label_5:
    antikickAccountDataList1 = (List<AntikickAccountData>) \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
    num1 = -580799861;
    goto label_2;
  }

  private void \u200F⁫⁮‎‏‬‌‌‌‫⁯‎‮​⁮‮⁮‌‪‭‬‭‏‏⁬⁭‌‮‭⁯‫‬‍‏⁭‏⁬⁫​‌‮(object _param1, EventArgs _param2)
  {
    int index = \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‎⁯‭‫‪⁯‫‪‌‌⁯‎⁬⁭‎‬‎⁯‪​‪⁮⁫⁮⁬⁪‏‮‎‭‌‭‏‭‍⁪‏⁮⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), DataGridViewElementStates.Selected);
label_1:
    int num1 = 353203111;
    List<AntikickAccountData> antikickAccountDataList1;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 259412636)) % 6U)
      {
        case 1:
          int num3 = index != -1 ? 1493896615 : (num3 = 570839442);
          num1 = num3 ^ (int) num2 * 1121080022;
          continue;
        case 2:
          goto label_24;
        case 3:
          antikickAccountDataList1 = (List<AntikickAccountData>) \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
          int num4;
          num1 = num4 = antikickAccountDataList1 != null ? 1427492226 : (num4 = 1579963531);
          continue;
        case 4:
          goto label_1;
        case 5:
          goto label_4;
        default:
          goto label_6;
      }
    }
label_24:
    return;
label_4:
    return;
label_6:
    List<AntikickAccountData> antikickAccountDataList2 = antikickAccountDataList1;
    bool flag = false;
    try
    {
      \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‎‎⁯⁫‎‎‏‪​‭‫‭⁮⁬⁯⁭‮‫⁮‭⁪⁮‍‬‮‏⁭‎‌⁬‭‌‍‍⁭‎‬⁭‮‮((object) antikickAccountDataList2, ref flag);
label_8:
      int num5 = 1236241376;
      while (true)
      {
        uint num6;
        int num7;
        int num8;
        switch ((num6 = (uint) (num5 ^ 259412636)) % 9U)
        {
          case 0:
            num8 = \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‎⁬‬⁬‏⁫‏​⁪​‍‌⁪‪​⁪‫‌⁮⁮‌‬‮⁬⁯‮‎‫‍‎‎⁬⁮‫‪‌‪‮⁪‮(0, index - 1);
            break;
          case 1:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u200D‌‫‮⁬⁯⁪‬‮‭‌⁫⁫⁪‎‪⁮‬‬‏⁯⁪‪⁪‍‌‫‪‪⁪⁬⁮⁯⁪⁮​⁪⁮⁯‪‮((DataGridViewBand) \u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), num7), true);
            num5 = (int) num6 * 2018712680 ^ 1408075850;
            continue;
          case 2:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u206A‎‏‍‍‎‫⁬⁬‎⁬⁮‍⁯‎‪‪‪‎⁪‬‏⁫⁭⁯⁭‫‪⁯‫‮‫​‍⁬⁫‏⁬⁭‍‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), index);
            num5 = (int) num6 * 1027975753 ^ -1670138123;
            continue;
          case 3:
            goto label_8;
          case 4:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u206E⁭‌‪‏​⁫‏‏‬⁯‏‎‭⁪‎‌‪‫⁭‍‮‏⁮‏‏‪‪⁮‌‪‌⁯⁪‎⁪‮⁯⁮‎‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
            num5 = (int) num6 * -572933840 ^ -1179996075;
            continue;
          case 6:
            if (\u007BZ\u003Be\u005E_\u005E\u0023.\u206D‮‫⁯‪‬‭⁪⁬⁬‌‮⁭‍‎‍⁪‮‮⁪‮⁫​⁬⁫‎⁭⁫‮⁬‍‬⁬‬⁪⁯‏⁯‪⁪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮)) == 0)
            {
              num8 = -1;
              break;
            }
            num5 = (int) num6 * -639389860 ^ 239276712;
            continue;
          case 7:
            antikickAccountDataList1.RemoveAt(index);
            num5 = (int) num6 * -2019516040 ^ -33673223;
            continue;
          case 8:
            int num9 = num7 == -1 ? -1592035657 : (num9 = -1648481180);
            num5 = num9 ^ (int) num6 * -526856819;
            continue;
          default:
            goto label_20;
        }
        num7 = num8;
        num5 = 1580503125;
      }
label_20:
      ConfigController.AntikickConfig.Save();
    }
    finally
    {
      if (flag)
      {
label_22:
        int num10 = 35729499;
        while (true)
        {
          uint num11;
          switch ((num11 = (uint) (num10 ^ 259412636)) % 3U)
          {
            case 1:
              \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‭‬⁯‮​​⁫‮‮‪‬⁭‫⁫‌⁫‫⁭‍‫⁭‮⁮⁪‫⁯⁮‍⁫⁪​‪‫‮‌‌‎⁮‮((object) antikickAccountDataList2);
              num10 = (int) num11 * -1143777943 ^ 1114102693;
              continue;
            case 2:
              goto label_22;
            default:
              goto label_26;
          }
        }
      }
label_26:;
    }
  }

  private void \u202B‪⁭‪‫⁫‫‪⁬⁭⁭⁭⁪⁫⁪‌⁮‏‬‫⁮⁮‏⁮⁯‫⁬⁪‍⁯‏‎‍‮​​‭‭⁫⁮‮(object _param1, EventArgs _param2)
  {
    ConfigController.AntikickConfig.LeavedIntentionallyFrom = new ConcurrentDictionary<string, List<long>>();
    if (\u007BZ\u003Be\u005E_\u005E\u0023.\u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮ == null)
      goto label_3;
label_1:
    int num1 = 1355598979;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1697019561)) % 7U)
      {
        case 0:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D‪⁫​⁮‭‫‬⁬⁯‫‪‫‮‫‪‎⁪‎‫⁯‌⁭‮⁯‭‮‌‮‬‬‌‬‎‌‫‌⁬⁯‍‮((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(763423136U));
          num1 = (int) num2 * -1161519861 ^ 827438062;
          continue;
        case 1:
          goto label_3;
        case 3:
          goto label_6;
        case 4:
          goto label_5;
        case 5:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮.Dispose();
          num1 = (int) num2 * 810622224 ^ -861809128;
          continue;
        case 6:
          goto label_1;
        default:
          goto label_8;
      }
    }
label_5:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮ = (\u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮) null;
    return;
label_6:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(820397236U));
    return;
label_8:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u202D‪⁫​⁮‭‫‬⁬⁯‫‪‫‮‫‪‎⁪‎‫⁯‌⁭‮⁯‭‮‌‮‬‬‌‬‎‌‫‌⁬⁯‍‮((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(293833937U));
    \u007BZ\u003Be\u005E_\u005E\u0023.\u200D‭‭‏‫‪⁮‍‭⁯⁪⁮⁭‪⁪‫⁯‌‏‎‍⁮‭⁮⁫‪‌⁬‏‎⁬‌⁫‏‪‫‪‭‬⁪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D⁫​‌‬‬‏⁬‌⁬‎‍‭‎⁫⁯‬⁬‭​⁪⁭⁯​⁬‭‭‎‭‬⁫‮‮⁭‎⁭‌‌‍⁪‮(new Action(\u007BZ\u003Be\u005E_\u005E\u0023.\u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮)));
    return;
label_3:
    num1 = ConfigController.AntikickConfig.Targets.Count == 0 ? 1621984673 : (num1 = 35604013);
    goto label_2;
  }

  private void \u202E⁯‫‭‏‏‌⁯‏⁪⁬⁫⁬​⁪‍‬‪⁯‭⁪‌⁬⁫‌‬‭‪‭⁭‍‪⁫‭⁪⁮⁫⁫⁭⁫‮(object _param1, EventArgs _param2)
  {
    ConfigController.AntikickConfig.Delay = (int) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‬‭‫‪‪‬‮⁬⁫⁯⁮​‏‭‫‎‏⁬⁭‮⁪‭‮⁬⁪‎‪‎⁯⁫‍⁫‍​⁫⁮‍⁬‍‮(this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮);
    ConfigController.AntikickConfig.Save();
  }

  private void \u200F⁪⁬⁮⁬‏‬‮‬⁪‪‮⁪‎‭⁮⁭‌⁫⁮‌‎⁫‎⁮‍⁪‌⁮‪⁯‪‭⁮‎‎‍⁭⁮‮(object _param1, EventArgs _param2)
  {
    ConfigController.AntikickConfig.Validate();
label_1:
    int num1 = 1013252934;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 60613829)) % 6U)
      {
        case 0:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D‫‎‪⁫‪‮‪‭‌‍‏‬⁯⁮⁯‌‭​‎‮⁫⁯‎⁫‎​⁪‎‌‍‫‭‫‌⁫‏‌⁭‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁬‪‮‬‍⁮‭‪‫⁬⁮​⁭⁬⁪‬​⁭‍‌‪‎‬⁯‌‪‫‏⁮‮‪‬‬‪‭⁫​⁯‭‮(this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮));
          num1 = (int) num2 * 788744406 ^ -1577776101;
          continue;
        case 1:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁫‮‬‎⁮‎⁪‭‌​‫‏⁭‪⁫‎‫‍‮⁭‪⁪‫⁪‌‬‭⁭‭⁬‫‭⁮‫‭⁫⁭⁮‍‮((ListControl) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮, 0);
          num1 = (int) num2 * -122165435 ^ -1575551120;
          continue;
        case 2:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202C‫‍⁬‌⁫‫⁬‬‏⁪⁭​‬‏‏⁮‏⁫⁪‏‎‮‪‭⁮‏‪‫‍⁯⁯​‬⁮⁯⁪⁫⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁬‪‮‬‍⁮‭‪‫⁬⁮​⁭⁬⁪‬​⁭‍‌‪‎‬⁯‌‪‫‏⁮‮‪‬‬‪‭⁫​⁯‭‮(this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮), ((IEnumerable<object>) AccountsManager.GetAccountsList()).ToArray<object>());
          int num3 = \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‌⁮⁫‌⁭⁬⁬⁪⁫‮‎‬‭⁭⁬​‭‭‪⁯⁫⁬​​​⁬‍⁪‬‬‏‭​‫‬‍‭⁯‬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁬‪‮‬‍⁮‭‪‫⁬⁮​⁭⁬⁪‬​⁭‍‌‪‎‬⁯‌‪‫‏⁮‮‪‬‬‪‭⁫​⁯‭‮(this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮)) != 0 ? -528132040 : (num3 = -1133659327);
          num1 = num3 ^ (int) num2 * 749915433;
          continue;
        case 3:
          goto label_1;
        case 5:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u206C‌‫​⁮‬‬‍‮⁮‬‎⁬‫​⁮‪⁭‎‌‌‬⁫‮‌⁯⁮‮‮⁫‏‬⁯‌⁪‏⁬⁮⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮));
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D⁬‫‬‎‫⁯‍‮‌​‭‫‏‏⁪⁪⁪⁫‎‫​‫‎‬‏‏‪‌‎‌‪⁪‌‭⁭​⁮‮‌‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮));
          num1 = (int) num2 * -290319973 ^ 193077324;
          continue;
        default:
          goto label_7;
      }
    }
label_7:
    using (List<AntikickTarget>.Enumerator enumerator = ConfigController.AntikickConfig.Targets.GetEnumerator())
    {
label_12:
      int num4 = !enumerator.MoveNext() ? 1558620625 : (num4 = 940049656);
      while (true)
      {
        uint num5;
        switch ((num5 = (uint) (num4 ^ 60613829)) % 4U)
        {
          case 1:
            AntikickTarget current = enumerator.Current;
            \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‏‍‍⁫‎‮‬⁭​‫⁬‎‏‍​‌‌⁯⁪⁫‌‬‫‭‫‏‎‬‫‭​⁪​⁮‮⁫⁫‭⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮), (object) current.Name);
            num4 = 1041346130;
            continue;
          case 2:
            num4 = 940049656;
            continue;
          case 3:
            goto label_12;
          default:
            goto label_14;
        }
      }
    }
label_14:
    if (\u007BZ\u003Be\u005E_\u005E\u0023.\u200F⁪‍‏‬‍⁬⁬‬‫⁯⁫‪⁬‍⁭‬‭‎⁭​‪⁪‏‭⁪‬⁫⁭⁭⁪⁪​‫⁬⁫⁬‎⁬‬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮(this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮)) != 0)
    {
label_15:
      int num6 = 3209278;
      while (true)
      {
        uint num7;
        switch ((num7 = (uint) (num6 ^ 60613829)) % 3U)
        {
          case 0:
            goto label_15;
          case 1:
            \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁫‮‬‎⁮‎⁪‭‌​‫‏⁭‪⁫‎‫‍‮⁭‪⁪‫⁪‌‬‭⁭‭⁬‫‭⁮‫‭⁫⁭⁮‍‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮, 0);
            num6 = (int) num7 * 949837245 ^ -79542462;
            continue;
          default:
            goto label_18;
        }
      }
    }
label_18:
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206A⁭‪⁮​‎‭⁭‭‌⁫‭‭⁯⁭⁮‫⁭⁪‌‍⁯‫⁬‎‎⁭⁯‪⁫‌⁫‮⁯‮⁭⁫‏​⁫‮(this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮, (Decimal) ConfigController.AntikickConfig.Delay);
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206A⁭‪⁮​‎‭⁭‭‌⁫‭‭⁯⁭⁮‫⁭⁪‌‍⁯‫⁬‎‎⁭⁯‪⁫‌⁫‮⁯‮⁭⁫‏​⁫‮(this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮, (Decimal) ConfigController.AntikickConfig.PartialRejoinDelay);
  }

  private void \u202A⁮‌⁪‭‍⁬‮⁯‫‫⁯‫⁮‬⁬⁮‎⁭⁬‫‎⁬‬‮‮‭⁯​‬⁪​⁪​⁬‮‬​‬⁮‮(
    object _param1,
    FormClosedEventArgs _param2)
  {
    \u007BZ\u003Be\u005E_\u005E\u0023.\u206A‪‮⁯‫‮⁭​​‬⁮⁪⁫​​‪⁫‮⁯⁪⁯‪⁪‫‎⁫‍⁫​‬⁬‌‍‬‪‌‮‪⁮‎‮?.Dispose();
  }

  private void \u200F‬⁪‍⁯⁬⁮​⁯​⁮‭‍‌‬‮‏‬‫⁯‌‮‏‎‌⁯⁪‭‪⁪⁬‌​⁮‪⁭⁬⁪‎⁫‮(object _param1, EventArgs _param2)
  {
    int num1 = \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‎⁯‭‫‪⁯‫‪‌‌⁯‎⁬⁭‎‬‎⁯‪​‪⁮⁫⁮⁬⁪‏‮‎‭‌‭‏‭‍⁪‏⁮⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), DataGridViewElementStates.Selected);
label_1:
    int num2 = -294074328;
    while (true)
    {
      uint num3;
      switch ((num3 = (uint) (num2 ^ -1842168604)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D‪⁫​⁮‭‫‬⁬⁯‫‪‫‮‫‪‎⁪‎‫⁯‌⁭‮⁯‭‮‌‮‬‬‌‬‎‌‫‌⁬⁯‍‮((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮, \u007BZ\u003Be\u005E_\u005E\u0023.\u206F⁪‮‏⁬‫⁭‬‫⁮​​‮⁫⁬‭‮‍⁭​⁭‮⁬⁬​‎⁪⁬‌‬⁯⁪⁮⁮⁮⁬‏‮‬⁪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202C⁪‮⁫⁪‎⁭⁫‬⁯⁮‍‮⁮‍⁬​‪‫⁮‪‍‌‎⁪​‌‏‏‎‏‭⁬⁬​⁯⁭⁫⁯⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), num1)), 0))));
          num2 = -2018947266;
          continue;
        case 2:
          goto label_5;
        case 3:
          int num4 = num1 == -1 ? 161543170 : (num4 = 472136439);
          num2 = num4 ^ (int) num3 * 879552740;
          continue;
        case 4:
          goto label_1;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_5:
    return;
label_7:;
  }

  private void \u200B⁯⁯‫‍​‍⁪‬⁬‮‎⁫⁪‭‪‬‌⁮⁯⁪⁮⁭‫‏‌⁪‫⁫⁭‮‬‮‮⁬‬⁬‬⁯⁬‮(
    object _param1,
    DataGridViewRowsAddedEventArgs _param2)
  {
    int index1 = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E​⁬⁭‏⁬⁪⁭​‮‍‮‭‍‌‏⁯‫‫⁮⁫‌⁮‫‪‎⁫‫⁯‬‏‭‏⁯‬⁭⁭​‫‭‮((ListControl) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮);
label_1:
    int num1 = 392509060;
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ obj;
    int index2;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1947917222)) % 11U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          ((List<AntikickAccountData>) \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮))[index2].ChatId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = (int) num2 * -158140339 ^ -469946227;
          continue;
        case 3:
          index2 = \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‍‪⁬‪‬⁮‮⁮‮‮⁪‪⁬‮⁪⁫‏‏‬⁭‫‬‍‭⁬⁫‎⁫⁪‭⁯​⁫‏‍⁮‍‬‏‮(_param2);
          int num3;
          num1 = num3 = \u007BZ\u003Be\u005E_\u005E\u0023.\u202C⁪‮⁫⁪‎⁭⁫‬⁯⁮‍‮⁮‍⁬​‪‫⁮‪‍‌‎⁪​‌‏‏‎‏‭⁬⁬​⁯⁭⁫⁯⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), index2)), 1)) != null ? 1583371919 : (num3 = 1555238713);
          continue;
        case 4:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‍‏‌⁮⁭⁭⁪‪⁯⁫‮‮‮​​‌⁪⁬⁪‪‬​‏‌‪‎⁮⁫‍⁯‭⁬‎⁯⁫‏⁬‫⁭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), index2)), 1), (object) obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮);
          num1 = (int) num2 * -606387762 ^ 1049963478;
          continue;
        case 5:
          goto label_8;
        case 6:
          int num4 = obj.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ == \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat ? -2075382106 : (num4 = -193553549);
          num1 = num4 ^ (int) num2 * -730379740;
          continue;
        case 7:
          int num5 = index1 == -1 ? 1902935309 : (num5 = 1238301165);
          num1 = num5 ^ (int) num2 * -536425683;
          continue;
        case 8:
          Account account = AccountsManager.GetAccount(\u007BZ\u003Be\u005E_\u005E\u0023.\u202C⁪‮⁫⁪‎⁭⁫‬⁯⁮‍‮⁮‍⁬​‪‫⁮‪‍‌‎⁪​‌‏‏‎‏‭⁬⁬​⁯⁭⁫⁯⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), index2)), 0)) as string);
          string name = ConfigController.AntikickConfig.Targets[index1].Name;
          string str = \u007BZ\u003Be\u005E_\u005E\u0023.\u206B‏‌‮⁬‬⁯⁭‭‌⁯‫⁪​⁯‬⁮​⁬⁪‏⁮‌‎⁪‍‎⁪​⁬‍‫⁫‪⁭⁬​⁫⁬⁯‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1169049722U), name);
          obj = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(account, str);
          num1 = 530880305;
          continue;
        case 9:
          goto label_6;
        case 10:
          ConfigController.AntikickConfig.Save();
          num1 = (int) num2 * 1353024640 ^ 1737995727;
          continue;
        default:
          goto label_13;
      }
    }
label_3:
    return;
label_8:
    return;
label_6:
    return;
label_13:;
  }

  private void \u206C⁯‬⁫​‭⁫‬‏⁬​⁬‌⁯‭‫​⁪​⁫‮⁮⁯‎‪‮⁫‫‏‭⁬‭‪‫‏‍‏⁭‬‌‮(
    object _param1,
    DataGridViewCellEventArgs _param2)
  {
    List<AntikickAccountData> antikickAccountDataList = (List<AntikickAccountData>) \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
label_1:
    int num1 = 1547476257;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1925023723)) % 4U)
      {
        case 1:
          goto label_3;
        case 2:
          int num3 = antikickAccountDataList != null ? -8356361 : (num3 = -1229240762);
          num1 = num3 ^ (int) num2 * 1700079672;
          continue;
        case 3:
          goto label_1;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:
    AntikickAccountData antikickAccountData = antikickAccountDataList[\u007BZ\u003Be\u005E_\u005E\u0023.\u206E‭⁭‫⁫‌‏‭‏‮⁯⁪‏‌⁮‎⁪⁯‌‎⁬⁪‬⁭‏‬‏⁯‎‭‎⁭‬‮‬‎‫‌⁪‌‮(_param2)];
    int? nullable1 = \u007BZ\u003Be\u005E_\u005E\u0023.\u202C⁪‮⁫⁪‎⁭⁫‬⁯⁮‍‮⁮‍⁬​‪‫⁮‪‍‌‎⁪​‌‏‏‎‏‭⁬⁬​⁯⁭⁫⁯⁬‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(\u007BZ\u003Be\u005E_\u005E\u0023.\u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮(this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮), \u007BZ\u003Be\u005E_\u005E\u0023.\u206E‭⁭‫⁫‌‏‭‏‮⁯⁪‏‌⁮‎⁪⁯‌‎⁬⁪‬⁭‏‬‏⁯‎‭‎⁭‬‮‬‎‫‌⁪‌‮(_param2))), 1)) as int?;
    long? nullable2 = nullable1.HasValue ? new long?((long) nullable1.GetValueOrDefault()) : new long?();
    antikickAccountData.ChatId = nullable2;
    ConfigController.AntikickConfig.Save();
  }

  private void \u206A⁯‏‍‍⁬⁮‬⁭‍⁪‎‮⁭‏‎⁯⁫⁮⁬⁭‮⁯‭⁬‬⁯‍‪‍‎‍⁮‪⁬‎‎⁪‫⁭‮(object _param1, EventArgs _param2)
  {
    ConfigController.AntikickConfig.PartialRejoinDelay = (int) \u007BZ\u003Be\u005E_\u005E\u0023.\u200E‬‭‫‪‪‬‮⁬⁫⁯⁮​‏‭‫‎‏⁬⁭‮⁪‭‮⁬⁪‎‪‎⁯⁫‍⁫‍​⁫⁮‍⁬‍‮(this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮);
label_1:
    int num1 = -1618231397;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -648552251)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          ConfigController.AntikickConfig.Save();
          num1 = (int) num2 * -758631394 ^ 721579882;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  virtual void Form.\u202D⁫⁫‍‭​⁪‌‫⁬‎⁮‭‌⁬‌‫‎‭‮‍‭⁫‬‭⁬‪⁪⁪‌⁮⁮‏‭⁯⁬⁮⁬‮‌‮(bool _param1)
  {
    if (!_param1)
      goto label_6;
label_1:
    int num1 = -1265426128;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1919671891)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          int num3 = this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮ == null ? -1240214124 : (num3 = -1405682665);
          num1 = num3 ^ (int) num2 * 1180329038;
          continue;
        case 2:
          goto label_6;
        case 3:
          goto label_1;
        case 4:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202B‬‭‬‏‌‏⁪⁪‎⁭‌‪⁫⁭‭‏⁬‎⁬‬‬⁭‌​⁯​‪⁫‫⁪‮‫‎‌‭⁭‎⁪‮((IDisposable) this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          num1 = (int) num2 * -763140058 ^ -121785782;
          continue;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_7:
    return;
label_6:
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(_param1));
    num1 = -2060936489;
    goto label_2;
  }

  private void \u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮()
  {
    this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
label_1:
    int num1 = -1546998395;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1569584245)) % 136U)
      {
        case 0:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u202D⁮⁯‍‪⁭⁬⁭⁮⁯‌‏‪‪​‌⁭⁬⁭⁬‬⁬‪‫‌‬‮‫‭⁮‫⁪⁪⁬⁮⁮‌‎‮⁭‮((Control) this);
          num1 = (int) num2 * -2138134291 ^ 1399668347;
          continue;
        case 1:
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Maximum = new Decimal(new int[4]
          {
            1000000000,
            0,
            0,
            0
          });
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(308976439U);
          num1 = (int) num2 * -807517190 ^ -488678256;
          continue;
        case 2:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.TabIndex = 46;
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(763423136U);
          num1 = (int) num2 * -1360882477 ^ -1526537157;
          continue;
        case 3:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.TabIndex = 44;
          num1 = (int) num2 * -1394067447 ^ -475695367;
          continue;
        case 4:
          this.Controls.Add((Control) this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮);
          num1 = (int) num2 * 1007130115 ^ 1101339130;
          continue;
        case 5:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2680088457U);
          num1 = (int) num2 * -1090445076 ^ 467602658;
          continue;
        case 6:
          this.Controls.Add((Control) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
          this.Controls.Add((Control) this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮);
          this.Controls.Add((Control) this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮);
          num1 = (int) num2 * 481169880 ^ 391548392;
          continue;
        case 7:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.TabIndex = 49;
          num1 = (int) num2 * 409014352 ^ 1894619202;
          continue;
        case 8:
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.SelectedIndexChanged += new EventHandler(this.\u200B‏​‫⁮‫⁯⁫‍‮⁬‬‍‮⁭‎⁭‏‏‭⁪​‍‬⁫‎⁬⁬‬‌‫‪‏‎⁪‎‮‭⁯‮);
          num1 = (int) num2 * 1822769715 ^ -1098665152;
          continue;
        case 9:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.TabIndex = 42;
          num1 = (int) num2 * -2054873625 ^ 1931453564;
          continue;
        case 10:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -1256273431 ^ -706101989;
          continue;
        case 11:
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.Size = new Size(92, 26);
          num1 = (int) num2 * -1991483357 ^ 513908676;
          continue;
        case 12:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          num1 = (int) num2 * 413155164 ^ 502856964;
          continue;
        case 13:
          ((ISupportInitialize) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮).EndInit();
          num1 = (int) num2 * -1475368361 ^ -2060357389;
          continue;
        case 14:
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.TabIndex = 37;
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1099642758U);
          num1 = (int) num2 * 1750391393 ^ 381598643;
          continue;
        case 15:
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1242272740U);
          num1 = (int) num2 * -90639144 ^ 1886847136;
          continue;
        case 16 /*0x10*/:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.Size = new Size(92, 26);
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.TabIndex = 36;
          num1 = (int) num2 * -1025361969 ^ -1697841477;
          continue;
        case 17:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(583594080U);
          num1 = (int) num2 * -481243643 ^ 2107628866;
          continue;
        case 18:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.Click += new EventHandler(this.\u206E⁪⁬⁭⁯‮⁫⁫‬⁮⁭‬‭⁬‎‎‮‎‮⁫⁬‬‏⁬‮⁯‌‮⁬​⁮⁪‫‎‪‫‬‍⁬‭‮);
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮.Location = new Point(15, 301);
          num1 = (int) num2 * 521238497 ^ -53724745;
          continue;
        case 19:
          this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2956717965U);
          num1 = (int) num2 * 1776659846 ^ -734688724;
          continue;
        case 20:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Click += new EventHandler(this.\u202B‪⁭‪‫⁫‫‪⁬⁭⁭⁭⁪⁫⁪‌⁮‏‬‫⁮⁮‏⁮⁯‫⁬⁪‍⁯‏‎‍‮​​‭‭⁫⁮‮);
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.BackColor = Color.WhiteSmoke;
          num1 = (int) num2 * 875449883 ^ -1353932352;
          continue;
        case 21:
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.TabIndex = 34;
          num1 = (int) num2 * -1260780558 ^ -1266377738;
          continue;
        case 22:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Size = new Size(22, 13);
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.TabIndex = 48 /*0x30*/;
          num1 = (int) num2 * -1079740770 ^ 374309375;
          continue;
        case 23:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Minimum = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 701458310 ^ -718477544;
          continue;
        case 24:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.AllowUserToDeleteRows = false;
          num1 = (int) num2 * 1367102512 ^ 190597943;
          continue;
        case 25:
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.TabIndex = 32 /*0x20*/;
          num1 = (int) num2 * 1717962094 ^ 902943285;
          continue;
        case 26:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.Click += new EventHandler(this.\u206C⁫‬⁭⁮‌⁪⁪‫‏‬‌‫‪​⁫‍‫‎‏‎​⁯⁭‎⁭‍⁭⁬‭‍‌​‫⁫‭‬‎‫‮‮);
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * -1177313588 ^ 71787605;
          continue;
        case 27:
          this.Shown += new EventHandler(this.\u200F⁪⁬⁮⁬‏‬‮‬⁪‪‮⁪‎‭⁮⁭‌⁫⁮‌‎⁫‎⁮‍⁪‌⁮‪⁯‪‭⁮‎‎‍⁭⁮‮);
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.EndInit();
          num1 = (int) num2 * -1302944988 ^ -1799310046;
          continue;
        case 28:
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2096097399U);
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.Size = new Size(182, 13);
          num1 = (int) num2 * 1661214005 ^ 108313650;
          continue;
        case 29:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Location = new Point(281, 400);
          num1 = (int) num2 * -504797125 ^ 784021385;
          continue;
        case 30:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * 1845609379 ^ -1752911987;
          continue;
        case 31 /*0x1F*/:
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮.Location = new Point(337, 334);
          num1 = (int) num2 * 854544381 ^ -1979154534;
          continue;
        case 32 /*0x20*/:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Location = new Point(12, 369);
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1745674976U);
          num1 = (int) num2 * 541410166 ^ 1402812361;
          continue;
        case 33:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.SelectionChanged += new EventHandler(this.\u200F‬⁪‍⁯⁬⁮​⁯​⁮‭‍‌‬‮‏‬‫⁯‌‮‏‎‌⁯⁪‭‪⁪⁬‌​⁮‪⁭⁬⁪‎⁫‮);
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.HeaderText = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2956717965U);
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4102481138U);
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.ReadOnly = true;
          num1 = (int) num2 * -1734640204 ^ 887144965;
          continue;
        case 34:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2871301248U);
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Size = new Size(288, 26);
          num1 = (int) num2 * 957215078 ^ -704883387;
          continue;
        case 35:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u200F⁯‌‬‮‌‪⁮‎‍⁪‍⁫‍⁬⁪‪⁯‎‌‍‮‮‍‮‎⁮⁫‫‏⁯⁬‎‫⁭‭⁭⁫⁯‭‮();
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D‮⁯‪‭‍⁯⁫‬⁯‍⁭‏‮⁬‫‏⁭​⁮⁫⁯​‬⁪⁫⁯‮⁪⁪‏⁪‌‫‍​‫⁯‭‍‮();
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D‮⁯‪‭‍⁯⁫‬⁯‍⁭‏‮⁬‫‏⁭​⁮⁫⁯​‬⁪⁫⁯‮⁪⁪‏⁪‌‫‍​‫⁯‭‍‮();
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D‪‎‪‎‎⁯⁪‏‎⁬​⁯‮⁫‍‎⁬‫⁯⁯‏⁭‌⁫⁮‏‭​‎‏⁭⁪‬​‍⁪‌⁭⁫‮();
          \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‬⁮‮‬⁬⁬‭⁫⁭‍⁯⁮⁪‫⁬⁭‬​⁫‮⁬⁫⁪‌⁭‭‮‬‭⁯‮‎⁭‬‏⁪⁪‍⁪‮((ISupportInitialize) this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮);
          num1 = (int) num2 * -1641305962 ^ 223160917;
          continue;
        case 36:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.AllowUserToAddRows = false;
          num1 = (int) num2 * -33377791 ^ -226280977;
          continue;
        case 37:
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.Width = 70;
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.AutoSize = true;
          num1 = (int) num2 * 1878213998 ^ -1647946379;
          continue;
        case 38:
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.Location = new Point(113, 327);
          num1 = (int) num2 * -557061053 ^ -698657835;
          continue;
        case 39:
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206F‪‌⁯‍‬‏‬‎‌⁬⁬‮‎​‌‍⁯‍⁬‮‍⁪‬‪‎‬‏⁪‏‏​‬‮⁪‭‭‍‎⁫‮();
          num1 = (int) num2 * -1790994316 ^ -1888799293;
          continue;
        case 40:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3692104285U);
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -1850143158 ^ -1004139711;
          continue;
        case 41:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Location = new Point(77, 396);
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Maximum = new Decimal(new int[4]
          {
            1000000000,
            0,
            0,
            0
          });
          num1 = (int) num2 * 1623580862 ^ -1956155614;
          continue;
        case 42:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1785753523U);
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.Size = new Size(92, 26);
          num1 = (int) num2 * 284247214 ^ -591378442;
          continue;
        case 43:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.Location = new Point(336, 395);
          num1 = (int) num2 * -1330892538 ^ -1431582557;
          continue;
        case 44:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          num1 = (int) num2 * -1710274434 ^ 1144317960;
          continue;
        case 45:
          this.Controls.Add((Control) this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮);
          num1 = (int) num2 * 1220289263 ^ -864982025;
          continue;
        case 46:
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.Size = new Size(92, 26);
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.TabIndex = 40;
          num1 = (int) num2 * -891749317 ^ -2056751830;
          continue;
        case 47:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.TabIndex = 52;
          num1 = (int) num2 * -1854346771 ^ -2020440150;
          continue;
        case 48 /*0x30*/:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.MultiSelect = false;
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(978683553U);
          num1 = (int) num2 * 62775396 ^ 1264292681;
          continue;
        case 49:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.ValueChanged += new EventHandler(this.\u202E⁯‫‭‏‏‌⁯‏⁪⁬⁫⁬​⁪‍‬‪⁯‭⁪‌⁬⁫‌‬‭‪‭⁭‍‪⁫‭⁪⁮⁫⁫⁭⁫‮);
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.AutoSize = true;
          num1 = (int) num2 * -60987178 ^ -2067379872;
          continue;
        case 50:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.RowsAdded += new DataGridViewRowsAddedEventHandler(this.\u200B⁯⁯‫‍​‍⁪‬⁬‮‎⁫⁪‭‪‬‌⁮⁯⁪⁮⁭‫‏‌⁪‫⁫⁭‮‬‮‮⁬‬⁬‬⁯⁬‮);
          num1 = (int) num2 * 377659184 ^ -836568070;
          continue;
        case 51:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.AutoSize = true;
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Location = new Point(130, 10);
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1569363266U);
          num1 = (int) num2 * -435628602 ^ -1571356637;
          continue;
        case 52:
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.Click += new EventHandler(this.\u202B‬‮‮⁭‭‌‏‌‎​⁯‌‍⁮⁭‬⁯‍‫⁬‫​‭⁮‪‭⁬⁭‏‍‌‫​⁪⁮⁪⁬‎‮);
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.FlatStyle = FlatStyle.Flat;
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.Location = new Point(211, 327);
          num1 = (int) num2 * -178514907 ^ -397137790;
          continue;
        case 53:
          this.ClientSize = new Size(639, 427);
          num1 = (int) num2 * 182453654 ^ 800675197;
          continue;
        case 54:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 1334706094 ^ -1451703026;
          continue;
        case 55:
          this.Controls.Add((Control) this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮);
          this.Controls.Add((Control) this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮);
          num1 = (int) num2 * 972775633 ^ 1236417580;
          continue;
        case 56:
          this.FormClosed += new FormClosedEventHandler(this.\u202A⁮‌⁪‭‍⁬‮⁯‫‫⁯‫⁮‬⁬⁮‎⁭⁬‫‎⁬‬‮‮‭⁯​‬⁪​⁪​⁬‮‬​‬⁮‮);
          num1 = (int) num2 * 781804024 ^ -1659289232;
          continue;
        case 57:
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.FormattingEnabled = true;
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.Location = new Point(15, 26);
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(75786021U);
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮.Size = new Size(288, 251);
          num1 = (int) num2 * 36068553 ^ -697059037;
          continue;
        case 58:
          this.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * -17697330 ^ 861833050;
          continue;
        case 59:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.ScrollBars = ScrollBars.Vertical;
          num1 = (int) num2 * -969905222 ^ -1281249972;
          continue;
        case 60:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.TabIndex = 33;
          num1 = (int) num2 * 965954259 ^ 651190171;
          continue;
        case 61:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.Location = new Point(337, 26);
          num1 = (int) num2 * -1193583325 ^ -1103382900;
          continue;
        case 62:
          this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮.Size = new Size(48 /*0x30*/, 13);
          this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮.TabIndex = 45;
          num1 = (int) num2 * -1939768716 ^ 1392210432;
          continue;
        case 63 /*0x3F*/:
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * 1441548960 ^ -213421677;
          continue;
        case 64 /*0x40*/:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2055190961U);
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.UseVisualStyleBackColor = true;
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.Click += new EventHandler(this.\u200F⁫⁮‎‏‬‌‌‌‫⁯‎‮​⁮‮⁮‌‪‭‬‭‏‏⁬⁭‌‮‭⁯‫‬‍‏⁭‏⁬⁫​‌‮);
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.FlatStyle = FlatStyle.Flat;
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.Location = new Point(434, 361);
          num1 = (int) num2 * -1773957203 ^ -2082931810;
          continue;
        case 65:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2287287430U);
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮.FormattingEnabled = true;
          num1 = (int) num2 * 658342879 ^ -1629087269;
          continue;
        case 66:
          this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮.Width = 215;
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.HeaderText = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(769358519U);
          num1 = (int) num2 * 672071535 ^ 899353085;
          continue;
        case 67:
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3998163832U);
          num1 = (int) num2 * 85803132 ^ 1038458794;
          continue;
        case 68:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          num1 = (int) num2 * 1159753084 ^ 481871633;
          continue;
        case 69:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(18839030U);
          num1 = (int) num2 * -87015175 ^ 1474088169;
          continue;
        case 70:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.FlatStyle = FlatStyle.Flat;
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.Location = new Point(15, 327);
          num1 = (int) num2 * -819993501 ^ 1263604422;
          continue;
        case 71:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.TabIndex = 38;
          num1 = (int) num2 * 2094171138 ^ 1076498313;
          continue;
        case 72:
          this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1525760604U);
          num1 = (int) num2 * -1830301202 ^ 541245070;
          continue;
        case 73:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(729561106U);
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.Size = new Size(198, 20);
          num1 = (int) num2 * -384375477 ^ 1089215405;
          continue;
        case 74:
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202C⁫‪⁮⁬‪⁫​⁮‫‭‮‮‬‍‎⁬‮‏​⁮‬‫⁬‪‭‮‭‮‪⁭‬​⁫‭⁬‬‬⁮‪‮();
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          num1 = (int) num2 * 353525542 ^ 479126967;
          continue;
        case 75:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          num1 = (int) num2 * -1468403762 ^ -1728518547;
          continue;
        case 76:
          this.Controls.Add((Control) this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮);
          this.Controls.Add((Control) this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮);
          this.Controls.Add((Control) this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮);
          this.Controls.Add((Control) this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮);
          num1 = (int) num2 * 565707205 ^ -405950160;
          continue;
        case 77:
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.FlatStyle = FlatStyle.Flat;
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.Location = new Point(337, 361);
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3424422796U);
          num1 = (int) num2 * 1229023795 ^ -2017063246;
          continue;
        case 78:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.TabIndex = 50;
          num1 = (int) num2 * 128860121 ^ 1422281398;
          continue;
        case 79:
          this.Controls.Add((Control) this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮);
          num1 = (int) num2 * -1456238736 ^ 378919047;
          continue;
        case 80 /*0x50*/:
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮.TabIndex = 35;
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮.Click += new EventHandler(this.\u200B‏​‫⁮‫⁯⁫‍‮⁬‬‍‮⁭‎⁭‏‏‭⁪​‍‬⁫‎⁬⁬‬‌‫‪‏‎⁪‎‮‭⁯‮);
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.AutoSize = true;
          num1 = (int) num2 * -479419721 ^ 342870729;
          continue;
        case 81:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.Location = new Point(130, 285);
          num1 = (int) num2 * 346958912 ^ -311639530;
          continue;
        case 82:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Size = new Size(165, 13);
          num1 = (int) num2 * -2126356637 ^ -1000782986;
          continue;
        case 83:
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.EndInit();
          num1 = (int) num2 * 591063052 ^ -1602196028;
          continue;
        case 84:
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.BackColor = Color.WhiteSmoke;
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.ForeColor = SystemColors.WindowText;
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Location = new Point(183, 367);
          num1 = (int) num2 * 937025455 ^ -2002874858;
          continue;
        case 85:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3184709045U);
          num1 = (int) num2 * -1191979966 ^ 993987815;
          continue;
        case 86:
          this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3594253948U);
          num1 = (int) num2 * 1768353858 ^ 510377921;
          continue;
        case 87:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.AutoSize = true;
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Location = new Point(281, 371);
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3866587072U);
          num1 = (int) num2 * 1006015032 ^ 280051600;
          continue;
        case 88:
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.Click += new EventHandler(this.\u200D⁬⁮​‬⁮⁮‮⁮​‏‎⁪‌⁭⁪⁯⁬‭‮‍‍‌‎⁬‮‭⁯⁯‫‮‍⁫‍‎‭‫‬‍‏‮);
          num1 = (int) num2 * 1852179015 ^ 736608446;
          continue;
        case 89:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.Size = new Size(287, 290);
          num1 = (int) num2 * 1780325184 ^ -640051507;
          continue;
        case 90:
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.Size = new Size(92, 26);
          num1 = (int) num2 * -1191070138 ^ 1423449065;
          continue;
        case 91:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.TabIndex = 53;
          num1 = (int) num2 * -1985108251 ^ -1345123568;
          continue;
        case 92:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(955942664U);
          num1 = (int) num2 * 1339678056 ^ -666432860;
          continue;
        case 93:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.Size = new Size(57, 13);
          num1 = (int) num2 * -1181612628 ^ 490000500;
          continue;
        case 94:
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.TabIndex = 41;
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1099642758U);
          num1 = (int) num2 * -182428750 ^ 1860909656;
          continue;
        case 95:
          this.Controls.Add((Control) this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮);
          num1 = (int) num2 * -486916510 ^ -622109485;
          continue;
        case 96 /*0x60*/:
          this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206E⁯‪⁭⁯⁭‬⁯‮​⁪‏‫‫⁪⁯⁯‬‏‎‎⁮⁮‌⁪‍⁬⁪‫‎‏‏⁪‭‪⁮‎‭⁪‫‮();
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮();
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u206D‪‎‪‎‎⁯⁪‏‎⁬​⁯‮⁫‍‎⁬‫⁯⁯‏⁭‌⁫⁮‏‭​‎‏⁭⁪‬​‍⁪‌⁭⁫‮();
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          num1 = (int) num2 * 515422681 ^ 1899238920;
          continue;
        case 98:
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1527529377U);
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮.Size = new Size(287, 21);
          num1 = (int) num2 * 538767680 ^ -474374558;
          continue;
        case 99:
          this.Controls.Add((Control) this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮);
          num1 = (int) num2 * 784182074 ^ 183685961;
          continue;
        case 100:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2055190961U);
          num1 = (int) num2 * -1129543864 ^ 1541771953;
          continue;
        case 101:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮.AutoSize = true;
          num1 = (int) num2 * 1564735424 ^ 1004664306;
          continue;
        case 102:
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.ValueChanged += new EventHandler(this.\u206A⁯‏‍‍⁬⁮‬⁭‍⁪‎‮⁭‏‎⁯⁫⁮⁬⁭‮⁯‭⁬‬⁯‍‪‍‎‍⁮‪⁬‎‎⁪‫⁭‮);
          this.AutoScaleDimensions = new SizeF(6f, 13f);
          this.AutoScaleMode = AutoScaleMode.Font;
          num1 = (int) num2 * -1204668101 ^ 705508179;
          continue;
        case 103:
          this.\u206B‪⁮⁮‭⁬‏⁮‭⁬⁬⁯‮‎‭‫‌‭​‪‍‏‬​⁬‏‍⁯‬⁬‮​‏‎⁯⁪‌⁬‫⁯‮.Size = new Size(92, 26);
          num1 = (int) num2 * -1010692673 ^ 863972205;
          continue;
        case 104:
          this.Controls.Add((Control) this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮);
          this.Controls.Add((Control) this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮);
          num1 = (int) num2 * -174033265 ^ 1940549679;
          continue;
        case 105:
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Size = new Size(92, 20);
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.TabIndex = 51;
          this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮.Value = new Decimal(new int[4]
          {
            333,
            0,
            0,
            0
          });
          num1 = (int) num2 * 345806482 ^ 772159431;
          continue;
        case 106:
          this.\u202B‫‎⁯⁫‬⁭⁬⁮⁬‪‭⁬‬‫‎⁬‫​‭‫‌‌‮‫‫⁫​⁮‭‍⁯‪‍​⁮‬‏‪⁭‮.Location = new Point(385, 10);
          num1 = (int) num2 * -1012181797 ^ 899198441;
          continue;
        case 107:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.CellEndEdit += new DataGridViewCellEventHandler(this.\u206C⁯‬⁫​‭⁫‬‏⁬​⁬‌⁯‭‫​⁪​⁫‮⁮⁯‎‪‮⁫‫‏‭⁬‭‪‫‏‍‏⁭‬‌‮);
          num1 = (int) num2 * -667026446 ^ 488525991;
          continue;
        case 108:
          this.Controls.Add((Control) this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮);
          num1 = (int) num2 * 730011086 ^ -1166202462;
          continue;
        case 109:
          this.\u206B‌‬‫‎⁬‪‫‫‌‬⁮⁪‫‭‌‬⁭‮⁪⁪‎⁬‍‌‮​⁬‫⁭‌‪‎‍‬⁪‌‪⁬‫‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -1441600130 ^ 1884354313;
          continue;
        case 110:
          this.\u206F‪‎‮‮‮⁯‭‮⁮‍‍⁫‌‬‪‫‮‎⁬‫‫‍‫‬‫‬⁬‌⁫⁬‍⁬‭‏‎‭‏‫‌‮ = \u007BZ\u003Be\u005E_\u005E\u0023.\u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮();
          num1 = (int) num2 * 443884149 ^ 970837170;
          continue;
        case 111:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.ForeColor = SystemColors.WindowText;
          num1 = (int) num2 * -617222763 ^ -2026283175;
          continue;
        case 112 /*0x70*/:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u200E⁭⁬‬⁭‏‫‮⁭⁬​‬⁯‬⁪⁬‏‎‌⁫‫‫‎⁫⁭‍⁪⁬‬​‌‍​⁪‎⁪⁫⁮‏‍‮((Control) this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮, true);
          this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮.Location = new Point(456, 319);
          num1 = (int) num2 * 1298435025 ^ 1079539965;
          continue;
        case 113:
          this.\u206F⁯‏‫⁮‏⁬‪‮⁪‍​⁭‎‪⁭⁬‌‎⁪‫‌‮‬‌⁫⁮‬⁪‍​‬‮‎⁭‫⁬‎‭‭‮.TabIndex = 43;
          num1 = (int) num2 * -1963359262 ^ 193258647;
          continue;
        case 114:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Size = new Size(46, 13);
          num1 = (int) num2 * 2048198835 ^ -1658601223;
          continue;
        case 115:
          this.ResumeLayout(false);
          num1 = (int) num2 * -1311095846 ^ -1214192196;
          continue;
        case 116:
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1802321378U);
          num1 = (int) num2 * 357979124 ^ -960253256;
          continue;
        case 117:
          goto label_1;
        case 118:
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.UseVisualStyleBackColor = true;
          this.\u200E⁮⁫‭‪‌‭‭‎​‫⁭‎⁮⁫‎⁭⁫‮⁯‌‎‮⁮‬⁬‏‮⁫⁮⁬⁫‪​⁮‍‪‪⁪‫‮.Click += new EventHandler(this.\u206A‮⁯‫‏‬⁮‏⁮‏⁪​⁪⁮‪⁮​⁭‍‏‍‍⁯‎‌⁭⁬‍​‭‍‮‍⁫‌⁮⁮‫‭⁬‮);
          num1 = (int) num2 * 2080782138 ^ 917051873;
          continue;
        case 119:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.Columns.AddRange((DataGridViewColumn) this.\u206B⁮‬⁯⁪⁬​⁪⁭‭‫⁭⁭⁮⁫‮​‏‏⁬‭‫⁭⁬⁯⁭‏⁫‍⁯‪‬‪⁫‍⁫‎⁭⁪‭‮, (DataGridViewColumn) this.\u200F⁫‪⁬⁯‪‬‫‏‏‪⁫⁫‎‍⁮⁪​‍‮⁬‬‎⁫⁪‪⁭⁪‌‏⁪‎‏⁭‏⁫‍‌‏‮‮);
          num1 = (int) num2 * -1163031012 ^ 222231602;
          continue;
        case 120:
          this.Controls.Add((Control) this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮);
          this.Controls.Add((Control) this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮);
          num1 = (int) num2 * -1739394620 ^ 1071539668;
          continue;
        case 121:
          this.Controls.Add((Control) this.\u200D⁬‍⁭⁬‏⁫⁫‫​‪‍‏⁭‪‍‭⁫⁪⁭⁫⁭​⁮‭‫‎​⁬‪⁫‪⁯​⁯⁭​‪‌‮‮);
          num1 = (int) num2 * -522161834 ^ -446193214;
          continue;
        case 122:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1953750094U);
          num1 = (int) num2 * 1424714713 ^ -1484606611;
          continue;
        case 123:
          this.\u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮.Size = new Size(22, 13);
          num1 = (int) num2 * 952407758 ^ 8331414;
          continue;
        case 124:
          \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‬⁮‮‬⁬⁬‭⁫⁭‍⁯⁮⁪‫⁬⁭‬​⁫‮⁬⁫⁪‌⁭‭‮‬‭⁯‮‎⁭‬‏⁪⁪‍⁪‮((ISupportInitialize) this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮);
          \u007BZ\u003Be\u005E_\u005E\u0023.\u200B‬⁮‮‬⁬⁬‭⁫⁭‍⁯⁮⁪‫⁬⁭‬​⁫‮⁬⁫⁪‌⁭‭‮‬‭⁯‮‎⁭‬‏⁪⁪‍⁪‮((ISupportInitialize) this.\u206E⁯‪⁫⁮‭⁮‬‍‭‎​‭‎‌⁮‮⁫‍‎⁯‏‌‫‍‭⁯‮‫‎‎⁯​‭‫‍⁬‍⁮⁬‮);
          num1 = (int) num2 * 847596061 ^ -2097168185;
          continue;
        case 125:
          this.\u200C⁭‏⁯‭​​⁮‬⁫‍⁯​⁯‫‎‍‭⁮​‪‫‌‌‭⁯⁬‏‭‪‪‭​‫‫⁪‏‎⁭‌‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1026452880U);
          num1 = (int) num2 * 2006911019 ^ -1269615026;
          continue;
        case 126:
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3313881727U);
          this.\u202E‮⁯⁯⁪‍⁮⁫⁯‏‎‭‫​‭‎‫‫‎⁮‍‌‮⁯‫‭‭‫‮‪⁫⁯⁫‭‎‮‎‌⁯‮.Size = new Size(288, 20);
          num1 = (int) num2 * -1568624807 ^ 1890306469;
          continue;
        case (uint) sbyte.MaxValue:
          this.Controls.Add((Control) this.\u206D​⁯⁫‪‌‏⁫⁯⁫‫‎⁬‬‌‫‭⁯‎‏‎⁭⁭‎⁬‮‮‭‪⁯‭‏‍⁮⁯‬​‫⁬‮‮);
          this.FormBorderStyle = FormBorderStyle.FixedDialog;
          this.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1898868619U);
          this.Text = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1898868619U);
          num1 = (int) num2 * 50957705 ^ 2078885812;
          continue;
        case 128 /*0x80*/:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1028295527U);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.AutoSize = true;
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Location = new Point(12, 398);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4259584384U);
          num1 = (int) num2 * 1348506080 ^ -177740379;
          continue;
        case 129:
          this.\u200C‪‭‬​⁪‭‪⁬‌‫⁪‪‌‎⁬‍‎‍⁭‪‎‏⁬‪‎⁫​‍⁬‍‮⁪‬⁯⁬‮‭⁫‭‮.Location = new Point(532, 361);
          num1 = (int) num2 * 383420383 ^ -448725194;
          continue;
        case 130:
          this.\u200E‫⁪‏‫‏‪‍⁫‫‏‍‭‭‮‪‫⁮‫‏‭‬‬⁪⁭‭⁪⁬‏⁮‪⁬⁮⁫‬⁯⁮‫⁪⁫‮.RowHeadersVisible = false;
          num1 = (int) num2 * -1499385364 ^ 1771136264;
          continue;
        case 131:
          this.\u206E‬‮⁭‭⁯‏⁯⁬‫⁬‏⁭⁮⁬‍​‍‍‎⁯‌‍‏⁬‪‭⁬⁮⁯‮⁮‪⁭‪‭‏⁬‬‍‮.FlatStyle = FlatStyle.Flat;
          num1 = (int) num2 * 1607454179 ^ -1462145839;
          continue;
        case 132:
          this.\u206A‎⁬⁫‬⁬‌‫⁯‍‌​⁭⁬⁭⁬‏‪‭‭‪⁪⁬‍⁬‫‫‍⁯⁯‌⁫‎⁭⁬⁪‭⁪⁪⁭‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2253340468U);
          num1 = (int) num2 * 2027151710 ^ 35361514;
          continue;
        case 133:
          this.\u206A⁪‌‎⁬‌⁮​​⁫⁮‪‍‏‬‍‭‍‎⁮⁭⁬⁬⁪⁬‮‌‪‏⁮‮‪⁯​⁫​‫‭⁬‏‮.TabIndex = 47;
          num1 = (int) num2 * 1288572433 ^ 316974375;
          continue;
        case 134:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Size = new Size(59, 13);
          num1 = (int) num2 * 773761731 ^ 184681886;
          continue;
        case 135:
          this.\u206A‮⁯⁯‬⁬‪‬‮⁯‏‍⁪⁫‪‪⁬‪‫‎‏‪‎‮‪⁮⁯‮‌‎‪⁯​‎‪‬‮⁪‮⁬‮.Name = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3813460000U);
          num1 = (int) num2 * 1081940042 ^ -1649354243;
          continue;
        default:
          goto label_137;
      }
    }
label_137:
    this.PerformLayout();
  }

  static void \u200D⁪⁮‫‍‭‏‭‌⁭​‍‍⁫‫‮​‎⁫⁮⁯‏‭‮⁬‮⁭⁮⁪‪‪​⁯‫‏‬⁬‭‏⁪‮([In] Control obj0, [In] Color obj1)
  {
    obj0.ForeColor = obj1;
  }

  static void \u206B⁬⁬⁪‫‏⁬⁫‪‍⁫⁬⁬‌‪⁮​‫‌‏⁮⁫​⁪‎⁫⁫‏‪‎‮⁭‍⁯⁬‫‪⁫‏⁫‮([In] Form obj0, [In] bool obj1)
  {
    obj0.MaximizeBox = obj1;
  }

  static string \u206B‏‌‮⁬‬⁯⁭‭‌⁯‫⁪​⁯‬⁮​⁬⁪‏⁮‌‎⁪‍‎⁪​⁬‍‫⁫‪⁭⁬​⁫⁬⁯‮([In] string obj0, [In] string obj1)
  {
    return obj0 + obj1;
  }

  static int \u202E​⁬⁭‏⁬⁪⁭​‮‍‮‭‍‌‏⁯‫‫⁮⁫‌⁮‫‪‎⁫‫⁯‬‏‭‏⁯‬⁭⁭​‫‭‮([In] ListControl obj0)
  {
    return obj0.SelectedIndex;
  }

  static DataGridViewRowCollection \u202D‬‏‌⁬‎⁪‎⁫‍‪‍‭‫‬‏‌‮⁫‮⁬⁮⁫⁫‭⁫⁬⁭‎⁮⁫‏‍‏‬⁫⁬‮‌‬‮([In] DataGridView obj0)
  {
    return obj0.Rows;
  }

  static void \u202D⁬‫‬‎‫⁯‍‮‌​‭‫‏‏⁪⁪⁪⁫‎‫​‫‎‬‏‏‪‌‎‌‪⁪‌‭⁭​⁮‮‌‮([In] DataGridViewRowCollection obj0)
  {
    obj0.Clear();
  }

  static ListBox.ObjectCollection \u200D⁫‍⁫‪‫‫‬‮‌‪‏​‎⁯​‌⁬‪‭‬‎⁭​⁯​⁮⁪⁮⁯‌‫‎‎‪⁯‪⁮⁯⁬‮([In] ListBox obj0)
  {
    return obj0.Items;
  }

  static object \u200D⁮‌‍⁫‌‭⁮‪‎⁪‌‭​⁭⁯⁪‮‬‮⁫‮⁬⁯‎​‭‎⁬‫‏‭‎‭⁫⁯⁯‪⁪‭‮(
    [In] ListBox.ObjectCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static string \u206F⁪‮‏⁬‫⁭‬‫⁮​​‮⁫⁬‭‮‍⁭​⁭‮⁬⁬​‎⁪⁬‌‬⁯⁪⁮⁮⁮⁬‏‮‬⁪‮([In] object obj0) => obj0.ToString();

  static void \u202D‪⁫​⁮‭‫‬⁬⁯‫‪‫‮‫‪‎⁪‎‫⁯‌⁭‮⁯‭‮‌‮‬‬‌‬‎‌‫‌⁬⁯‍‮([In] Control obj0, [In] string obj1)
  {
    obj0.Text = obj1;
  }

  static void \u202E‮⁪⁯⁯⁮‪‬​‭‫⁯‭⁭⁪⁭⁮‫⁪‪⁯⁮⁯​‌⁯‪⁬⁮​‍⁬‫‎‬⁮⁯‎⁮‮([In] Control obj0, [In] object obj1)
  {
    obj0.Tag = obj1;
  }

  static int \u202E‪⁮‭⁬‎⁮‎‭​⁪​⁮⁫‪⁭‭⁭​⁬⁪‮‫‎‪‬‪‌‍‏‭⁯⁪‎⁪‪‭⁮⁪‮‮(
    [In] DataGridViewRowCollection obj0,
    [In] object[] obj1)
  {
    return obj0.Add(obj1);
  }

  static string \u200E‍⁮⁬‌⁮‎‌⁫‭⁭‏‫‬⁪⁭‪⁫​‬​‮‪⁬⁮⁭​‫⁮‭‪⁫⁯‬‍‍⁪⁪​‌‮([In] Control obj0) => obj0.Text;

  static int \u206E‏‍‍⁫‎‮‬⁭​‫⁬‎‏‍​‌‌⁯⁪⁫‌‬‫‭‫‏‎‬‫‭​⁪​⁮‮⁫⁫‭⁬‮(
    [In] ListBox.ObjectCollection obj0,
    [In] object obj1)
  {
    return obj0.Add(obj1);
  }

  static int \u200F⁪‍‏‬‍⁬⁬‬‫⁯⁫‪⁬‍⁭‬‭‎⁭​‪⁪‏‭⁪‬⁫⁭⁭⁪⁪​‫⁬⁫⁬‎⁬‬‮([In] ListBox.ObjectCollection obj0)
  {
    return obj0.Count;
  }

  static void \u202E⁫‮‬‎⁮‎⁪‭‌​‫‏⁭‪⁫‎‫‍‮⁭‪⁪‫⁪‌‬‭⁭‭⁬‫‭⁮‫‭⁫⁭⁮‍‮([In] ListControl obj0, [In] int obj1)
  {
    obj0.SelectedIndex = obj1;
  }

  static void \u206F⁯‌‏​⁪‍‍⁮‏⁪⁭​‎‭‍‪⁬‫⁯‎⁭⁫‪‍‎‬​⁪​⁯‎⁮⁪​‪‪⁯‪⁪‮(
    [In] ListBox.ObjectCollection obj0,
    [In] int obj1,
    [In] object obj2)
  {
    obj0[obj1] = obj2;
  }

  static void \u200C‍⁮‫‭⁪‎‬⁮‮⁬‎​‍‪‭‎⁭‌‬​⁬‏‮‬‬‎‌‌​‏⁬⁮‪⁯⁬⁯⁭‬‭‮(
    [In] ListBox.ObjectCollection obj0,
    [In] int obj1)
  {
    obj0.RemoveAt(obj1);
  }

  static int \u206E‎⁬‬⁬‏⁫‏​⁪​‍‌⁪‪​⁪‫‌⁮⁮‌‬‮⁬⁯‮‎‫‍‎‎⁬⁮‫‪‌‪‮⁪‮([In] int obj0, [In] int obj1)
  {
    return Math.Max(obj0, obj1);
  }

  static object \u202E⁯⁯‏⁭‭⁬‭⁬⁬‍⁫‫‭‌⁬‌⁫​⁫⁬⁬‭‬⁫⁯‍‫​‫​‎‌⁬‭⁮‏‬‍‮([In] Control obj0) => obj0.Tag;

  static void \u200B‎‎⁯⁫‎‎‏‪​‭‫‭⁮⁬⁯⁭‮‫⁮‭⁪⁮‍‬‮‏⁭‎‌⁬‭‌‍‍⁭‎‬⁭‮‮([In] object obj0, [In] ref bool obj1)
  {
    Monitor.Enter(obj0, ref obj1);
  }

  static void \u200E‭‬⁯‮​​⁫‮‮‪‬⁭‫⁫‌⁫‫⁭‍‫⁭‮⁮⁪‫⁯⁮‍⁫⁪​‪‫‮‌‌‎⁮‮([In] object obj0) => Monitor.Exit(obj0);

  static int \u206B‎⁯‭‫‪⁯‫‪‌‌⁯‎⁬⁭‎‬‎⁯‪​‪⁮⁫⁮⁬⁪‏‮‎‭‌‭‏‭‍⁪‏⁮⁬‮(
    [In] DataGridViewRowCollection obj0,
    [In] DataGridViewElementStates obj1)
  {
    return obj0.GetFirstRow(obj1);
  }

  static DataGridViewRow \u206C‪​⁯⁯‏‏‏⁫‮‎‭⁭⁯⁭‌⁭⁭⁭‌‪‌⁪⁬‫‎‬‍‫⁯⁫⁫⁬‫‌⁬‪⁭⁯‮‮(
    [In] DataGridViewRowCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static DataGridViewCellCollection \u200F‏⁮⁪⁮​‎‪⁯‎‮⁭​‏⁭‫​⁬⁭⁭‏‏​​‎⁮‪‎‎⁬⁯⁭⁮⁫‏⁬⁬‏⁬‭‮(
    [In] DataGridViewRow obj0)
  {
    return obj0.Cells;
  }

  static DataGridViewCell \u202A‬‭‭‎‫⁪⁪⁭⁬‮⁮‎‮‌⁪‫⁮‫‌‌‬‏‎‪‌‬‪‪‏‭⁭​⁯‍‬⁬‪⁮‪‮(
    [In] DataGridViewCellCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static void \u206B‍‏‌⁮⁭⁭⁪‪⁯⁫‮‮‮​​‌⁪⁬⁪‪‬​‏‌‪‎⁮⁫‍⁯‭⁬‎⁯⁫‏⁬‫⁭‮([In] DataGridViewCell obj0, [In] object obj1)
  {
    obj0.Value = obj1;
  }

  static void \u206A‎‏‍‍‎‫⁬⁬‎⁬⁮‍⁯‎‪‪‪‎⁪‬‏⁫⁭⁯⁭‫‪⁯‫‮‫​‍⁬⁫‏⁬⁭‍‮(
    [In] DataGridViewRowCollection obj0,
    [In] int obj1)
  {
    obj0.RemoveAt(obj1);
  }

  static void \u206E⁭‌‪‏​⁫‏‏‬⁯‏‎‭⁪‎‌‪‫⁭‍‮‏⁮‏‏‪‪⁮‌‪‌⁯⁪‎⁪‮⁯⁮‎‮([In] DataGridView obj0)
  {
    obj0.ClearSelection();
  }

  static int \u206D‮‫⁯‪‬‭⁪⁬⁬‌‮⁭‍‎‍⁪‮‮⁪‮⁫​⁬⁫‎⁭⁫‮⁬‍‬⁬‬⁪⁯‏⁯‪⁪‮([In] DataGridViewRowCollection obj0)
  {
    return obj0.Count;
  }

  static void \u200D‌‫‮⁬⁯⁪‬‮‭‌⁫⁫⁪‎‪⁮‬‬‏⁯⁪‪⁪‍‌‫‪‪⁪⁬⁮⁯⁪⁮​⁪⁮⁯‪‮([In] DataGridViewBand obj0, [In] bool obj1)
  {
    obj0.Selected = obj1;
  }

  static Task \u202D⁫​‌‬‬‏⁬‌⁬‎‍‭‎⁫⁯‬⁬‭​⁪⁭⁯​⁬‭‭‎‭‬⁫‮‮⁭‎⁭‌‌‍⁪‮([In] Action obj0) => new Task(obj0);

  static void \u200D‭‭‏‫‪⁮‍‭⁯⁪⁮⁭‪⁪‫⁯‌‏‎‍⁮‭⁮⁫‪‌⁬‏‎⁬‌⁫‏‪‫‪‭‬⁪‮([In] Task obj0) => obj0.Start();

  static Decimal \u200E‬‭‫‪‪‬‮⁬⁫⁯⁮​‏‭‫‎‏⁬⁭‮⁪‭‮⁬⁪‎‪‎⁯⁫‍⁫‍​⁫⁮‍⁬‍‮([In] NumericUpDown obj0)
  {
    return obj0.Value;
  }

  static void \u206C‌‫​⁮‬‬‍‮⁮‬‎⁬‫​⁮‪⁭‎‌‌‬⁫‮‌⁯⁮‮‮⁫‏‬⁯‌⁪‏⁬⁮⁬‭‮([In] ListBox.ObjectCollection obj0)
  {
    obj0.Clear();
  }

  static ComboBox.ObjectCollection \u202E⁬‪‮‬‍⁮‭‪‫⁬⁮​⁭⁬⁪‬​⁭‍‌‪‎‬⁯‌‪‫‏⁮‮‪‬‬‪‭⁫​⁯‭‮([In] ComboBox obj0)
  {
    return obj0.Items;
  }

  static void \u202D‫‎‪⁫‪‮‪‭‌‍‏‬⁯⁮⁯‌‭​‎‮⁫⁯‎⁫‎​⁪‎‌‍‫‭‫‌⁫‏‌⁭‮‮([In] ComboBox.ObjectCollection obj0)
  {
    obj0.Clear();
  }

  static void \u202C‫‍⁬‌⁫‫⁬‬‏⁪⁭​‬‏‏⁮‏⁫⁪‏‎‮‪‭⁮‏‪‫‍⁯⁯​‬⁮⁯⁪⁫⁬‭‮(
    [In] ComboBox.ObjectCollection obj0,
    [In] object[] obj1)
  {
    obj0.AddRange(obj1);
  }

  static int \u206E‌⁮⁫‌⁭⁬⁬⁪⁫‮‎‬‭⁭⁬​‭‭‪⁯⁫⁬​​​⁬‍⁪‬‬‏‭​‫‬‍‭⁯‬‮([In] ComboBox.ObjectCollection obj0)
  {
    return obj0.Count;
  }

  static void \u206A⁭‪⁮​‎‭⁭‭‌⁫‭‭⁯⁭⁮‫⁭⁪‌‍⁯‫⁬‎‎⁭⁯‪⁫‌⁫‮⁯‮⁭⁫‏​⁫‮([In] NumericUpDown obj0, [In] Decimal obj1)
  {
    obj0.Value = obj1;
  }

  static object \u202C⁪‮⁫⁪‎⁭⁫‬⁯⁮‍‮⁮‍⁬​‪‫⁮‪‍‌‎⁪​‌‏‏‎‏‭⁬⁬​⁯⁭⁫⁯⁬‮([In] DataGridViewCell obj0)
  {
    return obj0.Value;
  }

  static int \u200E‍‪⁬‪‬⁮‮⁮‮‮⁪‪⁬‮⁪⁫‏‏‬⁭‫‬‍‭⁬⁫‎⁫⁪‭⁯​⁫‏‍⁮‍‬‏‮([In] DataGridViewRowsAddedEventArgs obj0)
  {
    return obj0.RowIndex;
  }

  static int \u206E‭⁭‫⁫‌‏‭‏‮⁯⁪‏‌⁮‎⁪⁯‌‎⁬⁪‬⁭‏‬‏⁯‎‭‎⁭‬‮‬‎‫‌⁪‌‮([In] DataGridViewCellEventArgs obj0)
  {
    return obj0.RowIndex;
  }

  static void \u202B‬‭‬‏‌‏⁪⁪‎⁭‌‪⁫⁭‭‏⁬‎⁬‬‬⁭‌​⁯​‪⁫‫⁪‮‫‎‌‭⁭‎⁪‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static Label \u202E⁮‎⁬⁫‪‮⁮‏​⁯‬‏‫⁪​‍⁮‮‎⁭​⁮⁬‍⁪⁬‌⁪‍‫⁭⁬‭‌‏‫‪⁯‌‮() => new Label();

  static ComboBox \u206F‪‌⁯‍‬‏‬‎‌⁬⁬‮‎​‌‍⁯‍⁬‮‍⁪‬‪‎‬‏⁪‏‏​‬‮⁪‭‭‍‎⁫‮() => new ComboBox();

  static Button \u206D⁫⁪‌‎‬‏‌‏⁫⁫⁪⁪⁮‌⁯‫⁬⁬​⁯⁪‍⁪⁭‮‮‏⁬⁪​‏⁯⁯⁬⁯‮⁭‏‫‮() => new Button();

  static TextBox \u202C⁫‪⁮⁬‪⁫​⁮‫‭‮‮‬‍‎⁬‮‏​⁮‬‫⁬‪‭‮‭‮‪⁭‬​⁫‭⁬‬‬⁮‪‮() => new TextBox();

  static ListBox \u206E⁯‪⁭⁯⁭‬⁯‮​⁪‏‫‫⁪⁯⁯‬‏‎‎⁮⁮‌⁪‍⁬⁪‫‎‏‏⁪‭‪⁮‎‭⁪‫‮() => new ListBox();

  static NumericUpDown \u206D‪‎‪‎‎⁯⁪‏‎⁬​⁯‮⁫‍‎⁬‫⁯⁯‏⁭‌⁫⁮‏‭​‎‏⁭⁪‬​‍⁪‌⁭⁫‮() => new NumericUpDown();

  static DataGridView \u200F⁯‌‬‮‌‪⁮‎‍⁪‍⁫‍⁬⁪‪⁯‎‌‍‮‮‍‮‎⁮⁫‫‏⁯⁬‎‫⁭‭⁭⁫⁯‭‮() => new DataGridView();

  static DataGridViewTextBoxColumn \u206D‮⁯‪‭‍⁯⁫‬⁯‍⁭‏‮⁬‫‏⁭​⁮⁫⁯​‬⁪⁫⁯‮⁪⁪‏⁪‌‫‍​‫⁯‭‍‮()
  {
    return new DataGridViewTextBoxColumn();
  }

  static void \u200B‬⁮‮‬⁬⁬‭⁫⁭‍⁯⁮⁪‫⁬⁭‬​⁫‮⁬⁫⁪‌⁭‭‮‬‭⁯‮‎⁭‬‏⁪⁪‍⁪‮([In] ISupportInitialize obj0)
  {
    obj0.BeginInit();
  }

  static void \u202D⁮⁯‍‪⁭⁬⁭⁮⁯‌‏‪‪​‌⁭⁬⁭⁬‬⁬‪‫‌‬‮‫‭⁮‫⁪⁪⁬⁮⁮‌‎‮⁭‮([In] Control obj0)
  {
    obj0.SuspendLayout();
  }

  static void \u200E⁭⁬‬⁭‏‫‮⁭⁬​‬⁯‬⁪⁬‏‎‌⁫‫‫‎⁫⁭‍⁪⁬‬​‌‍​⁪‎⁪⁫⁮‏‍‮([In] Control obj0, [In] bool obj1)
  {
    obj0.AutoSize = obj1;
  }
}
