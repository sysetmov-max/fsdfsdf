﻿// Decompiled with JetBrains decompiler
// Type: ‮⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
public class \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮ : Form
{
  public void \u200D‏‪⁫⁯⁭‮‭⁯‪‏‫⁫‬‎‬‪​⁭‍‬‭⁯‫‪‏⁭‬‪⁬⁮‭‏‎⁪​‫‏⁪‏‮(IWin32Window _param1)
  {
    \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮.\u200E‭⁭​⁫‪⁮‬‍‫⁬⁫‬‏‭⁮‍‫⁭⁭⁬‭⁭‍‫‪‫‬⁮‏‬‮‎‫‌​⁯‬‫‪‮((Form) this, _param1);
label_1:
    int num1 = -297701300;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1799506875)) % 4U)
      {
        case 0:
          goto label_1;
        case 1:
          int num3 = \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮.\u202E‫‬‍⁮⁫‍‎‫‬⁭⁮‍‭‫‪⁮‏⁮‬‮‏‪⁮‎‎​‎‏‎‌‫‫‮⁭‏‮‪⁫‫‮((Form) this) != null ? 482516974 : (num3 = 1956355271);
          num1 = num3 ^ (int) num2 * 23935376;
          continue;
        case 2:
          goto label_3;
        case 3:
          this.Location = new Point(\u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮.\u202C‬⁬‫⁫⁭‫‮​⁭‫‪‮⁫‍⁯‍‍‎‮‎‪‪‭⁬⁫​‪⁯⁮‭‫‌​⁫⁯⁯‏⁮‭‮(\u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮.\u202E‫‬‍⁮⁫‍‎‫‬⁭⁮‍‭‫‪⁮‏⁮‬‮‏‪⁮‎‎​‎‏‎‌‫‫‮⁭‏‮‪⁫‫‮((Form) this)).X + this.Owner.Width / 2 - this.Width / 2, this.Owner.Location.Y + this.Owner.Height / 2 - this.Height / 2);
          num1 = (int) num2 * 329413712 ^ -1675371353;
          continue;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  static void \u200E‭⁭​⁫‪⁮‬‍‫⁬⁫‬‏‭⁮‍‫⁭⁭⁬‭⁭‍‫‪‫‬⁮‏‬‮‎‫‌​⁯‬‫‪‮([In] Form obj0, [In] IWin32Window obj1)
  {
    obj0.Show(obj1);
  }

  static Form \u202E‫‬‍⁮⁫‍‎‫‬⁭⁮‍‭‫‪⁮‏⁮‬‮‏‪⁮‎‎​‎‏‎‌‫‫‮⁭‏‮‪⁫‫‮([In] Form obj0) => obj0.Owner;

  static Point \u202C‬⁬‫⁫⁭‫‮​⁭‫‪‮⁫‍⁯‍‍‎‮‎‪‪‭⁬⁫​‪⁯⁮‭‫‌​⁫⁯⁯‏⁮‭‮([In] Form obj0) => obj0.Location;
}
