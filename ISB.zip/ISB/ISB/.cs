﻿// Decompiled with JetBrains decompiler
// Type: ‫⁪⁮⁫⁬⁮⁬‬⁭⁮‎⁮‍‪‏‎⁫​‫⁮⁫‏⁭‎⁮‮‍⁫⁪‏‏⁫⁭‪‪‏‌⁬‏⁬‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Runtime.InteropServices;

#nullable disable
internal static class \u202B⁪⁮⁫⁬⁮⁬‬⁭⁮‎⁮‍‪‏‎⁫​‫⁮⁫‏⁭‎⁮‮‍⁫⁪‏‏⁫⁭‪‪‏‌⁬‏⁬‮
{
  public static int \u206E⁮‏⁮⁭‏⁪⁭‮‌⁮‬⁯⁯‪‍⁭‭‬‏‍‏‫‍‏‪‍⁮‪⁮​⁯‫‫⁬‬​⁫‍⁪‮(
    this int _param0,
    int _param1,
    int _param2)
  {
    return \u202B⁪⁮⁫⁬⁮⁬‬⁭⁮‎⁮‍‪‏‎⁫​‫⁮⁫‏⁭‎⁮‮‍⁫⁪‏‏⁫⁭‪‪‏‌⁬‏⁬‮.\u202D‭‫‪‏‮‮‮‏‮⁬⁬⁭⁪‎‏‍‌⁬‌‬⁬‫⁬⁫​⁮⁫⁭‪‭​‏‏⁫⁯‫⁮⁬⁪‮(\u202B⁪⁮⁫⁬⁮⁬‬⁭⁮‎⁮‍‪‏‎⁫​‫⁮⁫‏⁭‎⁮‮‍⁫⁪‏‏⁫⁭‪‪‏‌⁬‏⁬‮.\u202E⁯‌‮‍‫⁫‏‫‍‪‪‏⁭‎‮⁬‎‪‪‬⁯⁬‫‪⁭⁮​‬⁫‬‌‮⁪⁪‪‮⁪⁮‏‮(_param0, _param2), _param1);
  }

  static int \u202E⁯‌‮‍‫⁫‏‫‍‪‪‏⁭‎‮⁬‎‪‪‬⁯⁬‫‪⁭⁮​‬⁫‬‌‮⁪⁪‪‮⁪⁮‏‮([In] int obj0, [In] int obj1)
  {
    return Math.Min(obj0, obj1);
  }

  static int \u202D‭‫‪‏‮‮‮‏‮⁬⁬⁭⁪‎‏‍‌⁬‌‬⁬‫⁬⁫​⁮⁫⁭‪‭​‏‏⁫⁯‫⁮⁬⁪‮([In] int obj0, [In] int obj1)
  {
    return Math.Max(obj0, obj1);
  }
}
