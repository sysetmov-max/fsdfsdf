﻿// Decompiled with JetBrains decompiler
// Type: ​‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using VkNet.Utils.AntiCaptcha;

#nullable disable
internal sealed class \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮ : ICaptchaSolver
{
  public static readonly Queue<string> \u200E‫⁫‎‭‭‍‎⁯⁬⁮⁬⁭‬⁬⁪‏⁪‬​‏‬⁭‌‮​‫​⁮‏‎‪‫⁪‏​‎⁯‮⁬‮ = new Queue<string>();
  private static readonly Dictionary<string, string> \u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮;

  public void CaptchaIsFalse()
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3364398700U));
  }

  public string Solve(string url)
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2648138095U));
label_1:
    int num1 = 1049766482;
    string key;
    string str1;
    string str2;
    string str3;
    SelectedMode selectedMode;
    int num2;
    string str4;
    \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮ obj;
    string str5;
    while (true)
    {
      uint num3;
      switch ((num3 = (uint) (num1 ^ 949900159)) % 24U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_31;
        case 2:
          str3 = "";
          str2 = "";
          num1 = (int) num3 * 207251838 ^ -1880818640;
          continue;
        case 3:
          str5 = obj.\u200B‬‏‪‮‭‫‎⁯‫‬⁪⁫⁮⁫‭⁫⁪​⁬⁭⁯⁯‫‌⁪​⁫‏⁭⁪⁫⁪⁪‪‬‭⁬‍⁭‮(str1);
          num1 = (int) num3 * 983952806 ^ -92482276;
          continue;
        case 4:
          str2 = ConfigController.AnticapConfig.AnticaptchaKey;
          num1 = (int) num3 * -1146345867 ^ 1371382018;
          continue;
        case 5:
          obj = new \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮(str3, str2);
          num1 = 81966060;
          continue;
        case 6:
          key = num2.ToString();
          num1 = (int) num3 * 717524277 ^ 671761918;
          continue;
        case 7:
          Thread.Sleep(1000);
          num1 = 919003532;
          continue;
        case 8:
          num1 = (int) num3 * -156977876 ^ 1091005004;
          continue;
        case 9:
          System.IO.File.Delete(str1);
          str4 = (string) null;
          num1 = (int) num3 * 261301010 ^ 144169372;
          continue;
        case 10:
label_9:
          \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200E‫⁫‎‭‭‍‎⁯⁬⁮⁬⁭‬⁬⁪‏⁪‬​‏‬⁭‌‮​‫​⁮‏‎‪‫⁪‏​‎⁯‮⁬‮.Enqueue(key);
          bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024.\u200B​⁭‌‏‎⁭‏‮⁯⁭​⁮‍‮‍⁫‬‏‪‭‏‪‎‏‭‌​⁯‮‍‌‌‮​​​‍‮⁮‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4218223359U));
          num1 = 1851609519;
          continue;
        case 11:
          selectedMode = ConfigController.AnticapConfig.SelectedMode;
          num1 = (int) num3 * -163065910 ^ -523469941;
          continue;
        case 12:
          num1 = (int) num3 * 162577515 ^ -682874834;
          continue;
        case 13:
          num2 = \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u202E⁯‎‌⁯‫‪⁯‭⁫⁮⁭​‪‌‌⁫‎‬⁯‫⁪‎⁬‍‬‫⁯⁪‏‍⁬‪‎‪‪‭‌⁮‫‮(\u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200C‬‪‎⁪‌⁮‎‭​‬‏‮⁭​⁯‬⁬⁫⁫‪​‏⁭‭‫‭‏‏‪⁫⁭⁯​‭‏⁭‎⁫⁪‮());
          num1 = (int) num3 * 1425149129 ^ -1651809428;
          continue;
        case 14:
label_15:
          str3 = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4076588642U);
          num1 = 1143121424;
          continue;
        case 15:
          str1 = string.Format(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3780659842U), (object) key);
          num1 = (int) num3 * -543558747 ^ -1535434740;
          continue;
        case 16 /*0x10*/:
          new WebClient().DownloadFile(url, str1);
          num1 = (int) num3 * 1126242377 ^ 1102479269;
          continue;
        case 17:
          num1 = (int) num3 * -1193208153 ^ 490168117;
          continue;
        case 18:
          switch (selectedMode)
          {
            case SelectedMode.Rucaptcha:
              goto label_15;
            case SelectedMode.Anticaptcha:
              goto label_5;
            case SelectedMode.Manual:
              goto label_9;
            default:
              num1 = (int) num3 * 975172091 ^ -1996704811;
              continue;
          }
        case 19:
          int num4;
          num1 = num4 = !\u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮.ContainsKey(key) ? 699736032 : (num4 = 2083133835);
          continue;
        case 20:
          goto label_14;
        case 22:
label_5:
          str3 = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3890824203U);
          num1 = 807007491;
          continue;
        case 23:
          str2 = ConfigController.AnticapConfig.RucaptchaKey;
          num1 = (int) num3 * 2108255648 ^ -987290366;
          continue;
        default:
          goto label_25;
      }
    }
label_14:
    string str6 = \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮[key];
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮.Remove(key);
    return str6;
label_25:
    Thread.Sleep(1000);
    try
    {
      str4 = obj.\u206F‫⁬⁯‏‏‪⁭⁫‫⁯⁮‬⁪⁭⁬⁫⁮⁫‎‫​‭‏⁪‌‪‎‬⁬⁭⁮⁪‪‎⁪‌⁪‪‬‮(str5);
    }
    catch (Exception ex)
    {
      if (!ex.Message.Contains(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1781608750U)))
      {
label_28:
        int num5 = 1923779153;
        while (true)
        {
          uint num6;
          switch ((num6 = (uint) (num5 ^ 949900159)) % 3U)
          {
            case 0:
              goto label_28;
            case 2:
              \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1200235973U) + ex.Message);
              num5 = (int) num6 * 419645904 ^ 2026711060;
              continue;
            default:
              goto label_31;
          }
        }
      }
    }
label_31:
    if (!string.IsNullOrEmpty(str4))
      return str4;
    goto label_25;
  }

  public static void \u200B​‭⁮⁯‎‌‌⁬⁯‪‬‪‎‍‭⁬‎‬‮‮‪⁮⁭‭‎⁫⁯‭⁫⁪‪‎⁬‍​⁫‍‬⁭‮(string _param0, string _param1)
  {
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮.Add(_param0, _param1);
  }

  static \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮()
  {
label_1:
    int num1 = 693205703;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1546438603)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮.\u200F⁬‬‪‌⁬⁫⁫‭‏⁪⁯‎​⁯⁪‮‏​‍‪‌‌‌⁬‎‏⁯⁪‪⁬‪⁫‫‬‏‪‍​‎‮ = new Dictionary<string, string>();
          num1 = (int) num2 * 659219808 ^ 2048177039;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  static Random \u200C‬‪‎⁪‌⁮‎‭​‬‏‮⁭​⁯‬⁬⁫⁫‪​‏⁭‭‫‭‏‏‪⁫⁭⁯​‭‏⁭‎⁫⁪‮() => new Random();

  static int \u202E⁯‎‌⁯‫‪⁯‭⁫⁮⁭​‪‌‌⁫‎‬⁯‫⁪‎⁬‍‬‫⁯⁪‏‍⁬‪‎‪‪‭‌⁮‫‮([In] Random obj0) => obj0.Next();
}
