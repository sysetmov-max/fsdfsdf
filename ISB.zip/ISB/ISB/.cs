﻿// Decompiled with JetBrains decompiler
// Type: ‌‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;

#nullable disable
internal abstract class \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
{
  protected \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮ \u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮;

  public abstract void \u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(Account _param1);

  public abstract void \u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮();
}
