﻿// Decompiled with JetBrains decompiler
// Type: ‍‏⁭⁮‎‍‫‍‭⁪‍‮​⁬⁬⁪‍‫‪⁬⁪⁮‪⁬‪⁯⁭⁪⁯‫‎‭⁫‮​‌‭⁮⁭‮‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
[CompilerGenerated]
internal sealed class \u200D‏⁭⁮‎‍‫‍‭⁪‍‮​⁬⁬⁪‍‫‪⁬⁪⁮‪⁬‪⁯⁭⁪⁯‫‎‭⁫‮​‌‭⁮⁭‮‮
{
  internal static uint \u206E⁯‪⁪⁫‌‪‪‮⁬⁮⁬‪⁭‬‍‬‫‮‫‪‭‬⁪‌⁪⁪‬‮⁫⁮​‫​‍⁫⁮​‪‮(string _param0)
  {
    uint num1;
    if (_param0 != null)
    {
label_1:
      int num2 = 869348513;
      int num3;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num2 ^ 625163938)) % 8U)
        {
          case 0:
            // ISSUE: reference to a compiler-generated method
            num1 = (uint) (((int) \u200D‏⁭⁮‎‍‫‍‭⁪‍‮​⁬⁬⁪‍‫‪⁬⁪⁮‪⁬‪⁯⁭⁪⁯‫‎‭⁫‮​‌‭⁮⁭‮‮.\u202D‍‮‭‮⁬⁭⁭⁪‍⁫‌‎⁫‫⁪‪⁯⁮‭​⁫‪‍‭‬⁪​‮⁮‏⁯​⁬⁯‏​‌‮‎‮(_param0, num3) ^ (int) num1) * 16777619);
            num2 = 1975074933;
            continue;
          case 1:
            num3 = 0;
            num2 = (int) num4 * 1203118808 ^ 761841812;
            continue;
          case 2:
            int num5;
            // ISSUE: reference to a compiler-generated method
            num2 = num5 = num3 >= \u200D‏⁭⁮‎‍‫‍‭⁪‍‮​⁬⁬⁪‍‫‪⁬⁪⁮‪⁬‪⁯⁭⁪⁯‫‎‭⁫‮​‌‭⁮⁭‮‮.\u206A‭⁯⁭⁪⁮‎‭⁮‏⁯‎​⁮​⁬‍‍⁬‭⁭⁭‍⁪‍‎⁬⁯‪‪‮‮​‭‎⁯‏‏‬‮(_param0) ? 193184222 : (num5 = 2010439338);
            continue;
          case 3:
            num1 = 2166136261U;
            num2 = (int) num4 * -2073426167 ^ 1855017400;
            continue;
          case 5:
            goto label_1;
          case 6:
            num2 = (int) num4 * 48220048 ^ -1686925960;
            continue;
          case 7:
            ++num3;
            num2 = (int) num4 * 1327549303 ^ 50870377;
            continue;
          default:
            goto label_9;
        }
      }
    }
label_9:
    return num1;
  }

  static char \u202D‍‮‭‮⁬⁭⁭⁪‍⁫‌‎⁫‫⁪‪⁯⁮‭​⁫‪‍‭‬⁪​‮⁮‏⁯​⁬⁯‏​‌‮‎‮([In] string obj0, [In] int obj1)
  {
    return obj0[obj1];
  }

  static int \u206A‭⁯⁭⁪⁮‎‭⁮‏⁯‎​⁮​⁬‍‍⁬‭⁭⁭‍⁪‍‎⁬⁯‪‪‮‮​‭‎⁯‏‏‬‮([In] string obj0) => obj0.Length;
}
