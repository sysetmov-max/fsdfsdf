﻿// Decompiled with JetBrains decompiler
// Type: ‫‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.IO;
using System.Net;
using System.Runtime.InteropServices;

#nullable disable
internal static class \u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮
{
  public static string \u206F​⁬⁮‪‎⁬‎⁯‬‎‏‎‍‏⁮⁫‮‌​⁬⁭‬‏‎‬‫‎​⁮‌‎‌‍‏⁮‬‏‫‫‮(string _param0)
  {
    return \u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u206E‪⁬‌‪⁪⁮​⁫‪⁫⁭⁭‫‫⁫‮‍⁪‪⁮‍‬‫⁭⁬⁬‪⁭⁪‮⁭‍⁮‪⁬⁮‫⁫⁭‮((TextReader) \u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u200C‮‏⁬⁭‎‎‫⁭‭⁮‎⁪‬‍⁮​⁫‫‫‪⁯‌‍‍‌⁬​⁭⁪⁯⁮‍‬⁮‎⁮⁮⁪⁫‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u202D‌⁮‍‌⁫‭‌​​‫⁫‮‪‭‫‭‏⁪⁮‏⁪⁬‪‍‏⁬⁫⁬⁬⁪⁮⁬⁭‮‎‎‎​‎‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u202B⁯⁬‍‪‮‭⁫⁬⁭⁯‫⁬‫⁬‭‫‪‎⁭‬‫⁭⁬‍⁯‏‪​‍‭⁪‮‬‫‌‪‎⁭‮‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u200E⁪‌‬‬‭‫⁫​⁮‫⁬‬⁮⁭‏‫‬‪⁯‫⁪‫⁮‏‬‫‌‍⁭⁬‎⁬‏‫⁭⁪⁭‭⁮‮(_param0)))));
  }

  static WebRequest \u200E⁪‌‬‬‭‫⁫​⁮‫⁬‬⁮⁭‏‫‬‪⁯‫⁪‫⁮‏‬‫‌‍⁭⁬‎⁬‏‫⁭⁪⁭‭⁮‮([In] string obj0)
  {
    return WebRequest.Create(obj0);
  }

  static WebResponse \u202B⁯⁬‍‪‮‭⁫⁬⁭⁯‫⁬‫⁬‭‫‪‎⁭‬‫⁭⁬‍⁯‏‪​‍‭⁪‮‬‫‌‪‎⁭‮‮([In] WebRequest obj0)
  {
    return obj0.GetResponse();
  }

  static Stream \u202D‌⁮‍‌⁫‭‌​​‫⁫‮‪‭‫‭‏⁪⁮‏⁪⁬‪‍‏⁬⁫⁬⁬⁪⁮⁬⁭‮‎‎‎​‎‮([In] WebResponse obj0)
  {
    return obj0.GetResponseStream();
  }

  static StreamReader \u200C‮‏⁬⁭‎‎‫⁭‭⁮‎⁪‬‍⁮​⁫‫‫‪⁯‌‍‍‌⁬​⁭⁪⁯⁮‍‬⁮‎⁮⁮⁪⁫‮([In] Stream obj0)
  {
    return new StreamReader(obj0);
  }

  static string \u206E‪⁬‌‪⁪⁮​⁫‪⁫⁭⁭‫‫⁫‮‍⁪‪⁮‍‬‫⁭⁬⁬‪⁭⁪‮⁭‍⁮‪⁬⁮‫⁫⁭‮([In] TextReader obj0)
  {
    return obj0.ReadToEnd();
  }
}
