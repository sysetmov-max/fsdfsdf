﻿// Decompiled with JetBrains decompiler
// Type: ​⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;

#nullable disable
public class \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮
{
  private Dictionary<string, string> \u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮;

  public Dictionary<string, string> \u206A‏‪⁫​⁭⁭⁬⁬‭‌‍⁪‮‮⁯⁯‏‍​‭‪⁫⁫​⁫‭‏‌⁬‭⁪‎⁫⁮‪⁭⁮⁫‎‮
  {
    get => this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮;
  }

  public NameValueCollection \u202B‭⁮‎​⁪​‪‌‫‫⁮⁭​‫‎‍‏‬⁯⁪​⁭⁭⁬‫⁯‭​⁮‮‫​‫‎⁪‮​‍‎‮()
  {
    NameValueCollection nameValueCollection = \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮.\u202A⁪‎‭⁯‍‭‫‍‮‪⁭⁫​⁮⁭‫‭‏‭⁭‭‭⁮⁮‮⁯⁬​‎‌‮‏‌‎‭‍⁫‍⁯‮();
    using (Dictionary<string, string>.Enumerator enumerator = this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮.GetEnumerator())
    {
label_5:
      int num1 = !enumerator.MoveNext() ? 12332848 : (num1 = 1564752213);
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1350013230)) % 4U)
        {
          case 0:
            num1 = 1564752213;
            continue;
          case 1:
            goto label_5;
          case 3:
            KeyValuePair<string, string> current = enumerator.Current;
            \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮.\u206C⁬⁬⁭‬‌⁮⁪‌‫‍‬⁯⁬‭⁭⁮‎⁮​⁫‮‎‏⁭‎⁮‬‬​⁪⁫‭‪‌‍⁪‬‌‮‮(nameValueCollection, current.Key, current.Value);
            num1 = 256016351;
            continue;
          default:
            goto label_7;
        }
      }
    }
label_7:
    return nameValueCollection;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮()
  {
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮ = new Dictionary<string, string>();
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u202A‬⁬‭⁮‍⁭⁭⁫‏⁯⁮‮‏⁭‎‪‫‎‎⁭‎‭⁮‫⁭‪‪‏‫‎‭⁫‎⁮⁪‫‬‍‭‮(
    bool _param1)
  {
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2588106044U)] = _param1 ? \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2201855314U) : \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1887261198U);
    return this;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u202A‬⁭‎‎‫⁮​⁭‪‫⁭​‪‍‪‮⁫⁬‫‮⁭⁭‏⁪⁮⁮‎‎‭‏‪‏⁮⁬⁭‪‏‫⁬‮(
    bool _param1)
  {
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1314123964U)] = _param1 ? \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3701343339U) : \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1376291497U);
    return this;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u206A‎⁯⁪‪⁪‪​​‪‌‬⁮‮‭‫‪‭‬‌‍⁮‭⁭⁭⁮‪​‍⁫⁬‬⁫‌⁭‌⁮‭‫‪‮(
    bool _param1)
  {
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3576242316U)] = _param1 ? \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3571928110U) : \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3672053581U);
    return this;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u200D‭‎⁪‬‬‌⁮⁯‏⁪‫‏‪​​⁬⁮‏⁮‏‏⁫​‍⁬⁯⁫⁫‌⁪‭‬‎‍‎‏⁯‍‮(
    \u202E‪‍‌⁪‮‪⁭‌⁪‎⁯⁭​‬⁫⁪⁬‌‭⁫‫⁫‮​‭‭‎⁬⁫⁪⁬‏‍⁬‪⁪‪⁮‮‮ _param1)
  {
    if (_param1 != \u202E‪‍‌⁪‮‪⁭‌⁪‎⁯⁭​‬⁫⁪⁬‌‭⁫‫⁫‮​‭‭‎⁬⁫⁪⁬‏‍⁬‪⁪‪⁮‮‮.Default)
      goto label_4;
label_1:
    int num1 = 1991021321;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 847954780)) % 5U)
      {
        case 0:
          goto label_4;
        case 1:
          this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮.Remove(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(25898787U));
          num1 = (int) num2 * 689375184 ^ 1624900221;
          continue;
        case 2:
          goto label_1;
        case 3:
          num1 = (int) num2 * 224409412 ^ -1277485612;
          continue;
        default:
          goto label_6;
      }
    }
label_6:
    return this;
label_4:
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2357594228U)] = ((int) _param1).ToString();
    num1 = 2137138640;
    goto label_2;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u202E‌‌‫⁮‭‫‌​‌‫⁭‏‎‌‏⁭⁬‍‏​⁯⁮⁯‮‭‏‬​⁮‪‍​‍⁬‫‮‏⁪‭‮(
    int? _param1)
  {
    if (!_param1.HasValue)
      goto label_10;
label_1:
    int num1 = -1909674082;
label_2:
    while (true)
    {
      uint num2;
      int? nullable;
      int num3;
      switch ((num2 = (uint) (num1 ^ -52928785)) % 9U)
      {
        case 0:
label_4:
          this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2687899109U)] = _param1.Value.ToString();
          num1 = -1175285828;
          continue;
        case 1:
          int num4 = _param1.Value >= 1 ? 631526250 : (num4 = 1057914559);
          num1 = num4 ^ (int) num2 * -1732337955;
          continue;
        case 2:
          num3 = 0;
          break;
        case 3:
          nullable = _param1;
          num1 = (int) num2 * 271801586 ^ -304117867;
          continue;
        case 5:
          goto label_1;
        case 6:
          goto label_3;
        case 7:
          goto label_10;
        case 8:
          int num5 = 20;
          if (nullable.GetValueOrDefault() > num5)
          {
            num3 = nullable.HasValue ? 1 : 0;
            break;
          }
          num1 = (int) num2 * -502738321 ^ 1936644855;
          continue;
        default:
          goto label_14;
      }
      if (num3 != 0)
        num1 = -1957146062;
      else
        goto label_4;
    }
label_3:
    throw \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮.\u200B‏‮‭‫‏‬‬‪⁮‮⁯‪⁬‫‪‬⁪⁯⁮‏‬⁮⁫⁮‍⁯‪‫‪⁮‪‫‫‮‬‬‬‎⁬‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(680721396U), (object) _param1.Value, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1341480358U));
label_14:
    return this;
label_10:
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮.Remove(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3150369055U));
    num1 = -1175285828;
    goto label_2;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u200C‏⁫⁯⁬⁮⁪⁯​‍‭⁮⁫‍‏⁯‏‎⁮‮⁭‪‫‭‎⁫​‏⁭⁪‌‬⁭‌⁫⁭‪⁯‫‮(
    int? _param1)
  {
    if (!_param1.HasValue)
      goto label_11;
label_1:
    int num1 = 303528296;
label_2:
    while (true)
    {
      uint num2;
      int? nullable;
      int num3;
      int num4;
      switch ((num2 = (uint) (num1 ^ 1510884734)) % 10U)
      {
        case 0:
          goto label_11;
        case 1:
          num1 = (int) num2 * 1866863201 ^ 2016172510;
          continue;
        case 2:
          goto label_1;
        case 3:
          num4 = 0;
          break;
        case 4:
          int num5 = _param1.Value < 1 ? -886125241 : (num5 = -1637507798);
          num1 = num5 ^ (int) num2 * -616179504;
          continue;
        case 5:
          goto label_5;
        case 6:
          if (nullable.GetValueOrDefault() <= num3)
          {
            num1 = (int) num2 * -1048616503 ^ -1387784017;
            continue;
          }
          num4 = nullable.HasValue ? 1 : 0;
          break;
        case 7:
label_12:
          Dictionary<string, string> dictionary = this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮;
          string key = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(697037127U);
          num3 = _param1.Value;
          string str = num3.ToString();
          dictionary[key] = str;
          num1 = 327581999;
          continue;
        case 8:
          nullable = _param1;
          num3 = 20;
          num1 = (int) num2 * 783143348 ^ 1571683340;
          continue;
        default:
          goto label_15;
      }
      if (num4 != 0)
        num1 = 672115879;
      else
        goto label_12;
    }
label_5:
    throw \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮.\u200B‏‮‭‫‏‬‬‪⁮‮⁯‪⁬‫‪‬⁪⁯⁮‏‬⁮⁫⁮‍⁯‪‫‪⁮‪‫‫‮‬‬‬‎⁬‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2808705082U), (object) _param1.Value, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1832491908U));
label_15:
    return this;
label_11:
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮.Remove(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4269814814U));
    num1 = 1072319855;
    goto label_2;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u202E‬‮⁬⁪‏‫‏⁬⁭⁯‪⁭‎‏‬‫⁫⁫⁪⁬⁫‬‎⁭⁯‮⁮⁬‪‬⁪‌‌‎‌⁫‭​⁫‮(
    \u206E⁯⁪‌‌‭⁫​‮⁯⁪⁬‭‬‬⁫⁪⁭‮‎‌‏⁬‌⁯⁫‬‫⁯‎‭​‪​⁫‭‬⁬‏⁭‮ _param1)
  {
    if (_param1 != \u206E⁯⁪‌‌‭⁫​‮⁯⁪⁬‭‬‬⁫⁪⁭‮‎‌‏⁬‌⁯⁫‬‫⁯‎‭​‪​⁫‭‬⁬‏⁭‮.Default)
      goto label_3;
label_1:
    int num1 = -803222086;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -2011341992)) % 5U)
      {
        case 0:
          num1 = (int) num2 * 489624789 ^ -699660732;
          continue;
        case 1:
          this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮.Remove(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1578742022U));
          num1 = (int) num2 * 1668310912 ^ -59054085;
          continue;
        case 2:
          goto label_1;
        case 4:
          goto label_3;
        default:
          goto label_6;
      }
    }
label_6:
    return this;
label_3:
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1136273360U)] = ((int) _param1).ToString();
    num1 = -2037766949;
    goto label_2;
  }

  public \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ \u202E‏⁯‪‏⁭‫‬⁮‭‎‌‌⁬⁬⁯‮​‌‏⁮‮‎‪⁪‮⁯‏⁯‫‌⁪‭⁪​⁭⁬​⁮⁭‮(
    string _param1)
  {
    this.\u206E⁬⁭‬⁪‪‍‏⁪‏‏⁯‍​‮‭‬‏⁪⁫‭‭‫⁪‏⁬‪‌‬‎‌⁫‮⁭‭‏‭‫⁫‫‮[\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(461811698U)] = _param1;
    return this;
  }

  static NameValueCollection \u202A⁪‎‭⁯‍‭‫‍‮‪⁭⁫​⁮⁭‫‭‏‭⁭‭‭⁮⁮‮⁯⁬​‎‌‮‏‌‎‭‍⁫‍⁯‮()
  {
    return new NameValueCollection();
  }

  static void \u206C⁬⁬⁭‬‌⁮⁪‌‫‍‬⁯⁬‭⁭⁮‎⁮​⁫‮‎‏⁭‎⁮‬‬​⁪⁫‭‪‌‍⁪‬‌‮‮(
    [In] NameValueCollection obj0,
    [In] string obj1,
    [In] string obj2)
  {
    obj0.Add(obj1, obj2);
  }

  static ArgumentOutOfRangeException \u200B‏‮‭‫‏‬‬‪⁮‮⁯‪⁬‫‪‬⁪⁯⁮‏‬⁮⁫⁮‍⁯‪‫‪⁮‪‫‫‮‬‬‬‎⁬‮(
    [In] string obj0,
    [In] object obj1,
    [In] string obj2)
  {
    return new ArgumentOutOfRangeException(obj0, obj1, obj2);
  }
}
