﻿// Decompiled with JetBrains decompiler
// Type: ​⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using ISP.Engine.Accounts;
using ISP.Tasks.Settings;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using VkNet;
using VkNet.Categories;
using VkNet.Enums.Filters;
using VkNet.Enums.SafetyEnums;
using VkNet.Model;

#nullable disable
internal sealed class \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮ : 
  \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
{
  private Dictionary<string, string> \u206B​‏⁮‎⁫‮‫‌‪‍‌‎‌⁫​⁪‬‮​​⁯‍‍⁯⁭⁬⁮‏⁪⁯‬⁮⁭‍‭‎‫‎‮;

  private string \u206A‫‏⁯‌​⁫‌⁪​⁫‫⁫‌⁮‮‭⁫⁬‪​‭‪​‏‎⁭⁮​‎‪​⁪‬‬‮⁯‏⁫‬‮(
    Account _param1,
    long _param2,
    string _param3)
  {
    if (!this.\u206B​‏⁮‎⁫‮‫‌‪‍‌‎‌⁫​⁪‬‮​​⁯‍‍⁯⁭⁬⁮‏⁪⁯‬⁮⁭‍‭‎‫‎‮.Keys.Contains<string>(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁪‎⁮‏⁬⁪‮‌‏‪⁮⁪⁫⁫‎‎‮‌‎⁫⁬‏‫⁬⁭‮‬‏⁪⁭⁭‫⁪⁫⁭‏‫​‭‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3874287036U), (object) _param2, (object) _param3)))
      goto label_4;
label_1:
    int num1 = 776577541;
label_2:
    string str;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1811527855)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_5;
        case 3:
          _param3 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F⁬‮‎‭‌‪⁬​⁬‪‬‭⁯​‫⁮⁫​⁪⁮‮‎‭⁮⁬⁫‭‌⁫⁪​⁮⁬‮‫‌⁬‎⁪‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2296218463U), (object) _param3);
          VkApi vkApi = _param1.VkApi;
          WebClient webClient = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206B⁪⁬⁪⁪⁮‫‫⁭‪⁬⁯‪‪‌⁭‮‎‭⁭​‎‬​⁯‏‍‏​​⁮‫⁫⁭⁫‪⁯⁫‭‏‮();
          UploadServerInfo uploadServerInfo = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B⁭‭‫‏​⁫​‭‬‪⁫‌⁫‬‎​‫‍‫​⁪‍⁯⁫​⁬⁮‌⁯‍‪‏‬⁬⁫⁪⁭‮⁬‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200D⁬⁬‫⁮⁯‮⁮‌‫⁯⁮‌‏⁮⁫‭‏‌⁮⁫‮⁯‮‪⁭​‬⁯⁬‏‏⁯⁬⁮⁬‏‏⁪‍‮(vkApi), (ulong) _param2, new ulong?(), new ulong?(), new ulong?());
          str = JsonConvert.DeserializeObject<Dictionary<string, string>>(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202D‌⁭⁭‏⁬⁮‮⁪‏⁯⁯⁯⁭‬‫‏⁪⁮⁮⁬‎‌​‌​⁭‌⁬‌⁬‮‭‏⁬‌⁬‫‎‌‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202D‭‌‌⁭⁮⁭‮‍⁬‌‌⁭‫⁫‭⁫‫⁫⁬​‪⁭⁬⁯‭‏‫‭⁫‌⁬⁭⁫⁪⁯‪‪⁬‬‮(), \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206D‫⁮⁫‍‍‮⁯⁯⁫⁮‪‏⁭⁬‭‬‎‭⁬‎⁪⁮‫‎⁭⁯⁪‫‏⁬⁫‬‏​‮⁬⁪‍‭‮(webClient, \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200D‎‏⁯⁬⁪‫⁭‍​⁮‏‮‍‬​⁪⁭‏‪‎‏⁬⁮‮‍‬‮‫‬‌‪‭‬‍⁬⁮‫⁪‎‮(uploadServerInfo), _param3)))[\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2104295230U)];
          num1 = (int) num2 * 1537547317 ^ -520395545;
          continue;
        case 4:
          goto label_4;
        default:
          goto label_6;
      }
    }
label_5:
    return this.\u206B​‏⁮‎⁫‮‫‌‪‍‌‎‌⁫​⁪‬‮​​⁯‍‍⁯⁭⁬⁮‏⁪⁯‬⁮⁭‍‭‎‫‎‮[\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁪‎⁮‏⁬⁪‮‌‏‪⁮⁪⁫⁫‎‎‮‌‎⁫⁬‏‫⁬⁭‮‬‏⁪⁭⁭‫⁪⁫⁭‏‫​‭‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(671166889U), (object) _param2, (object) _param3)];
label_6:
    this.\u206B​‏⁮‎⁫‮‫‌‪‍‌‎‌⁫​⁪‬‮​​⁯‍‍⁯⁭⁬⁮‏⁪⁯‬⁮⁭‍‭‎‫‎‮[\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁪‎⁮‏⁬⁪‮‌‏‪⁮⁪⁫⁫‎‎‮‌‎⁫⁬‏‫⁬⁭‮‬‏⁪⁭⁭‫⁪⁫⁭‏‫​‭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3089053762U), (object) _param2, (object) _param3)] = str;
    return str;
label_4:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F⁬‮‎‭‌‪⁬​⁬‪‬‭⁯​‫⁮⁫​⁪⁮‮‎‭⁮⁬⁫‭‌⁫⁪​⁮⁬‮‫‌⁬‎⁪‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1927748233U), (object) _param3));
    num1 = 773048584;
    goto label_2;
  }

  private void \u200C‮⁪‏⁯⁫‭‎‍‎⁯⁯​‏‪⁭⁪‫⁫⁬‍⁯‎⁬‮‮⁮⁭‫‏⁫⁯‮‎‌‏⁫⁭‎⁯‮(Account _param1, ChatsTarget _param2)
  {
    VkApi vkApi = _param1.VkApi;
label_1:
    int num1 = 1809433251;
    Chat chat;
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ obj;
    string titleMode;
    ChatsTaskSettings chatsTaskSettings;
    string title;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 40295481)) % 32U /*0x20*/)
      {
        case 0:
          int num3 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F‏‌‬⁬‭‭⁮‪⁪⁬‬⁮⁬‭‮​⁬‍‬⁪‏‮⁫‪‏⁪‪‪⁬‮‎⁬⁬‭⁯‮‏⁬⁭‮(chat) != null ? 1713318624 : (num3 = 2105459247);
          num1 = num3 ^ (int) num2 * -1846157186;
          continue;
        case 1:
          int num4 = !ConfigController.AntikickConfig.LeavedIntentionallyFrom.ContainsKey(_param1.Login) ? 761900698 : (num4 = 1620420235);
          num1 = num4 ^ (int) num2 * -1148226353;
          continue;
        case 2:
          int num5;
          num1 = num5 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206E‮⁫‬‪‌⁮⁬‏‌‭‭⁮‍‌‪‌​⁮‎‫⁯⁬‌⁭‍‎⁯‫‏⁭‮⁬⁮⁬‪‏⁬⁪‬‮(_param2.Title, \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200E‫⁯⁯‏‪⁫‫⁭⁬⁭⁮‪​⁮‎⁬‏⁮⁫‬‫‎⁫‪​‬⁭​‬⁪⁮‪‫‍‏⁮‭​⁭‮(chat)) ? 1855766313 : (num5 = 1516207743);
          continue;
        case 3:
          goto label_16;
        case 4:
          goto label_3;
        case 5:
          title = chatsTaskSettings.GetTitle(_param1, _param2);
          num1 = 1379688876;
          continue;
        case 6:
          int num6;
          num1 = num6 = ConfigController.AntikickConfig.LeavedIntentionallyFrom != null ? 1566113432 : (num6 = 817126069);
          continue;
        case 7:
          int num7 = !\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200D‎‭⁯‌‫‎‮‭‬‎‎​‎‏‭‏‍‫⁯‮‮⁮‬⁫⁭‌‪⁪‫⁭‮⁫⁭‍⁮⁮⁫‮‮‮(titleMode, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1024371865U)) ? -884504968 : (num7 = -868616980);
          num1 = num7 ^ (int) num2 * 1933864688;
          continue;
        case 8:
          goto label_10;
        case 9:
          int num8;
          num1 = num8 = !_param2.FloodWithAvatar ? 2136258649 : (num8 = 1543480687);
          continue;
        case 10:
          int num9 = ConfigController.AntikickConfig.LeavedIntentionallyFrom[_param1.Login].Contains(obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value) ? 987574360 : (num9 = 1586907900);
          num1 = num9 ^ (int) num2 * 36030555;
          continue;
        case 11:
          chat = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B‎‪‏‍​⁮‍‌‏​‫‮⁫‌‬⁫‍‫‫‬⁭​⁫⁫‍‍‬⁯‍⁪⁪⁭⁮⁯‫‫⁯‌‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮(vkApi), obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value, (ProfileFields) null, (NameCase) null);
          titleMode = _param2.TitleMode;
          num1 = 1955707910;
          continue;
        case 12:
          int num10;
          num1 = num10 = !\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206E‮⁫‬‪‌⁮⁬‏‌‭‭⁮‍‌‪‌​⁮‎‫⁯⁬‌⁭‍‎⁯‫‏⁭‮⁬⁮⁬‪‏⁬⁪‬‮(_param2.AvatarMode, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2442314891U)) ? 1890133684 : (num10 = 1040882341);
          continue;
        case 13:
          goto label_23;
        case 14:
          goto label_1;
        case 15:
          goto label_21;
        case 16 /*0x10*/:
          \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B‭‮‬‌⁮⁮⁮⁪⁫‍‎‍‎‍‌‎⁫​‮‍‎‪⁭⁭‏‫⁭⁬‍‭‏⁫‌⁪⁫⁪‪‮‪‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮(vkApi), \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁯‪‬⁪⁪​⁬⁭⁫‭⁬⁬⁫‌‍‌⁫⁫‮‎‌‪⁪‪‎⁬‏⁫⁯⁭⁪‭‫⁫‏‪‫⁪⁪‮(chat), _param2.Title);
          num1 = (int) num2 * -849163897 ^ -1850821873;
          continue;
        case 17:
          num1 = (int) num2 * 1873254426 ^ -1898139835;
          continue;
        case 18:
          \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B‭‮‬‌⁮⁮⁮⁪⁫‍‎‍‎‍‌‎⁫​‮‍‎‪⁭⁭‏‫⁭⁬‍‭‏⁫‌⁪⁫⁪‪‮‪‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮(vkApi), \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁯‪‬⁪⁪​⁬⁭⁫‭⁬⁬⁫‌‍‌⁫⁫‮‎‌‪⁪‪‎⁬‏⁫⁯⁭⁪‭‫⁫‏‪‫⁪⁪‮(chat), title);
          num1 = (int) num2 * 1809807240 ^ -650370321;
          continue;
        case 19:
          chatsTaskSettings = _param1.ChatsTaskSettings;
          int num11 = obj.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ != \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.NotFound ? 420353053 : (num11 = 2010872545);
          num1 = num11 ^ (int) num2 * -48280524;
          continue;
        case 20:
          goto label_4;
        case 21:
          int num12 = title != null ? -1902619711 : (num12 = -931841739);
          num1 = num12 ^ (int) num2 * -798272606;
          continue;
        case 22:
          long num13;
          _param2.TargetPhoto200 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F‏‌‬⁬‭‭⁮‪⁪⁬‬⁮⁬‭‮​⁬‍‬⁪‏‮⁫‪‏⁪‪‪⁬‮‎⁬⁬‭⁯‮‏⁬⁭‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206B‎‬‏‏⁮⁪‍⁪⁯‫‍⁬‏⁫‭‬‎⁪‏‪​‮⁯‎‍‏‬‭‭⁪‌⁮⁮⁮⁪⁬‪‬⁭‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮(vkApi), ref num13, this.\u206A‫‏⁯‌​⁫‌⁪​⁫‫⁫‌⁮‮‭⁫⁬‪​‭‪​‏‎⁭⁮​‎‪​⁪‬‬‮⁯‏⁫‬‮(_param1, \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁯‪‬⁪⁪​⁬⁭⁫‭⁬⁬⁫‌‍‌⁫⁫‮‎‌‪⁪‪‎⁬‏⁫⁯⁭⁪‭‫⁫‏‪‫⁪⁪‮(chat), _param2.AvatarMode)));
          num1 = 1890133684;
          continue;
        case 23:
          int num14;
          num1 = num14 = ConfigController.AntikickConfig.LeavedIntentionallyFrom != null ? 1525909383 : (num14 = 939949394);
          continue;
        case 24:
          int num15;
          num1 = num15 = obj.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ == \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat ? 749292782 : (num15 = 1750254778);
          continue;
        case 25:
          int num16 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206E‮⁫‬‪‌⁮⁬‏‌‭‭⁮‍‌‪‌​⁮‎‫⁯⁬‌⁭‍‎⁯‫‏⁭‮⁬⁮⁬‪‏⁬⁪‬‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F‏‌‬⁬‭‭⁮‪⁪⁬‬⁮⁬‭‮​⁬‍‬⁪‏‮⁫‪‏⁪‪‪⁬‮‎⁬⁬‭⁯‮‏⁬⁭‮(chat), _param2.TargetPhoto200) ? 2028450277 : (num16 = 1404121662);
          num1 = num16 ^ (int) num2 * -2061991142;
          continue;
        case 26:
          obj = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(_param1, _param2.Link);
          num1 = (int) num2 * 1362741337 ^ -468253184;
          continue;
        case 27:
          int num17 = \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F‏‌‬⁬‭‭⁮‪⁪⁬‬⁮⁬‭‮​⁬‍‬⁪‏‮⁫‪‏⁪‪‪⁬‮‎⁬⁬‭⁯‮‏⁬⁭‮(chat) == null ? 61772511 : (num17 = 1250560738);
          num1 = num17 ^ (int) num2 * -587704003;
          continue;
        case 28:
          int num18 = !\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200D‎‭⁯‌‫‎‮‭‬‎‎​‎‏‭‏‍‫⁯‮‮⁮‬⁫⁭‌‪⁪‫⁭‮⁫⁭‍⁮⁮⁫‮‮‮(_param2.AvatarMode, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(428455459U)) ? -1739807668 : (num18 = -1805611042);
          num1 = num18 ^ (int) num2 * 1208350281;
          continue;
        case 29:
          int num19 = ConfigController.AntikickConfig.LeavedIntentionallyFrom[_param1.Login].Contains(obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value) ? -1905769872 : (num19 = -78921740);
          num1 = num19 ^ (int) num2 * -110215691;
          continue;
        case 30:
          int num20 = !ConfigController.AntikickConfig.LeavedIntentionallyFrom.ContainsKey(_param1.Login) ? -1164862736 : (num20 = -2113643023);
          num1 = num20 ^ (int) num2 * -990825393;
          continue;
        case 31 /*0x1F*/:
          int num21 = !\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200D‎‭⁯‌‫‎‮‭‬‎‎​‎‏‭‏‍‫⁯‮‮⁮‬⁫⁭‌‪⁪‫⁭‮⁫⁭‍⁮⁮⁫‮‮‮(titleMode, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1835422574U)) ? -139729397 : (num21 = -454527538);
          num1 = num21 ^ (int) num2 * 601449483;
          continue;
        default:
          goto label_34;
      }
    }
label_3:
    return;
label_10:
    return;
label_23:
    return;
label_21:
    return;
label_34:
    return;
label_4:
    ulong num22;
    \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206B‏⁫⁬⁪​⁮‫‍⁯⁮‭⁫‍⁫⁬‭‪​⁫‮‭‍‪⁮‌⁫⁭‌‍⁪⁯⁬‎‬​⁬‫⁮‎‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮(vkApi), ref num22, (ulong) \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A⁯‪‬⁪⁪​⁬⁭⁫‭⁬⁬⁫‌‍‌⁫⁫‮‎‌‪⁪‪‎⁬‏⁫⁯⁭⁪‭‫⁫‏‪‫⁪⁪‮(chat));
    return;
label_16:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u206F⁬‮‎‭‌‪⁬​⁬‪‬‭⁯​‫⁮⁫​⁪⁮‮‎‭⁮⁬⁫‭‌⁫⁪​⁮⁬‮‫‌⁬‎⁪‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1250470571U), (object) _param2.Link));
  }

  private void \u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮(Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202C⁬⁫‍⁯⁭‎⁯‭⁭‬‬‏⁮⁪‭‌‮‎⁪‪‏‏‫⁯​‫⁬‬⁮‫‫⁫⁮‪⁬‌⁯‎⁮‮ obj = new \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202C⁬⁫‍⁯⁭‎⁯‭⁭‬‬‏⁮⁪‭‌‮‎⁪‪‏‏‫⁯​‫⁬‬⁮‫‫⁫⁮‪⁬‌⁯‎⁮‮();
label_1:
    int num1 = 1357265526;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 419308948)) % 7U)
      {
        case 0:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj.\u206C⁫⁪‍​‬⁯‍​⁭⁮‬⁯‬‎‮⁪⁫‌⁫⁬⁯‍‭⁪‍⁮‪⁪⁯‍⁫‮‎​‍⁪‫⁭⁭‮ = obj.\u202E‬⁬‮⁮‪‌‮‫‪⁪‪⁬‪⁮‏‭‌‍‏⁫⁬⁬⁮⁫⁯‎‪‪⁫‪‎‍⁮⁭‬⁮⁭⁯⁮‮.Targets;
          // ISSUE: reference to a compiler-generated field
          obj.\u206D⁪‌⁬‌‭‌‍⁯⁭‍‫‏‭‮⁯⁭⁭⁭⁭‬⁯‬⁫‌‍⁯‮‪‭‭‮‮‏‪⁯​⁮‫⁫‮ = -1;
          num1 = (int) num2 * 1660343051 ^ -364771310;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
          num1 = (int) num2 * 700040036 ^ -1796424661;
          continue;
        case 2:
          goto label_3;
        case 3:
          goto label_1;
        case 4:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1;
          num1 = (int) num2 * 1998162222 ^ -1964465390;
          continue;
        case 5:
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated field
          this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = new \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮(new Action(obj.\u206B⁭​⁮‪‏‭‪‫⁪‫‬‏‫‬⁫‌‍‬‮‫⁯⁬​​​‌‎‪⁫‏‪⁮‏‮⁫⁯‬‬‍‮), obj.\u202E‬⁬‮⁮‪‌‮‫‪⁪‪⁬‪⁮‏‭‌‍‏⁫⁬⁬⁮⁫⁯‎‪‪⁫‪‎‍⁮⁭‬⁮⁭⁯⁮‮.Delay);
          num1 = (int) num2 * 1387280610 ^ -1007148873;
          continue;
        case 6:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj.\u202E‬⁬‮⁮‪‌‮‫‪⁪‪⁬‪⁮‏‭‌‍‏⁫⁬⁬⁮⁫⁯‎‪‪⁫‪‎‍⁮⁭‬⁮⁭⁯⁮‮ = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.ChatsTaskSettings;
          num1 = (int) num2 * 1460077599 ^ 1754106268;
          continue;
        default:
          goto label_9;
      }
    }
label_3:
    return;
label_9:;
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(
    Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B‬⁮‫​‎‪‬‍‎⁪⁭⁭⁭⁭⁬‎‪⁯⁯‬⁭‭⁯⁫‬‌‬‮‌‏⁮⁮‭⁪⁯‬‫‎‫‮ obj = new \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202B‬⁮‫​‎‪‬‍‎⁪⁭⁭⁭⁭⁬‎‪⁯⁯‬⁭‭⁯⁫‬‌‬‮‌‏⁮⁮‭⁪⁯‬‫‎‫‮();
    // ISSUE: reference to a compiler-generated field
    obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
label_1:
    int num1 = 993587479;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 771163117)) % 7U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1;
          // ISSUE: reference to a compiler-generated field
          int num3 = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.ChatsTaskSettings.Enabled ? -1218937825 : (num3 = -943823913);
          num1 = num3 ^ (int) num2 * -335119632;
          continue;
        case 3:
          int num4;
          // ISSUE: reference to a compiler-generated field
          num1 = num4 = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.ChatsTaskSettings.Targets.Count == 0 ? 278946086 : (num4 = 2110229231);
          continue;
        case 4:
          goto label_5;
        case 5:
          this.\u206B​‏⁮‎⁫‮‫‌‪‍‌‎‌⁫​⁪‬‮​​⁯‍‍⁯⁭⁬⁮‏⁪⁯‬⁮⁭‍‭‎‫‎‮ = new Dictionary<string, string>();
          // ISSUE: reference to a compiler-generated method
          \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202D⁫‍⁫‮⁮⁪‍‪⁯‏‭⁬⁫‎‏‮⁭⁮⁫⁪⁭‮⁮⁮‫⁮⁪⁮‮‍⁮‏‮‭⁬‌‬‎‫‮(\u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮.\u202A​⁮‫⁭⁯⁯‍‎‍‌⁬⁬‬‌‎⁬⁮⁫‬‪‍‏⁭‎‭‬‏⁯‌⁪‮‍‮‮⁬‪‪‍⁯‮(new Action(obj.\u200E⁭‍‪⁮‍‎⁭‍‍‍‮⁮‮​⁮​⁮​⁮⁫‎​⁯⁫⁫‮​‌⁯‮​‬‏⁯⁬⁮⁬⁮‍‮)));
          num1 = 1981191999;
          continue;
        case 6:
          goto label_6;
        default:
          goto label_9;
      }
    }
label_3:
    return;
label_6:
    return;
label_9:
    return;
label_5:
    // ISSUE: reference to a compiler-generated field
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2330458501U));
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮()
  {
    this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮?.Dispose();
    this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = (\u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮) null;
  }

  static string \u202A⁪‎⁮‏⁬⁪‮‌‏‪⁮⁪⁫⁫‎‎‮‌‎⁫⁬‏‫⁬⁭‮‬‏⁪⁭⁭‫⁪⁫⁭‏‫​‭‮(
    [In] string obj0,
    [In] object obj1,
    [In] object obj2)
  {
    return string.Format(obj0, obj1, obj2);
  }

  static string \u206F⁬‮‎‭‌‪⁬​⁬‪‬‭⁯​‫⁮⁫​⁪⁮‮‎‭⁮⁬⁫‭‌⁫⁪​⁮⁬‮‫‌⁬‎⁪‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static WebClient \u206B⁪⁬⁪⁪⁮‫‫⁭‪⁬⁯‪‪‌⁭‮‎‭⁭​‎‬​⁯‏‍‏​​⁮‫⁫⁭⁫‪⁯⁫‭‏‮() => new WebClient();

  static PhotoCategory \u200D⁬⁬‫⁮⁯‮⁮‌‫⁯⁮‌‏⁮⁫‭‏‌⁮⁫‮⁯‮‪⁭​‬⁯⁬‏‏⁯⁬⁮⁬‏‏⁪‍‮([In] VkApi obj0)
  {
    return obj0.Photo;
  }

  static UploadServerInfo \u202B⁭‭‫‏​⁫​‭‬‪⁫‌⁫‬‎​‫‍‫​⁪‍⁯⁫​⁬⁮‌⁯‍‪‏‬⁬⁫⁪⁭‮⁬‮(
    [In] PhotoCategory obj0,
    [In] ulong obj1,
    [In] ulong? obj2,
    [In] ulong? obj3,
    [In] ulong? obj4)
  {
    return obj0.GetChatUploadServer(obj1, obj2, obj3, obj4);
  }

  static Encoding \u202D‭‌‌⁭⁮⁭‮‍⁬‌‌⁭‫⁫‭⁫‫⁫⁬​‪⁭⁬⁯‭‏‫‭⁫‌⁬⁭⁫⁪⁯‪‪⁬‬‮() => Encoding.ASCII;

  static string \u200D‎‏⁯⁬⁪‫⁭‍​⁮‏‮‍‬​⁪⁭‏‪‎‏⁬⁮‮‍‬‮‫‬‌‪‭‬‍⁬⁮‫⁪‎‮([In] UploadServerInfo obj0)
  {
    return obj0.UploadUrl;
  }

  static byte[] \u206D‫⁮⁫‍‍‮⁯⁯⁫⁮‪‏⁭⁬‭‬‎‭⁬‎⁪⁮‫‎⁭⁯⁪‫‏⁬⁫‬‏​‮⁬⁪‍‭‮(
    [In] WebClient obj0,
    [In] string obj1,
    [In] string obj2)
  {
    return obj0.UploadFile(obj1, obj2);
  }

  static string \u202D‌⁭⁭‏⁬⁮‮⁪‏⁯⁯⁯⁭‬‫‏⁪⁮⁮⁬‎‌​‌​⁭‌⁬‌⁬‮‭‏⁬‌⁬‫‎‌‮([In] Encoding obj0, [In] byte[] obj1)
  {
    return obj0.GetString(obj1);
  }

  static MessagesCategory \u200C‮⁫‭⁮⁭⁭‍‫‍‮‎⁫⁯⁬​⁭⁫​⁭⁮‫‭‫⁯‬‫‍‏⁮⁮‪‍⁪‬⁯⁪‏‍⁯‮([In] VkApi obj0)
  {
    return obj0.Messages;
  }

  static Chat \u202B‎‪‏‍​⁮‍‌‏​‫‮⁫‌‬⁫‍‫‫‬⁭​⁫⁫‍‍‬⁯‍⁪⁪⁭⁮⁯‫‫⁯‌‮(
    [In] MessagesCategory obj0,
    [In] long obj1,
    [In] ProfileFields obj2,
    [In] NameCase obj3)
  {
    return obj0.GetChat(obj1, obj2, obj3);
  }

  static bool \u200D‎‭⁯‌‫‎‮‭‬‎‎​‎‏‭‏‍‫⁯‮‮⁮‬⁫⁭‌‪⁪‫⁭‮⁫⁭‍⁮⁮⁫‮‮‮([In] string obj0, [In] string obj1)
  {
    return obj0 == obj1;
  }

  static string \u200E‫⁯⁯‏‪⁫‫⁭⁬⁭⁮‪​⁮‎⁬‏⁮⁫‬‫‎⁫‪​‬⁭​‬⁪⁮‪‫‍‏⁮‭​⁭‮([In] Chat obj0) => obj0.Title;

  static bool \u206E‮⁫‬‪‌⁮⁬‏‌‭‭⁮‍‌‪‌​⁮‎‫⁯⁬‌⁭‍‎⁯‫‏⁭‮⁬⁮⁬‪‏⁬⁪‬‮([In] string obj0, [In] string obj1)
  {
    return obj0 != obj1;
  }

  static long \u202A⁯‪‬⁪⁪​⁬⁭⁫‭⁬⁬⁫‌‍‌⁫⁫‮‎‌‪⁪‪‎⁬‏⁫⁯⁭⁪‭‫⁫‏‪‫⁪⁪‮([In] Chat obj0) => obj0.Id;

  static bool \u202B‭‮‬‌⁮⁮⁮⁪⁫‍‎‍‎‍‌‎⁫​‮‍‎‪⁭⁭‏‫⁭⁬‍‭‏⁫‌⁪⁫⁪‪‮‪‮(
    [In] MessagesCategory obj0,
    [In] long obj1,
    [In] string obj2)
  {
    return obj0.EditChat(obj1, obj2);
  }

  static string \u206F‏‌‬⁬‭‭⁮‪⁪⁬‬⁮⁬‭‮​⁬‍‬⁪‏‮⁫‪‏⁪‪‪⁬‮‎⁬⁬‭⁯‮‏⁬⁭‮([In] Chat obj0) => obj0.Photo200;

  static Chat \u206B‏⁫⁬⁪​⁮‫‍⁯⁮‭⁫‍⁫⁬‭‪​⁫‮‭‍‪⁮‌⁫⁭‌‍⁪⁯⁬‎‬​⁬‫⁮‎‮(
    [In] MessagesCategory obj0,
    [In] ref ulong obj1,
    [In] ulong obj2)
  {
    return obj0.DeleteChatPhoto(out obj1, obj2);
  }

  static Chat \u206B‎‬‏‏⁮⁪‍⁪⁯‫‍⁬‏⁫‭‬‎⁪‏‪​‮⁯‎‍‏‬‭‭⁪‌⁮⁮⁮⁪⁬‪‬⁭‮(
    [In] MessagesCategory obj0,
    [In] ref long obj1,
    [In] string obj2)
  {
    return obj0.SetChatPhoto(out obj1, obj2);
  }

  static Task \u202A​⁮‫⁭⁯⁯‍‎‍‌⁬⁬‬‌‎⁬⁮⁫‬‪‍‏⁭‎‭‬‏⁯‌⁪‮‍‮‮⁬‪‪‍⁯‮([In] Action obj0) => new Task(obj0);

  static void \u202D⁫‍⁫‮⁮⁪‍‪⁯‏‭⁬⁫‎‏‮⁭⁮⁫⁪⁭‮⁮⁮‫⁮⁪⁮‮‍⁮‏‮‭⁬‌‬‎‫‮([In] Task obj0) => obj0.Start();
}
