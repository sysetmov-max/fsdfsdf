﻿// Decompiled with JetBrains decompiler
// Type: ‍‬⁪‭‭‎⁬⁮⁮⁮‫‍‭‍‮‭⁪‮‍‪‭⁮⁯​‬‫​‏⁮⁪⁭⁬⁪⁭‭‏‍⁭⁪‫‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using System.Collections.Generic;
using VkNet;
using VkNet.Model.Attachments;
using VkNet.Model.RequestParams;

#nullable disable
internal static class \u200D‬⁪‭‭‎⁬⁮⁮⁮‫‍‭‍‮‭⁪‮‍‪‭⁮⁯​‬‫​‏⁮⁪⁭⁬⁪⁭‭‏‍⁭⁪‫‮
{
  public static void \u202A⁫‌‭‏‭‪‪⁪‭‬‍⁬‬⁬‌‭⁬‭‬‭⁬⁪‎⁯‬‬⁯‫‮‎⁭‬‬‏⁭‫⁪‬‮(
    Account _param0,
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ _param1,
    string _param2)
  {
    MessagesSendParams @params = new MessagesSendParams();
label_1:
    int num1 = 1720569052;
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮ obj;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1210632221)) % 12U)
      {
        case 0:
          num1 = (int) num2 * -414994895 ^ -913930423;
          continue;
        case 1:
          int num3 = obj != \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat ? -817594220 : (num3 = -386896023);
          num1 = num3 ^ (int) num2 * -160857109;
          continue;
        case 2:
          @params.UserId = _param1.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = 66127933;
          continue;
        case 3:
          num1 = (int) num2 * -597065636 ^ 31087277;
          continue;
        case 4:
          goto label_3;
        case 5:
          goto label_6;
        case 6:
          goto label_1;
        case 7:
          int num4 = obj == \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.PersonalMessage ? 2030787705 : (num4 = 67885622);
          num1 = num4 ^ (int) num2 * -1401961986;
          continue;
        case 8:
          VkApi vkApi = _param0.VkApi;
          @params.Attachments = (IEnumerable<MediaAttachment>) _param0.FlooderTaskSettings.VoiceMessage(_param0, _param2);
          vkApi.Messages.Send(@params);
          num1 = 105422028;
          continue;
        case 9:
          obj = _param1.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮;
          num1 = (int) num2 * 276461708 ^ 1790370818;
          continue;
        case 10:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param0, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3432621305U));
          num1 = 1653440325;
          continue;
        case 11:
          @params.ChatId = _param1.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = (int) num2 * -13155309 ^ 711604471;
          continue;
        default:
          goto label_14;
      }
    }
label_3:
    return;
label_6:
    return;
label_14:;
  }
}
