﻿// Decompiled with JetBrains decompiler
// Type: ⁫‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
internal class \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮ : IDisposable
{
  private readonly Timer \u202B‎⁭⁯‮⁪‍⁫⁪‬⁯‮⁯‎‏⁭⁫‮​‭⁮‎​‫​‎‫‪‮‌‭‪‎‌‏‎⁭‏⁮‎‮;
  private bool \u200E‍‏⁪‌‏‫⁪⁬‎‎​‏‪⁭‏‌⁭​‭⁮‌‮⁮‬⁪‎⁪‍‪‮⁬⁫‫‎⁪‎⁫⁫‌‮;

  public \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮(Action _param1, int _param2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮.\u202D⁭‮⁫‍⁪‎‏‭‎⁫​⁪‍‎‎‪⁫⁬‪‎‏⁪⁪⁪‏‎⁪‪⁫‏⁯‏‌‍⁭‌​‪‫‮ obj = new \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮.\u202D⁭‮⁫‍⁪‎‏‭‎⁫​⁪‍‎‎‪⁫⁬‪‎‏⁪⁪⁪‏‎⁪‪⁫‏⁯‏‌‍⁭‌​‪‫‮();
    // ISSUE: reference to a compiler-generated field
    obj.\u200C⁮‪⁪‮⁮‌‍‎‏‌‫‫‏‬‭⁬​‎‏‬‭⁮⁭‬​​​‫‍⁫⁬‎‎‮‭⁪⁪‭‍‮ = _param1;
    // ISSUE: explicit constructor call
    base.\u002Ector();
label_1:
    int num1 = -865565969;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -133204150)) % 4U)
      {
        case 0:
          // ISSUE: reference to a compiler-generated method
          this.\u202B‎⁭⁯‮⁪‍⁫⁪‬⁯‮⁯‎‏⁭⁫‮​‭⁮‎​‫​‎‫‪‮‌‭‪‎‌‏‎⁭‏⁮‎‮ = \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮.\u202B‎‮‌​⁮⁬‌⁫‍⁫⁭⁪‭‬⁪⁫‪⁪‏‬‏⁮⁮‎‪‏⁮‮⁭‬‎‮‎⁭‍‭‌⁯‪‮(new TimerCallback(obj.\u206D⁮‭⁬‪⁭‭⁯⁯⁪⁯⁭‎⁬‍‫⁫‌‫⁪‎⁪⁭‪⁪⁯⁪‌‍⁫‍⁪​‬‌⁯‮⁯‫⁫‮), (object) null, 0, _param2);
          num1 = (int) num2 * -429017176 ^ 139870949;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
          num1 = (int) num2 * 1890792924 ^ 1590777758;
          continue;
        case 2:
          goto label_1;
        case 3:
          goto label_3;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  public void Dispose()
  {
    ((\u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮) this.\u202B‎⁭⁯‮⁪‍⁫⁪‬⁯‮⁯‎‏⁭⁫‮​‭⁮‎​‫​‎‫‪‮‌‭‪‎‌‏‎⁭‏⁮‎‮)?.\u202D⁬‎‫⁮‫⁭‌‪‎‬⁭⁮⁮‬‬‍‪‭‮‪⁭⁯‎‌‬‮⁮‍‭‮⁮‬⁭‫‍‮‏‮‏‮();
  }

  static Timer \u202B‎‮‌​⁮⁬‌⁫‍⁫⁭⁪‭‬⁪⁫‪⁪‏‬‏⁮⁮‎‪‏⁮‮⁭‬‎‮‎⁭‍‭‌⁯‪‮(
    [In] TimerCallback obj0,
    [In] object obj1,
    [In] int obj2,
    [In] int obj3)
  {
    return new Timer(obj0, obj1, obj2, obj3);
  }

  void \u202D⁬‎‫⁮‫⁭‌‪‎‬⁭⁮⁮‬‬‍‪‭‮‪⁭⁯‎‌‬‮⁮‍‭‮⁮‬⁭‫‍‮‏‮‏‮() => ((Timer) this).Dispose();
}
