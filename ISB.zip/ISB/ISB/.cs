﻿// Decompiled with JetBrains decompiler
// Type: ‮⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;

#nullable disable
public class \u202E⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮ : Exception
{
  public \u202E⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮()
  {
  }

  public \u202E⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮(string _param1)
    : base(_param1)
  {
  }

  public \u202E⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮(string _param1, Exception _param2)
    : base(_param1, _param2)
  {
  }
}
