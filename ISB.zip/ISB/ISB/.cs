﻿// Decompiled with JetBrains decompiler
// Type: ‎‬‮⁮‎‬⁯‮⁮‏⁪⁪‭‭⁭⁭​‍​‍‬‏⁯⁯⁫‪⁬⁪⁯‪‍‌⁭⁭‬⁬‎⁫‬‎‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
internal static class \u200E‬‮⁮‎‬⁯‮⁮‏⁪⁪‭‭⁭⁭​‍​‍‬‏⁯⁯⁫‪⁬⁪⁯‪‍‌⁭⁭‬⁬‎⁫‬‎‮
{
  [STAThread]
  private static void \u200E‭⁮⁬​⁬‎⁮⁮‎‪‮‭‎⁭‫‮‌⁫⁫‎‏‏‭⁬‍⁫⁭‮⁪‫‭‪‫⁪⁯⁪‭‪⁯‮()
  {
    \u200E‬‮⁮‎‬⁯‮⁮‏⁪⁪‭‭⁭⁭​‍​‍‬‏⁯⁯⁫‪⁬⁪⁯‪‍‌⁭⁭‬⁬‎⁫‬‎‮.\u202E‬⁫​‬‬‏⁫⁮‌‮⁯‭⁪⁬‏​‎‮⁫‌‮⁮‫‪⁫‏⁫‭⁫‫‌⁭‌⁬⁮‏⁬‪‪‮();
    \u200E‬‮⁮‎‬⁯‮⁮‏⁪⁪‭‭⁭⁭​‍​‍‬‏⁯⁯⁫‪⁬⁪⁯‪‍‌⁭⁭‬⁬‎⁫‬‎‮.\u200F‌⁪‍​⁪‍⁯‌‏‍​‫‌‍⁬‏‪⁭‍⁮⁬‭⁪⁭‬⁭‬⁫‍‌​‮⁬⁯⁮⁮‮‍‮(false);
label_1:
    int num1 = 556927835;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 198256252)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          \u200E‬‮⁮‎‬⁯‮⁮‏⁪⁪‭‭⁭⁭​‍​‍‬‏⁯⁯⁫‪⁬⁪⁯‪‍‌⁭⁭‬⁬‎⁫‬‎‮.\u202E‬⁬‭‬‭⁮⁪‎⁭⁮‭⁭‏‎⁪⁯⁫‎⁮‫​⁫‍⁯⁪⁬‭‬⁯‪‍‫‌⁫‫‍‮⁯⁫‮((Form) new bp3S90\u0020Wj\u003B\u0024\u002ASQ\u0025Bl\u007Bs\u007B\u003D\u0026ig\u0024());
          num1 = (int) num2 * -1641381653 ^ 675128758;
          continue;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  static void \u202E‬⁫​‬‬‏⁫⁮‌‮⁯‭⁪⁬‏​‎‮⁫‌‮⁮‫‪⁫‏⁫‭⁫‫‌⁭‌⁬⁮‏⁬‪‪‮() => Application.EnableVisualStyles();

  static void \u200F‌⁪‍​⁪‍⁯‌‏‍​‫‌‍⁬‏‪⁭‍⁮⁬‭⁪⁭‬⁭‬⁫‍‌​‮⁬⁯⁮⁮‮‍‮([In] bool obj0)
  {
    Application.SetCompatibleTextRenderingDefault(obj0);
  }

  static void \u202E‬⁬‭‬‭⁮⁪‎⁭⁮‭⁭‏‎⁪⁯⁫‎⁮‫​⁫‍⁯⁪⁬‭‬⁯‪‍‫‌⁫‫‍‮⁯⁫‮([In] Form obj0)
  {
    Application.Run(obj0);
  }
}
