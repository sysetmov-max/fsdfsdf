﻿// Decompiled with JetBrains decompiler
// Type: ⁪‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

#nullable disable
internal struct \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮
{
  public readonly \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮ \u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮;
  public long? \u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
  public long? \u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮;

  public \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮ _param1,
    string _param2,
    string _param3)
  {
    this.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ = _param1;
    this.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮ = new long?(long.Parse(_param2));
    this.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮ = new long?(long.Parse(_param3));
  }

  public \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮ _param1)
  {
    this.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮ = _param1;
    this.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮ = this.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮ = new long?();
  }

  public enum \u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮
  {
    Unknown,
    NotFound,
    PersonalMessage,
    Chat,
    Wall,
    Photo,
    Video,
    Topic,
  }
}
