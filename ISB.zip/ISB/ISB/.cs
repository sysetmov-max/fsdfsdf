﻿// Decompiled with JetBrains decompiler
// Type: ⁫‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.Runtime.InteropServices;

#nullable disable
internal static class \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮
{
  public static string \u206C‏‌‮⁮‎‍‫‭‮⁭⁬⁯‏⁫‬⁮⁮​⁫‭⁫⁮‏‪⁮‮‪⁭‬⁮‮​‫⁯‌‮⁮‎‫‮(
    string _param0,
    string _param1,
    bool _param2 = false)
  {
    if (_param2)
    {
label_1:
      uint num;
      switch ((num = (uint) (1499838005 ^ 1283463906)) % 3U)
      {
        case 1:
          return \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u200D‬⁯‫‍‭‭‭​‫‫⁭⁫⁯‌⁫​‭‏‬‪‮​‬⁬‪⁫⁮​⁮‪‍‪‏‫⁮‍⁮⁮⁪‮(_param0, 0, \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206F‌‮‭​‬‪‫⁬‫⁫‏‭⁫⁯​⁮‭⁬⁪‬‭⁯‎‏‮‌‍⁮⁯⁭‏‪⁬‫‎‍‫⁯‎‮(_param0, _param1));
        case 2:
          goto label_1;
      }
    }
    return \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206F⁪‮‮‌‮‫⁫‍‭‎‭‪​‭⁪⁮‏‎‬‬⁪‍⁮‌​‎‍‭‎⁭⁮‮‏⁫‬‌‭‎⁭‮(_param0, \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206F‌‮‭​‬‪‫⁬‫⁫‏‭⁫⁯​⁮‭⁬⁪‬‭⁯‎‏‮‌‍⁮⁯⁭‏‪⁬‫‎‍‫⁯‎‮(_param0, _param1) + \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206B‫⁬⁯‍⁭‭‮⁬​‫‏‫‍​⁪‭‫⁯​‏‭‍‌​‪‭‫⁬‬‏⁮⁯⁯⁫‌⁯‭‎‮‮(_param1));
  }

  public static string \u200D⁭⁫⁮‭‬⁬‍‍​‭‌‭‌‪⁪‌‪⁭⁭⁬⁮​‏‪‮‍‏‮‏⁫‪⁭‫⁯‏⁪‎⁮‫‮(
    string _param0,
    string _param1,
    string _param2)
  {
    return \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206C‏‌‮⁮‎‍‫‭‮⁭⁬⁯‏⁫‬⁮⁮​⁫‭⁫⁮‏‪⁮‮‪⁭‬⁮‮​‫⁯‌‮⁮‎‫‮(\u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206C‏‌‮⁮‎‍‫‭‮⁭⁬⁯‏⁫‬⁮⁮​⁫‭⁫⁮‏‪⁮‮‪⁭‬⁮‮​‫⁯‌‮⁮‎‫‮(_param0, _param1), _param2, true);
  }

  static int \u206F‌‮‭​‬‪‫⁬‫⁫‏‭⁫⁯​⁮‭⁬⁪‬‭⁯‎‏‮‌‍⁮⁯⁭‏‪⁬‫‎‍‫⁯‎‮([In] string obj0, [In] string obj1)
  {
    return obj0.IndexOf(obj1);
  }

  static string \u200D‬⁯‫‍‭‭‭​‫‫⁭⁫⁯‌⁫​‭‏‬‪‮​‬⁬‪⁫⁮​⁮‪‍‪‏‫⁮‍⁮⁮⁪‮([In] string obj0, [In] int obj1, [In] int obj2)
  {
    return obj0.Substring(obj1, obj2);
  }

  static int \u206B‫⁬⁯‍⁭‭‮⁬​‫‏‫‍​⁪‭‫⁯​‏‭‍‌​‪‭‫⁬‬‏⁮⁯⁯⁫‌⁯‭‎‮‮([In] string obj0) => obj0.Length;

  static string \u206F⁪‮‮‌‮‫⁫‍‭‎‭‪​‭⁪⁮‏‎‬‬⁪‍⁮‌​‎‍‭‎⁭⁮‮‏⁫‬‌‭‎⁭‮([In] string obj0, [In] int obj1)
  {
    return obj0.Substring(obj1);
  }
}
