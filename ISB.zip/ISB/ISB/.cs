﻿// Decompiled with JetBrains decompiler
// Type: ‍‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.Runtime.InteropServices;

#nullable disable
internal static class \u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮
{
  public static \u0001 \u200D⁯‏​‪⁭​‏⁯⁬⁪⁯⁫‮‌‮‫⁮⁯⁮‎⁮⁬‪‪‮‍​‪‌‮⁪⁮‌⁪‍‍‭‏‏‮<\u0001>(\u0001 _param0)
  {
    return JsonConvert.DeserializeObject<\u0001>(\u200D‮‍⁮⁭‎‪‭​‬⁮‍‪‏⁬⁮‮‌‎‭‫​⁭‎⁬‌‫⁪‌‍‮‫⁪⁮‭‫⁪⁬‏‍‮.\u206C⁭‎⁫⁪‪⁪​‭⁯‌⁯‏⁬⁪‏‬⁯‪‌​‪⁪⁯⁪‌⁫‭‫‫⁬‌‮‪⁫⁭‏⁬‪⁭‮((object) _param0));
  }

  static string \u206C⁭‎⁫⁪‪⁪​‭⁯‌⁯‏⁬⁪‏‬⁯‪‌​‪⁪⁯⁪‌⁫‭‫‫⁬‌‮‪⁫⁭‏⁬‪⁭‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }
}
