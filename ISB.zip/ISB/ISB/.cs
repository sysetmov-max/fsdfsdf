﻿// Decompiled with JetBrains decompiler
// Type: ‍‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using VkNet;
using VkNet.Categories;
using VkNet.Model;
using VkNet.Model.RequestParams;

#nullable disable
internal static class \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮
{
  private static readonly Dictionary<Account, Dictionary<string, long?>> \u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮ = new Dictionary<Account, Dictionary<string, long?>>();
  private static readonly Dictionary<Account, Dictionary<string, long?>> \u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮ = new Dictionary<Account, Dictionary<string, long?>>();

  public static void \u206A‬‍‫⁯⁪⁮‬‮‌‮‏⁬‎⁬‬‭⁫‍⁬​‭⁪‍‬‪⁪‫⁫‪‎⁫‌​​⁫⁪‌‫‏‮()
  {
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮.Clear();
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮.Clear();
  }

  public static \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ \u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(
    Account _param0,
    string _param1_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬⁯​⁯⁫⁭⁯⁫⁪⁪‎⁫‌‌‫‌‍‏⁯⁯​‬‎‌‌‍​‪‏‬‬‮‪⁫‏⁪‍‬‬‮ obj1 = new \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬⁯​⁯⁫⁭⁯⁫⁪⁪‎⁫‌‌‫‌‍‏⁯⁯​‬‎‌‌‍​‪‏‬‬‮‪⁫‏⁪‍‬‬‮();
    // ISSUE: reference to a compiler-generated field
    obj1.\u206C​⁬​‏‫‪‬‬‍⁪‫⁪‭‏​‮⁬‮‫⁪⁮⁪‮⁪‌⁪⁫‪⁯‏⁭‌‌⁫‏‬⁭‫‎‮ = _param0.VkApi;
label_1:
    int num1 = -678623962;
    // ISSUE: variable of a compiler-generated type
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206C​​⁮‍‫⁮‍‫⁮⁪⁯‫‪⁪‮⁮⁪‪⁪‭⁬‭⁮⁮⁯⁯‫‎‍‬‎‫‬⁪⁮‎‍‫‏‮ obj2;
    // ISSUE: variable of a compiler-generated type
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‮⁯⁮⁫‍‪‎​⁬‎⁮‬⁭​‬‬⁫‭‏‭‫‭⁮‮‮⁯‮⁭⁪⁯⁫⁬​‭‍⁮⁯⁮‌‮ obj3;
    long? nullable1;
    MessagesGetObject dialogs1;
    long? nullable2;
    int num2;
    MessagesGetObject dialogs2;
    Match match1;
    MessagesDialogsGetParams dialogsGetParams;
    int num3;
    Match match2;
    Match match3;
    Match match4;
    Match match5;
    Match match6;
    Match match7;
    Match match8;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num1 ^ -1285254319)) % 57U)
      {
        case 0:
          match2 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3218644092U)), _param1_1);
          match6 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1197124192U)), _param1_1);
          num1 = (int) num4 * -1410105037 ^ 15638137;
          continue;
        case 1:
          goto label_27;
        case 2:
          int num5;
          num1 = num5 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match4) ? -383517033 : (num5 = -1452794415);
          continue;
        case 3:
          int num6;
          // ISSUE: reference to a compiler-generated field
          num1 = num6 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮[_param0].Keys.Contains<string>(obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮) ? -214838556 : (num6 = -295596486);
          continue;
        case 4:
          int num7 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮.Keys.Contains<Account>(_param0) ? 2055172298 : (num7 = 651472752);
          num1 = num7 ^ (int) num4 * -423250104;
          continue;
        case 5:
          // ISSUE: reference to a compiler-generated field
          nullable1 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮[_param0][obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮];
          num1 = (int) num4 * -1459443790 ^ -842084470;
          continue;
        case 6:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          MessagesCategory messages = obj2.\u200B‎‮‭‫‍⁮⁯‏⁬‬⁭‍‭​‬‍⁬⁬‌‬⁪⁬‫⁮⁯‌⁫‫‏‍‍⁪‌‍​‏‬‪‪‮.\u206C​⁬​‏‫‪‬‬‍⁪‫⁪‭‏​‮⁬‮‫⁪⁮⁪‮⁪‌⁪⁫‪⁯‏⁭‌‌⁫‏‬⁭‫‎‮.Messages;
          dialogsGetParams = new MessagesDialogsGetParams();
          dialogsGetParams.Count = 200U;
          dialogsGetParams.Offset = num2;
          MessagesDialogsGetParams params1 = dialogsGetParams;
          dialogs1 = messages.GetDialogs(params1);
          int num8;
          num1 = num8 = dialogs1.Messages.Count != 0 ? -726652548 : (num8 = -1251888207);
          continue;
        case 7:
          goto label_46;
        case 8:
          // ISSUE: reference to a compiler-generated field
          MessagesCategory messagesCategory = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200C‎‎⁯⁪‍‮‏‫⁪‍‬‫‏⁬‍​‍⁬‎‎‎‮‭⁪‎⁬⁮⁭​⁮⁪‎⁫⁯⁬‫‮‮‎‮(obj1.\u206C​⁬​‏‫‪‬‬‍⁪‫⁪‭‏​‮⁬‮‫⁪⁮⁪‮⁪‌⁪⁫‪⁯‏⁭‌‌⁫‏‬⁭‫‎‮);
          dialogsGetParams = new MessagesDialogsGetParams();
          dialogsGetParams.Count = 200U;
          dialogsGetParams.Offset = num3;
          MessagesDialogsGetParams params2 = dialogsGetParams;
          dialogs2 = messagesCategory.GetDialogs(params2);
          num1 = -1968299667;
          continue;
        case 9:
          // ISSUE: reference to a compiler-generated field
          \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮[_param0][obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮] = nullable2;
          num1 = -711245755;
          continue;
        case 10:
          match8 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1263948355U)), _param1_1);
          int num9 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match1) ? -207721433 : (num9 = -887774654);
          num1 = num9 ^ (int) num4 * 851725661;
          continue;
        case 11:
          int num10;
          num1 = num10 = !nullable2.HasValue ? -559145617 : (num10 = -1251888207);
          continue;
        case 13:
          // ISSUE: reference to a compiler-generated field
          obj2.\u200B‎‮‭‫‍⁮⁯‏⁬‬⁭‍‭​‬‍⁬⁬‌‬⁪⁬‫⁮⁯‌⁫‫‏‍‍⁪‌‍​‏‬‪‪‮ = obj1;
          num1 = (int) num4 * -502284432 ^ 128980560;
          continue;
        case 14:
          // ISSUE: object of a compiler-generated type is created
          obj3 = new \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‮⁯⁮⁫‍‪‎​⁬‎⁮‬⁭​‬‬⁫‭‏‭‫‭⁮‮‮⁯‮⁭⁪⁯⁫⁬​‭‍⁮⁯⁮‌‮();
          num1 = (int) num4 * -946082540 ^ -782846133;
          continue;
        case 15:
          goto label_42;
        case 16 /*0x10*/:
          int num11;
          num1 = num11 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match7) ? -926119033 : (num11 = -911091050);
          continue;
        case 17:
          int num12;
          // ISSUE: reference to a compiler-generated field
          num1 = num12 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮[_param0].Keys.Contains<string>(obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮) ? -1440627003 : (num12 = -784742076);
          continue;
        case 18:
          // ISSUE: reference to a compiler-generated field
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param0, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206E‌‭⁭‎‌‎‍‏⁫⁪‪‎⁯⁫‎‮⁯​⁭‏‮‌‏⁭⁫‭⁫⁯‬‫​‌‬‪⁮‪‌‏‌‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1815373827U), (object) obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮));
          num1 = -557918578;
          continue;
        case 19:
          goto label_1;
        case 20:
          match5 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3504268996U)), _param1_1);
          num1 = (int) num4 * -129060186 ^ 389049759;
          continue;
        case 21:
          goto label_50;
        case 22:
          int num13;
          num1 = num13 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match3) ? -112298005 : (num13 = -1655108826);
          continue;
        case 23:
          match7 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2980177505U)), _param1_1);
          match3 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2611291072U)), _param1_1);
          match4 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2010794614U)), _param1_1);
          num1 = (int) num4 * 1138252422 ^ -407946278;
          continue;
        case 24:
          goto label_21;
        case 25:
          num1 = (int) num4 * -1466177267 ^ 728768544;
          continue;
        case 26:
          // ISSUE: reference to a compiler-generated field
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param0, string.Format(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2375004026U), (object) obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮));
          num1 = (int) num4 * -1913716561 ^ 1887648864;
          continue;
        case 27:
          // ISSUE: reference to a compiler-generated field
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param0, string.Format(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1010101962U), (object) obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮));
          num1 = -1765878600;
          continue;
        case 28:
          goto label_45;
        case 29:
          goto label_29;
        case 30:
          \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮[_param0] = new Dictionary<string, long?>();
          num1 = (int) num4 * -185445832 ^ 930097848;
          continue;
        case 31 /*0x1F*/:
          // ISSUE: reference to a compiler-generated field
          \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206D‫⁯⁫⁭⁮‌​‭⁭‬⁫‪⁭⁭‭⁫⁭‎​‮‭⁫⁭⁬‮​‭‬‪‮⁯⁭‪⁫‍‭⁬‌‭‮[_param0][obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮] = nullable1;
          num1 = -1807741616;
          continue;
        case 32 /*0x20*/:
          // ISSUE: object of a compiler-generated type is created
          obj2 = new \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206C​​⁮‍‫⁮‍‫⁮⁪⁯‫‪⁪‮⁮⁪‪⁪‭⁬‭⁮⁮⁯⁯‫‎‍‬‎‫‬⁪⁮‎‍‫‏‮();
          num1 = (int) num4 * -72260519 ^ 150199735;
          continue;
        case 33:
          int num14;
          num1 = num14 = !nullable1.HasValue ? -1552597373 : (num14 = -1487490006);
          continue;
        case 34:
          nullable2 = new long?();
          num1 = (int) num4 * -647310875 ^ 1419432555;
          continue;
        case 35:
          // ISSUE: reference to a compiler-generated field
          obj3.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮ = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‍⁮‮​‮‪​‫‬​⁮⁭‎​⁪⁪‏‪⁮‎‬‭‭⁭‏‌⁪⁫‫⁪⁭⁪⁬​‍‮⁮⁭‏‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match4), 1)));
          nullable1 = new long?();
          num1 = (int) num4 * 494067165 ^ -1844952345;
          continue;
        case 36:
          int num15;
          num1 = num15 = !match8.Success ? -954995292 : (num15 = -1043396906);
          continue;
        case 37:
          num3 = 0;
          num1 = (int) num4 * -1216553982 ^ 2082739438;
          continue;
        case 38:
          goto label_11;
        case 39:
          \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮[_param0] = new Dictionary<string, long?>();
          num1 = (int) num4 * 1098945607 ^ -136129164;
          continue;
        case 40:
          int num16;
          num1 = num16 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match5) ? -1586858296 : (num16 = -995198937);
          continue;
        case 41:
          num1 = (int) num4 * 1493141307 ^ -1418908528;
          continue;
        case 42:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated method
          nullable2 = dialogs1.Messages.Where<Message>(obj2.\u206F‪‫⁭‬‭⁮⁬‪‫‫⁪​⁯‭‮⁬‍⁬‮​​⁯‏⁪​⁯⁫⁪‮‎‭‮‫‭‌⁯‌⁪⁯‮ ?? (obj2.\u206F‪‫⁭‬‭⁮⁬‪‫‫⁪​⁯‭‮⁬‍⁬‮​​⁯‏⁪​⁯⁫⁪‮‎‭‮‫‭‌⁯‌⁪⁯‮ = new Func<Message, bool>(obj2.\u206B‭⁬‪⁯⁭‪‭‫‌⁮‫⁯‪⁭⁭⁫‪⁪‭⁫‭⁫‏‪‎‫‎⁮‎⁪‬‭‬‮⁫‍‫⁫‮‮))).Select<Message, long?>((Func<Message, long?>) (_param1_2 => \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‮‫‌‫‌⁮‎⁬⁮⁮⁪‮⁬‬⁭‌⁭⁪‬‎⁯‬‮⁪‭‍⁫‏‌‫⁯‌​‫⁮‪⁯‍‍‮.\u202D​⁮‮⁪⁬‫⁭⁮‮⁫‎‭‌​‏⁯⁪‏⁮‫‎‏‭‏⁫⁯⁯‮⁯‮‭‪⁫⁯⁮‪‫‮(_param1_2))).DefaultIfEmpty<long?>(new long?()).First<long?>();
          num2 += 200;
          num1 = -1283141170;
          continue;
        case 43:
          int num17;
          num1 = num17 = !nullable1.HasValue ? -1930137824 : (num17 = -2081021286);
          continue;
        case 44:
          // ISSUE: reference to a compiler-generated field
          nullable2 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮[_param0][obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮];
          num1 = (int) num4 * -343141612 ^ -626768564;
          continue;
        case 45:
          int num18 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‮⁭⁬​‫⁫⁭⁬‎‌⁮‭​‬‍‫​‎​‫‎⁭‭‎‌⁬⁭‭⁭⁮‭‏‎⁫‏‬​‮‮‮.Keys.Contains<Account>(_param0) ? -2121740630 : (num18 = -467662615);
          num1 = num18 ^ (int) num4 * 293630496;
          continue;
        case 46:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated method
          nullable1 = dialogs2.Messages.Where<Message>(obj3.\u202E‎⁪‫⁮‭‍‬⁭‭⁫‮⁬‫⁬‪‭‏⁯⁯‪⁬⁫‪‍⁯‮‬⁭⁫‎⁮‭‫⁭⁯‏⁫‭‌‮ ?? (obj3.\u202E‎⁪‫⁮‭‍‬⁭‭⁫‮⁬‫⁬‪‭‏⁯⁯‪⁬⁫‪‍⁯‮‬⁭⁫‎⁮‭‫⁭⁯‏⁫‭‌‮ = new Func<Message, bool>(obj3.\u200B‮⁭⁬‭⁮‎⁬‬‮‭⁮⁫‬‍‍‭⁬‬⁫‪‬‪⁪⁯‌‏⁫⁫‬‎‮⁯⁬‏⁪⁯⁬‍‍‮))).Select<Message, long?>((Func<Message, long?>) (_param1_3 => \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‮‫‌‫‌⁮‎⁬⁮⁮⁪‮⁬‬⁭‌⁭⁪‬‎⁯‬‮⁪‭‍⁫‏‌‫⁯‌​‫⁮‪⁯‍‍‮.\u202B⁬‏‫‭⁪⁮⁫‮‌‍‮‪‎‎‬⁭⁫⁬‮⁯⁮‬‎⁭‌⁯⁬‍‬‪​‮⁬⁬⁬‎‭‭⁬‮(_param1_3))).DefaultIfEmpty<long?>(new long?()).First<long?>();
          num1 = -1413352125;
          continue;
        case 47:
          match1 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(484373666U)), _param1_1);
          num1 = (int) num4 * -978614930 ^ 545481392;
          continue;
        case 48 /*0x30*/:
          num3 += 200;
          num1 = (int) num4 * 1523598253 ^ -1772379263;
          continue;
        case 49:
          int num19;
          num1 = num19 = !\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match6) ? -1843394505 : (num19 = -1695747894);
          continue;
        case 50:
          int num20 = dialogs2.Messages.Count == 0 ? 1655885922 : (num20 = 762730590);
          num1 = num20 ^ (int) num4 * 536146530;
          continue;
        case 51:
          int num21;
          num1 = num21 = !nullable2.HasValue ? -1507819135 : (num21 = -619580193);
          continue;
        case 52:
          // ISSUE: reference to a compiler-generated field
          obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮ = match8.Groups[1].Value.ToLower();
          num1 = (int) num4 * -2082729867 ^ -820266991;
          continue;
        case 53:
          goto label_15;
        case 54:
          int num22;
          num1 = num22 = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮((System.Text.RegularExpressions.Group) match2) ? -1587809939 : (num22 = -478830220);
          continue;
        case 55:
          num2 = 0;
          num1 = (int) num4 * -1066744992 ^ 1319084974;
          continue;
        case 56:
          goto label_57;
        default:
          goto label_58;
      }
    }
label_11:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match1), 1)), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3350070567U));
label_15:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Wall, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match2), 1)), \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match2), 2)));
label_21:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Topic, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match3), 1)), \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match3), 2)));
label_27:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Video, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match7), 1)), \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match7), 2)));
label_29:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.PersonalMessage, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match5), 1)), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3672053581U));
label_42:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.NotFound);
label_45:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat, nullable1.ToString(), \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4126073900U));
label_46:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.PersonalMessage, nullable2.ToString(), \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4126073900U));
label_50:
    // ISSUE: reference to a compiler-generated field
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param0, string.Format(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(138226758U), (object) obj2.\u200D⁭‮‬⁭‪⁬⁪‫‫‪⁭⁫‬⁬‎‬‫⁭‎⁮‎‭⁬​​⁬‍⁪⁯⁮⁫‮‫​‭‬‌‮‍‮));
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.NotFound);
label_57:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Photo, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match6), 1)), \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮((Capture) \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(\u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮(match6), 2)));
label_58:
    return new \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮(\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Unknown);
  }

  static Regex \u200E‪‎‭⁯⁪⁪‎‬‌⁮‌‭‬‮‌‍⁫‪⁬‍‭‍⁮⁬‌‏‪​⁫‌‫⁪⁯‎‭‎⁬‪‮‮([In] string obj0) => new Regex(obj0);

  static Match \u206F⁪⁯⁮‭⁪‫⁯‎⁫‪‭⁯​⁯‍‏‬‫⁬⁭‭‭⁫‎‭‏‪⁭‭‮‎⁮‭⁭‏‍‎⁪‮([In] Regex obj0, [In] string obj1)
  {
    return obj0.Match(obj1);
  }

  static bool \u200D​‮⁮‫‍⁭⁮‌‌‬‏⁫⁮‏‫⁪​‮⁭‮⁪⁪‮‬‏⁫‮‬‭‏⁬‬‎⁬⁯‪‍‮‏‮([In] System.Text.RegularExpressions.Group obj0)
  {
    return obj0.Success;
  }

  static GroupCollection \u200F‪‪⁪‏‎⁯‬⁮‪‮‪‪‎⁭‪⁯‫‎‍‬⁯⁯⁭‪‎‭‬‌‫⁫‮‭‌‏⁮⁬‪⁫⁬‮([In] Match obj0)
  {
    return obj0.Groups;
  }

  static System.Text.RegularExpressions.Group \u200F⁬‪⁭‍‭⁯‌⁯‌⁫‫⁫⁮⁭⁮‭‌⁯‎⁬‬‪⁮‍‎​‭⁬​‌⁯‌‌⁪​​‎‪⁪‮(
    [In] GroupCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static string \u206F‭‪‮‭‮‎‌⁫‏‌‪⁮⁮‍‫‬‎⁬‎‏​⁬‎⁮‫‪‫‎‌⁬‮‫‏‎‎‎‎‭‏‮([In] Capture obj0) => obj0.Value;

  static string \u206A‍⁮‮​‮‪​‫‬​⁮⁭‎​⁪⁪‏‪⁮‎‬‭‭⁭‏‌⁪⁫‫⁪⁭⁪⁬​‍‮⁮⁭‏‮([In] string obj0) => obj0.ToLower();

  static string \u206E‌‭⁭‎‌‎‍‏⁫⁪‪‎⁯⁫‎‮⁯​⁭‏‮‌‏⁭⁫‭⁫⁯‬‫​‌‬‪⁮‪‌‏‌‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static MessagesCategory \u200C‎‎⁯⁪‍‮‏‫⁪‍‬‫‏⁬‍​‍⁬‎‎‎‮‭⁪‎⁬⁮⁭​⁮⁪‎⁫⁯⁬‫‮‮‎‮([In] VkApi obj0)
  {
    return obj0.Messages;
  }
}
