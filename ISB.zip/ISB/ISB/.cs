﻿// Decompiled with JetBrains decompiler
// Type: ‭‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using ISP.Tasks.Settings;
using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

#nullable disable
internal sealed class \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮ : 
  \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
{
  private void \u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮(Account _param1)
  {
    try
    {
      VoiceTaskSettings voiceTaskSettings = _param1.VoiceTaskSettings;
label_1:
      int num1 = 1271112603;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1151457444)) % 7U)
        {
          case 0:
            goto label_3;
          case 1:
            \u200D‬⁪‭‭‎⁬⁮⁮⁮‫‍‭‍‮‭⁪‮‍‪‭⁮⁯​‬‫​‏⁮⁪⁭⁬⁪⁭‭‏‍⁭⁪‫‮.\u202A⁫‌‭‏‭‪‪⁪‭‬‍⁬‬⁬‌‭⁬‭‬‭⁬⁪‎⁯‬‬⁯‫‮‎⁭‬‬‏⁭‫⁪‬‮(_param1, \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(_param1, voiceTaskSettings.Target), voiceTaskSettings.Message);
            num1 = 983974675;
            continue;
          case 2:
            goto label_1;
          case 3:
            int num3 = !\u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u200E⁪‮‪⁬⁫‫⁪‭⁭⁬‮‌‍‪‍‍‪‌​‌‍⁫‎‪⁪‌⁯‮‬⁫‮‭⁪‫​‪‪‬‮(voiceTaskSettings.Yandexapi, nameof ()) ? 1341098500 : (num3 = 247157246);
            num1 = num3 ^ (int) num2 * 458407774;
            continue;
          case 4:
            int num4 = \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u200E⁪‮‪⁬⁫‫⁪‭⁭⁬‮‌‍‪‍‍‪‌​‌‍⁫‎‪⁪‌⁯‮‬⁫‮‭⁪‫​‪‪‬‮(voiceTaskSettings.Target, nameof ()) ? 141929456 : (num4 = 210252210);
            num1 = num4 ^ (int) num2 * -1229617514;
            continue;
          case 6:
            int num5 = \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u200E⁪‮‪⁬⁫‫⁪‭⁭⁬‮‌‍‪‍‍‪‌​‌‍⁫‎‪⁪‌⁯‮‬⁫‮‭⁪‫​‪‪‬‮(voiceTaskSettings.Message, nameof ()) ? 197677774 : (num5 = 1142968463);
            num1 = num5 ^ (int) num2 * -1070594595;
            continue;
          default:
            goto label_8;
        }
      }
label_3:
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3368809694U));
      return;
label_8:
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1226788773U));
    }
    catch (Exception ex)
    {
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u202E‍‌​‌‏‎⁪⁬‫‌⁬‬‎‏⁬​⁫‪⁫‌‮⁪⁪‭‏⁪‪⁮‫‏‮‏‫‍​⁮⁯‍‌‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1543490057U), (object) \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u202B​⁬⁯‎‬⁪‍‍‭‌‌⁯⁭‎‫‏‪‬​‭‮‏‫‍⁪‏‌‎‌⁭‬‬‍⁫​⁯‎‌‮‮(ex)));
    }
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(
    Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u206B‎‭⁪⁬⁯‪⁬⁯‎⁮⁭⁭⁬‌⁮⁫⁮⁯⁫⁮‎⁯‮⁪‌‮‭‪‬⁮⁯​⁫⁫‍⁪⁯‬‮(\u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u202D‌‬‮‭⁫‌‬‮⁪⁮⁫‪‎‎‌‪⁬‏⁯⁫⁪‭‎‭⁬⁬‬⁯‮‬⁬‮⁮‬⁯‍‫⁪⁮‮(new Action(new \u202D‍‭‫‏⁬‪‫⁬‫‮‬‌‬⁪‏‬‏⁯⁪⁯‮‪‍⁪‮⁯‏‬⁭‭⁫⁮‌⁯‬‏‏‎‮‮.\u206C‬‮‎‫‎⁮⁬‮‮⁭‍⁭‌​‌‬‭⁯‎⁬‬⁪⁮⁮⁮‌⁮‎⁭⁬⁯⁮‮‬‬⁭‎⁯‪‮()
    {
      \u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this,
      \u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1
    }.\u200E⁭‍‪⁮‍‎⁭‍‍‍‮⁮‮​⁮​⁮​⁮⁫‎​⁯⁫⁫‮​‌⁯‮​‬‏⁯⁬⁮⁬⁮‍‮)));
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮()
  {
  }

  static bool \u200E⁪‮‪⁬⁫‫⁪‭⁭⁬‮‌‍‪‍‍‪‌​‌‍⁫‎‪⁪‌⁯‮‬⁫‮‭⁪‫​‪‪‬‮([In] string obj0, [In] string obj1)
  {
    return obj0 == obj1;
  }

  static string \u202B​⁬⁯‎‬⁪‍‍‭‌‌⁯⁭‎‫‏‪‬​‭‮‏‫‍⁪‏‌‎‌⁭‬‬‍⁫​⁯‎‌‮‮([In] Exception obj0) => obj0.Message;

  static string \u202E‍‌​‌‏‎⁪⁬‫‌⁬‬‎‏⁬​⁫‪⁫‌‮⁪⁪‭‏⁪‪⁮‫‏‮‏‫‍​⁮⁯‍‌‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static Task \u202D‌‬‮‭⁫‌‬‮⁪⁮⁫‪‎‎‌‪⁬‏⁯⁫⁪‭‎‭⁬⁬‬⁯‮‬⁬‮⁮‬⁯‍‫⁪⁮‮([In] Action obj0) => new Task(obj0);

  static void \u206B‎‭⁪⁬⁯‪⁬⁯‎⁮⁭⁭⁬‌⁮⁫⁮⁯⁫⁮‎⁯‮⁪‌‮‭‪‬⁮⁯​⁫⁫‍⁪⁯‬‮([In] Task obj0) => obj0.Start();
}
