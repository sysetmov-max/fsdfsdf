﻿// Decompiled with JetBrains decompiler
// Type: ‪‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using VkNet;
using VkNet.Categories;
using VkNet.Model;
using VkNet.Model.RequestParams;

#nullable disable
internal class \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮ : 
  \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
{
  private void \u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮(Account _param1_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u202B⁪‌​‎‬‍‭‬‫⁪‬⁮‍‪‫‎‬‎⁬‌⁯‌‪⁫‫⁪⁬‌⁭‪​‍‫⁬‌‎⁮‮⁯‮ obj = new \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u202B⁪‌​‎‬‍‭‬‫⁪‬⁮‍‪‫‎‬‎⁬‌⁯‌‪⁫‫⁪⁬‌⁭‪​‍‫⁬‌‎⁮‮⁯‮();
    // ISSUE: reference to a compiler-generated field
    obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
label_1:
    int num1 = -722389805;
    MessagesGetObject dialogs;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -400890320)) % 8U)
      {
        case 0:
          // ISSUE: reference to a compiler-generated method
          IEnumerable<long> collection = dialogs.Messages.Where<Message>((Func<Message, bool>) (_param1_2 =>
          {
            // ISSUE: reference to a compiler-generated method
            if (\u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u200E‫‌‏⁭‮⁬⁯⁪⁬‍‎⁬‮‪⁫⁪‏⁪‭‬⁫‏‮‍‪‫‫‏⁮⁯⁯‏‫⁮‌‬‎⁬⁯‮.\u206D‪‍‮‭‮⁭⁫⁯⁬⁮‎⁯‏⁬‏⁮‫⁬‏‬​‎⁭⁯⁪⁫⁭‮⁬⁭‌‎‭⁪‭‪‎‌‫‮(_param1_2).HasValue)
            {
label_1:
              uint num3;
              switch ((num3 = (uint) (-923990090 ^ -2080863237)) % 3U)
              {
                case 0:
                  goto label_1;
                case 1:
                  // ISSUE: reference to a compiler-generated method
                  return \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u200E‫‌‏⁭‮⁬⁯⁪⁬‍‎⁬‮‪⁫⁪‏⁪‭‬⁫‏‮‍‪‫‫‏⁮⁯⁯‏‫⁮‌‬‎⁬⁯‮.\u202A⁬‭‮​⁫⁪‪⁪‭⁭‎‬⁫‌⁪⁮⁬‪‪‍‍⁯‌⁫⁬⁫‫‌‍‎⁬‌‮‬⁬​⁯​⁫‮(_param1_2).Any<long>();
              }
            }
            return false;
          })).Select<Message, long>((Func<Message, long>) (_param1_3 => \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u200E‫‌‏⁭‮⁬⁯⁪⁬‍‎⁬‮‪⁫⁪‏⁪‭‬⁫‏‮‍‪‫‫‏⁮⁯⁯‏‫⁮‌‬‎⁬⁯‮.\u206D‪‍‮‭‮⁭⁫⁯⁬⁮‎⁯‏⁬‏⁮‫⁬‏‬​‎⁭⁯⁪⁫⁭‮⁬⁭‌‎‭⁪‭‪‎‌‫‮(_param1_3).Value));
          // ISSUE: reference to a compiler-generated field
          obj.\u200D⁪⁬‫⁬‌⁬‭⁭​‏‮​⁪⁫⁬‎‌‌⁮​‪⁮​‎⁪‏⁮‬⁯‭‌‬⁯‏‪‍⁬‬⁮‮.AddRange(collection);
          num1 = -274554358;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          dialogs = \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u200C⁫‍⁭⁭‫⁪⁯‮‏⁮‍‌⁭‪‫‏​‌‌​‪⁭‎‪‌⁫⁬‮⁯⁫‭​​‪‫‭⁪⁮⁮‮(obj.\u206C​⁬​‏‫‪‬‬‍⁪‫⁪‭‏​‮⁬‮‫⁪⁮⁪‮⁪‌⁪⁫‪⁯‏⁭‌‌⁫‏‬⁭‫‎‮).GetDialogs(new MessagesDialogsGetParams()
          {
            Count = 200U,
            Offset = obj.\u202E‮⁯‪⁯‬‮‏⁮⁪‌‭‮⁭‎⁪‭‮⁯⁮⁭‫‎⁮‭‍⁪‌‎⁭‍⁪​‫⁬‎⁮‏⁯⁬‮
          });
          int num4;
          num1 = num4 = dialogs.Messages.Count == 0 ? -2078299107 : (num4 = -424550512);
          continue;
        case 2:
          // ISSUE: reference to a compiler-generated field
          obj.\u202E‮⁯‪⁯‬‮‏⁮⁪‌‭‮⁭‎⁪‭‮⁯⁮⁭‫‎⁮‭‍⁪‌‎⁭‍⁪​‫⁬‎⁮‏⁯⁬‮ += 200;
          num1 = (int) num2 * -1292220515 ^ 1985176229;
          continue;
        case 3:
          // ISSUE: reference to a compiler-generated field
          obj.\u206C​⁬​‏‫‪‬‬‍⁪‫⁪‭‏​‮⁬‮‫⁪⁮⁪‮⁪‌⁪⁫‪⁯‏⁭‌‌⁫‏‬⁭‫‎‮ = _param1_1.VkApi;
          // ISSUE: reference to a compiler-generated field
          obj.\u206C‎‏‬‪⁭‌‮‏‬‮‫​⁯⁪‬⁮‬‪‬⁮‏‍‮⁭⁫‎‬⁯‮⁫⁬‌‎⁯‌‏​‬‫‮ = _param1_1.InviteTaskSettings;
          // ISSUE: reference to a compiler-generated field
          obj.\u200D⁪⁬‫⁬‌⁬‭⁭​‏‮​⁪⁫⁬‎‌‌⁮​‪⁮​‎⁪‏⁮‬⁯‭‌‬⁯‏‪‍⁬‬⁮‮ = new List<long>();
          num1 = (int) num2 * 1141400655 ^ 1177957185;
          continue;
        case 4:
          // ISSUE: reference to a compiler-generated field
          obj.\u202E‮⁯‪⁯‬‮‏⁮⁪‌‭‮⁭‎⁪‭‮⁯⁮⁭‫‎⁮‭‍⁪‌‎⁭‍⁪​‫⁬‎⁮‏⁯⁬‮ = 0;
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1_1, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3383413743U));
          num1 = (int) num2 * 713902579 ^ 581469293;
          continue;
        case 6:
          goto label_1;
        case 7:
          num1 = (int) num2 * -1115594320 ^ -1205559543;
          continue;
        default:
          goto label_9;
      }
    }
label_9:
    // ISSUE: reference to a compiler-generated field
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1_1, string.Format(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2273923256U), (object) obj.\u200D⁪⁬‫⁬‌⁬‭⁭​‏‮​⁪⁫⁬‎‌‌⁮​‪⁮​‎⁪‏⁮‬⁯‭‌‬⁯‏‪‍⁬‬⁮‮.Count));
    // ISSUE: reference to a compiler-generated field
    obj.\u200B‭‪‌‍⁭​‬‫⁬⁬⁬⁭‭⁯⁬⁮⁮‭⁬‏‎‮‬⁭‮‪‭​⁭⁫‮‪‬⁭⁫‏‪‎‎‮ = 0;
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated field
    this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = new \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮(new Action(obj.\u202E⁮​‍‏‌‬‎‪⁫‮‮‍⁭⁮‏⁪⁯⁯⁫⁬⁫‮⁪‮‮‭‏‫⁪‌​⁬‪⁪⁪‪‎‌‮‮), obj.\u206C‎‏‬‪⁭‌‮‏‬‮‫​⁯⁪‬⁮‬‪‬⁮‏‍‮⁭⁫‎‬⁯‮⁫⁬‌‎⁯‌‏​‬‫‮.Delay);
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(
    Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u202D⁮​⁬‫‮⁭‎⁪‌⁭⁯⁬‏‫‍⁯‮⁪‬‎⁯‬⁬‮⁮‬⁬​‬‬‎‭‍⁯​‍⁫‮‭‮ obj = new \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u202D⁮​⁬‫‮⁭‎⁪‌⁭⁯⁬‏‫‍⁯‮⁪‬‎⁯‬⁬‮⁮‬⁬​‬‬‎‭‍⁯​‍⁫‮‭‮();
label_1:
    int num1 = -1846451067;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -683998502)) % 7U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_3;
        case 2:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1;
          num1 = (int) num2 * 1299647160 ^ 1870797754;
          continue;
        case 3:
          goto label_5;
        case 4:
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
          num1 = (int) num2 * 216586693 ^ -442865341;
          continue;
        case 5:
          // ISSUE: reference to a compiler-generated method
          \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u206A‪⁫‍‏‬⁯⁫​‬‏⁮⁮⁬⁭‭‌⁮‏‪⁫⁬‬‬‍‍⁪⁪‮‏⁮‍⁯‮⁮​‭‏‎⁫‮(\u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮.\u202D​‮‮‭‪‎​‏‎⁪⁮‌‏‍‮⁪‮⁬‪‍‌⁪⁮‮‪⁫⁫⁮⁮‏‍⁮​‌⁪⁪⁮‮⁮‮(new Action(obj.\u200E⁭‍‪⁮‍‎⁭‍‍‍‮⁮‮​⁮​⁮​⁮⁫‎​⁯⁫⁫‮​‌⁯‮​‬‏⁯⁬⁮⁬⁮‍‮)));
          num1 = -2022845825;
          continue;
        case 6:
          // ISSUE: reference to a compiler-generated field
          int num3 = !obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.InviteTaskSettings.Enabled ? -1933810502 : (num3 = -1959142200);
          num1 = num3 ^ (int) num2 * -1319821160;
          continue;
        default:
          goto label_9;
      }
    }
label_3:
    return;
label_5:
    return;
label_9:;
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮()
  {
    \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮ obj = this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮;
    if (obj != null)
    {
      // ISSUE: explicit non-virtual call
      __nonvirtual (obj.Dispose());
    }
    else
      goto label_5;
label_2:
    int num1 = 1412943875;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 1307924989)) % 3U)
    {
      case 0:
        goto label_2;
      case 1:
        break;
      case 2:
        return;
      default:
        return;
    }
label_5:
    this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = (\u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮) null;
    num1 = 1994245032;
    goto label_3;
  }

  static MessagesCategory \u200C⁫‍⁭⁭‫⁪⁯‮‏⁮‍‌⁭‪‫‏​‌‌​‪⁭‎‪‌⁫⁬‮⁯⁫‭​​‪‫‭⁪⁮⁮‮([In] VkApi obj0)
  {
    return obj0.Messages;
  }

  static Task \u202D​‮‮‭‪‎​‏‎⁪⁮‌‏‍‮⁪‮⁬‪‍‌⁪⁮‮‪⁫⁫⁮⁮‏‍⁮​‌⁪⁪⁮‮⁮‮([In] Action obj0) => new Task(obj0);

  static void \u206A‪⁫‍‏‬⁯⁫​‬‏⁮⁮⁬⁭‭‌⁮‏‪⁫⁬‬‬‍‍⁪⁪‮‏⁮‍⁯‮⁮​‭‏‎⁫‮([In] Task obj0) => obj0.Start();
}
