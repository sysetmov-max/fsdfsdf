﻿// Decompiled with JetBrains decompiler
// Type: ⁫‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using ISP.Engine.Accounts;
using ISP.Tasks.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using VkNet;
using VkNet.Model.Attachments;
using VkNet.Model.RequestParams;

#nullable disable
internal sealed class \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮ : 
  \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮
{
  private string \u202E‮‏‏⁬⁬‏‏⁬‪⁪‏⁫⁮‮‪⁯‌‫‍⁬‭⁪‎⁫‎⁫⁭‎​⁬⁯‍‮‮‭⁬⁯‮‬‮(FlooderTarget _param1)
  {
    return \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‏⁯⁪⁭⁯⁭‌‭​‫‭‮⁪‭‫⁭‏‭‮⁭‮‎⁮⁮⁫‏‫​⁮‬⁮⁯⁪‍⁬‫⁭⁪⁭‮(\u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u206C‏‌‮⁮‎‍‫‭‮⁭⁬⁯‏⁫‬⁮⁮​⁫‭⁫⁮‏‪⁮‮‪⁭‬⁮‮​‫⁯‌‮⁮‎‫‮(\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‏⁯⁪⁭⁯⁭‌‭​‫‭‮⁪‭‫⁭‏‭‮⁭‮‎⁮⁮⁫‏‫​⁮‬⁮⁯⁪‍⁬‫⁭⁪⁭‮(\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‏⁯⁪⁭⁯⁭‌‭​‫‭‮⁪‭‫⁭‏‭‮⁭‮‎⁮⁮⁫‏‫​⁮‬⁮⁯⁪‍⁬‫⁭⁪⁭‮(\u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u200D⁭⁫⁮‭‬⁬‍‍​‭‌‭‌‪⁪‌‪⁭⁭⁬⁮​‏‪‮‍‏‮‏⁫‪⁭‫⁯‏⁪‎⁮‫‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u206F​⁬⁮‪‎⁬‎⁯‬‎‏‎‍‏⁮⁫‮‌​⁬⁭‬‏‎‬‫‎​⁮‌‎‌‍‏⁮‬‏‫‫‮(\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206E‬‪‫‍‌⁪⁫‫‌⁮⁬‭​‎‍‬⁮⁮⁭‪⁮‍⁮​⁫⁮⁮‮⁫⁭‮⁬⁮‭⁫‭‍⁬‪‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3992013927U), (object) _param1.Name)), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(619237494U), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(173722384U)), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3001596841U), nameof ()), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1422069180U), nameof ()), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(784658114U)), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2045382023U), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1191557364U));
  }

  private string \u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(
    Account _param1,
    FlooderTaskSettings _param2,
    FlooderTarget _param3)
  {
    if (\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206A‎‫⁯‭⁯‎⁫‮‬⁭⁭‏‬⁬‎⁫⁬‌⁮‫‬‏‬‭‫⁭‪‭‪‮‌⁬‍⁪⁯‬‬⁭‪‮(_param3.NamePlace, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2207671234U)))
      goto label_9;
label_1:
    int num1 = -1540828741;
label_2:
    string str1;
    string namePlace;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -748289106)) % 13U)
      {
        case 0:
          num1 = (int) num2 * -1244930086 ^ -1996341714;
          continue;
        case 1:
          str1 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‏⁯⁪⁭⁯⁭‌‭​‫‭‮⁪‭‫⁭‏‭‮⁭‮‎⁮⁮⁫‏‫​⁮‬⁮⁯⁪‍⁬‫⁭⁪⁭‮(str1, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2155983232U), _param3.Name);
          num1 = -741048360;
          continue;
        case 2:
          goto label_8;
        case 3:
          int num3 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(namePlace, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3632473819U)) ? -532157110 : (num3 = -1931269069);
          num1 = num3 ^ (int) num2 * 132527329;
          continue;
        case 4:
          int num4 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(namePlace, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2699630028U)) ? -578916062 : (num4 = -1143505850);
          num1 = num4 ^ (int) num2 * 625203867;
          continue;
        case 5:
          str1 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u202D‎​⁫‪⁮‭‍‏‌‏⁪⁪⁭⁭⁫⁬⁯‎‌‪⁬‮‫⁮⁫⁭⁭‌‎⁪⁬‬⁭⁫⁯‫⁯‭⁪‮(str1, _param3.Name);
          num1 = -1191643054;
          continue;
        case 6:
          num1 = (int) num2 * 2077531640 ^ -94162654;
          continue;
        case 7:
          num1 = (int) num2 * -2019708953 ^ 1205723326;
          continue;
        case 8:
          int num5 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(namePlace, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3125484582U)) ? -1048810411 : (num5 = -307374686);
          num1 = num5 ^ (int) num2 * -1423050067;
          continue;
        case 9:
          string[] strArray = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u202A⁫‭‍‎⁭⁪⁮⁭⁯⁭‭‎‍⁭‭​‪‍⁫‌​⁭‮‍⁯‮‪‮‌⁬⁫‪‍‭‏‎⁮‎‪‮(_param3.Name, new char[1]
          {
            ':'
          });
          str1 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u202B‭‍‫‭‭‏​‏‍⁮‪⁪⁫‮‪⁬⁪‮‌⁬‎‌‌‎⁭⁯‍⁪⁮‪⁭‮⁭‏‮⁬⁮​⁪‮(strArray[0], str1, strArray.Length == 1 ? strArray[0] : strArray[1]);
          num1 = -1191643054;
          continue;
        case 10:
          goto label_1;
        case 12:
          str1 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u202D‎​⁫‪⁮‭‍‏‌‏⁪⁪⁭⁭⁫⁬⁯‎‌‪⁬‮‫⁮⁫⁭⁭‌‎⁪⁬‬⁭⁫⁯‫⁯‭⁪‮(_param3.Name, str1);
          num1 = -473474564;
          continue;
        default:
          goto label_16;
      }
    }
label_8:
    string str2 = _param2.GetPhraseWithDots(_param1, _param3);
    goto label_10;
label_16:
    return str1;
label_9:
    str2 = _param2.GetPhrase(_param1, _param3);
label_10:
    str1 = str2;
    namePlace = _param3.NamePlace;
    num1 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(namePlace, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2830984077U)) ? -975095020 : (num1 = -831381804);
    goto label_2;
  }

  private void \u200E‌‭⁭‍‭⁮⁫⁪‪‭⁯‍⁪‫‮⁬⁫⁯‫⁫‪⁭‌‬‌‌‪‏⁭‪⁫​‌‫‭‍⁮⁮⁮‮(
    Account _param1,
    FlooderTarget _param2)
  {
    VkApi vkApi = _param1.VkApi;
label_1:
    int num1 = 1119611573;
    VideoCreateCommentParams params1;
    uint num2;
    BoardCreateCommentParams params2;
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ obj;
    BoardCreateCommentParams createCommentParams1;
    string contains;
    MessagesSendParams messagesSendParams;
    MessagesSendParams params3;
    List<MediaAttachment> mediaAttachmentList;
    FlooderTaskSettings flooderTaskSettings;
    string str;
    MessagesSendParams params4;
    FlooderTarget flooderTarget1;
    long num3;
    FlooderTarget flooderTarget2;
    PhotoCreateCommentParams params5;
    WallAddCommentParams addCommentParams;
    WallAddCommentParams params6;
    VideoCreateCommentParams createCommentParams2;
    PhotoCreateCommentParams createCommentParams3;
    while (true)
    {
      uint num4;
      switch ((num4 = (uint) (num1 ^ 1291622060)) % 134U)
      {
        case 0:
          int num5;
          num1 = num5 = num2 > 2455176347U ? 520695608 : (num5 = 307756217);
          continue;
        case 1:
          num1 = (int) num4 * 629501581 ^ -754351670;
          continue;
        case 2:
          params1.StickerId = new long?((long) (uint) num3);
          num1 = (int) num4 * -1887825671 ^ 324831076;
          continue;
        case 3:
          flooderTarget1 = new FlooderTarget(_param2)
          {
            Contains = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(757960812U)
          };
          num1 = 812366083;
          continue;
        case 4:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomAudio());
          num1 = 1336699725;
          continue;
        case 5:
          int num6;
          num1 = num6 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2421648447U)) ? 1982667413 : (num6 = 825609848);
          continue;
        case 6:
          num1 = (int) num4 * -1011809472 ^ -998044621;
          continue;
        case 7:
          createCommentParams2.VideoId = obj.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮.Value;
          createCommentParams2.Message = str;
          num1 = (int) num4 * 523587971 ^ -1520857606;
          continue;
        case 8:
          createCommentParams1.Message = str;
          num1 = (int) num4 * 1253045790 ^ 885201660;
          continue;
        case 9:
          goto label_56;
        case 10:
          messagesSendParams.ChatId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = (int) num4 * -569698547 ^ -2062460019;
          continue;
        case 11:
          num3 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206A⁪‌​‌‮⁬​‍⁪‏‬⁫‮‭‫‍‭‮‌‬​⁫‬⁯‮‍‏‭‭‍⁬⁭​⁭⁪⁬‮‎⁯‮(flooderTaskSettings.RandomSticker(_param1, _param2).Last<MediaAttachment>()).Value;
          num1 = 685612723;
          continue;
        case 12:
          int num7 = num2 == 357203056U ? 1048442842 : (num7 = 1677011192);
          num1 = num7 ^ (int) num4 * 1512316653;
          continue;
        case 13:
          goto label_3;
        case 14:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomImage());
          num1 = (int) num4 * -2100021888 ^ 1978455031;
          continue;
        case 15:
          int num8 = num3 == -1L ? -132867435 : (num8 = -435014082);
          num1 = num8 ^ (int) num4 * -2015009003;
          continue;
        case 16 /*0x10*/:
          num1 = (int) num4 * -1436092853 ^ 269882363;
          continue;
        case 17:
          int num9 = num2 != 1536981666U ? 857237312 : (num9 = 136292662);
          num1 = num9 ^ (int) num4 * 533978008;
          continue;
        case 18:
          num1 = (int) num4 * -1180969919 ^ 1442163595;
          continue;
        case 19:
          params4.StickerId = new uint?((uint) num3);
          num1 = (int) num4 * -225880654 ^ 565329362;
          continue;
        case 20:
          int num10 = num2 != 1539999046U ? 1731720281 : (num10 = 1027141018);
          num1 = num10 ^ (int) num4 * 1332552743;
          continue;
        case 21:
          int num11 = num2 != 903333245U ? 798320372 : (num11 = 1650999149);
          num1 = num11 ^ (int) num4 * -1667100846;
          continue;
        case 22:
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomImage());
          num1 = (int) num4 * -1147140735 ^ 1131899055;
          continue;
        case 23:
          params6.StickerId = new long?((long) (uint) num3);
          num1 = (int) num4 * -924272820 ^ -22344278;
          continue;
        case 24:
          num1 = (int) num4 * -94689000 ^ -812699021;
          continue;
        case 25:
          createCommentParams2.OwnerId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = (int) num4 * -662516825 ^ -1998264664;
          continue;
        case 26:
label_55:
          createCommentParams3 = new PhotoCreateCommentParams();
          createCommentParams3.OwnerId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          num1 = 28067522;
          continue;
        case 27:
          this.\u200E‌‭⁭‍‭⁮⁫⁪‪‭⁯‍⁪‫‮⁬⁫⁯‫⁫‪⁭‌‬‌‌‪‏⁭‪⁫​‌‫‭‍⁮⁮⁮‮(_param1, flooderTarget2);
          num1 = (int) num4 * 1651691311 ^ -1604531197;
          continue;
        case 28:
          createCommentParams3.PhotoId = (ulong) obj.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮.Value;
          createCommentParams3.Message = str;
          num1 = (int) num4 * -698214850 ^ 55414672;
          continue;
        case 29:
          createCommentParams2.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          params1 = createCommentParams2;
          num1 = (int) num4 * 1453876891 ^ -149907762;
          continue;
        case 30:
          messagesSendParams.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          num1 = (int) num4 * -815670426 ^ -429960185;
          continue;
        case 31 /*0x1F*/:
          str = nameof ();
          num1 = (int) num4 * 2005934493 ^ -1635189712;
          continue;
        case 32 /*0x20*/:
          int num12;
          num1 = num12 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3091127393U)) ? 175081790 : (num12 = 1987057038);
          continue;
        case 33:
          int num13 = num2 != 2416787549U ? -578914490 : (num13 = -1464282706);
          num1 = num13 ^ (int) num4 * 1562489010;
          continue;
        case 34:
          goto label_9;
        case 35:
          num3 = -1L;
          num1 = (int) num4 * 1005243708 ^ -1568536836;
          continue;
        case 36:
          contains = _param2.Contains;
          num1 = (int) num4 * -469042501 ^ -1340656012;
          continue;
        case 37:
          num1 = (int) num4 * -1812603066 ^ -266614103;
          continue;
        case 38:
          int num14;
          num1 = num14 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(600006796U)) ? 461280007 : (num14 = 1684997622);
          continue;
        case 39:
          int num15 = !ConfigController.AntikickConfig.LeavedIntentionallyFrom.ContainsKey(_param1.Login) ? -1173367557 : (num15 = -1727165995);
          num1 = num15 ^ (int) num4 * -1753928146;
          continue;
        case 40:
          goto label_108;
        case 41:
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          num1 = (int) num4 * 1567129380 ^ -1242054859;
          continue;
        case 42:
          int num16;
          num1 = num16 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2643370043U)) ? 1239809814 : (num16 = 920185972);
          continue;
        case 43:
          this.\u200E‌‭⁭‍‭⁮⁫⁪‪‭⁯‍⁪‫‮⁬⁫⁯‫⁫‪⁭‌‬‌‌‪‏⁭‪⁫​‌‫‭‍⁮⁮⁮‮(_param1, flooderTarget1);
          flooderTarget2 = new FlooderTarget(_param2)
          {
            Contains = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4030630189U)
          };
          num1 = (int) num4 * 423587459 ^ -257614210;
          continue;
        case 44:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomAudio());
          num1 = 281856688;
          continue;
        case 45:
          num1 = (int) num4 * 1715199099 ^ -435203930;
          continue;
        case 46:
          messagesSendParams.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          num1 = (int) num4 * -248488934 ^ -382076393;
          continue;
        case 47:
          int num17;
          num1 = num17 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2027116491U)) ? 384786631 : (num17 = 555421856);
          continue;
        case 48 /*0x30*/:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomDocument());
          num1 = 807027193;
          continue;
        case 49:
          int num18;
          num1 = num18 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3784591571U)) ? 1224321118 : (num18 = 1114446650);
          continue;
        case 50:
          str = _param2.Name;
          num1 = 1823892030;
          continue;
        case 51:
          int num19;
          num1 = num19 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3402045356U)) ? 71668600 : (num19 = 1463694091);
          continue;
        case 52:
          int num20;
          num1 = num20 = num2 <= 1539999046U ? 835298485 : (num20 = 1667575480);
          continue;
        case 53:
          params6 = addCommentParams;
          num1 = (int) num4 * 1840934777 ^ 888986051;
          continue;
        case 54:
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          num1 = (int) num4 * 1609337825 ^ -1678058975;
          continue;
        case 55:
          num1 = (int) num4 * 844376908 ^ -2063060833;
          continue;
        case 56:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.VoiceMessage(_param1, this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2)));
          num1 = 648978178;
          continue;
        case 57:
          switch (obj.\u200F⁭‌‌‮‭‍​‮‬‎⁯⁬​‬⁫​‏⁯‬‏​⁪‮⁬‪⁯‫‪‌‎‬​‏‏⁮‍⁫​⁪‮)
          {
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.NotFound:
              goto label_137;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.PersonalMessage:
              goto label_81;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Chat:
              goto label_38;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Wall:
              goto label_120;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Photo:
              goto label_55;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Video:
              goto label_47;
            case \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮.\u206B‌⁯‎⁪⁮‭‍​‎‎‌‏​‫‫⁬⁯‬‬‌‮⁯​‌⁫‫⁯‍⁭‭⁭‎‫‮‬‏‏‮‮‮.Topic:
              goto label_12;
            default:
              num1 = 586337003;
              continue;
          }
        case 58:
          goto label_1;
        case 59:
          num1 = (int) num4 * -692807156 ^ -1446939617;
          continue;
        case 60:
          goto label_60;
        case 61:
          int num21 = num2 == 846588924U ? 1050651859 : (num21 = 1514928033);
          num1 = num21 ^ (int) num4 * -582013116;
          continue;
        case 62:
          num1 = (int) num4 * -1301280852 ^ -924505917;
          continue;
        case 63 /*0x3F*/:
          int num22;
          num1 = num22 = num2 == 760411286U ? 637921609 : (num22 = 1966586645);
          continue;
        case 64 /*0x40*/:
          num1 = (int) num4 * -538260254 ^ 213518519;
          continue;
        case 65:
          mediaAttachmentList = new List<MediaAttachment>();
          num1 = (int) num4 * -1296707173 ^ 981641170;
          continue;
        case 66:
          int num23;
          num1 = num23 = num2 == 2500113433U ? 807620852 : (num23 = 2105817194);
          continue;
        case 67:
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          num1 = (int) num4 * -631085493 ^ 1380868723;
          continue;
        case 68:
label_120:
          addCommentParams = new WallAddCommentParams();
          num1 = 522840948;
          continue;
        case 69:
          params4 = messagesSendParams;
          num1 = (int) num4 * -1839688625 ^ -2111495957;
          continue;
        case 70:
          int num24;
          num1 = num24 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2250049838U)) ? 1081930755 : (num24 = 134305557);
          continue;
        case 71:
          int num25 = num2 == 288100949U ? 652448396 : (num25 = 1710208115);
          num1 = num25 ^ (int) num4 * 2105454657;
          continue;
        case 72:
          createCommentParams1.GroupId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          createCommentParams1.TopicId = obj.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮.Value;
          num1 = (int) num4 * 1448372490 ^ 2089870426;
          continue;
        case 73:
          str = this.\u202E‮‏‏⁬⁬‏‏⁬‪⁪‏⁫⁮‮‪⁯‌‫‍⁬‭⁪‎⁫‎⁫⁭‎​⁬⁯‍‮‮‭⁬⁯‮‬‮(_param2);
          num1 = 685612723;
          continue;
        case 74:
          params5.StickerId = new ulong?((ulong) (uint) num3);
          num1 = (int) num4 * 1348640889 ^ -1232016803;
          continue;
        case 75:
          messagesSendParams.Message = str;
          num1 = (int) num4 * -926231454 ^ 397562592;
          continue;
        case 76:
          int num26 = num2 != 506396953U ? -2002013595 : (num26 = -796971211);
          num1 = num26 ^ (int) num4 * 31591788;
          continue;
        case 77:
          int num27 = !ConfigController.AntikickConfig.LeavedIntentionallyFrom[_param1.Login].Contains(obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮.Value) ? -811414509 : (num27 = -33845287);
          num1 = num27 ^ (int) num4 * 315354426;
          continue;
        case 78:
          num1 = (int) num4 * -2037225375 ^ -1899603955;
          continue;
        case 79:
          num1 = (int) num4 * -2117457516 ^ -1984821649;
          continue;
        case 80 /*0x50*/:
          num1 = (int) num4 * -207597865 ^ 1118855469;
          continue;
        case 81:
          messagesSendParams = new MessagesSendParams();
          num1 = 973226272;
          continue;
        case 82:
          int num28 = num3 == -1L ? -1109372012 : (num28 = -988788695);
          num1 = num28 ^ (int) num4 * -1994243986;
          continue;
        case 83:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomVideo());
          num1 = 685612723;
          continue;
        case 84:
          num1 = (int) num4 * -1309155498 ^ 479501795;
          continue;
        case 85:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomImage());
          num1 = (int) num4 * 1031609254 ^ 1192710092;
          continue;
        case 86:
          params2 = createCommentParams1;
          num1 = (int) num4 * 1503663504 ^ 2144909369;
          continue;
        case 87:
          params3.StickerId = new uint?((uint) num3);
          num1 = (int) num4 * -1332498240 ^ -1046541278;
          continue;
        case 88:
          num1 = (int) num4 * 1337542616 ^ 1152505667;
          continue;
        case 89:
          num1 = (int) num4 * 1506243153 ^ 1518194272;
          continue;
        case 90:
          int num29;
          num1 = num29 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(139210907U)) ? 1416998853 : (num29 = 1339282790);
          continue;
        case 91:
label_38:
          int num30;
          num1 = num30 = ConfigController.AntikickConfig.LeavedIntentionallyFrom == null ? 986913413 : (num30 = 2057559221);
          continue;
        case 92:
          num1 = (int) num4 * -1595960203 ^ 460626485;
          continue;
        case 93:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(_param1, string.Format(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1905585979U), (object) _param2.Link));
          num1 = 143284559;
          continue;
        case 94:
          num1 = (int) num4 * -329055899 ^ -1897058671;
          continue;
        case 95:
          params5 = createCommentParams3;
          num1 = (int) num4 * -594806217 ^ 1993886442;
          continue;
        case 96 /*0x60*/:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomAudio());
          num1 = 2041429753;
          continue;
        case 97:
          int num31 = num2 != 1419624446U ? 2076612634 : (num31 = 1570124698);
          num1 = num31 ^ (int) num4 * -1804903549;
          continue;
        case 98:
          goto label_4;
        case 99:
          num1 = (int) num4 * 970897331 ^ 56740766;
          continue;
        case 100:
          goto label_85;
        case 101:
          vkApi.Photo.CreateComment(params5);
          num1 = 1267599961;
          continue;
        case 102:
          num1 = (int) num4 * 1889941476 ^ -1975699869;
          continue;
        case 103:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomImage());
          num1 = 1977304062;
          continue;
        case 104:
          mediaAttachmentList.AddRange((IEnumerable<MediaAttachment>) flooderTaskSettings.RandomVideo());
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          num1 = 2063105610;
          continue;
        case 105:
label_12:
          createCommentParams1 = new BoardCreateCommentParams();
          num1 = 1393420818;
          continue;
        case 106:
          // ISSUE: reference to a compiler-generated method
          num2 = \u200D‏⁭⁮‎‍‫‍‭⁪‍‮​⁬⁬⁪‍‫‪⁬⁪⁮‪⁬‪⁯⁭⁪⁯‫‎‭⁫‮​‌‭⁮⁭‮‮.\u206E⁯‪⁪⁫‌‪‪‮⁬⁮⁬‪⁭‬‍‬‫‮‫‪‭‬⁪‌⁪⁪‬‮⁫⁮​‫​‍⁫⁮​‪‮(contains);
          int num32 = num2 > 903333245U ? -645849552 : (num32 = -92865795);
          num1 = num32 ^ (int) num4 * -891474001;
          continue;
        case 107:
          int num33 = num3 != -1L ? 1857156699 : (num33 = 1778767322);
          num1 = num33 ^ (int) num4 * 1518036075;
          continue;
        case 108:
          createCommentParams1.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          num1 = (int) num4 * -692234702 ^ -240810270;
          continue;
        case 109:
          params2.StickerId = new long?((long) (uint) num3);
          num1 = (int) num4 * 1410858906 ^ -515477230;
          continue;
        case 110:
          createCommentParams3.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          num1 = (int) num4 * 1029716948 ^ -1211352249;
          continue;
        case 111:
          num1 = (int) num4 * -402072116 ^ 1480734913;
          continue;
        case 112 /*0x70*/:
          int num34;
          num1 = num34 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4290839076U)) ? 15479342 : (num34 = 669108529);
          continue;
        case 113:
          obj = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(_param1, _param2.Link);
          flooderTaskSettings = _param1.FlooderTaskSettings;
          num1 = (int) num4 * 1714840207 ^ 1146287936;
          continue;
        case 114:
          int num35 = num2 == 2455176347U ? -1134137560 : (num35 = -462594706);
          num1 = num35 ^ (int) num4 * -1704026830;
          continue;
        case 115:
          int num36 = num2 <= 506396953U ? -891463604 : (num36 = -1446706604);
          num1 = num36 ^ (int) num4 * -243352901;
          continue;
        case 116:
          int num37 = num3 == -1L ? -683145810 : (num37 = -741193935);
          num1 = num37 ^ (int) num4 * -2076011604;
          continue;
        case 117:
          int num38 = num3 == -1L ? -1317171041 : (num38 = -666093929);
          num1 = num38 ^ (int) num4 * -1805324521;
          continue;
        case 118:
          num1 = (int) num4 * -1924223826 ^ -1892070681;
          continue;
        case 119:
          int num39;
          num1 = num39 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3593473895U)) ? 1068678948 : (num39 = 1280581058);
          continue;
        case 120:
label_47:
          createCommentParams2 = new VideoCreateCommentParams();
          num1 = 737986015;
          continue;
        case 121:
          num1 = (int) num4 * 423941589 ^ 1533072498;
          continue;
        case 122:
          str = this.\u200F⁯​⁬⁪‌⁯‬​‎​⁬‎⁫⁭​‏⁬‭‎​‍⁮⁮⁪⁬⁭⁪⁪‌‍​​‎‪‪⁫‫‪‌‮(_param1, flooderTaskSettings, _param2);
          num1 = 440636751;
          continue;
        case 123:
label_81:
          messagesSendParams = new MessagesSendParams();
          messagesSendParams.UserId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          messagesSendParams.Message = str;
          num1 = 1900362610;
          continue;
        case 124:
          num1 = (int) num4 * -1510523230 ^ 2123810911;
          continue;
        case 125:
          num1 = (int) num4 * -1701490410 ^ 291457121;
          continue;
        case 126:
          goto label_31;
        case (uint) sbyte.MaxValue:
          num1 = (int) num4 * 762046922 ^ -559309751;
          continue;
        case 128 /*0x80*/:
          int num40;
          num1 = num40 = !\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3091108334U)) ? 106220579 : (num40 = 1955272352);
          continue;
        case 129:
          params3 = messagesSendParams;
          num1 = (int) num4 * 1791948792 ^ 1040826123;
          continue;
        case 130:
          int num41 = num2 == 2686493633U ? -397445052 : (num41 = -515913220);
          num1 = num41 ^ (int) num4 * -1994022628;
          continue;
        case 131:
          int num42 = num3 != -1L ? 1345955846 : (num42 = 174633461);
          num1 = num42 ^ (int) num4 * 721939033;
          continue;
        case 132:
          addCommentParams.OwnerId = obj.\u206D‭‪‏‭‍⁬⁭⁬‎‫‍‮⁭‏‎⁫⁯⁫‭‫⁪‬‍​⁬‮‮‮‬⁪‮‪‍‪​‪‮⁬⁯‮;
          addCommentParams.PostId = obj.\u202A⁮‬⁭‫⁯‮‫⁭‬​‭‬⁮⁮⁮‬⁭⁯‭‮​​‏⁭‮​⁬⁭‮⁬‎‫​‏​‏‫⁪‬‮.Value;
          addCommentParams.Text = str;
          addCommentParams.Attachments = (IEnumerable<MediaAttachment>) mediaAttachmentList;
          num1 = (int) num4 * 629605021 ^ -1818024855;
          continue;
        case 133:
          int num43;
          num1 = num43 = \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮(contains, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(4052235456U)) ? 1353950163 : (num43 = 118236218);
          continue;
        default:
          goto label_138;
      }
    }
label_56:
    return;
label_3:
    return;
label_31:
    return;
label_138:
    return;
label_4:
    vkApi.Video.CreateComment(params1);
    return;
label_9:
    vkApi.Board.СreateComment(params2);
    return;
label_137:
    return;
label_60:
    vkApi.Messages.Send(params3);
    return;
label_85:
    vkApi.Wall.AddComment(params6);
    return;
label_108:
    vkApi.Messages.Send(params4);
  }

  private void \u200C‭⁬‬⁭‍‎⁫⁮‏‌⁭​⁮‌‏‮‫⁯⁭⁬⁬⁮⁯⁯⁬​⁪‏⁪‏‍‪⁭‏‫‪‮‌⁪‮(Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‍⁪‍‍​‭⁭⁫⁭‏⁯‍​‫​⁬‏‍⁪‫⁯‍⁯‍‪‏⁬‭⁬‫⁫‌⁯⁮‮‌⁫⁬‌‮ obj = new \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200D‍⁪‍‍​‭⁭⁫⁭‏⁯‍​‫​⁬‏‍⁪‫⁯‍⁯‍‪‏⁬‭⁬‫⁫‌⁯⁮‮‌⁫⁬‌‮();
label_1:
    int num1 = -757621474;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -540118767)) % 6U)
      {
        case 0:
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated field
          this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = new \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮(new Action(obj.\u200C⁭​‫‬⁭⁮‮‏‬⁮‫‏‌​‌⁫⁬‌‭⁪‎‬‫⁫‭⁯⁪‎‭‪⁪⁯‎⁯‪‎‌⁮‫‮), obj.\u206F‫⁪‌‎⁭‌‭⁫⁯‫​‏‫‎⁬‫⁬⁭⁯⁮​‍‮‮‌‍‭‭​‍‫‏⁭⁭⁯‫‭‎‪‮.Delay);
          num1 = (int) num2 * 1253936754 ^ -1055026124;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
          num1 = (int) num2 * 1302215255 ^ 381770478;
          continue;
        case 2:
          goto label_1;
        case 3:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫⁪‌‎⁭‌‭⁫⁯‫​‏‫‎⁬‫⁬⁭⁯⁮​‍‮‮‌‍‭‭​‍‫‏⁭⁭⁯‫‭‎‪‮.LoadAccountSpecific(obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj.\u206C⁫⁪‍​‬⁯‍​⁭⁮‬⁯‬‎‮⁪⁫‌⁫⁬⁯‍‭⁪‍⁮‪⁪⁯‍⁫‮‎​‍⁪‫⁭⁭‮ = obj.\u206F‫⁪‌‎⁭‌‭⁫⁯‫​‏‫‎⁬‫⁬⁭⁯⁮​‍‮‮‌‍‭‭​‍‫‏⁭⁭⁯‫‭‎‪‮.Targets;
          // ISSUE: reference to a compiler-generated field
          obj.\u206D⁪‌⁬‌‭‌‍⁯⁭‍‫‏‭‮⁯⁭⁭⁭⁭‬⁯‬⁫‌‍⁯‮‪‭‭‮‮‏‪⁯​⁮‫⁫‮ = -1;
          num1 = (int) num2 * -1557794858 ^ 476074599;
          continue;
        case 4:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫⁪‌‎⁭‌‭⁫⁯‫​‏‫‎⁬‫⁬⁭⁯⁮​‍‮‮‌‍‭‭​‍‫‏⁭⁭⁯‫‭‎‪‮ = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.FlooderTaskSettings;
          num1 = (int) num2 * -835270392 ^ -1840122498;
          continue;
        case 5:
          goto label_3;
        default:
          goto label_8;
      }
    }
label_3:
    return;
label_8:;
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(
    Account _param1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‮⁭‎‫⁭⁬⁪⁬‏⁭⁬‭‪‌‏‪⁮‪⁭‪⁭‬⁪‫⁫⁭‮‪⁮⁮⁬⁭‎‬‮⁯⁭‭‭‮ obj = new \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u206F‮⁭‎‫⁭⁬⁪⁬‏⁭⁬‭‪‌‏‪⁮‪⁭‪⁭‬⁪‫⁫⁭‮‪⁮⁮⁬⁭‎‬‮⁯⁭‭‭‮();
label_1:
    int num1 = -2051859439;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1024519724)) % 8U)
      {
        case 0:
          // ISSUE: reference to a compiler-generated method
          \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200F⁪⁮⁫‎‍‏⁪⁬‪‭⁭​‪⁮‫‬‌‏⁯‮⁭‪‫⁫‭‎‫‮‌‍‫‫⁭⁮​‪‮⁮⁮‮(\u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮.\u200F‌⁫⁬‍‪‪‫⁫⁭⁪‪‌‍‎‌​⁮⁯⁫‌⁮‪⁪‪‎‌​⁮‌​‏⁪‌‍⁫‬‍‬⁭‮(new Action(obj.\u200E⁭‍‪⁮‍‎⁭‍‍‍‮⁮‮​⁮​⁮​⁮⁫‎​⁯⁫⁫‮​‌⁯‮​‬‏⁯⁬⁮⁬⁮‍‮)));
          num1 = -1054711657;
          continue;
        case 1:
          // ISSUE: reference to a compiler-generated field
          obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮ = _param1;
          // ISSUE: reference to a compiler-generated field
          int num3 = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.FlooderTaskSettings.Enabled ? -4805185 : (num3 = -572849786);
          num1 = num3 ^ (int) num2 * -515433395;
          continue;
        case 2:
          goto label_9;
        case 3:
          goto label_5;
        case 4:
          goto label_1;
        case 5:
          // ISSUE: reference to a compiler-generated field
          obj.\u206F‫‌‬⁬‮⁮⁫‌⁪⁫‪‪⁯‎‬‮‫⁯⁭‌‬‬‏⁪⁫​‪⁭‪‪⁪⁮⁭⁭‌‍‫‍‭‮ = this;
          num1 = (int) num2 * 776266770 ^ -714153081;
          continue;
        case 6:
          int num4;
          // ISSUE: reference to a compiler-generated field
          num1 = num4 = obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮.FlooderTaskSettings.Targets.Count == 0 ? -1845146354 : (num4 = -2058989780);
          continue;
        case 7:
          goto label_3;
        default:
          goto label_10;
      }
    }
label_5:
    return;
label_3:
    return;
label_10:
    return;
label_9:
    // ISSUE: reference to a compiler-generated field
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(obj.\u206B⁪‍⁯⁬⁬‪​⁪‫⁬‬‬⁭‌‍‪⁯‍‍⁪⁭‪‏⁮⁪‏‮⁫‫​​‌‎‫⁫⁮⁯‌⁬‮, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3254921703U));
  }

  void \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮.\u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮()
  {
    \u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮ obj = this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮;
    if (obj != null)
    {
      // ISSUE: explicit non-virtual call
      __nonvirtual (obj.Dispose());
    }
    else
      goto label_5;
label_2:
    int num1 = -2100554696;
label_3:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -288467826)) % 3U)
    {
      case 0:
        goto label_2;
      case 1:
        return;
      case 2:
        break;
      default:
        return;
    }
label_5:
    this.\u202B⁫​‏⁬‫⁫‮‮⁯‬‎‭‌‎‭⁬‎⁯‌‪⁮⁪‏‏‪⁯⁯​⁪​⁬‫⁯​⁪‫‬⁭‮‮ = (\u206B‬⁬⁪⁬⁮⁫‏⁪‌⁭‎‮⁯‍‎‍‬‬‍‌⁪‪‪‏‪‬⁮‍‮‎⁮⁯‎‎‍‍⁬⁬‪‮) null;
    num1 = -1335617775;
    goto label_3;
  }

  static string \u206E‬‪‫‍‌⁪⁫‫‌⁮⁬‭​‎‍‬⁮⁮⁭‪⁮‍⁮​⁫⁮⁮‮⁫⁭‮⁬⁮‭⁫‭‍⁬‪‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static string \u206F‏⁯⁪⁭⁯⁭‌‭​‫‭‮⁪‭‫⁭‏‭‮⁭‮‎⁮⁮⁫‏‫​⁮‬⁮⁯⁪‍⁬‫⁭⁪⁭‮(
    [In] string obj0,
    [In] string obj1,
    [In] string obj2)
  {
    return obj0.Replace(obj1, obj2);
  }

  static bool \u206A‎‫⁯‭⁯‎⁫‮‬⁭⁭‏‬⁬‎⁫⁬‌⁮‫‬‏‬‭‫⁭‪‭‪‮‌⁬‍⁪⁯‬‬⁭‪‮([In] string obj0, [In] string obj1)
  {
    return obj0 != obj1;
  }

  static bool \u200D‮‎‌⁫‫⁮‏⁬‫‍‭‬‎⁪⁭⁪‮⁭⁪‌‎‎‭⁭‌⁪⁬‍⁬‍⁯‌‮⁫‏‮‭‪⁫‮([In] string obj0, [In] string obj1)
  {
    return obj0 == obj1;
  }

  static string \u202D‎​⁫‪⁮‭‍‏‌‏⁪⁪⁭⁭⁫⁬⁯‎‌‪⁬‮‫⁮⁫⁭⁭‌‎⁪⁬‬⁭⁫⁯‫⁯‭⁪‮([In] string obj0, [In] string obj1)
  {
    return obj0 + obj1;
  }

  static string[] \u202A⁫‭‍‎⁭⁪⁮⁭⁯⁭‭‎‍⁭‭​‪‍⁫‌​⁭‮‍⁯‮‪‮‌⁬⁫‪‍‭‏‎⁮‎‪‮([In] string obj0, [In] char[] obj1)
  {
    return obj0.Split(obj1);
  }

  static string \u202B‭‍‫‭‭‏​‏‍⁮‪⁪⁫‮‪⁬⁪‮‌⁬‎‌‌‎⁭⁯‍⁪⁮‪⁭‮⁭‏‮⁬⁮​⁪‮(
    [In] string obj0,
    [In] string obj1,
    [In] string obj2)
  {
    return obj0 + obj1 + obj2;
  }

  static long? \u206A⁪‌​‌‮⁬​‍⁪‏‬⁫‮‭‫‍‭‮‌‬​⁫‬⁯‮‍‏‭‭‍⁬⁭​⁭⁪⁬‮‎⁯‮([In] MediaAttachment obj0) => obj0.Id;

  static Task \u200F‌⁫⁬‍‪‪‫⁫⁭⁪‪‌‍‎‌​⁮⁯⁫‌⁮‪⁪‪‎‌​⁮‌​‏⁪‌‍⁫‬‍‬⁭‮([In] Action obj0) => new Task(obj0);

  static void \u200F⁪⁮⁫‎‍‏⁪⁬‪‭⁭​‪⁮‫‬‌‏⁯‮⁭‪‫⁫‭‎‫‮‌‍‫‫⁭⁮​‪‮⁮⁮‮([In] Task obj0) => obj0.Start();
}
