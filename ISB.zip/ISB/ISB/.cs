﻿// Decompiled with JetBrains decompiler
// Type: ‏‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;

#nullable disable
public class \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮
{
  private readonly string \u200F‫⁪⁫⁯‫‏​‮⁯‏‫⁪‫‫​⁬‍⁪‎⁬​‭⁮⁭‌‬⁮‫⁭‎‎‎⁮⁯‏‫​⁯⁯‮;
  private string \u200D⁮⁪‮⁯⁪‭​‮‎⁮‌⁫‭‮‏‎‏‎‍‍‬‍⁮⁮⁬⁯‎‎‏‫‪​‏⁫‎⁯⁯‫‌‮;
  private static Dictionary<string, string> \u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮;

  public \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮(string _param1, string _param2)
  {
label_1:
    int num1 = 209280059;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1351599496)) % 13U)
      {
        case 0:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1535960052U), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2796774796U));
          num1 = (int) num2 * 775252626 ^ 2126985828;
          continue;
        case 1:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4253888569U), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2299131884U));
          num1 = (int) num2 * -175089432 ^ 1317753123;
          continue;
        case 2:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1111819351U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1949783255U));
          num1 = (int) num2 * 1478314231 ^ -845562166;
          continue;
        case 3:
          goto label_3;
        case 4:
          goto label_1;
        case 5:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2724481672U), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2021622215U));
          num1 = (int) num2 * -307182180 ^ -1657532873;
          continue;
        case 6:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3242403900U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3314385773U));
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(236440894U), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1645355791U));
          num1 = (int) num2 * 407696105 ^ -162489078;
          continue;
        case 7:
          this.\u200D⁮⁪‮⁯⁪‭​‮‎⁮‌⁫‭‮‏‎‏‎‍‍‬‍⁮⁮⁬⁯‎‎‏‫‪​‏⁫‎⁯⁯‫‌‮ = _param1;
          num1 = (int) num2 * -1605169695 ^ -1244349595;
          continue;
        case 8:
          this.\u200F‫⁪⁫⁯‫‏​‮⁯‏‫⁪‫‫​⁬‍⁪‎⁬​‭⁮⁭‌‬⁮‫⁭‎‎‎⁮⁯‏‫​⁯⁯‮ = _param2;
          int num3 = \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮ == null ? 1483782928 : (num3 = 709620071);
          num1 = num3 ^ (int) num2 * 919653966;
          continue;
        case 9:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2756599243U), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3349480141U));
          num1 = (int) num2 * 568900184 ^ 1297485763;
          continue;
        case 10:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(977161883U), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3649622835U));
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3621012714U), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2901290875U));
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2934901949U), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1952228424U));
          num1 = (int) num2 * 2091365227 ^ 1057095651;
          continue;
        case 11:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(4048741172U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3336711611U));
          num1 = (int) num2 * -626505392 ^ 1145177056;
          continue;
        case 12:
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮ = new Dictionary<string, string>();
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(327865600U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3079396474U));
          \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Add(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(675365654U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1972109093U));
          num1 = (int) num2 * 1759372325 ^ 1790473314;
          continue;
        default:
          goto label_15;
      }
    }
label_3:
    return;
label_15:;
  }

  public string \u206F‫⁬⁯‏‏‪⁭⁫‫⁯⁮‬⁪⁭⁬⁫⁮⁫‎‫​‭‏⁪‌‪‎‬⁬⁭⁮⁪‪‎⁪‌⁪‪‬‮(string _param1)
  {
    return this.\u206E‏⁭‮⁭‪‫⁯‎‏⁯⁪⁫‍⁪‮⁫⁯‫‮‪‏‌⁭‏‪‍‫​⁬⁪‍‭⁯‭‍‪‮⁯‫‮(\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206B​⁬⁮‮‎⁪‪​⁪‪⁮‌⁮‪‫‎‎⁬‮‬⁭‬‪​‮‎‌⁫‮‎‌‍‮⁮⁪⁯‎⁮⁯‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1327430722U), (object) this.\u200D⁮⁪‮⁯⁪‭​‮‎⁮‌⁫‭‮‏‎‏‎‍‍‬‍⁮⁮⁬⁯‎‎‏‫‪​‏⁫‎⁯⁯‫‌‮, (object) this.\u200F‫⁪⁫⁯‫‏​‮⁯‏‫⁪‫‫​⁬‍⁪‎⁬​‭⁮⁭‌‬⁮‫⁭‎‎‎⁮⁯‏‫​⁯⁯‮, (object) _param1));
  }

  public string \u200B‬‏‪‮‭‫‎⁯‫‬⁪⁫⁮⁫‭⁫⁪​⁬⁭⁯⁯‫‌⁪​⁫‏⁭⁪⁫⁪⁪‪‬‭⁬‍⁭‮(string _param1)
  {
    return this.\u200B‬‏‪‮‭‫‎⁯‫‬⁪⁫⁮⁫‭⁫⁪​⁬⁭⁯⁯‫‌⁪​⁫‏⁭⁪⁫⁪⁪‪‬‭⁬‍⁭‮(_param1, (\u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮) null);
  }

  public string \u200B‬‏‪‮‭‫‎⁯‫‬⁪⁫⁮⁫‭⁫⁪​⁬⁭⁯⁯‫‌⁪​⁫‏⁭⁪⁫⁪⁪‪‬‭⁬‍⁭‮(
    string _param1,
    \u200B⁭‫​‮⁮‮⁫⁬⁪‫⁭⁪‏‎⁮⁮​⁬‪‫‫⁭​‬⁪‫‎‬‭⁮‫‬⁫‪‏‬‭⁫⁮‮ _param2)
  {
    string requestUriString = \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‏⁮‏‬‌‌⁫‬‪⁫‫⁬⁬‬⁮‎⁪⁬⁯‭⁭⁫‏⁯⁮‭‏‍‎‎‮⁫‫​‭⁬‌‏‌‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3643397913U), (object) this.\u200D⁮⁪‮⁯⁪‭​‮‎⁮‌⁫‭‮‏‎‏‎‍‍‬‍⁮⁮⁬⁯‎‎‏‫‪​‏⁫‎⁯⁯‫‌‮);
    NameValueCollection nameValueCollection = \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202B‬‮⁭⁭‪‪⁯‮‌⁭‌⁯‬‏⁫‭⁫‍‌‎⁫‮‏⁯⁯‌‮‭⁫⁪‭⁮‫‪‏⁪⁬⁮⁬‮();
    \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202B⁬⁭⁪‭⁪⁫‏⁬​​⁮‪​⁭‌⁭‭⁭‬⁬‫⁮‌⁫⁫⁪‌⁬‫⁫⁭⁪‬⁬‏‬‏⁬⁪‮(nameValueCollection, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4105537957U), this.\u200F‫⁪⁫⁯‫‏​‮⁯‏‫⁪‫‫​⁬‍⁪‎⁬​‭⁮⁭‌‬⁮‫⁭‎‎‎⁮⁯‏‫​⁯⁯‮);
    if (_param2 != null)
      \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u200E⁭⁮⁫⁬⁮‫‬​‭⁪‬​‌​​‫‫⁪⁭‭‪‏⁮⁮‮⁪⁯‎‮‮‫‏‎‌⁯‌⁫‏‬‮(nameValueCollection, _param2.\u202B‭⁮‎​⁪​‪‌‫‫⁮⁭​‫‎‍‏‬⁯⁪​⁭⁭⁬‫⁯‭​⁮‮‫​‫‎⁪‮​‍‎‮());
    string str = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2335585107U) + DateTime.Now.Ticks.ToString(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1081931516U));
    byte[] bytes1 = Encoding.ASCII.GetBytes(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(730866684U) + str + \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3550447719U));
    HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(requestUriString);
label_3:
    int num1 = 149930810;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 2065924707)) % 4U)
      {
        case 1:
          httpWebRequest.ContentType = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1312474472U) + str;
          httpWebRequest.Method = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2979043803U);
          num1 = (int) num2 * 994933263 ^ 20179287;
          continue;
        case 2:
          goto label_3;
        case 3:
          httpWebRequest.KeepAlive = true;
          num1 = (int) num2 * -791281711 ^ -2058592836;
          continue;
        default:
          goto label_7;
      }
    }
label_7:
    httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
    Stream requestStream = httpWebRequest.GetRequestStream();
    string format = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1122364049U);
    IEnumerator enumerator = nameValueCollection.Keys.GetEnumerator();
    try
    {
label_13:
      int num3 = !enumerator.MoveNext() ? 1988975956 : (num3 = 1336038664);
      string current;
      string s;
      byte[] bytes2;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 2065924707)) % 8U)
        {
          case 0:
            requestStream.Write(bytes2, 0, bytes2.Length);
            num3 = (int) num4 * -2106541826 ^ -83532329;
            continue;
          case 1:
            bytes2 = Encoding.UTF8.GetBytes(s);
            num3 = (int) num4 * -1804841687 ^ -421126326;
            continue;
          case 2:
            num3 = 1336038664;
            continue;
          case 3:
            current = (string) enumerator.Current;
            num3 = 1425889414;
            continue;
          case 4:
            goto label_13;
          case 5:
            requestStream.Write(bytes1, 0, bytes1.Length);
            num3 = (int) num4 * -1482332244 ^ 250403809;
            continue;
          case 6:
            s = string.Format(format, (object) current, (object) nameValueCollection[current]);
            num3 = (int) num4 * 581850543 ^ 84671960;
            continue;
          default:
            goto label_22;
        }
      }
    }
    finally
    {
      if (enumerator is IDisposable disposable)
      {
label_18:
        int num5 = 1452637608;
        while (true)
        {
          uint num6;
          switch ((num6 = (uint) (num5 ^ 2065924707)) % 3U)
          {
            case 0:
              goto label_18;
            case 1:
              disposable.Dispose();
              num5 = (int) num6 * 1210622739 ^ -816090232;
              continue;
            default:
              goto label_21;
          }
        }
      }
label_21:;
    }
label_22:
    requestStream.Write(bytes1, 0, bytes1.Length);
label_23:
    int num7 = 935237866;
    FileStream fileStream;
    byte[] buffer;
    int count;
    while (true)
    {
      uint num8;
      switch ((num8 = (uint) (num7 ^ 2065924707)) % 9U)
      {
        case 0:
          fileStream.Close();
          num7 = (int) num8 * -807845428 ^ -2062280425;
          continue;
        case 1:
          count = 0;
          num7 = (int) num8 * 1290497094 ^ -2073212995;
          continue;
        case 2:
          requestStream.Write(buffer, 0, count);
          num7 = 659305713;
          continue;
        case 3:
          byte[] bytes3 = Encoding.UTF8.GetBytes(string.Format(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(510684465U), (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1147094567U), (object) _param1, (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3662471735U)));
          requestStream.Write(bytes3, 0, bytes3.Length);
          num7 = (int) num8 * -1229599318 ^ -390839163;
          continue;
        case 4:
          buffer = new byte[4096 /*0x1000*/];
          num7 = (int) num8 * 1832381359 ^ 1689054212;
          continue;
        case 5:
          fileStream = new FileStream(_param1, FileMode.Open, FileAccess.Read);
          num7 = (int) num8 * -1958180928 ^ -761179096;
          continue;
        case 6:
          int num9;
          num7 = num9 = (count = fileStream.Read(buffer, 0, buffer.Length)) != 0 ? 1218238493 : (num9 = 970216185);
          continue;
        case 7:
          goto label_23;
        default:
          goto label_32;
      }
    }
label_32:
    byte[] bytes4 = Encoding.ASCII.GetBytes(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(155897097U) + str + \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3261022696U));
    requestStream.Write(bytes4, 0, bytes4.Length);
    requestStream.Close();
    WebResponse response = httpWebRequest.GetResponse();
    try
    {
      return this.\u206C⁫⁬‭⁮‏‭⁮⁮‍‫‬⁫⁯‭‬⁬‬⁭‭‫‫‫⁮⁯⁭‎‎⁫⁭‪⁫⁬‭​‫‎​‭⁭‮(new StreamReader(response.GetResponseStream()).ReadToEnd());
    }
    finally
    {
      if (response != null)
      {
label_35:
        int num10 = 1972557028;
        while (true)
        {
          uint num11;
          switch ((num11 = (uint) (num10 ^ 2065924707)) % 3U)
          {
            case 0:
              goto label_35;
            case 1:
              response.Dispose();
              num10 = (int) num11 * -296567809 ^ 1281867324;
              continue;
            default:
              goto label_38;
          }
        }
      }
label_38:;
    }
  }

  public Decimal \u200D‏‫‏⁪‫⁪⁯⁭‌⁯⁭⁭‌‌‏⁯⁪‎‫‍⁯⁮‫‬‪​‍​​⁮​‎‌⁭⁭‮⁫⁫⁯‮()
  {
    return Decimal.Parse(this.\u206E‏⁭‮⁭‪‫⁯‎‏⁯⁪⁫‍⁪‮⁫⁯‫‮‪‏‌⁭‏‪‍‫​⁬⁪‍‭⁯‭‍‪‮⁯‫‮(\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202C⁪‫‮‪⁬‪‪​‎‪​⁪‎‏⁯⁮‪‭‏⁮⁫‪‏‮​‮‍⁪‭‪⁮​⁪‮‮⁫‍‎‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2509292405U), (object) this.\u200D⁮⁪‮⁯⁪‭​‮‎⁮‌⁫‭‮‏‎‏‎‍‍‬‍⁮⁮⁬⁯‎‎‏‫‪​‏⁫‎⁯⁯‫‌‮, (object) this.\u200F‫⁪⁫⁯‫‏​‮⁯‏‫⁪‫‫​⁬‍⁪‎⁬​‭⁮⁭‌‬⁮‫⁭‎‎‎⁮⁯‏‫​⁯⁯‮)), (IFormatProvider) \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202B⁪‏‏​‎‬⁫⁭‍‎‭‪‪‫​‎⁬⁫​⁫⁬‭⁮⁭‫⁬⁮‏⁬‫⁬‌‏‏⁯‍⁭⁫‍‮(\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u200E​⁮⁭⁯‮‫‏‫‮⁪‬⁪​‪⁬‮‪⁫⁫‎‬‮⁪⁪⁪⁫⁯‭⁬‮‎⁭⁬‍‮‮‎‌‫‮()));
  }

  private string \u206E‏⁭‮⁭‪‫⁯‎‏⁯⁪⁫‍⁪‮⁫⁯‫‮‪‏‌⁭‏‪‍‫​⁬⁪‍‭⁯‭‍‪‮⁯‫‮(string _param1)
  {
    HttpWebRequest httpWebRequest = (HttpWebRequest) \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u200E‮‫​⁭⁭‭‍‬‎⁮‌‍⁫‫‌⁯‌‬‮⁭⁪‪‭‫‌‌‍⁭​‭⁭⁫‍‮‏⁭⁪‮‪‮(_param1);
    \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206C⁬⁭‍⁮⁬‪‬‪‌⁯‪⁯⁯⁭‎‏⁪⁪‬⁯⁬‬‮⁫‍‎‪⁫‌‎⁯‪‭⁬‭⁪‍⁬‬‮((WebRequest) httpWebRequest, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4114847355U));
    string str = nameof ();
    HttpWebResponse httpWebResponse = (HttpWebResponse) \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202A⁬⁯‪⁭⁬⁮​⁫⁯‎‮‭‫‍⁯‎⁬‍‍⁮‮‫‭⁬‫‫⁬⁫⁯‪‪‏⁭​⁯‌⁭⁬⁭‮((WebRequest) httpWebRequest);
    try
    {
      str = \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206A‎⁫⁬‬⁫‬⁫⁭‫‫⁯‪‏⁪‌‏⁪‍⁫‍‍‏‍‮‍⁫‎‫⁯⁮​‬⁭‫‪‎⁬⁮⁯‮((TextReader) \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206A‮⁭⁪⁪‌⁮⁪‭⁫‎‫⁪‮⁫‎⁮‬‎⁮⁬⁮‏‪‪⁮‪‭‪‍⁪⁫​⁬⁮⁬‮‭‬⁭‮(\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u200B⁬‪‬⁯‏⁫⁫⁫⁫‍‪⁭​‎⁯‍‬⁭‎‍‭⁭⁯‬‎‮‪‭‏‍⁮‍⁫‬‎⁪⁮‏⁪‮((WebResponse) httpWebResponse)));
    }
    finally
    {
      if (httpWebResponse != null)
      {
label_3:
        int num1 = -1476125801;
        while (true)
        {
          uint num2;
          switch ((num2 = (uint) (num1 ^ -1849174376)) % 3U)
          {
            case 0:
              goto label_3;
            case 1:
              \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202C⁭‎‮​⁮‏⁪⁮⁯‪⁬‬‮⁮⁫‌⁫‬⁬⁪⁮‎‌⁭⁯‮​‪‌⁪‌⁯‍‍‎‍⁭⁬⁯‮((IDisposable) httpWebResponse);
              num1 = (int) num2 * 1636995446 ^ -1271804065;
              continue;
            default:
              goto label_6;
          }
        }
      }
label_6:;
    }
    return this.\u206C⁫⁬‭⁮‏‭⁮⁮‍‫‬⁫⁯‭‬⁬‬⁭‭‫‫‫⁮⁯⁭‎‎⁫⁭‪⁫⁬‭​‫‎​‭⁭‮(str);
  }

  private string \u206C⁫⁬‭⁮‏‭⁮⁮‍‫‬⁫⁯‭‬⁬‬⁭‭‫‫‫⁮⁯⁭‎‎⁫⁭‪⁫⁬‭​‫‎​‭⁭‮(string _param1)
  {
    if (!\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮.Keys.Contains<string>(_param1))
      goto label_4;
label_1:
    int num1 = 982612081;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ 1364643483)) % 5U)
    {
      case 0:
        goto label_1;
      case 2:
        throw new \u202E⁬⁯‎⁮‏‍‭‫‪‫‬‌⁮⁮⁭⁭‬​‫⁮⁯‎‮‮‫‮​⁫⁭‏‬‏⁯‫‬⁫‮‬⁯‮(\u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u202C⁪‫‮‪⁬‪‪​‎‪​⁪‎‏⁯⁮‪‭‏⁮⁫‪‏‮​‮‍⁪‭‪⁮​⁪‮‮⁫‍‎‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1178292244U), (object) \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206F‎⁫‫⁪‬‍⁯⁪​⁮‌⁪⁪‮‍‭‮‪​‏⁪‌‪​‍‌‎‎⁫⁮⁬⁮⁬‭‪⁪⁪‌⁬‮[_param1], (object) _param1));
      case 3:
        return \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u206B⁯‎⁮⁪‏⁪‌⁯‫⁯⁯⁮‏‌⁯‌‫‌‮⁮⁫⁬​‌‎‫‍‪‬⁭⁯‮⁪‪‎⁮⁯‏⁮‮(_param1, 3);
      case 4:
        break;
      default:
        return _param1;
    }
label_4:
    num1 = \u200F‬‏‎⁬⁪​‬⁭‏‏⁮‌⁮⁪⁭‫⁫‍⁫⁪​‭‍‏‌⁪‪‍‎⁫​⁪‬⁪‏​‌‬‎‮.\u200E‏⁪‎‮‭‎⁭‬⁯⁬‮‏‬‮​‌‪‪‏‫‎⁯‭⁪‬⁪​‎⁫⁬⁮‫⁯​‍⁪⁮‏‏‮(_param1, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3098733485U)) ? 1240100777 : (num1 = 1234790050);
    goto label_2;
  }

  static string \u206B​⁬⁮‮‎⁪‪​⁪‪⁮‌⁮‪‫‎‎⁬‮‬⁭‬‪​‮‎‌⁫‮‎‌‍‮⁮⁪⁯‎⁮⁯‮(
    [In] string obj0,
    [In] object obj1,
    [In] object obj2,
    [In] object obj3)
  {
    return string.Format(obj0, obj1, obj2, obj3);
  }

  static string \u206F‏⁮‏‬‌‌⁫‬‪⁫‫⁬⁬‬⁮‎⁪⁬⁯‭⁭⁫‏⁯⁮‭‏‍‎‎‮⁫‫​‭⁬‌‏‌‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static NameValueCollection \u202B‬‮⁭⁭‪‪⁯‮‌⁭‌⁯‬‏⁫‭⁫‍‌‎⁫‮‏⁯⁯‌‮‭⁫⁪‭⁮‫‪‏⁪⁬⁮⁬‮()
  {
    return new NameValueCollection();
  }

  static void \u202B⁬⁭⁪‭⁪⁫‏⁬​​⁮‪​⁭‌⁭‭⁭‬⁬‫⁮‌⁫⁫⁪‌⁬‫⁫⁭⁪‬⁬‏‬‏⁬⁪‮(
    [In] NameValueCollection obj0,
    [In] string obj1,
    [In] string obj2)
  {
    obj0.Add(obj1, obj2);
  }

  static void \u200E⁭⁮⁫⁬⁮‫‬​‭⁪‬​‌​​‫‫⁪⁭‭‪‏⁮⁮‮⁪⁯‎‮‮‫‏‎‌⁯‌⁫‏‬‮(
    [In] NameValueCollection obj0,
    [In] NameValueCollection obj1)
  {
    obj0.Add(obj1);
  }

  static string \u202C⁪‫‮‪⁬‪‪​‎‪​⁪‎‏⁯⁮‪‭‏⁮⁫‪‏‮​‮‍⁪‭‪⁮​⁪‮‮⁫‍‎‮‮(
    [In] string obj0,
    [In] object obj1,
    [In] object obj2)
  {
    return string.Format(obj0, obj1, obj2);
  }

  static CultureInfo \u200E​⁮⁭⁯‮‫‏‫‮⁪‬⁪​‪⁬‮‪⁫⁫‎‬‮⁪⁪⁪⁫⁯‭⁬‮‎⁭⁬‍‮‮‎‌‫‮()
  {
    return CultureInfo.InvariantCulture;
  }

  static NumberFormatInfo \u202B⁪‏‏​‎‬⁫⁭‍‎‭‪‪‫​‎⁬⁫​⁫⁬‭⁮⁭‫⁬⁮‏⁬‫⁬‌‏‏⁯‍⁭⁫‍‮([In] CultureInfo obj0)
  {
    return obj0.NumberFormat;
  }

  static WebRequest \u200E‮‫​⁭⁭‭‍‬‎⁮‌‍⁫‫‌⁯‌‬‮⁭⁪‪‭‫‌‌‍⁭​‭⁭⁫‍‮‏⁭⁪‮‪‮([In] string obj0)
  {
    return WebRequest.Create(obj0);
  }

  static void \u206C⁬⁭‍⁮⁬‪‬‪‌⁯‪⁯⁯⁭‎‏⁪⁪‬⁯⁬‬‮⁫‍‎‪⁫‌‎⁯‪‭⁬‭⁪‍⁬‬‮([In] WebRequest obj0, [In] string obj1)
  {
    obj0.Method = obj1;
  }

  static WebResponse \u202A⁬⁯‪⁭⁬⁮​⁫⁯‎‮‭‫‍⁯‎⁬‍‍⁮‮‫‭⁬‫‫⁬⁫⁯‪‪‏⁭​⁯‌⁭⁬⁭‮([In] WebRequest obj0)
  {
    return obj0.GetResponse();
  }

  static Stream \u200B⁬‪‬⁯‏⁫⁫⁫⁫‍‪⁭​‎⁯‍‬⁭‎‍‭⁭⁯‬‎‮‪‭‏‍⁮‍⁫‬‎⁪⁮‏⁪‮([In] WebResponse obj0)
  {
    return obj0.GetResponseStream();
  }

  static StreamReader \u206A‮⁭⁪⁪‌⁮⁪‭⁫‎‫⁪‮⁫‎⁮‬‎⁮⁬⁮‏‪‪⁮‪‭‪‍⁪⁫​⁬⁮⁬‮‭‬⁭‮([In] Stream obj0)
  {
    return new StreamReader(obj0);
  }

  static string \u206A‎⁫⁬‬⁫‬⁫⁭‫‫⁯‪‏⁪‌‏⁪‍⁫‍‍‏‍‮‍⁫‎‫⁯⁮​‬⁭‫‪‎⁬⁮⁯‮([In] TextReader obj0)
  {
    return obj0.ReadToEnd();
  }

  static void \u202C⁭‎‮​⁮‏⁪⁮⁯‪⁬‬‮⁮⁫‌⁫‬⁬⁪⁮‎‌⁭⁯‮​‪‌⁪‌⁯‍‍‎‍⁭⁬⁯‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static bool \u200E‏⁪‎‮‭‎⁭‬⁯⁬‮‏‬‮​‌‪‪‏‫‎⁯‭⁪‬⁪​‎⁫⁬⁮‫⁯​‍⁪⁮‏‏‮([In] string obj0, [In] string obj1)
  {
    return obj0.StartsWith(obj1);
  }

  static string \u206B⁯‎⁮⁪‏⁪‌⁯‫⁯⁯⁮‏‌⁯‌‫‌‮⁮⁫⁬​‌‎‫‍‪‬⁭⁯‮⁪‪‎⁮⁯‏⁮‮([In] string obj0, [In] int obj1)
  {
    return obj0.Substring(obj1);
  }
}
