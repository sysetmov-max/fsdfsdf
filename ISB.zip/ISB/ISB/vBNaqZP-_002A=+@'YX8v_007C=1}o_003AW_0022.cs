﻿// Decompiled with JetBrains decompiler
// Type: vBNaqZP-*=+@'YX8v|=1}o:W"
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Configs;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
internal sealed class vBNaqZP\u002D\u002A\u003D\u002B\u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022 : 
  \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮
{
  private IContainer \u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮;
  private TextBox \u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮;
  private Label \u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮;
  private Label \u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮;
  private TextBox \u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮;
  private Button \u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮;
  private Button \u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮;
  private Label \u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮;

  public vBNaqZP\u002D\u002A\u003D\u002B\u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022()
  {
label_1:
    int num1 = -283541814;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1450299529)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          this.\u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮();
          num1 = (int) num2 * -1755753071 ^ -1773794124;
          continue;
        case 2:
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200E‏⁬‌⁭‫‪‬‭⁮‬‭‭⁪⁭​‬‍‏​‎‮‫‏‪​⁫‮‪⁪⁬‌​‭‍​⁭‮⁬⁬‮((Control) this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮, ConfigController.AnticapConfig.AnticaptchaKey);
          num1 = (int) num2 * 1156286931 ^ 386486363;
          continue;
        case 3:
          goto label_3;
        case 4:
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206D⁪‪‎‮⁮⁫​‮​‬⁪⁭‭‫‪⁪‍​⁫‎‎‪​‏‏‌‫‪⁯‭‪‮‫⁪‭⁪⁬⁪⁬‮((Control) this, Color.FromArgb(ConfigController.InterfaceConfig.ForColorAsArgb));
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200E‏⁬‌⁭‫‪‬‭⁮‬‭‭⁪⁭​‬‍‏​‎‮‫‏‪​⁫‮‪⁪⁬‌​‭‍​⁭‮⁬⁬‮((Control) this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮, ConfigController.AnticapConfig.RucaptchaKey);
          num1 = (int) num2 * 1175788685 ^ 739604300;
          continue;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_7:;
  }

  private void \u206E‏‌⁮⁫⁭‫‪‮‬‏‫‮‭‮​‪‭‬‪​‫⁯‎‫‌‫​‍‫‭‫‏‮⁫⁭‫​​‭‮(object _param1, EventArgs _param2)
  {
    ConfigController.AnticapConfig.RucaptchaKey = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206E⁫⁫‎‎⁬⁮‍⁪⁮‬‍‮‍⁬‬‏‌⁪‭⁭‭⁪‫‎‫‏⁪‮​‭‎‍‪‪‭‌⁬‮‏‮((Control) this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮);
label_1:
    int num1 = -1750434026;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -169691158)) % 3U)
      {
        case 0:
          goto label_3;
        case 1:
          ConfigController.AnticapConfig.Save();
          num1 = (int) num2 * -2009271885 ^ -1746645543;
          continue;
        case 2:
          goto label_1;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private void \u200B‪⁮‫⁬‌⁮⁪‏⁫⁭‫‍​‎⁯‬‭⁮⁮‌‏‭‍‎⁪⁭⁫‏⁭‎⁯​‍‫⁬⁬‌‭‎‮(object _param1, EventArgs _param2)
  {
    ConfigController.AnticapConfig.AnticaptchaKey = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206E⁫⁫‎‎⁬⁮‍⁪⁮‬‍‮‍⁬‬‏‌⁪‭⁭‭⁪‫‎‫‏⁪‮​‭‎‍‪‪‭‌⁬‮‏‮((Control) this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮);
    ConfigController.AnticapConfig.Save();
  }

  private void \u206E‮⁮⁭‭‫⁫‌⁬‫‏⁫‍‪⁮⁬‌‪‮‫‪⁮‭⁯⁯‮‭⁭⁪‫⁯‫‭‫‎‍⁪‌​‌‮(object _param1, EventArgs _param2)
  {
    \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200E‏⁬‌⁭‫‪‬‭⁮‬‭‭⁪⁭​‬‍‏​‎‮‫‏‪​⁫‮‪⁪⁬‌​‭‍​⁭‮⁬⁬‮((Control) this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮, \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200D⁮‌‏‌⁯⁪‮​⁭⁪⁪‭‮​‪‭⁯⁭‏‫‍⁫‏⁭​⁪‫⁫‎‮‭⁬⁫‎⁯⁪‬‍‎‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u206F​⁬⁮‪‎⁬‎⁯‬‎‏‎‍‏⁮⁫‮‌​⁬⁭‬‏‎‬‫‎​⁮‌‎‌‍‏⁮‬‏‫‫‮(\u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200C‭‍‭‎‫‫‬‭‮⁪‏⁬⁫⁫‫‬‫‍⁮⁭‍⁮‮‍​⁮‫‫‏‍‬⁭‌‫‎‫‎⁪‍‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2594740474U), (object) \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206E⁫⁫‎‎⁬⁮‍⁪⁮‬‍‮‍⁬‬‏‌⁪‭⁭‭⁪‫‎‫‏⁪‮​‭‎‍‪‪‭‌⁬‮‏‮((Control) this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮))), \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(585537213U)));
  }

  private void \u200C‬‏​⁭‏‭‍​⁬​‮‪‭‫⁫‌⁯⁮‏⁬‮‎‭‮⁫⁪‫‏⁬⁭⁫‌‏⁭‪‏⁪⁬⁪‮(object _param1, EventArgs _param2)
  {
    \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200E‏⁬‌⁭‫‪‬‭⁮‬‭‭⁪⁭​‬‍‏​‎‮‫‏‪​⁫‮‪⁪⁬‌​‭‍​⁭‮⁬⁬‮((Control) this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮, \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200D⁮‌‏‌⁯⁪‮​⁭⁪⁪‭‮​‪‭⁯⁭‏‫‍⁫‏⁭​⁪‫⁫‎‮‭⁬⁫‎⁯⁪‬‍‎‮(\u202B‬‭‌⁬⁮‬‏⁯⁬‍‬⁫⁮⁫‬⁭‮‪‏⁪⁪⁪‍‬⁫‍‭‏‪⁮‫‪‮​‬‮⁬‭⁫‮.\u206F​⁬⁮‪‎⁬‎⁯‬‎‏‎‍‏⁮⁫‮‌​⁬⁭‬‏‎‬‫‎​⁮‌‎‌‍‏⁮‬‏‫‫‮(\u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200C‭‍‭‎‫‫‬‭‮⁪‏⁬⁫⁫‫‬‫‍⁮⁭‍⁮‮‍​⁮‫‫‏‍‬⁭‌‫‎‫‎⁪‍‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3763974742U), (object) \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206E⁫⁫‎‎⁬⁮‍⁪⁮‬‍‮‍⁬‬‏‌⁪‭⁭‭⁪‫‎‫‏⁪‮​‭‎‍‪‪‭‌⁬‮‏‮((Control) this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮))), \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2865164850U)));
  }

  virtual void Form.\u202D⁫⁫‍‭​⁪‌‫⁬‎⁮‭‌⁬‌‫‎‭‮‍‭⁫‬‭⁬‪⁪⁪‌⁮⁮‏‭⁯⁬⁮⁬‮‌‮(bool _param1)
  {
    if (!_param1)
      goto label_6;
label_1:
    int num1 = -563664040;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1077189044)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          int num3 = this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮ == null ? 29868179 : (num3 = 2119677072);
          num1 = num3 ^ (int) num2 * -1228349580;
          continue;
        case 2:
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206C⁪⁯⁬⁬‌⁫⁬​‍‮⁮⁯‭⁭​‬‪⁪‬​‏‪⁬‬‮‌⁯‬⁯‮‪⁭⁮‪⁬‎‪⁬‮‮((IDisposable) this.\u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮);
          num1 = (int) num2 * 1431226455 ^ 1260092375;
          continue;
        case 3:
          goto label_1;
        case 4:
          goto label_6;
        default:
          goto label_7;
      }
    }
label_3:
    return;
label_7:
    return;
label_6:
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(_param1));
    num1 = -527055891;
    goto label_2;
  }

  private void \u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮()
  {
    this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206D‏⁯‎‫‪⁪⁭​⁭⁮‬‏⁯⁭​⁪⁪⁮‏‏⁭‭‮‫‪‌‭‎‍‭‬‭​‏‌‭‭⁪⁮‮();
    this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u202C‍​⁮​‎⁬⁭⁪⁪⁪⁭⁯‬⁮⁬‪‫‪⁯⁮‏‮‍​‮⁯‍‭⁮⁯‍‫⁯‌⁯‌‪‬‪‮();
label_1:
    int num1 = 597657135;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 996875201)) % 48U /*0x30*/)
      {
        case 0:
          this.AutoScaleDimensions = new SizeF(6f, 13f);
          this.AutoScaleMode = AutoScaleMode.Font;
          num1 = (int) num2 * -1890028140 ^ -2095976934;
          continue;
        case 1:
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206C‪‭​⁭‭‫‮‮‎‍​‏⁬‌‬⁯‪‎‭⁫‏‎⁫‎‍‏‪‍‍⁯‌‎⁬‎⁪‍‪‫‭‮((Control) this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮, Color.WhiteSmoke);
          num1 = (int) num2 * -1405516226 ^ -1356301854;
          continue;
        case 2:
          this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮.TextChanged += new EventHandler(this.\u206E‏‌⁮⁫⁭‫‪‮‬‏‫‮‭‮​‪‭‬‪​‫⁯‎‫‌‫​‍‫‭‫‏‮⁫⁭‫​​‭‮);
          num1 = (int) num2 * 2124582343 ^ 1679961445;
          continue;
        case 3:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Size = new Size(107, 13);
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.TabIndex = 1;
          num1 = (int) num2 * -1233801937 ^ 682264486;
          continue;
        case 4:
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.TextChanged += new EventHandler(this.\u200B‪⁮‫⁬‌⁮⁪‏⁫⁭‫‍​‎⁯‬‭⁮⁮‌‏‭‍‎⁪⁭⁫‏⁭‎⁯​‍‫⁬⁬‌‭‎‮);
          num1 = (int) num2 * -157701605 ^ -1432474222;
          continue;
        case 5:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1313837672U);
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Size = new Size(118, 13);
          num1 = (int) num2 * 1846255697 ^ -278615391;
          continue;
        case 6:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Location = new Point(176 /*0xB0*/, 7);
          num1 = (int) num2 * 562959355 ^ 1496420344;
          continue;
        case 7:
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u202C⁪⁮⁪⁯‭‫‎‭‭‭⁬⁬‫‮⁪⁫⁬‪‫⁪‮⁬⁪‮⁬‬‍⁬‬‫‏⁬⁮⁭‬⁯‫‮‏‮();
          num1 = (int) num2 * 1364414493 ^ 734156147;
          continue;
        case 8:
          this.Controls.Add((Control) this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮);
          num1 = (int) num2 * 1319554683 ^ 196912389;
          continue;
        case 9:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.UseVisualStyleBackColor = true;
          num1 = (int) num2 * -972129781 ^ 797068241;
          continue;
        case 10:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Text = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3125865750U);
          num1 = (int) num2 * -1857310740 ^ 329875770;
          continue;
        case 11:
          this.BackColor = SystemColors.WindowFrame;
          num1 = (int) num2 * 1623657063 ^ 1365447057;
          continue;
        case 12:
          this.Controls.Add((Control) this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮);
          this.Controls.Add((Control) this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮);
          num1 = (int) num2 * 2087151689 ^ 117865391;
          continue;
        case 13:
          this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮.Location = new Point(12, 23);
          num1 = (int) num2 * 1144077161 ^ 2046332400;
          continue;
        case 14:
          \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u200F‫‎⁬⁯⁫‬⁯⁮‪‮⁯⁬‎⁭‍⁪‮‪‬⁫⁫‌⁭⁬⁭‌⁬‍‫⁪‎⁮‬⁯​⁪‪⁭‮((Control) this);
          num1 = (int) num2 * -2052686349 ^ -325549894;
          continue;
        case 15:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.FlatStyle = FlatStyle.Flat;
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Font = new Font(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2958081165U), 6.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          num1 = (int) num2 * -664046779 ^ 1694998902;
          continue;
        case 16 /*0x10*/:
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Size = new Size(82, 20);
          num1 = (int) num2 * -1143564395 ^ 1540879821;
          continue;
        case 17:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.AutoSize = true;
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Location = new Point(437, 7);
          num1 = (int) num2 * 11327971 ^ 911508610;
          continue;
        case 18:
          this.Controls.Add((Control) this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮);
          num1 = (int) num2 * -1947870673 ^ -1928909273;
          continue;
        case 19:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Click += new EventHandler(this.\u206E‮⁮⁭‭‫⁫‌⁬‫‏⁫‍‪⁮⁬‌‪‮‫‪⁮‭⁯⁯‮‭⁭⁪‫⁯‫‭‫‎‍⁪‌​‌‮);
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.FlatStyle = FlatStyle.Flat;
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Font = new Font(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4290614350U), 6.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 204);
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Location = new Point(438, 64 /*0x40*/);
          num1 = (int) num2 * -1944104610 ^ 1576779974;
          continue;
        case 20:
          this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2040904207U);
          this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮.Size = new Size(420, 20);
          num1 = (int) num2 * -1155298810 ^ 1078361375;
          continue;
        case 21:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.TabIndex = 3;
          num1 = (int) num2 * 2144543414 ^ 1130083400;
          continue;
        case 22:
          this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮.TabIndex = 0;
          num1 = (int) num2 * 1891558837 ^ 2055435245;
          continue;
        case 23:
          this.Controls.Add((Control) this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮);
          this.Controls.Add((Control) this.\u202C‫‭​‏‮⁬‫‪⁬‎‍⁫⁬⁯‪⁫‪‍‪‎⁭⁭‮​⁫‮‎​​‎‫⁪‫⁮⁮‪‫‏‮‮);
          num1 = (int) num2 * -467037837 ^ 580644986;
          continue;
        case 24:
          this.Controls.Add((Control) this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮);
          num1 = (int) num2 * -1090707731 ^ -1662632354;
          continue;
        case 25:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u202C‍​⁮​‎⁬⁭⁪⁪⁪⁭⁯‬⁮⁬‪‫‪⁯⁮‏‮‍​‮⁯‍‭⁮⁯‍‫⁯‌⁯‌‪‬‪‮();
          num1 = (int) num2 * 785208361 ^ -2034376274;
          continue;
        case 26:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.AutoSize = true;
          num1 = (int) num2 * 1975369774 ^ -1867801173;
          continue;
        case 27:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.TabIndex = 35;
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Text = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1370272904U);
          num1 = (int) num2 * 1396729362 ^ -1405118009;
          continue;
        case 28:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Location = new Point(438, 23);
          num1 = (int) num2 * 675463750 ^ 1533840571;
          continue;
        case 29:
          this.ClientSize = new Size(526, 96 /*0x60*/);
          num1 = (int) num2 * -780129661 ^ 1008862414;
          continue;
        case 30:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u202C‍​⁮​‎⁬⁭⁪⁪⁪⁭⁯‬⁮⁬‪‫‪⁯⁮‏‮‍​‮⁯‍‭⁮⁯‍‫⁯‌⁯‌‪‬‪‮();
          num1 = (int) num2 * -1137412769 ^ -1831023542;
          continue;
        case 31 /*0x1F*/:
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.Name = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(106109711U);
          num1 = (int) num2 * -335805095 ^ -2135663600;
          continue;
        case 32 /*0x20*/:
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1745674976U);
          this.\u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮.Size = new Size(83, 13);
          num1 = (int) num2 * 1058682541 ^ -28546214;
          continue;
        case 33:
          goto label_3;
        case 34:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Name = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3043988664U);
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Size = new Size(82, 20);
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.TabIndex = 33;
          num1 = (int) num2 * 732438965 ^ 155679331;
          continue;
        case 35:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.AutoSize = true;
          num1 = (int) num2 * -1248130834 ^ 1748235313;
          continue;
        case 36:
          this.ResumeLayout(false);
          this.PerformLayout();
          num1 = (int) num2 * 177261720 ^ -656499728;
          continue;
        case 37:
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2391873746U);
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.UseVisualStyleBackColor = true;
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Click += new EventHandler(this.\u200C‬‏​⁭‏‭‍​⁬​‮‪‭‫⁫‌⁯⁮‏⁬‮‎‭‮⁫⁪‫‏⁬⁭⁫‌‏⁭‪‏⁪⁬⁪‮);
          num1 = (int) num2 * 1920511726 ^ 1413503542;
          continue;
        case 38:
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.Size = new Size(420, 20);
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.TabIndex = 2;
          num1 = (int) num2 * 156257516 ^ 1008894765;
          continue;
        case 39:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(320225476U);
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.BackColor = Color.WhiteSmoke;
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮.Location = new Point(12, 65);
          num1 = (int) num2 * 2079663989 ^ 1437544973;
          continue;
        case 40:
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮.Text = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3300344481U);
          num1 = (int) num2 * -1096959250 ^ 669002328;
          continue;
        case 41:
          this.\u200E‬‪‪⁭⁮⁯⁭⁭‌‪⁬⁮​‮⁬‫⁮‭⁯‌‬⁫​‏‌⁬‫‪⁫‎⁬‮‮‭⁬‬‎‭‮‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u206D‏⁯‎‫‪⁪⁭​⁭⁮‬‏⁯⁭​⁪⁪⁮‏‏⁭‭‮‫‪‌‭‎‍‭‬‭​‏‌‭‭⁪⁮‮();
          this.\u202B⁬⁭‏⁯‬⁬‌‎‌‏⁮‫⁯‌⁮⁫‏⁭⁫⁪‍⁫‬⁪⁯‏‬‎‭‪⁬⁬⁮⁫⁬‭‍‏‮‮ = \u0040\u0027YX8v\u007C\u003D1\u007Do\u003AW\u0022.\u202C⁪⁮⁪⁯‭‫‎‭‭‭⁬⁬‫‮⁪⁫⁬‪‫⁪‮⁬⁪‮⁬‬‍⁬‬‫‏⁬⁮⁭‬⁯‫‮‏‮();
          num1 = (int) num2 * 1314887100 ^ -468099990;
          continue;
        case 42:
          this.\u206F‮⁬‫‏‪⁬⁫⁯‍‮⁮⁮‏‬‭‌⁪⁬‫‪‮⁭‎⁮‭‪‍‪​‏‍‮‫‏​⁮⁯​‪‮.Location = new Point(170, 49);
          num1 = (int) num2 * -1372434677 ^ -924139574;
          continue;
        case 43:
          this.\u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮.Name = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2789965955U);
          num1 = (int) num2 * -1513164874 ^ 171459920;
          continue;
        case 44:
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.TabIndex = 34;
          num1 = (int) num2 * -343860022 ^ 959814828;
          continue;
        case 45:
          this.\u206A⁯⁫⁭⁯‮⁮​⁫‏⁭⁯‎‪‌⁬‌⁮‫‬‎‫⁪​⁯‬⁯⁮⁬‍​‎​⁬‭‏‬‍‫⁯‮.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1492898776U);
          num1 = (int) num2 * 1865818007 ^ -1356763590;
          continue;
        case 46:
          this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
          this.Name = \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3819329928U);
          this.Text = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(769772328U);
          num1 = (int) num2 * -2076879410 ^ -1754340431;
          continue;
        case 47:
          goto label_1;
        default:
          goto label_50;
      }
    }
label_3:
    return;
label_50:;
  }

  static void \u206D⁪‪‎‮⁮⁫​‮​‬⁪⁭‭‫‪⁪‍​⁫‎‎‪​‏‏‌‫‪⁯‭‪‮‫⁪‭⁪⁬⁪⁬‮([In] Control obj0, [In] Color obj1)
  {
    obj0.ForeColor = obj1;
  }

  static void \u200E‏⁬‌⁭‫‪‬‭⁮‬‭‭⁪⁭​‬‍‏​‎‮‫‏‪​⁫‮‪⁪⁬‌​‭‍​⁭‮⁬⁬‮([In] Control obj0, [In] string obj1)
  {
    obj0.Text = obj1;
  }

  static string \u206E⁫⁫‎‎⁬⁮‍⁪⁮‬‍‮‍⁬‬‏‌⁪‭⁭‭⁪‫‎‫‏⁪‮​‭‎‍‪‪‭‌⁬‮‏‮([In] Control obj0) => obj0.Text;

  static string \u200C‭‍‭‎‫‫‬‭‮⁪‏⁬⁫⁫‫‬‫‍⁮⁭‍⁮‮‍​⁮‫‫‏‍‬⁭‌‫‎‫‎⁪‍‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static string \u200D⁮‌‏‌⁯⁪‮​⁭⁪⁪‭‮​‪‭⁯⁭‏‫‍⁫‏⁭​⁪‫⁫‎‮‭⁬⁫‎⁯⁪‬‍‎‮([In] string obj0, [In] string obj1)
  {
    return obj0 + obj1;
  }

  static void \u206C⁪⁯⁬⁬‌⁫⁬​‍‮⁮⁯‭⁭​‬‪⁪‬​‏‪⁬‬‮‌⁯‬⁯‮‪⁭⁮‪⁬‎‪⁬‮‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static TextBox \u206D‏⁯‎‫‪⁪⁭​⁭⁮‬‏⁯⁭​⁪⁪⁮‏‏⁭‭‮‫‪‌‭‎‍‭‬‭​‏‌‭‭⁪⁮‮() => new TextBox();

  static Label \u202C‍​⁮​‎⁬⁭⁪⁪⁪⁭⁯‬⁮⁬‪‫‪⁯⁮‏‮‍​‮⁯‍‭⁮⁯‍‫⁯‌⁯‌‪‬‪‮() => new Label();

  static Button \u202C⁪⁮⁪⁯‭‫‎‭‭‭⁬⁬‫‮⁪⁫⁬‪‫⁪‮⁬⁪‮⁬‬‍⁬‬‫‏⁬⁮⁭‬⁯‫‮‏‮() => new Button();

  static void \u200F‫‎⁬⁯⁫‬⁯⁮‪‮⁯⁬‎⁭‍⁪‮‪‬⁫⁫‌⁭⁬⁭‌⁬‍‫⁪‎⁮‬⁯​⁪‪⁭‮([In] Control obj0)
  {
    obj0.SuspendLayout();
  }

  static void \u206C‪‭​⁭‭‫‮‮‎‍​‏⁬‌‬⁯‪‎‭⁫‏‎⁫‎‍‏‪‍‍⁯‌‎⁬‎⁪‍‪‫‭‮([In] Control obj0, [In] Color obj1)
  {
    obj0.BackColor = obj1;
  }
}
