﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.SelectedMode
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

#nullable disable
namespace ISP.Configs;

internal enum SelectedMode
{
  Rucaptcha,
  Anticaptcha,
  Manual,
}
