﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.InterfaceConfig
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Configs;

internal sealed class InterfaceConfig : ISBConfig
{
  public string PathToBackgroundImgGeneral;
  public string PathToBackgroundImgTabs;
  public int ForColorAsArgb;

  public InterfaceConfig()
  {
label_1:
    int num1 = 1098023352;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1849150873)) % 4U)
      {
        case 0:
          goto label_3;
        case 1:
          this.PathToBackgroundImgGeneral = this.PathToBackgroundImgTabs = (string) null;
          num1 = (int) num2 * -1446988120 ^ 1727214538;
          continue;
        case 2:
          goto label_1;
        case 3:
          this.ForColorAsArgb = Color.Black.ToArgb();
          num1 = (int) num2 * 980440736 ^ -1228492035;
          continue;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  public void Save()
  {
    InterfaceConfig.\u202D‭⁮⁯⁮‮‎⁬‪‮⁬​‭⁭‍⁯‮⁪‮⁫‍‍‭‬⁫‏⁭⁫‎⁫‎‬​‮‫‫⁭‎⁯‍‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3342181720U), InterfaceConfig.\u202E‏⁪⁯‫‪⁮‪‌⁬‬‏⁯‫⁪‌⁯‌​⁮‬⁭‪⁬⁭‬‭‍‎‬‫‪‭‍⁬‌⁮‫⁯‭‮((object) this));
  }

  static string \u202E‏⁪⁯‫‪⁮‪‌⁬‬‏⁯‫⁪‌⁯‌​⁮‬⁭‪⁬⁭‬‭‍‎‬‫‪‭‍⁬‌⁮‫⁯‭‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }

  static void \u202D‭⁮⁯⁮‮‎⁬‪‮⁬​‭⁭‍⁯‮⁪‮⁫‍‍‭‬⁫‏⁭⁫‎⁫‎‬​‮‫‫⁭‎⁯‍‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }
}
