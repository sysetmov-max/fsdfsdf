﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.AnticapConfig
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.IO;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Configs;

internal sealed class AnticapConfig : ISBConfig
{
  public string RucaptchaKey;
  public string AnticaptchaKey;
  public SelectedMode SelectedMode;

  public AnticapConfig()
  {
    this.RucaptchaKey = this.AnticaptchaKey = "";
    this.SelectedMode = SelectedMode.Manual;
  }

  public void Save()
  {
    AnticapConfig.\u206A‫‌⁯‭⁪‮‏⁯‍‪‎​‭‍‮⁮‫‎‌⁮‭‪‭⁫⁬⁬‎⁪‍‌​‮⁯‍⁬‫⁯‭⁭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(829829197U), AnticapConfig.\u202B⁫⁫⁮⁯⁭⁪⁫⁭⁫⁮‮‮‮⁬⁮‭​⁬​⁯⁭⁫‎‌‪‍‍⁯‌‍‏‏‏⁯‮‬‬‌‭‮((object) this));
  }

  static string \u202B⁫⁫⁮⁯⁭⁪⁫⁭⁫⁮‮‮‮⁬⁮‭​⁬​⁯⁭⁫‎‌‪‍‍⁯‌‍‏‏‏⁯‮‬‬‌‭‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }

  static void \u206A‫‌⁯‭⁪‮‏⁯‍‪‎​‭‍‮⁮‫‎‌⁮‭‪‭⁫⁬⁬‎⁪‍‌​‮⁯‍⁬‫⁯‭⁭‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }
}
