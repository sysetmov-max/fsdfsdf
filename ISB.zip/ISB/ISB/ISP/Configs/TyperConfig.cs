﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.TyperConfig
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.IO;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Configs;

internal sealed class TyperConfig : ISBConfig
{
  public int TypingDelay;
  public int SendingDelay;
  public string Name;
  public int NamePlacement;

  public TyperConfig()
  {
label_1:
    int num1 = 1231995593;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 792550850)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          this.TypingDelay = 100;
          num1 = (int) num2 * 115645008 ^ 24334516;
          continue;
        default:
          goto label_4;
      }
    }
label_4:
    this.SendingDelay = 1000;
    this.Name = "";
    this.NamePlacement = 0;
  }

  public void Save()
  {
    TyperConfig.\u202E⁫⁪‌​‮⁮⁬‭‍⁮‎‏​‎⁯‏‬‍⁬‍‭⁭⁭‬‌‪​‌⁭⁪‪‪‌‮‎‎​⁭‫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1296906507U), TyperConfig.\u206E⁮⁮⁪‎⁫⁪‍‍⁭‏‭​⁭‬⁯‫⁭⁯⁪‫‏‮⁭⁭‎⁮⁯⁯‍⁯‌⁬⁬‫‏⁭‬‌‫‮((object) this));
  }

  static string \u206E⁮⁮⁪‎⁫⁪‍‍⁭‏‭​⁭‬⁯‫⁭⁯⁪‫‏‮⁭⁭‎⁮⁯⁯‍⁯‌⁬⁬‫‏⁭‬‌‫‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }

  static void \u202E⁫⁪‌​‮⁮⁬‭‍⁮‎‏​‎⁯‏‬‍⁬‍‭⁭⁭‬‌‪​‌⁭⁪‪‪‌‮‎‎​⁭‫‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }
}
