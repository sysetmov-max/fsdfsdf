﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.ConfigController
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.IO;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Configs;

internal static class ConfigController
{
  public static InterfaceConfig InterfaceConfig;
  public static AnticapConfig AnticapConfig;
  public static TyperConfig TyperConfig;
  public static AntikickConfig AntikickConfig;

  public static void Load()
  {
    try
    {
      ConfigController.InterfaceConfig = JsonConvert.DeserializeObject<InterfaceConfig>(ConfigController.\u200D‎‎‌‭‭​‭‌‮‫‎‍‏⁫⁭⁭‭‭⁫‏‬‪‍‬‍‪‏⁬‍⁫⁭‭‏⁭‌‎⁬‫‌‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2845295546U)));
    }
    catch
    {
      ConfigController.InterfaceConfig = new InterfaceConfig();
    }
    try
    {
      ConfigController.TyperConfig = JsonConvert.DeserializeObject<TyperConfig>(ConfigController.\u200D‎‎‌‭‭​‭‌‮‫‎‍‏⁫⁭⁭‭‭⁫‏‬‪‍‬‍‪‏⁬‍⁫⁭‭‏⁭‌‎⁬‫‌‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(851954793U)));
    }
    catch
    {
      ConfigController.TyperConfig = new TyperConfig();
    }
    try
    {
      ConfigController.AnticapConfig = JsonConvert.DeserializeObject<AnticapConfig>(ConfigController.\u200D‎‎‌‭‭​‭‌‮‫‎‍‏⁫⁭⁭‭‭⁫‏‬‪‍‬‍‪‏⁬‍⁫⁭‭‏⁭‌‎⁬‫‌‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3997854626U)));
    }
    catch
    {
      ConfigController.AnticapConfig = new AnticapConfig();
    }
    try
    {
      ConfigController.AntikickConfig = JsonConvert.DeserializeObject<AntikickConfig>(ConfigController.\u200D‎‎‌‭‭​‭‌‮‫‎‍‏⁫⁭⁭‭‭⁫‏‬‪‍‬‍‪‏⁬‍⁫⁭‭‏⁭‌‎⁬‫‌‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(4228366442U)));
    }
    catch
    {
      ConfigController.AntikickConfig = new AntikickConfig();
    }
  }

  static string \u200D‎‎‌‭‭​‭‌‮‫‎‍‏⁫⁭⁭‭‭⁫‏‬‪‍‬‍‪‏⁬‍⁫⁭‭‏⁭‌‎⁬‫‌‮([In] string obj0)
  {
    return File.ReadAllText(obj0);
  }
}
