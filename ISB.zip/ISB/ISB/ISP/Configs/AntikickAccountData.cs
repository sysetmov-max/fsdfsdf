﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.AntikickAccountData
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

#nullable disable
namespace ISP.Configs;

internal class AntikickAccountData
{
  public string Name;
  public long? ChatId;

  public AntikickAccountData(string name, long? chatId = null)
  {
    this.Name = name;
    this.ChatId = chatId;
  }
}
