﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.AntikickTarget
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections.Generic;

#nullable disable
namespace ISP.Configs;

internal sealed class AntikickTarget
{
  public readonly string Name;
  public readonly List<AntikickAccountData> Accounts;
  public int IndexOfActiveAcc;
  [NonSerialized]
  public DateTime? WhenToRejoin;

  public AntikickTarget(string name)
  {
    this.IndexOfActiveAcc = 0;
    this.Name = name;
    this.Accounts = new List<AntikickAccountData>();
    this.WhenToRejoin = new DateTime?();
  }
}
