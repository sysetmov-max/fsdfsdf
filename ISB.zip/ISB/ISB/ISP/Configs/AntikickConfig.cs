﻿// Decompiled with JetBrains decompiler
// Type: ISP.Configs.AntikickConfig
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
namespace ISP.Configs;

internal class AntikickConfig : ISBConfig
{
  public readonly List<AntikickTarget> Targets;
  public int Delay;
  public int PartialRejoinDelay;
  [NonSerialized]
  public ConcurrentDictionary<string, List<long>> LeavedIntentionallyFrom;

  public AntikickConfig()
  {
    this.Targets = new List<AntikickTarget>();
    this.Delay = this.PartialRejoinDelay = 333;
  }

  public void Save()
  {
    AntikickConfig.\u202B‌‎⁪⁯‏‏‏‭‏⁪‫⁪‭​⁫⁬‏⁯​⁮‌‫⁫‌‮⁭⁬‫‮‪⁪‫⁭‫‬‏⁭⁫⁯‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2027981749U), AntikickConfig.\u202E⁫⁪‭‎⁪‬‎⁮‬‏‬‬‭⁭⁭‎​‌⁪‏⁯‏‪​⁬⁭‫‏⁯‭⁪⁫‏‎⁪‪‍‌‫‮((object) this));
  }

  public bool AddNewTarget(AntikickTarget atg)
  {
label_1:
    int num1 = 1104888426;
    List<AntikickTarget> targets;
    AntikickTarget atg1;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 977791267)) % 4U)
      {
        case 0:
          targets = this.Targets;
          num1 = (int) num2 * 1453969404 ^ -354735488;
          continue;
        case 1:
          atg1 = atg;
          num1 = (int) num2 * -1093282237 ^ 761583380;
          continue;
        case 2:
          goto label_1;
        default:
          goto label_5;
      }
    }
label_5:
    bool flag1 = false;
    bool flag2;
    try
    {
      AntikickConfig.\u206B⁯⁯​‎‮‫⁪⁮​​‏⁬‌‌‮⁪​‭‍‍‎‎‭‮‫‍⁮‏⁪⁬⁬⁯⁯‫‪‭‮‭⁬‮((object) targets, ref flag1);
label_7:
      int num3 = 699265542;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 977791267)) % 6U)
        {
          case 0:
            goto label_10;
          case 2:
            goto label_7;
          case 3:
            flag2 = true;
            num3 = (int) num4 * 703852258 ^ 1869691144;
            continue;
          case 4:
            this.Targets.Add(atg1);
            num3 = 1616846590;
            continue;
          case 5:
            // ISSUE: reference to a compiler-generated method
            int num5 = !this.Targets.Where<AntikickTarget>((Func<AntikickTarget, bool>) (x => AntikickConfig.\u003C\u003Ec__DisplayClass6_0.\u206A‍‪‪⁮‍‌⁫‎‍⁭⁯‮⁮‪⁭‎‭⁯‪‎‏‏⁫‬‎⁮‍⁭‪‌‏‫‭‫‭⁮⁪⁬‏‮(x.Name, atg1.Name))).Any<AntikickTarget>() ? 238837274 : (num5 = 1112997740);
            num3 = num5 ^ (int) num4 * 740228587;
            continue;
          default:
            goto label_18;
        }
      }
label_10:
      flag2 = false;
    }
    finally
    {
      if (flag1)
      {
label_14:
        int num6 = 255626679;
        while (true)
        {
          uint num7;
          switch ((num7 = (uint) (num6 ^ 977791267)) % 3U)
          {
            case 0:
              goto label_14;
            case 1:
              AntikickConfig.\u206E⁯‬‬⁬⁭‏‫‪‭‏​​⁯‏‌⁫⁮‬‎⁫‭‎‬‏‬‪⁬‌‌⁮‫​⁬‏⁫⁫⁮​⁮‮((object) targets);
              num6 = (int) num7 * -1024544426 ^ -1639625134;
              continue;
            default:
              goto label_17;
          }
        }
      }
label_17:;
    }
label_18:
    return flag2;
  }

  public void SetChatsList(IEnumerable<string> chats)
  {
    List<AntikickTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      AntikickConfig.\u206B⁯⁯​‎‮‫⁪⁮​​‏⁬‌‌‮⁪​‭‍‍‎‎‭‮‫‍⁮‏⁪⁬⁬⁯⁯‫‪‭‮‭⁬‮((object) targets, ref flag);
      HashSet<string> stringSet1 = new HashSet<string>(chats);
label_2:
      int num1 = 1388003128;
      HashSet<string> stringSet2;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1124483157)) % 3U)
        {
          case 0:
            goto label_2;
          case 1:
            stringSet2 = new HashSet<string>(this.Targets.Select<AntikickTarget, string>((Func<AntikickTarget, string>) (t => t.Name)));
            num1 = 1593240321;
            continue;
          default:
            goto label_5;
        }
      }
label_5:
      HashSet<string> stringSet3 = new HashSet<string>((IEnumerable<string>) stringSet1);
      stringSet3.ExceptWith((IEnumerable<string>) stringSet2);
      HashSet<string> toRemove = new HashSet<string>((IEnumerable<string>) stringSet2);
      toRemove.ExceptWith((IEnumerable<string>) stringSet1);
      this.Targets.RemoveAll((Predicate<AntikickTarget>) (x => toRemove.Contains(x.Name)));
      using (HashSet<string>.Enumerator enumerator = stringSet3.GetEnumerator())
      {
label_9:
        int num3 = !enumerator.MoveNext() ? 1552947273 : (num3 = 467688559);
        string current;
        while (true)
        {
          uint num4;
          switch ((num4 = (uint) (num3 ^ 1124483157)) % 5U)
          {
            case 0:
              num3 = 467688559;
              continue;
            case 1:
              goto label_9;
            case 2:
              goto label_17;
            case 3:
              this.Targets.Add(new AntikickTarget(current));
              num3 = (int) num4 * -787545744 ^ -230405925;
              continue;
            case 4:
              current = enumerator.Current;
              num3 = 1406798039;
              continue;
            default:
              goto label_12;
          }
        }
label_17:
        return;
label_12:;
      }
    }
    finally
    {
      if (flag)
      {
label_15:
        int num5 = 2021890769;
        while (true)
        {
          uint num6;
          switch ((num6 = (uint) (num5 ^ 1124483157)) % 3U)
          {
            case 0:
              goto label_15;
            case 2:
              AntikickConfig.\u206E⁯‬‬⁬⁭‏‫‪‭‏​​⁯‏‌⁫⁮‬‎⁫‭‎‬‏‬‪⁬‌‌⁮‫​⁬‏⁫⁫⁮​⁮‮((object) targets);
              num5 = (int) num6 * -1187174596 ^ -1030440212;
              continue;
            default:
              goto label_19;
          }
        }
      }
label_19:;
    }
  }

  public void Validate()
  {
    List<AntikickTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      AntikickConfig.\u206B⁯⁯​‎‮‫⁪⁮​​‏⁬‌‌‮⁪​‭‍‍‎‎‭‮‫‍⁮‏⁪⁬⁬⁯⁯‫‪‭‮‭⁬‮((object) targets, ref flag);
      using (List<AntikickTarget>.Enumerator enumerator = this.Targets.GetEnumerator())
      {
label_6:
        int num1 = !enumerator.MoveNext() ? -1056424796 : (num1 = -2032970630);
        while (true)
        {
          uint num2;
          switch ((num2 = (uint) (num1 ^ -41280475)) % 4U)
          {
            case 0:
              num1 = -2032970630;
              continue;
            case 1:
              goto label_12;
            case 2:
              goto label_6;
            case 3:
              enumerator.Current.Accounts.RemoveAll((Predicate<AntikickAccountData>) (x => !AccountsManager.GetAccountsList().Contains(x.Name)));
              num1 = -1367047489;
              continue;
            default:
              goto label_7;
          }
        }
label_12:
        return;
label_7:;
      }
    }
    finally
    {
      if (flag)
      {
label_10:
        int num3 = -711715719;
        while (true)
        {
          uint num4;
          switch ((num4 = (uint) (num3 ^ -41280475)) % 3U)
          {
            case 0:
              goto label_10;
            case 2:
              AntikickConfig.\u206E⁯‬‬⁬⁭‏‫‪‭‏​​⁯‏‌⁫⁮‬‎⁫‭‎‬‏‬‪⁬‌‌⁮‫​⁬‏⁫⁫⁮​⁮‮((object) targets);
              num3 = (int) num4 * 1609489552 ^ -1060532380;
              continue;
            default:
              goto label_14;
          }
        }
      }
label_14:;
    }
  }

  static string \u202E⁫⁪‭‎⁪‬‎⁮‬‏‬‬‭⁭⁭‎​‌⁪‏⁯‏‪​⁬⁭‫‏⁯‭⁪⁫‏‎⁪‪‍‌‫‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }

  static void \u202B‌‎⁪⁯‏‏‏‭‏⁪‫⁪‭​⁫⁬‏⁯​⁮‌‫⁫‌‮⁭⁬‫‮‪⁪‫⁭‫‬‏⁭⁫⁯‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }

  static void \u206B⁯⁯​‎‮‫⁪⁮​​‏⁬‌‌‮⁪​‭‍‍‎‎‭‮‫‍⁮‏⁪⁬⁬⁯⁯‫‪‭‮‭⁬‮([In] object obj0, [In] ref bool obj1)
  {
    Monitor.Enter(obj0, ref obj1);
  }

  static void \u206E⁯‬‬⁬⁭‏‫‪‭‏​​⁯‏‌⁫⁮‬‎⁫‭‎‬‏‬‪⁬‌‌⁮‫​⁬‏⁫⁫⁮​⁮‮([In] object obj0)
  {
    Monitor.Exit(obj0);
  }
}
