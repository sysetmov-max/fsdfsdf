﻿// Decompiled with JetBrains decompiler
// Type: ISP.Engine.Accounts.Account
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Tasks.Settings;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Runtime.InteropServices;
using VkNet;
using VkNet.Enums.Filters;
using VkNet.Model;
using VkNet.Utils.AntiCaptcha;

#nullable disable
namespace ISP.Engine.Accounts;

internal sealed class Account
{
  public FlooderTaskSettings FlooderTaskSettings;
  public ChatsTaskSettings ChatsTaskSettings;
  public VoiceTaskSettings VoiceTaskSettings;
  public InviteTaskSettings InviteTaskSettings;

  public VkApi VkApi { get; private set; }

  public string Login { get; set; }

  public User Myself { get; set; }

  public string Token { get; set; }

  public Account()
  {
    this.FlooderTaskSettings = new FlooderTaskSettings();
    this.VoiceTaskSettings = new VoiceTaskSettings();
    this.ChatsTaskSettings = new ChatsTaskSettings();
    this.InviteTaskSettings = new InviteTaskSettings();
  }

  public void ValidateSettings()
  {
    if (this.FlooderTaskSettings != null)
      goto label_8;
label_1:
    int num1 = -1436506377;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1286081495)) % 12U)
      {
        case 0:
          this.VoiceTaskSettings.Validate();
          num1 = (int) num2 * -1985422637 ^ 833055640;
          continue;
        case 2:
          goto label_1;
        case 3:
          goto label_8;
        case 4:
          this.ChatsTaskSettings = new ChatsTaskSettings();
          num1 = (int) num2 * -1004971725 ^ -910064186;
          continue;
        case 5:
          int num3;
          num1 = num3 = this.ChatsTaskSettings != null ? -1784116202 : (num3 = -566289703);
          continue;
        case 6:
          this.FlooderTaskSettings = new FlooderTaskSettings();
          num1 = (int) num2 * 1740129536 ^ 1145832986;
          continue;
        case 7:
          this.InviteTaskSettings = new InviteTaskSettings();
          num1 = (int) num2 * 929843277 ^ 1173275590;
          continue;
        case 8:
          this.FlooderTaskSettings.Validate();
          num1 = -369445409;
          continue;
        case 9:
          this.VoiceTaskSettings = new VoiceTaskSettings();
          num1 = (int) num2 * -185798834 ^ -1571853906;
          continue;
        case 10:
          this.ChatsTaskSettings.Validate();
          num1 = (int) num2 * -1597328591 ^ -2090068301;
          continue;
        case 11:
          int num4;
          num1 = num4 = this.InviteTaskSettings == null ? -732674850 : (num4 = -84184691);
          continue;
        default:
          goto label_13;
      }
    }
label_13:
    this.InviteTaskSettings.Validate();
    return;
label_8:
    num1 = this.VoiceTaskSettings != null ? -1155674752 : (num1 = -753773512);
    goto label_2;
  }

  public void Reauth(
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮ solver)
  {
    this.VkApi = Account.\u206E⁭‫⁫⁯‎⁯⁭⁮⁪​⁮⁭⁫‬‬⁬‎‬⁯‭‎‮⁫⁯⁭‮‎⁪‭⁮‎⁮‍‮‭⁪‌‮‭‮((ICaptchaSolver) solver);
    ApiAuthParams apiAuthParams = new ApiAuthParams();
label_1:
    int num1 = 1402655256;
    ApiAuthParams @params;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 15676487)) % 4U)
      {
        case 0:
          this.VkApi.Authorize(@params);
          num1 = (int) num2 * -763114370 ^ 833381258;
          continue;
        case 1:
          goto label_3;
        case 2:
          goto label_1;
        case 3:
          apiAuthParams.AccessToken = this.Token;
          @params = apiAuthParams;
          num1 = (int) num2 * 1727665782 ^ 538434153;
          continue;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  private Account.AuthResult Auth(
    string login,
    string password,
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮ solver,
    Func<string> twoFactHandler,
    ulong appId)
  {
    this.VkApi = Account.\u206E⁭‫⁫⁯‎⁯⁭⁮⁪​⁮⁭⁫‬‬⁬‎‬⁯‭‎‮⁫⁯⁭‮‎⁪‭⁮‎⁮‍‮‭⁪‌‮‭‮((ICaptchaSolver) solver);
    ApiAuthParams apiAuthParams = new ApiAuthParams();
label_1:
    int num1 = 1070759281;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1415617794)) % 5U)
      {
        case 0:
          apiAuthParams.Login = login;
          num1 = (int) num2 * 1742373003 ^ 989967629;
          continue;
        case 2:
          goto label_1;
        case 3:
          apiAuthParams.Password = password;
          apiAuthParams.Settings = (MultivaluedFilter<VkNet.Enums.Filters.Settings>) VkNet.Enums.Filters.Settings.All | (MultivaluedFilter<VkNet.Enums.Filters.Settings>) VkNet.Enums.Filters.Settings.Offline;
          num1 = (int) num2 * 92515812 ^ 663202285;
          continue;
        case 4:
          apiAuthParams.ApplicationId = appId;
          num1 = (int) num2 * 478220276 ^ -382493391;
          continue;
        default:
          goto label_6;
      }
    }
label_6:
    apiAuthParams.TwoFactorAuthorization = twoFactHandler;
    ApiAuthParams @params = apiAuthParams;
    Account.AuthResult authResult;
    try
    {
      this.VkApi.Authorize(@params);
label_8:
      int num3 = 1402444465;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 1415617794)) % 3U)
        {
          case 0:
            goto label_8;
          case 2:
            this.Token = this.VkApi.Token;
            num3 = (int) num4 * -1235060297 ^ -1218091040;
            continue;
          default:
            goto label_11;
        }
      }
label_11:
      authResult = Account.AuthResult.Ok;
    }
    catch (Exception ex)
    {
      this.VkApi = (VkApi) null;
      if (ex.Message.Contains(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(222057651U)))
      {
label_13:
        int num5 = 1075406735;
        while (true)
        {
          uint num6;
          switch ((num6 = (uint) (num5 ^ 1415617794)) % 4U)
          {
            case 0:
              goto label_13;
            case 1:
              authResult = Account.AuthResult.InvalidCred;
              num5 = (int) num6 * -1285629623 ^ -615290019;
              continue;
            case 2:
              goto label_17;
            default:
              goto label_16;
          }
        }
      }
label_16:
      authResult = Account.AuthResult.Other;
    }
label_17:
    return authResult;
  }

  public void Auth(
    string login,
    string password,
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮ solver,
    Func<string> twoFactHandler)
  {
    this.Login = login;
    this.VkApi = (VkApi) null;
    try
    {
      Account.AuthResult authResult = this.Auth(login, password, solver, (Func<string>) null, 2168679UL);
label_2:
      int num1 = -1630722238;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -561384336)) % 14U)
        {
          case 0:
            int num3 = this.Auth(login, password, solver, (Func<string>) null, 4747736UL) != Account.AuthResult.InvalidCred ? -509349414 : (num3 = -1798624097);
            num1 = num3 ^ (int) num2 * -1630195005;
            continue;
          case 1:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(this, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4275987207U));
            num1 = -1766311122;
            continue;
          case 2:
            int num4 = authResult != Account.AuthResult.InvalidCred ? -372154334 : (num4 = -1931072223);
            num1 = num4 ^ (int) num2 * -524314360;
            continue;
          case 3:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(this, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1616005248U));
            num1 = (int) num2 * 2086596880 ^ 356147420;
            continue;
          case 4:
            int num5 = authResult == Account.AuthResult.Other ? -1019039517 : (num5 = -1317441761);
            num1 = num5 ^ (int) num2 * -1518005094;
            continue;
          case 5:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(this, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1374169107U));
            MB\u0029Bz\u0024\u005C0V\u002C\u00284bIV\u0022y7tT_GM\u005D6.\u206E‫‪​‏⁬‫⁮‏‏‍‬‏⁭‍⁫‮⁭‫⁮⁫‪⁭‏⁯‫‬⁫⁫⁮⁮‫‪⁬‭‏‪‪‭‌‮ = login;
            int num6 = (int) this.Auth(login, password, solver, twoFactHandler, 2168679UL);
            num1 = -382467336;
            continue;
          case 6:
            num1 = (int) num2 * 746646907 ^ -309986792;
            continue;
          case 7:
            int num7 = (int) this.Auth(login, password, solver, twoFactHandler, 4747736UL);
            num1 = (int) num2 * -628115771 ^ -503017143;
            continue;
          case 8:
            int num8;
            num1 = num8 = this.VkApi != null ? -1617523707 : (num8 = -554110269);
            continue;
          case 9:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(this, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2625034922U));
            num1 = -1741817354;
            continue;
          case 10:
            goto label_4;
          case 11:
            num1 = (int) num2 * -2030069221 ^ -1932609191;
            continue;
          case 12:
            this.SaveToDisk();
            num1 = (int) num2 * 1819824268 ^ -224391130;
            continue;
          case 13:
            goto label_2;
          default:
            goto label_18;
        }
      }
label_4:
      return;
label_18:;
    }
    catch (Exception ex)
    {
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(this, Account.\u202A‍‌‬‭‮‪‭‌⁪‪‫⁮‌‎⁯⁯‭‫⁭‫‏‍⁯⁪⁯⁭​‬‫‮‏⁭‏‍⁪‬⁮‎⁬‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(731260493U), Account.\u202D⁮‪‬‍‬‍‏‎‭‮‮⁯‏⁪⁬‫‪⁯‎⁫‬‬⁬‏‫‎⁯⁬‌⁮⁯⁭‬‫‍‪⁬⁬⁪‮(ex)));
      this.VkApi = (VkApi) null;
    }
  }

  public void ResetSettings()
  {
    this.FlooderTaskSettings = new FlooderTaskSettings();
label_1:
    int num1 = -1663001476;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -46102518)) % 4U)
      {
        case 0:
          goto label_3;
        case 1:
          this.ChatsTaskSettings = new ChatsTaskSettings();
          this.InviteTaskSettings = new InviteTaskSettings();
          num1 = (int) num2 * 1295124348 ^ -994902074;
          continue;
        case 2:
          this.VoiceTaskSettings = new VoiceTaskSettings();
          num1 = (int) num2 * 84252467 ^ 826817957;
          continue;
        case 3:
          goto label_1;
        default:
          goto label_6;
      }
    }
label_3:
    return;
label_6:;
  }

  public void SaveToDisk()
  {
    string str = Account.\u202B⁭⁭⁭⁯⁪‮⁮⁬‎⁬‮‍⁬⁫‫⁮⁭⁫‫‫⁮‏⁫‬⁮‫⁫‍‏‬‪‎‭‭‮⁫‫‭⁮‮((object) this);
    Account.\u202C‭⁬⁭⁫‫‬‫​‭⁬⁪‪⁯⁫⁬‫‎‎‫‮⁪‬⁬⁫⁫‍‬⁭‫‏⁪‮‪⁮‍‍‍‎‬‮(Account.\u202D‏⁯⁭⁬⁮‮‮‫⁪‬⁯‪‮⁪⁪‮⁫⁬‌‫‮‏‎‪⁭‍‭‍‫⁮‏⁪⁭‮‮⁬⁬‍⁫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3169835826U), (object) this.Login), str);
  }

  static VkApi \u206E⁭‫⁫⁯‎⁯⁭⁮⁪​⁮⁭⁫‬‬⁬‎‬⁯‭‎‮⁫⁯⁭‮‎⁪‭⁮‎⁮‍‮‭⁪‌‮‭‮([In] ICaptchaSolver obj0)
  {
    return new VkApi(obj0);
  }

  static string \u202D⁮‪‬‍‬‍‏‎‭‮‮⁯‏⁪⁬‫‪⁯‎⁫‬‬⁬‏‫‎⁯⁬‌⁮⁯⁭‬‫‍‪⁬⁬⁪‮([In] Exception obj0) => obj0.Message;

  static string \u202A‍‌‬‭‮‪‭‌⁪‪‫⁮‌‎⁯⁯‭‫⁭‫‏‍⁯⁪⁯⁭​‬‫‮‏⁭‏‍⁪‬⁮‎⁬‮([In] string obj0, [In] string obj1)
  {
    return obj0 + obj1;
  }

  static string \u202B⁭⁭⁭⁯⁪‮⁮⁬‎⁬‮‍⁬⁫‫⁮⁭⁫‫‫⁮‏⁫‬⁮‫⁫‍‏‬‪‎‭‭‮⁫‫‭⁮‮([In] object obj0)
  {
    return JsonConvert.SerializeObject(obj0);
  }

  static string \u202D‏⁯⁭⁬⁮‮‮‫⁪‬⁯‪‮⁪⁪‮⁫⁬‌‫‮‏‎‪⁭‍‭‍‫⁮‏⁪⁭‮‮⁬⁬‍⁫‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static void \u202C‭⁬⁭⁫‫‬‫​‭⁬⁪‪⁯⁫⁬‫‎‎‫‮⁪‬⁬⁫⁫‍‬⁭‫‏⁪‮‪⁮‍‍‍‎‬‮([In] string obj0, [In] string obj1)
  {
    File.WriteAllText(obj0, obj1);
  }

  private enum AuthResult
  {
    Ok,
    InvalidCred,
    Other,
  }
}
