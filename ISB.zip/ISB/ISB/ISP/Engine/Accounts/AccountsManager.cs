﻿// Decompiled with JetBrains decompiler
// Type: ISP.Engine.Accounts.AccountsManager
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using VkNet;
using VkNet.Model;
using VkNet.Utils;

#nullable disable
namespace ISP.Engine.Accounts;

internal static class AccountsManager
{
  private static readonly Dictionary<string, Account> Accounts = new Dictionary<string, Account>();
  private static string _activeAccount;
  private static readonly List<\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮> AccsTasks;
  private static bool _toAll;

  static AccountsManager()
  {
label_1:
    int num1 = 609802015;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 892900208)) % 3U)
      {
        case 0:
          goto label_3;
        case 1:
          AccountsManager.AccsTasks = new List<\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮>();
          AccountsManager._activeAccount = (string) null;
          AccountsManager._toAll = false;
          num1 = (int) num2 * 1814167440 ^ 427773160;
          continue;
        case 2:
          goto label_1;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  public static bool ToggleToAll()
  {
    AccountsManager._toAll = !AccountsManager._toAll;
    return AccountsManager._toAll;
  }

  public static void LoadAndPrepareAccounts(Func<string> twoFactHandler)
  {
    string[] strArray1 = AccountsManager.\u202D​⁫‏‫⁬⁪‎⁪⁮⁪⁯‮‪‪⁭‮⁭‌‌‪⁯‭‫‍‫‫⁪⁪‫⁭‪⁪⁫‫‎‎‌‪⁪‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3922545757U), AccountsManager.\u200C​‭‭‭‮‏⁯‫‌‌‭⁮⁮⁬⁬‭‎‍‮​‪‮‫⁭‫‌‬⁬‪‪‮⁫‮⁬⁬‌‫‮‍‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4243293650U)));
    \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮ solver = new \u200B‭‪⁮‫‭⁫⁭‭⁫⁬⁯‮​‭‎‬‫‫‏⁬‭‫‪‪‎⁪​‭‏‍‫⁫‬⁫​‮‭‌⁯‮();
    string[] strArray2 = strArray1;
label_1:
    int num1 = 1502332995;
    int index;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 275944778)) % 4U)
      {
        case 1:
          index = 0;
          num1 = (int) num2 * 250300492 ^ -133749043;
          continue;
        case 2:
          goto label_1;
        case 3:
          goto label_40;
        default:
          goto label_4;
      }
    }
label_4:
    string str = strArray2[index];
    try
    {
      string[] strArray3 = AccountsManager.\u200F⁬‏‬‌⁬​⁪‬⁫⁪‬‌‏⁫‮⁯‫⁬⁯⁫⁪⁮‫​‬⁪‌‏‍‮‪‌‏​⁯‮‎​‪‮(str, new char[1]
      {
        ':'
      });
label_6:
      int num3 = 805371837;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 275944778)) % 4U)
        {
          case 0:
            goto label_6;
          case 2:
            goto label_36;
          case 3:
            int num5 = strArray3.Length == 2 ? 1207185689 : (num5 = 2098852642);
            num3 = num5 ^ (int) num4 * 725142002;
            continue;
          default:
            goto label_9;
        }
      }
label_9:
      Account account1;
      try
      {
        account1 = JsonConvert.DeserializeObject<Account>(AccountsManager.\u202D⁮‬‫​‪‌⁪​‭⁮‌‍‮‫‎⁮‬‫⁪‌‌‌‌⁬⁪⁬‎‌⁪‏⁪‏⁭⁮⁪‬‌‭‌‮(AccountsManager.\u202B⁯⁪‬​‏‬‪⁬​‮‮⁭⁮⁯⁪‌⁯​​‫​‍‍⁬‎⁬‫‮‌‮⁯‫⁫‎⁬⁫⁯‎‌‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3169835826U), (object) strArray3[0])));
      }
      catch
      {
        account1 = new Account();
      }
      bool flag = false;
      try
      {
        if (account1.Token != null)
          goto label_17;
label_14:
        int num6 = 1802767119;
label_15:
        VkResponse vkResponse;
        while (true)
        {
          uint num7;
          switch ((num7 = (uint) (num6 ^ 275944778)) % 6U)
          {
            case 0:
              Account account2 = account1;
              User user = AccountsManager.\u202C⁪‎⁭⁮⁪⁬⁬‍‭‬⁭‫‎⁬‏‏​‬‫‬⁫​⁪‍​⁮⁭⁫‌‪‏‭⁯⁯‌‭‍‌⁮‮();
              AccountsManager.\u206F⁮⁯‪⁯⁬​⁭‭‫‍‍⁭⁮‭‍‏⁭‫⁭⁭⁭‪‌‭⁪‎‏⁯‍‍‫‮‌⁭‫​‪‎‮(user, AccountsManager.\u206E⁭​⁯⁬⁬‮‍⁭​​‬​‫⁯‫​⁫‭‪⁬‮‫⁬‫⁬‌‏‬‬‮‬⁫‮‌‏‬‌‪‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2907034168U))));
              AccountsManager.\u206D‬‭‫‬‮​​‪‪‫‎⁭‬⁫‮⁯‏‏​‏‬​‬‭‎⁭‎⁬⁯⁫‌⁭⁬‏‎‮⁮⁯‭‮(user, AccountsManager.\u206E⁭​⁯⁬⁬‮‍⁭​​‬​‫⁯‫​⁫‭‪⁬‮‫⁬‫⁬‌‏‬‬‮‬⁫‮‌‏‬‌‪‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(195105746U))));
              AccountsManager.\u200B‍⁬‭‪⁯​‮⁭‬⁭⁬​‎‮⁭⁫‫‮⁫‭‎‪‬⁫​‮‏‌⁮⁭‫‎‏‍‭‪‫⁭‪‮(user, AccountsManager.\u206F⁫⁯⁯‪‪‌⁬⁭⁪⁬⁪⁪‏‫‮⁪‍⁮⁯⁬⁭‫‍⁯⁭‍‮⁭⁭⁮‏‬‎​⁬⁭⁪‭‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(4034988624U))));
              account2.Myself = user;
              num6 = (int) num7 * -293279590 ^ -1147042385;
              continue;
            case 2:
              goto label_17;
            case 3:
              vkResponse = AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(AccountsManager.\u202B⁯‏⁪⁪⁬⁮‎⁪‌⁮‬‫⁬⁮‭‪‎‮⁯⁮⁯⁬⁬⁮⁫‎‌‪⁯‎⁪‌⁯‪‮‮​⁮‬‮(account1.VkApi, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2590332884U), AccountsManager.\u206D‎‏⁯‪‭‮‍‬⁮‍‬⁮‬⁫‪⁬‪‭⁬⁬‎‫⁮​⁪‬⁫‏⁪‪⁯‮⁫⁬‭⁯‎‍⁬‮(), false), (object) 0);
              num6 = (int) num7 * -122381276 ^ 1532083052;
              continue;
            case 4:
              goto label_14;
            case 5:
              flag = true;
              num6 = (int) num7 * 125044697 ^ 152093798;
              continue;
            default:
              goto label_24;
          }
        }
label_17:
        account1.Reauth(solver);
        num6 = 1621365947;
        goto label_15;
      }
      catch
      {
label_21:
        int num8 = 875007849;
        while (true)
        {
          uint num9;
          switch ((num9 = (uint) (num8 ^ 275944778)) % 3U)
          {
            case 0:
              goto label_21;
            case 2:
              flag = true;
              num8 = (int) num9 * 1452369362 ^ -301386069;
              continue;
            default:
              goto label_24;
          }
        }
      }
label_24:
      if (!flag)
        goto label_31;
label_25:
      int num10 = 31796030;
label_26:
      while (true)
      {
        uint num11;
        switch ((num11 = (uint) (num10 ^ 275944778)) % 9U)
        {
          case 0:
            int num12 = AccountsManager.Accounts.Last<KeyValuePair<string, Account>>().Value.VkApi == null ? 2018803877 : (num12 = 1634460171);
            num10 = num12 ^ (int) num11 * -1514939369;
            continue;
          case 1:
            int num13 = AccountsManager._activeAccount == null ? -913180773 : (num13 = -1041170495);
            num10 = num13 ^ (int) num11 * -1645128534;
            continue;
          case 2:
            goto label_25;
          case 3:
            goto label_31;
          case 4:
            VkResponse vkResponse = AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(AccountsManager.\u202B⁯‏⁪⁪⁬⁮‎⁪‌⁮‬‫⁬⁮‭‪‎‮⁯⁮⁯⁬⁬⁮⁫‎‌‪⁯‎⁪‌⁯‪‮‮​⁮‬‮(account1.VkApi, \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2120829833U), AccountsManager.\u206D‎‏⁯‪‭‮‍‬⁮‍‬⁮‬⁫‪⁬‪‭⁬⁬‎‫⁮​⁪‬⁫‏⁪‪⁯‮⁫⁬‭⁯‎‍⁬‮(), false), (object) 0);
            Account account3 = account1;
            User user = AccountsManager.\u202C⁪‎⁭⁮⁪⁬⁬‍‭‬⁭‫‎⁬‏‏​‬‫‬⁫​⁪‍​⁮⁭⁫‌‪‏‭⁯⁯‌‭‍‌⁮‮();
            AccountsManager.\u206F⁮⁯‪⁯⁬​⁭‭‫‍‍⁭⁮‭‍‏⁭‫⁭⁭⁭‪‌‭⁪‎‏⁯‍‍‫‮‌⁭‫​‪‎‮(user, AccountsManager.\u206E⁭​⁯⁬⁬‮‍⁭​​‬​‫⁯‫​⁫‭‪⁬‮‫⁬‫⁬‌‏‬‬‮‬⁫‮‌‏‬‌‪‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(88602093U))));
            AccountsManager.\u206D‬‭‫‬‮​​‪‪‫‎⁭‬⁫‮⁯‏‏​‏‬​‬‭‎⁭‎⁬⁯⁫‌⁭⁬‏‎‮⁮⁯‭‮(user, AccountsManager.\u206E⁭​⁯⁬⁬‮‍⁭​​‬​‫⁯‫​⁫‭‪⁬‮‫⁬‫⁬‌‏‬‬‮‬⁫‮‌‏‬‌‪‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(968270753U))));
            AccountsManager.\u200B‍⁬‭‪⁯​‮⁭‬⁭⁬​‎‮⁭⁫‫‮⁫‭‎‪‬⁫​‮‏‌⁮⁭‫‎‏‍‭‪‫⁭‪‮(user, AccountsManager.\u206F⁫⁯⁯‪‪‌⁬⁭⁪⁬⁪⁪‏‫‮⁪‍⁮⁯⁬⁭‫‍⁯⁭‍‮⁭⁭⁮‏‬‎​⁬⁭⁪‭‫‮(AccountsManager.\u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮(vkResponse, (object) \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3231010309U))));
            account3.Myself = user;
            num10 = (int) num11 * 240409928 ^ -1066234547;
            continue;
          case 5:
            account1.SaveToDisk();
            num10 = (int) num11 * 516007709 ^ 1564580812;
            continue;
          case 6:
            account1.Auth(strArray3[0], strArray3[1], solver, twoFactHandler);
            num10 = (int) num11 * 1396968245 ^ 1022073252;
            continue;
          case 7:
            AccountsManager._activeAccount = AccountsManager.Accounts.Last<KeyValuePair<string, Account>>().Key;
            num10 = (int) num11 * -1843565833 ^ -6621978;
            continue;
          default:
            goto label_36;
        }
      }
label_31:
      AccountsManager.Accounts.Add(strArray3[0], account1);
      num10 = 126150636;
      goto label_26;
    }
    catch (Exception ex)
    {
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(AccountsManager.\u202B⁯⁪‬​‏‬‪⁬​‮‮⁭⁮⁯⁪‌⁯​​‫​‍‍⁬‎⁬‫‮‌‮⁯‫⁫‎⁬⁫⁯‎‌‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1067117454U), (object) AccountsManager.\u206A‌‪‎⁭‮⁫‎‪⁭‪‭‫⁭‭‬‪⁮‍⁫⁪‏⁯⁬‭⁭‭⁯⁮‌⁮‎‎‌‌‮⁫⁮‮⁮‮(ex)));
    }
label_36:
    ++index;
label_37:
    int num14 = 1930817743;
label_38:
    while (true)
    {
      uint num15;
      switch ((num15 = (uint) (num14 ^ 275944778)) % 4U)
      {
        case 0:
          AccountsManager.Accounts.ToList<KeyValuePair<string, Account>>().ForEach((Action<KeyValuePair<string, Account>>) (x => x.Value.ValidateSettings()));
          num14 = 1103744084;
          continue;
        case 1:
          goto label_40;
        case 2:
          goto label_39;
        case 3:
          goto label_37;
        default:
          goto label_34;
      }
    }
label_39:
    return;
label_34:
    return;
label_40:
    if (index >= strArray2.Length)
    {
      num14 = 1442380558;
      goto label_38;
    }
    goto label_4;
  }

  public static List<string> GetAccountsList()
  {
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated method
    return AccountsManager.Accounts.Where<KeyValuePair<string, Account>>((Func<KeyValuePair<string, Account>, bool>) (acc => acc.Value.VkApi != null)).Select<KeyValuePair<string, Account>, string>((Func<KeyValuePair<string, Account>, string>) (acc => AccountsManager.\u003C\u003Ec.\u206F⁪⁪⁬⁮⁪⁫‭‎‎⁪⁫‎‍⁪⁬⁮‭‪⁯⁪‌⁭⁪​⁫‭⁭‭‭‏‪‬‏⁭⁯‌‭​‪‮(acc.Key, AccountsManager.\u003C\u003Ec.\u200E‎‏‭‬​​‍⁮‏⁯‬‫‮⁯‎⁮‪‫‮‌⁬‪⁮‮‫‬​⁬‏⁫⁭​⁪⁬⁭‎‪⁫‍‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(525457988U), (object) AccountsManager.\u003C\u003Ec.\u200F⁯⁯‏⁬‌⁮⁮‬‍‎‮‎‍⁪‌‪‪⁮⁫⁫‎​⁯​‪‪‍⁯‌‭‭‎‮​‭⁯⁪‏⁪‮(acc.Value.Myself), (object) AccountsManager.\u003C\u003Ec.\u200E‬‭‎⁮‫⁪‪⁫‏⁫⁫‭‮⁭‏‎⁪‪‏⁭‍‍⁮‭‮‍‬⁯‭‪‫​⁮⁫‭⁮‏⁪‌‮(acc.Value.Myself))))).ToList<string>();
  }

  public static void SetActiveAccount(string accWithName)
  {
    AccountsManager._activeAccount = AccountsManager.\u200F⁬‏‬‌⁬​⁪‬⁫⁪‬‌‏⁫‮⁯‫⁬⁯⁫⁪⁮‫​‬⁪‌‏‍‮‪‌‏​⁯‮‎​‪‮(accWithName, new char[1]
    {
      ' '
    })[0];
  }

  public static Account ActiveAccount => AccountsManager.Accounts[AccountsManager._activeAccount];

  public static Account GetAccount(string acc)
  {
    return AccountsManager.Accounts[AccountsManager.\u200F⁬‏‬‌⁬​⁪‬⁫⁪‬‌‏⁫‮⁯‫⁬⁯⁫⁪⁮‫​‬⁪‌‏‍‮‪‌‏​⁯‮‎​‪‮(acc, new char[1]
    {
      ' '
    })[0]];
  }

  public static void ApplyToCurrent(Action<Account> func)
  {
    if (!AccountsManager._toAll)
      goto label_5;
label_1:
    int num1 = -1160008532;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -204216719)) % 4U)
    {
      case 0:
        goto label_1;
      case 1:
        AccountsManager.Accounts.Values.ToList<Account>().ForEach(func);
        return;
      case 2:
        break;
      case 3:
        return;
      default:
        return;
    }
label_5:
    func(AccountsManager.ActiveAccount);
    num1 = -502678870;
    goto label_2;
  }

  public static void StartAllTasks()
  {
    \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206A‬‍‫⁯⁪⁮‬‮‌‮‏⁬‎⁬‬‭⁫‍⁬​‭⁪‍‬‪⁪‫⁫‪‎⁫‌​​⁫⁪‌‫‏‮();
    AccountsManager.AccsTasks.Clear();
    using (Dictionary<string, Account>.ValueCollection.Enumerator enumerator = AccountsManager.Accounts.Values.GetEnumerator())
    {
label_7:
      int num1 = !enumerator.MoveNext() ? 1292001685 : (num1 = 21673875);
      // ISSUE: variable of a compiler-generated type
      AccountsManager.\u003C\u003Ec__DisplayClass13_0 cDisplayClass130;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1218041537)) % 7U)
        {
          case 0:
            num1 = 21673875;
            continue;
          case 1:
            goto label_7;
          case 2:
            AccountsManager.\u003CStartAllTasks\u003Eg__AddTask13_0((\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮) new \u206B‮‏‏⁫⁪‫‭‮⁮⁯‭⁫‪‭‍​‎‏‭⁬⁬‪‮⁫‭‎⁪​⁭‫‫​‬⁯‪‫‍‎⁫‮(), ref cDisplayClass130);
            num1 = (int) num2 * -1312609514 ^ -7563692;
            continue;
          case 3:
            AccountsManager.\u003CStartAllTasks\u003Eg__AddTask13_0((\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮) new \u200B⁬⁪​⁬​⁬‭‬‫‬‫‎‬‬‎⁯‎⁪⁮‏‮⁭‫‎⁯⁬⁪‪‌​⁪⁯​⁬⁭⁬⁫‪⁪‮(), ref cDisplayClass130);
            AccountsManager.\u003CStartAllTasks\u003Eg__AddTask13_0((\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮) new \u202A‌‭‭‭‎‫‮​⁪‬‭⁯‍‍⁫⁭‏⁭‍‪⁯‫‬‎⁬‪⁬‪‍⁭‍‌⁫‭⁭‭​⁮‬‮(), ref cDisplayClass130);
            num1 = (int) num2 * 1615912862 ^ -210140483;
            continue;
          case 4:
            goto label_10;
          case 5:
            // ISSUE: reference to a compiler-generated field
            cDisplayClass130.acc = enumerator.Current;
            num1 = (int) num2 * 1106844313 ^ -1231403353;
            continue;
          case 6:
            // ISSUE: object of a compiler-generated type is created
            cDisplayClass130 = new AccountsManager.\u003C\u003Ec__DisplayClass13_0();
            num1 = 111053489;
            continue;
          default:
            goto label_4;
        }
      }
label_10:
      return;
label_4:;
    }
  }

  public static void StopAllTasks()
  {
    using (List<\u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮>.Enumerator enumerator = AccountsManager.AccsTasks.GetEnumerator())
    {
label_6:
      int num1 = enumerator.MoveNext() ? 1231704119 : (num1 = 717176973);
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 820824754)) % 4U)
        {
          case 0:
            goto label_6;
          case 1:
            enumerator.Current.\u200C‭⁪‍‎‬‎⁭‪‌‬⁬‎‮‎‪‭‎⁯⁬⁮⁬⁯​⁪‬​‭⁫⁫‮​⁬⁫⁬‎⁭⁫⁪⁪‮();
            num1 = 36673014;
            continue;
          case 2:
            num1 = 1231704119;
            continue;
          case 3:
            goto label_7;
          default:
            goto label_4;
        }
      }
label_7:
      return;
label_4:;
    }
  }

  [CompilerGenerated]
  internal static void \u003CStartAllTasks\u003Eg__AddTask13_0(
    \u200C‪​‌‪​⁬‮‮‌⁯⁫‌‍‭‎⁬⁫‫‫‏⁭‬‍‍‭⁮⁮‏‭‍‏‮‎⁮‌⁮‪⁮⁫‮ task,
    [In] ref AccountsManager.\u003C\u003Ec__DisplayClass13_0 obj1)
  {
    AccountsManager.AccsTasks.Add(task);
label_1:
    int num1 = -2103890810;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1019027874)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          // ISSUE: reference to a compiler-generated field
          task.\u202A⁬⁬‫⁫⁯⁯‍‪‭‭⁯⁫‪‌‎‎​‫‌⁯‮⁭‎‏‭‪‮​⁭⁮‮​‍‌‌⁯⁫‫‮‮(obj1.acc);
          num1 = (int) num2 * -433220761 ^ 2072925906;
          continue;
        case 2:
          goto label_3;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  static Encoding \u200C​‭‭‭‮‏⁯‫‌‌‭⁮⁮⁬⁬‭‎‍‮​‪‮‫⁭‫‌‬⁬‪‪‮⁫‮⁬⁬‌‫‮‍‮([In] string obj0)
  {
    return Encoding.GetEncoding(obj0);
  }

  static string[] \u202D​⁫‏‫⁬⁪‎⁪⁮⁪⁯‮‪‪⁭‮⁭‌‌‪⁯‭‫‍‫‫⁪⁪‫⁭‪⁪⁫‫‎‎‌‪⁪‮([In] string obj0, [In] Encoding obj1)
  {
    return System.IO.File.ReadAllLines(obj0, obj1);
  }

  static string[] \u200F⁬‏‬‌⁬​⁪‬⁫⁪‬‌‏⁫‮⁯‫⁬⁯⁫⁪⁮‫​‬⁪‌‏‍‮‪‌‏​⁯‮‎​‪‮([In] string obj0, [In] char[] obj1)
  {
    return obj0.Split(obj1);
  }

  static string \u202B⁯⁪‬​‏‬‪⁬​‮‮⁭⁮⁯⁪‌⁯​​‫​‍‍⁬‎⁬‫‮‌‮⁯‫⁫‎⁬⁫⁯‎‌‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static string \u202D⁮‬‫​‪‌⁪​‭⁮‌‍‮‫‎⁮‬‫⁪‌‌‌‌⁬⁪⁬‎‌⁪‏⁪‏⁭⁮⁪‬‌‭‌‮([In] string obj0)
  {
    return System.IO.File.ReadAllText(obj0);
  }

  static VkParameters \u206D‎‏⁯‪‭‮‍‬⁮‍‬⁮‬⁫‪⁬‪‭⁬⁬‎‫⁮​⁪‬⁫‏⁪‪⁯‮⁫⁬‭⁯‎‍⁬‮() => VkParameters.Empty;

  static VkResponse \u202B⁯‏⁪⁪⁬⁮‎⁪‌⁮‬‫⁬⁮‭‪‎‮⁯⁮⁯⁬⁬⁮⁫‎‌‪⁯‎⁪‌⁯‪‮‮​⁮‬‮(
    [In] VkApi obj0,
    [In] string obj1,
    [In] VkParameters obj2,
    [In] bool obj3)
  {
    return obj0.Call(obj1, obj2, obj3);
  }

  static VkResponse \u202B‫‏⁪‌⁪⁯⁯‍‮‌‍‌‪‮‎⁪⁫⁫‭‮⁫⁮‌‏‭‏⁬⁮‪‍‪⁪⁪⁪‮‌⁯​⁪‮([In] VkResponse obj0, [In] object obj1)
  {
    return obj0[obj1];
  }

  static User \u202C⁪‎⁭⁮⁪⁬⁬‍‭‬⁭‫‎⁬‏‏​‬‫‬⁫​⁪‍​⁮⁭⁫‌‪‏‭⁯⁯‌‭‍‌⁮‮() => new User();

  static string \u206E⁭​⁯⁬⁬‮‍⁭​​‬​‫⁯‫​⁫‭‪⁬‮‫⁬‫⁬‌‏‬‬‮‬⁫‮‌‏‬‌‪‫‮([In] VkResponse obj0)
  {
    return (string) obj0;
  }

  static void \u206F⁮⁯‪⁯⁬​⁭‭‫‍‍⁭⁮‭‍‏⁭‫⁭⁭⁭‪‌‭⁪‎‏⁯‍‍‫‮‌⁭‫​‪‎‮([In] User obj0, [In] string obj1)
  {
    obj0.FirstName = obj1;
  }

  static void \u206D‬‭‫‬‮​​‪‪‫‎⁭‬⁫‮⁯‏‏​‏‬​‬‭‎⁭‎⁬⁯⁫‌⁭⁬‏‎‮⁮⁯‭‮([In] User obj0, [In] string obj1)
  {
    obj0.LastName = obj1;
  }

  static long \u206F⁫⁯⁯‪‪‌⁬⁭⁪⁬⁪⁪‏‫‮⁪‍⁮⁯⁬⁭‫‍⁯⁭‍‮⁭⁭⁮‏‬‎​⁬⁭⁪‭‫‮([In] VkResponse obj0) => (long) obj0;

  static void \u200B‍⁬‭‪⁯​‮⁭‬⁭⁬​‎‮⁭⁫‫‮⁫‭‎‪‬⁫​‮‏‌⁮⁭‫‎‏‍‭‪‫⁭‪‮([In] User obj0, [In] long obj1)
  {
    obj0.Id = obj1;
  }

  static string \u206A‌‪‎⁭‮⁫‎‪⁭‪‭‫⁭‭‬‪⁮‍⁫⁪‏⁯⁬‭⁭‭⁯⁮‌⁮‎‎‌‌‮⁫⁮‮⁮‮([In] Exception obj0) => obj0.Message;
}
