﻿// Decompiled with JetBrains decompiler
// Type: ISP.Properties.Settings
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Properties;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "15.0.0.0")]
internal sealed class Settings : ApplicationSettingsBase
{
  private static Settings \u206F⁮‍⁪⁮‍‎⁫‭‏‎‏‮‏‭⁯‮⁮⁭‌⁭‎⁭‎⁫‬‎⁮‮‮⁯‌⁮‍‏‏‏​‫‪‮ = (Settings) Settings.\u206D‌‌‏‌⁫‭‎‌‮⁮‪‬‬‍⁫‭‎‎‏‮‮⁪‭⁫‭⁫‌‍‮‎​⁬‭‏⁬​‭⁭⁪‮((SettingsBase) new Settings());

  public static Settings Default => Settings.\u206F⁮‍⁪⁮‍‎⁫‭‏‎‏‮‏‭⁯‮⁮⁭‌⁭‎⁭‎⁫‬‎⁮‮‮⁯‌⁮‍‏‏‏​‫‪‮;

  static SettingsBase \u206D‌‌‏‌⁫‭‎‌‮⁮‪‬‬‍⁫‭‎‎‏‮‮⁪‭⁫‭⁫‌‍‮‎​⁬‭‏⁬​‭⁭⁪‮([In] SettingsBase obj0)
  {
    return SettingsBase.Synchronized(obj0);
  }
}
