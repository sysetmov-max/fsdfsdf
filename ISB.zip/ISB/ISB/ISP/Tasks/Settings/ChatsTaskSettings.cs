﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.ChatsTaskSettings
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace ISP.Tasks.Settings;

internal sealed class ChatsTaskSettings : ISBTaskSettings
{
  private static Dictionary<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮, ChatsTaskSettings.CounterContainer> _targetRelatedCounters;
  public readonly List<ChatsTarget> Targets;
  private static List<string> _titlesToFlood;

  static ChatsTaskSettings() => ChatsTaskSettings.ReloadFromTxts();

  public static void ReloadFromTxts()
  {
    ChatsTaskSettings._titlesToFlood = new List<string>((IEnumerable<string>) ChatsTaskSettings.\u206F‪⁬⁭‭⁬⁫‮‪⁪‫‎‎⁪⁪‏​⁫‍⁬⁮⁭‬‍⁯⁬⁬⁫‌‫‬⁯​‫‎‌⁮⁬‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1079018095U), ChatsTaskSettings.\u202A‮‎⁪‎‪‬‏‫⁬‎⁭‎⁪‬‏‬⁫⁭⁭‮⁯​‪‮‬‏‍⁬‮‭⁪‬⁮⁬‬⁮‎‌‏‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(844754735U))));
label_1:
    int num1 = -960005748;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1990300729)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          ChatsTaskSettings._targetRelatedCounters = new Dictionary<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮, ChatsTaskSettings.CounterContainer>();
          num1 = (int) num2 * 935735030 ^ -824149881;
          continue;
        case 2:
          goto label_3;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  public ChatsTaskSettings()
  {
label_1:
    int num1 = -1256309759;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1681357020)) % 3U)
      {
        case 0:
          goto label_3;
        case 1:
          this.Targets = new List<ChatsTarget>();
          num1 = (int) num2 * 1069094270 ^ -2058859959;
          continue;
        case 2:
          goto label_1;
        default:
          goto label_5;
      }
    }
label_3:
    return;
label_5:;
  }

  private static ChatsTaskSettings.CounterContainer CounterContainerFromTarget(
    Account acc,
    ChatsTarget ctg)
  {
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ key = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(acc, ctg.Link);
    if (!ChatsTaskSettings._targetRelatedCounters.Keys.Contains<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>(key))
    {
label_1:
      int num1 = 1789213045;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 66723509)) % 3U)
        {
          case 0:
            goto label_1;
          case 2:
            ChatsTaskSettings._targetRelatedCounters[key] = new ChatsTaskSettings.CounterContainer();
            num1 = (int) num2 * -1586209246 ^ -184750667;
            continue;
          default:
            goto label_4;
        }
      }
    }
label_4:
    return ChatsTaskSettings._targetRelatedCounters[key];
  }

  public void AddNewTarget(ChatsTarget target)
  {
    List<ChatsTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      ChatsTaskSettings.\u206F‌‌⁮‍‏⁪‫⁪‏‎‮⁫‌‏⁫⁭⁪‭‭​⁫‫‍‭‮‪⁮‎⁯‫⁪‫‎‮⁭‎​‬‍‮((object) targets, ref flag);
label_2:
      int num1 = -1125028330;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -1202610772)) % 3U)
        {
          case 0:
            goto label_2;
          case 1:
            goto label_9;
          case 2:
            this.Targets.Add(target);
            num1 = (int) num2 * -1461963602 ^ -1977349754;
            continue;
          default:
            goto label_5;
        }
      }
label_9:
      return;
label_5:;
    }
    finally
    {
      if (flag)
      {
label_7:
        int num3 = -315762159;
        while (true)
        {
          uint num4;
          switch ((num4 = (uint) (num3 ^ -1202610772)) % 3U)
          {
            case 1:
              ChatsTaskSettings.\u202E‌‫‏‮‎⁪‬‍‍‏⁫‪⁭⁬‎⁬⁭⁮‌⁮⁪‏‭⁫‭‭‬‎‬​‍⁮‭‮⁭‍​⁪⁭‮((object) targets);
              num3 = (int) num4 * -1840466808 ^ 414609886;
              continue;
            case 2:
              goto label_7;
            default:
              goto label_11;
          }
        }
      }
label_11:;
    }
  }

  public void RemoveTarget(ChatsTarget target)
  {
    List<ChatsTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      ChatsTaskSettings.\u206F‌‌⁮‍‏⁪‫⁪‏‎‮⁫‌‏⁫⁭⁪‭‭​⁫‫‍‭‮‪⁮‎⁯‫⁪‫‎‮⁭‎​‬‍‮((object) targets, ref flag);
      this.Targets.Remove(target);
    }
    finally
    {
      if (flag)
      {
label_3:
        int num1 = 412275455;
        while (true)
        {
          uint num2;
          switch ((num2 = (uint) (num1 ^ 1785664536)) % 3U)
          {
            case 0:
              goto label_3;
            case 1:
              ChatsTaskSettings.\u202E‌‫‏‮‎⁪‬‍‍‏⁫‪⁭⁬‎⁬⁭⁮‌⁮⁪‏‭⁫‭‭‬‎‬​‍⁮‭‮⁭‍​⁪⁭‮((object) targets);
              num1 = (int) num2 * -1599586125 ^ -1551220722;
              continue;
            default:
              goto label_6;
          }
        }
      }
label_6:;
    }
  }

  public void ReplaceTarget(ChatsTarget from, ChatsTarget to)
  {
    List<ChatsTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      ChatsTaskSettings.\u206F‌‌⁮‍‏⁪‫⁪‏‎‮⁫‌‏⁫⁭⁪‭‭​⁫‫‍‭‮‪⁮‎⁯‫⁪‫‎‮⁭‎​‬‍‮((object) targets, ref flag);
label_2:
      int num1 = 150011720;
      int index;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 770749116)) % 5U)
        {
          case 0:
            goto label_2;
          case 1:
            int num3 = index == -1 ? -1749579951 : (num3 = -269472685);
            num1 = num3 ^ (int) num2 * -479204041;
            continue;
          case 2:
            this.Targets[index] = to;
            num1 = (int) num2 * -692399154 ^ -2100504737;
            continue;
          case 3:
            index = this.Targets.IndexOf(from);
            num1 = (int) num2 * -1483525516 ^ -2143736768;
            continue;
          case 4:
            goto label_11;
          default:
            goto label_7;
        }
      }
label_11:
      return;
label_7:;
    }
    finally
    {
      if (flag)
      {
label_9:
        int num4 = 1664474012;
        while (true)
        {
          uint num5;
          switch ((num5 = (uint) (num4 ^ 770749116)) % 3U)
          {
            case 1:
              ChatsTaskSettings.\u202E‌‫‏‮‎⁪‬‍‍‏⁫‪⁭⁬‎⁬⁭⁮‌⁮⁪‏‭⁫‭‭‬‎‬​‍⁮‭‮⁭‍​⁪⁭‮((object) targets);
              num4 = (int) num5 * 992709998 ^ -737461169;
              continue;
            case 2:
              goto label_9;
            default:
              goto label_13;
          }
        }
      }
label_13:;
    }
  }

  public void ParseDataGridView(DataGridView view)
  {
    List<ChatsTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      ChatsTaskSettings.\u206F‌‌⁮‍‏⁪‫⁪‏‎‮⁫‌‏⁫⁭⁪‭‭​⁫‫‍‭‮‪⁮‎⁯‫⁪‫‎‮⁭‎​‬‍‮((object) targets, ref flag);
label_2:
      int num1 = -1911325598;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -919508177)) % 3U)
        {
          case 1:
            this.Targets.Clear();
            num1 = (int) num2 * 1944055616 ^ -1709524721;
            continue;
          case 2:
            goto label_2;
          default:
            goto label_5;
        }
      }
label_5:
      IEnumerator enumerator = ChatsTaskSettings.\u202A‎​‏‏‏‏‬‮⁯⁫​‪‪⁯⁪‎⁮‭‫‪‬​⁯‎‌⁭‬⁮⁯​⁬⁭​⁫‪‬⁯⁯‎‮((IEnumerable) ChatsTaskSettings.\u202E⁮‫‫⁯⁪‌⁬⁪‌⁪‍⁪‭‬‎‎‬​‭‎⁬​‭⁬⁪⁮⁪‬⁬‫‪⁬‌⁭⁪‮‬⁬‮(view));
      try
      {
label_9:
        int num3 = !ChatsTaskSettings.\u200B‭⁭⁮​‮‍‫‫‬‌⁯‌⁭‎⁭‭⁯⁫‫‏‭⁬‭‮‫⁪‮⁮​‌⁬‫‎‮‌‫‬‏‍‮(enumerator) ? -1537591777 : (num3 = -830674061);
        DataGridViewRow dataGridViewRow;
        while (true)
        {
          uint num4;
          switch ((num4 = (uint) (num3 ^ -919508177)) % 5U)
          {
            case 0:
              num3 = -830674061;
              continue;
            case 1:
              goto label_9;
            case 2:
              goto label_21;
            case 3:
              this.Targets.Add(new ChatsTarget()
              {
                Link = ChatsTaskSettings.\u206A⁭⁭⁪⁯⁬‮⁫⁫‮​‎⁪⁪‪‍⁪​‮⁪‭⁯⁬​‪⁭‪​‌⁪‎‮‪‮⁮‮‮‍⁯‌‮(ChatsTaskSettings.\u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮(ChatsTaskSettings.\u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(ChatsTaskSettings.\u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(dataGridViewRow), 0)) ?? (object) ""),
                TitleMode = ChatsTaskSettings.\u206A⁭⁭⁪⁯⁬‮⁫⁫‮​‎⁪⁪‪‍⁪​‮⁪‭⁯⁬​‪⁭‪​‌⁪‎‮‪‮⁮‮‮‍⁯‌‮(ChatsTaskSettings.\u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮(ChatsTaskSettings.\u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(ChatsTaskSettings.\u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(dataGridViewRow), 1))),
                Title = ChatsTaskSettings.\u206A⁭⁭⁪⁯⁬‮⁫⁫‮​‎⁪⁪‪‍⁪​‮⁪‭⁯⁬​‪⁭‪​‌⁪‎‮‪‮⁮‮‮‍⁯‌‮(ChatsTaskSettings.\u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮(ChatsTaskSettings.\u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(ChatsTaskSettings.\u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(dataGridViewRow), 2)) ?? (object) ""),
                AvatarMode = ChatsTaskSettings.\u206A⁭⁭⁪⁯⁬‮⁫⁫‮​‎⁪⁪‪‍⁪​‮⁪‭⁯⁬​‪⁭‪​‌⁪‎‮‪‮⁮‮‮‍⁯‌‮(ChatsTaskSettings.\u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮(ChatsTaskSettings.\u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(ChatsTaskSettings.\u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(dataGridViewRow), 3))),
                FloodWithAvatar = (bool) ChatsTaskSettings.\u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮(ChatsTaskSettings.\u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(ChatsTaskSettings.\u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(dataGridViewRow), 4))
              });
              num3 = -2098980184;
              continue;
            case 4:
              dataGridViewRow = (DataGridViewRow) ChatsTaskSettings.\u206C‬⁭⁭⁮‪‎⁯‎‬‎⁬‍​⁮‎⁯‭‎‏⁮⁫​‭‮⁪⁫‬⁯‪⁭⁭‪‌⁮‌‮⁭​‍‮(enumerator);
              num3 = -1297586310;
              continue;
            default:
              goto label_15;
          }
        }
label_21:
        return;
label_15:;
      }
      finally
      {
        if (enumerator is IDisposable disposable)
        {
label_13:
          int num5 = -1946427265;
          while (true)
          {
            uint num6;
            switch ((num6 = (uint) (num5 ^ -919508177)) % 3U)
            {
              case 1:
                ChatsTaskSettings.\u206F⁭⁬‎‌‪​⁫‏‮‮⁯‌‎⁫‭​⁬‌⁪⁬⁮⁬‭‫⁮‬‏‌⁭‌⁭‬‪‌⁭‫‍‎‏‮(disposable);
                num5 = (int) num6 * 779729350 ^ -1789460116;
                continue;
              case 2:
                goto label_13;
              default:
                goto label_17;
            }
          }
        }
label_17:;
      }
    }
    finally
    {
      if (flag)
      {
label_19:
        int num7 = -1218990044;
        while (true)
        {
          uint num8;
          switch ((num8 = (uint) (num7 ^ -919508177)) % 3U)
          {
            case 0:
              goto label_19;
            case 2:
              ChatsTaskSettings.\u202E‌‫‏‮‎⁪‬‍‍‏⁫‪⁭⁬‎⁬⁭⁮‌⁮⁪‏‭⁫‭‭‬‎‬​‍⁮‭‮⁭‍​⁪⁭‮((object) targets);
              num7 = (int) num8 * -1636107791 ^ -1065966053;
              continue;
            default:
              goto label_23;
          }
        }
      }
label_23:;
    }
  }

  public override void Validate()
  {
    List<string> stringList = new List<string>((IEnumerable<string>) ChatsTaskSettings.\u200E⁭⁮​‫⁬‏‪‭⁭‮⁫‍​‭‮‍⁪‬‭‌‭‫‎‮‌‌‍‫⁫⁪‌⁯‫‭‎‫‌‍‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(529934142U)));
label_1:
    int num1 = -1476169563;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -855033555)) % 3U)
      {
        case 0:
          goto label_1;
        case 2:
          stringList = stringList.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * 1585244171 ^ -1375702557;
          continue;
        default:
          goto label_4;
      }
    }
label_4:
    using (List<ChatsTarget>.Enumerator enumerator = this.Targets.GetEnumerator())
    {
label_10:
      int num3 = !enumerator.MoveNext() ? -1875263664 : (num3 = -787229391);
      ChatsTarget current;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ -855033555)) % 7U)
        {
          case 0:
            num3 = -787229391;
            continue;
          case 1:
            int num5 = !stringList.Contains(current.AvatarMode) ? 1310746060 : (num5 = 65508897);
            num3 = num5 ^ (int) num4 * -1361892029;
            continue;
          case 2:
            current = enumerator.Current;
            num3 = -1210149731;
            continue;
          case 3:
            goto label_14;
          case 4:
            current.AvatarMode = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1187788849U);
            num3 = (int) num4 * 1157170749 ^ 1315120044;
            continue;
          case 5:
            goto label_10;
          case 6:
            int num6 = ChatsTaskSettings.\u202C⁭‍‏‏‏‫⁫‭⁬‮‪‫⁭⁭⁯‫⁭⁭‌‪‮⁫⁭‍⁭⁪‏⁬‪‭‌‍⁯‏‪‬⁯⁪⁫‮(current.AvatarMode, \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3697237743U)) ? 1201384901 : (num6 = 1976180121);
            num3 = num6 ^ (int) num4 * 1713277096;
            continue;
          default:
            goto label_8;
        }
      }
label_14:
      return;
label_8:;
    }
  }

  public string GetTitle(Account acc, ChatsTarget ctg)
  {
    if (ChatsTaskSettings._titlesToFlood.Count == 0)
    {
label_1:
      uint num;
      switch ((num = (uint) (-253398636 ^ -384235674)) % 3U)
      {
        case 1:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3401629153U));
          return (string) null;
        case 2:
          goto label_1;
      }
    }
    ChatsTaskSettings.CounterContainer counterContainer = ChatsTaskSettings.CounterContainerFromTarget(acc, ctg);
    counterContainer.TitleIndex = (counterContainer.TitleIndex + 1) % ChatsTaskSettings._titlesToFlood.Count;
    return ChatsTaskSettings._titlesToFlood[counterContainer.TitleIndex];
  }

  static Encoding \u202A‮‎⁪‎‪‬‏‫⁬‎⁭‎⁪‬‏‬⁫⁭⁭‮⁯​‪‮‬‏‍⁬‮‭⁪‬⁮⁬‬⁮‎‌‏‮([In] string obj0)
  {
    return Encoding.GetEncoding(obj0);
  }

  static string[] \u206F‪⁬⁭‭⁬⁫‮‪⁪‫‎‎⁪⁪‏​⁫‍⁬⁮⁭‬‍⁯⁬⁬⁫‌‫‬⁯​‫‎‌⁮⁬‮([In] string obj0, [In] Encoding obj1)
  {
    return File.ReadAllLines(obj0, obj1);
  }

  static void \u206F‌‌⁮‍‏⁪‫⁪‏‎‮⁫‌‏⁫⁭⁪‭‭​⁫‫‍‭‮‪⁮‎⁯‫⁪‫‎‮⁭‎​‬‍‮([In] object obj0, [In] ref bool obj1)
  {
    Monitor.Enter(obj0, ref obj1);
  }

  static void \u202E‌‫‏‮‎⁪‬‍‍‏⁫‪⁭⁬‎⁬⁭⁮‌⁮⁪‏‭⁫‭‭‬‎‬​‍⁮‭‮⁭‍​⁪⁭‮([In] object obj0)
  {
    Monitor.Exit(obj0);
  }

  static DataGridViewRowCollection \u202E⁮‫‫⁯⁪‌⁬⁪‌⁪‍⁪‭‬‎‎‬​‭‎⁬​‭⁬⁪⁮⁪‬⁬‫‪⁬‌⁭⁪‮‬⁬‮([In] DataGridView obj0)
  {
    return obj0.Rows;
  }

  static IEnumerator \u202A‎​‏‏‏‏‬‮⁯⁫​‪‪⁯⁪‎⁮‭‫‪‬​⁯‎‌⁭‬⁮⁯​⁬⁭​⁫‪‬⁯⁯‎‮([In] IEnumerable obj0)
  {
    return obj0.GetEnumerator();
  }

  static object \u206C‬⁭⁭⁮‪‎⁯‎‬‎⁬‍​⁮‎⁯‭‎‏⁮⁫​‭‮⁪⁫‬⁯‪⁭⁭‪‌⁮‌‮⁭​‍‮([In] IEnumerator obj0)
  {
    return obj0.Current;
  }

  static DataGridViewCellCollection \u206B⁯​‎‪‍⁬⁮‪⁬‭⁬‮​‭‫‪‍‏‮​⁭⁪‪‎‍⁬⁮‌‬‎‫‪⁮​​⁮‎⁫⁪‮(
    [In] DataGridViewRow obj0)
  {
    return obj0.Cells;
  }

  static DataGridViewCell \u200B‬⁭⁫‮‎‭⁮‬‮‪​‍‏⁪⁭⁫‫⁭‍‫⁭⁫‫​⁭​⁪‌‫‪‭‎‮‌‭⁭‮⁬‎‮(
    [In] DataGridViewCellCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static object \u202E⁬​‏‌‭‌​⁭⁫⁪⁫⁯‬‪⁮⁫⁫​‭⁭⁮⁬‌‮⁮‪⁪⁮⁬‌⁭⁪​⁬⁮‭‎⁫⁮‮([In] DataGridViewCell obj0)
  {
    return obj0.Value;
  }

  static string \u206A⁭⁭⁪⁯⁬‮⁫⁫‮​‎⁪⁪‪‍⁪​‮⁪‭⁯⁬​‪⁭‪​‌⁪‎‮‪‮⁮‮‮‍⁯‌‮([In] object obj0) => obj0.ToString();

  static bool \u200B‭⁭⁮​‮‍‫‫‬‌⁯‌⁭‎⁭‭⁯⁫‫‏‭⁬‭‮‫⁪‮⁮​‌⁬‫‎‮‌‫‬‏‍‮([In] IEnumerator obj0)
  {
    return obj0.MoveNext();
  }

  static void \u206F⁭⁬‎‌‪​⁫‏‮‮⁯‌‎⁫‭​⁬‌⁪⁬⁮⁬‭‫⁮‬‏‌⁭‌⁭‬‪‌⁭‫‍‎‏‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static string[] \u200E⁭⁮​‫⁬‏‪‭⁭‮⁫‍​‭‮‍⁪‬‭‌‭‫‎‮‌‌‍‫⁫⁪‌⁯‫‭‎‫‌‍‫‮([In] string obj0)
  {
    return Directory.GetFiles(obj0);
  }

  static bool \u202C⁭‍‏‏‏‫⁫‭⁬‮‪‫⁭⁭⁯‫⁭⁭‌‪‮⁫⁭‍⁭⁪‏⁬‪‭‌‍⁯‏‪‬⁯⁪⁫‮([In] string obj0, [In] string obj1)
  {
    return obj0 != obj1;
  }

  private class CounterContainer
  {
    public int TitleIndex = -1;
  }
}
