﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.VoiceTaskSettings
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

#nullable disable
namespace ISP.Tasks.Settings;

internal sealed class VoiceTaskSettings : ISBTaskSettings
{
  public string Voice = \u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(3188631705U);
  public string Emotion = \u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1135329137U);
  public int Speed = 10;
  public string Yandexapi;
  public string Message;
  public string Target;

  public override void Validate()
  {
    this.Speed = this.Speed.\u206E⁮‏⁮⁭‏⁪⁭‮‌⁮‬⁯⁯‪‍⁭‭‬‏‍‏‫‍‏‪‍⁮‪⁮​⁯‫‫⁬‬​⁫‍⁪‮(1, 30);
  }
}
