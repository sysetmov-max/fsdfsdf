﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.FlooderTarget
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Tasks.Settings;

internal sealed class FlooderTarget
{
  public string Link;
  public string NamePlace;
  public string Name;
  public string Contains;

  public FlooderTarget()
  {
  }

  public FlooderTarget(FlooderTarget ftg)
  {
    this.Link = ftg.Link;
    this.NamePlace = ftg.NamePlace;
    this.Name = ftg.Name;
    this.Contains = ftg.Contains;
  }

  public override bool Equals(object obj)
  {
    if (obj != null)
      goto label_4;
label_1:
    int num1 = -790769948;
label_2:
    uint num2;
    switch ((num2 = (uint) (num1 ^ -1850543164)) % 5U)
    {
      case 0:
        return false;
      case 2:
        goto label_1;
      case 3:
        break;
      case 4:
        return false;
      default:
        return this.Equals(other);
    }
label_4:
    num1 = !(obj is FlooderTarget other) ? -1492163780 : (num1 = -764266863);
    goto label_2;
  }

  private bool Equals(FlooderTarget other)
  {
    if (FlooderTarget.\u200B‍‮‪‎⁬⁯⁫‪⁪⁫⁭‬‍‮‌‬⁫⁭⁫‌‏‏⁭‮⁮⁮‎⁬⁮⁮‏‪⁫⁬‫‍⁯⁬‏‮(this.Link, other.Link))
    {
label_1:
      int num1 = -716517437;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -36776391)) % 5U)
        {
          case 0:
            goto label_1;
          case 1:
            int num3 = FlooderTarget.\u200B‍‮‪‎⁬⁯⁫‪⁪⁫⁭‬‍‮‌‬⁫⁭⁫‌‏‏⁭‮⁮⁮‎⁬⁮⁮‏‪⁫⁬‫‍⁯⁬‏‮(this.Name, other.Name) ? -721756418 : (num3 = -1584526492);
            num1 = num3 ^ (int) num2 * 78706605;
            continue;
          case 2:
            int num4 = !FlooderTarget.\u200B‍‮‪‎⁬⁯⁫‪⁪⁫⁭‬‍‮‌‬⁫⁭⁫‌‏‏⁭‮⁮⁮‎⁬⁮⁮‏‪⁫⁬‫‍⁯⁬‏‮(this.NamePlace, other.NamePlace) ? -608638269 : (num4 = -766460238);
            num1 = num4 ^ (int) num2 * 1775399169;
            continue;
          case 3:
            goto label_5;
          default:
            goto label_6;
        }
      }
label_5:
      return FlooderTarget.\u200B‍‮‪‎⁬⁯⁫‪⁪⁫⁭‬‍‮‌‬⁫⁭⁫‌‏‏⁭‮⁮⁮‎⁬⁮⁮‏‪⁫⁬‫‍⁯⁬‏‮(this.Contains, other.Contains);
    }
label_6:
    return false;
  }

  public override int GetHashCode()
  {
    return (((this.Link != null ? FlooderTarget.\u200E⁭⁪⁪‌‎⁭‬‫‪⁭‪⁯‍⁭‍‎‭⁪⁬‌‫‍‮⁪‏⁬⁬⁪‎‎‍⁯‎⁮⁯‫‌⁫‏‮((object) this.Link) : 0) * 397 ^ (this.NamePlace != null ? FlooderTarget.\u200E⁭⁪⁪‌‎⁭‬‫‪⁭‪⁯‍⁭‍‎‭⁪⁬‌‫‍‮⁪‏⁬⁬⁪‎‎‍⁯‎⁮⁯‫‌⁫‏‮((object) this.NamePlace) : 0)) * 397 ^ (this.Name != null ? FlooderTarget.\u200E⁭⁪⁪‌‎⁭‬‫‪⁭‪⁯‍⁭‍‎‭⁪⁬‌‫‍‮⁪‏⁬⁬⁪‎‎‍⁯‎⁮⁯‫‌⁫‏‮((object) this.Name) : 0)) * 397 ^ (this.Contains != null ? FlooderTarget.\u200E⁭⁪⁪‌‎⁭‬‫‪⁭‪⁯‍⁭‍‎‭⁪⁬‌‫‍‮⁪‏⁬⁬⁪‎‎‍⁯‎⁮⁯‫‌⁫‏‮((object) this.Contains) : 0);
  }

  static bool \u200B‍‮‪‎⁬⁯⁫‪⁪⁫⁭‬‍‮‌‬⁫⁭⁫‌‏‏⁭‮⁮⁮‎⁬⁮⁮‏‪⁫⁬‫‍⁯⁬‏‮([In] string obj0, [In] string obj1)
  {
    return string.Equals(obj0, obj1);
  }

  static int \u200E⁭⁪⁪‌‎⁭‬‫‪⁭‪⁯‍⁭‍‎‭⁪⁬‌‫‍‮⁪‏⁬⁬⁪‎‎‍⁯‎⁮⁯‫‌⁫‏‮([In] object obj0) => obj0.GetHashCode();
}
