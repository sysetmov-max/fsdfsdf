﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.FlooderTaskSettings
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using ISP.Engine.Accounts;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using VkNet;
using VkNet.Categories;
using VkNet.Model;
using VkNet.Model.Attachments;
using VkNet.Utils;

#nullable disable
namespace ISP.Tasks.Settings;

internal sealed class FlooderTaskSettings : ISBTaskSettings
{
  public readonly List<FlooderTarget> Targets;
  public bool ImagesFromFolder;
  public string PhrasesFile;
  public string PhrasesWithDotsFile;
  public string StickersFile;
  public string StickerId;
  private static Dictionary<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮, FlooderTaskSettings.CounterContainer> _targetRelatedCounters;
  private List<string> _phrases;
  private List<string> _phrasesWithDots;
  private static List<MediaAttachment> _audios;
  private static List<MediaAttachment> _videos;
  private List<MediaAttachment> _documents;
  private List<MediaAttachment> _images;
  private List<MediaAttachment> _stickers;
  private static Random _rnd;

  static FlooderTaskSettings() => FlooderTaskSettings.ReloadFromTxts();

  public static void ReloadFromTxts()
  {
    FlooderTaskSettings._targetRelatedCounters = new Dictionary<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮, FlooderTaskSettings.CounterContainer>();
label_1:
    int num1 = -1605574955;
    Match match1;
    Regex regex1;
    string str1;
    Regex regex2;
    string str2;
    Match match2;
    string[] strArray;
    int index;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -95902625)) % 27U)
      {
        case 0:
          ++index;
          num1 = -1934825335;
          continue;
        case 1:
          index = 0;
          num1 = (int) num2 * 2002446535 ^ 1092843005;
          continue;
        case 2:
          match2 = FlooderTaskSettings.\u202B⁪‏‍‎⁮⁫​‍‮‫‮‮‫‮‍⁭⁪‌⁫⁮‬‪⁭‫‪‪‏‭⁬⁮‌‪‭‍​‎⁮⁪‎‮(regex2, str2);
          num1 = (int) num2 * 1449409692 ^ 1882965583;
          continue;
        case 3:
          num1 = (int) num2 * -1686309340 ^ 737827093;
          continue;
        case 4:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1357243681U), (object) str1));
          num1 = -798392015;
          continue;
        case 5:
          List<MediaAttachment> audios = FlooderTaskSettings._audios;
          Audio audio = FlooderTaskSettings.\u202E‌‎‎‎‭⁪⁫⁮⁭⁪‎⁮‮‎‭‍‎⁪⁬‮⁬⁫⁫‬⁬‮‌‏‏⁫‮‎⁫‏⁯‫‬⁪‮‮();
          FlooderTaskSettings.\u202B‪‭‎‪⁮⁪​​‬‫‮⁮⁮‮⁯⁭⁮‬⁫⁫‍⁪‍‎‎‌⁪‬⁫⁪‏‫⁫‪‍​⁭‭⁬‮((MediaAttachment) audio, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match1), 1)))));
          FlooderTaskSettings.\u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮((MediaAttachment) audio, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match1), 2)))));
          audios.Add((MediaAttachment) audio);
          num1 = (int) num2 * 1311923579 ^ 767065780;
          continue;
        case 6:
          FlooderTaskSettings._rnd = FlooderTaskSettings.\u206B‬⁯​⁮​⁪⁯​‎‎‪‮‫⁬‏‫‬‫‪‫⁭‏‪⁪⁬‍⁮‌⁯‌‎‌‭‬‏‌⁬‏‬‮();
          FlooderTaskSettings._audios = new List<MediaAttachment>();
          num1 = (int) num2 * -1372089106 ^ -667051414;
          continue;
        case 7:
          str2 = strArray[index];
          num1 = -1418949483;
          continue;
        case 8:
          goto label_1;
        case 9:
          int num3;
          num1 = num3 = index >= strArray.Length ? -1805425358 : (num3 = -168489165);
          continue;
        case 10:
          match1 = FlooderTaskSettings.\u202B⁪‏‍‎⁮⁫​‍‮‫‮‮‫‮‍⁭⁪‌⁫⁮‬‪⁭‫‪‪‏‭⁬⁮‌‪‭‍​‎⁮⁪‎‮(regex1, str1);
          num1 = (int) num2 * -741804978 ^ 455162875;
          continue;
        case 11:
          num1 = (int) num2 * 1637303429 ^ -298312263;
          continue;
        case 12:
          ++index;
          num1 = -1985840679;
          continue;
        case 13:
          regex2 = FlooderTaskSettings.\u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1056751842U));
          num1 = (int) num2 * 1704451031 ^ -857758613;
          continue;
        case 14:
          int num4 = !FlooderTaskSettings.\u206E‪‍​‫⁬‪⁪‌‪‏‌‫‍⁬‪​⁫‌⁯⁫​⁯⁮⁯‎‍⁪‭‏⁬‍‍‌⁪‏⁭‫⁬‪‮((System.Text.RegularExpressions.Group) match2) ? -130893125 : (num4 = -2076158613);
          num1 = num4 ^ (int) num2 * 1854250331;
          continue;
        case 15:
          FlooderTaskSettings._videos = new List<MediaAttachment>();
          num1 = (int) num2 * -1036743024 ^ -232289332;
          continue;
        case 16 /*0x10*/:
          num1 = (int) num2 * 1306310689 ^ -1219373616;
          continue;
        case 17:
          int num5;
          num1 = num5 = index < strArray.Length ? -1958999983 : (num5 = -1571895871);
          continue;
        case 18:
          num1 = (int) num2 * 883130016 ^ -1561300343;
          continue;
        case 19:
          strArray = FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(451680109U), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1112900782U)));
          index = 0;
          num1 = (int) num2 * -44443996 ^ 1984472823;
          continue;
        case 20:
          regex1 = FlooderTaskSettings.\u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3303790854U));
          num1 = (int) num2 * -1726414381 ^ -2121260072;
          continue;
        case 21:
          List<MediaAttachment> videos = FlooderTaskSettings._videos;
          Video video = FlooderTaskSettings.\u202A‪⁯⁭‌⁪⁮‭⁪‬⁮⁭⁬‮‪⁫‍‬‏‏‪⁮⁭⁬‬​​‍⁫‪‌⁯‌⁬⁬⁪‭‪‪⁪‮();
          FlooderTaskSettings.\u202B‪‭‎‪⁮⁪​​‬‫‮⁮⁮‮⁯⁭⁮‬⁫⁫‍⁪‍‎‎‌⁪‬⁫⁪‏‫⁫‪‍​⁭‭⁬‮((MediaAttachment) video, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match2), 1)))));
          FlooderTaskSettings.\u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮((MediaAttachment) video, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match2), 2)))));
          videos.Add((MediaAttachment) video);
          num1 = (int) num2 * -348728894 ^ 964566056;
          continue;
        case 22:
          int num6 = FlooderTaskSettings.\u206E‪‍​‫⁬‪⁪‌‪‏‌‫‍⁬‪​⁫‌⁯⁫​⁯⁮⁯‎‍⁪‭‏⁬‍‍‌⁪‏⁭‫⁬‪‮((System.Text.RegularExpressions.Group) match1) ? 611364101 : (num6 = 685272050);
          num1 = num6 ^ (int) num2 * -2099781902;
          continue;
        case 23:
          goto label_3;
        case 24:
          str1 = strArray[index];
          num1 = -290632990;
          continue;
        case 25:
          strArray = FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2222121644U), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3438476176U)));
          num1 = (int) num2 * 828877187 ^ -1250878544;
          continue;
        case 26:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(563536499U), (object) str2));
          num1 = -511659694;
          continue;
        default:
          goto label_29;
      }
    }
label_3:
    return;
label_29:;
  }

  public void LoadAccountSpecific(Account acc)
  {
    this._phrases = new List<string>();
    this._phrasesWithDots = new List<string>();
label_1:
    int num1 = -294810483;
    string[] strArray;
    int index;
    string str1;
    Match match1;
    Regex regex1;
    Regex regex2;
    string str2;
    Match match2;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -1141158324)) % 32U /*0x20*/)
      {
        case 0:
          num1 = (int) num2 * 793761866 ^ 863208297;
          continue;
        case 1:
          int num3 = !FlooderTaskSettings.\u206B‪⁮⁫⁫‫‭‭⁪‪⁭‎‭⁬‪⁪⁫⁫‬‭⁪⁮‮‭‌‭​‭⁪⁬‬⁭⁮⁮⁮⁯⁭​​⁪‮(this.PhrasesFile) ? -1655681399 : (num3 = -910791812);
          num1 = num3 ^ (int) num2 * -861544519;
          continue;
        case 2:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2111520435U), (object) str2));
          num1 = -1543026199;
          continue;
        case 3:
          regex1 = FlooderTaskSettings.\u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2956959546U));
          int num4 = !FlooderTaskSettings.\u206B‪⁮⁫⁫‫‭‭⁪‪⁭‎‭⁬‪⁪⁫⁫‬‭⁪⁮‮‭‌‭​‭⁪⁬‬⁭⁮⁮⁮⁯⁭​​⁪‮(this.StickersFile) ? -1980478752 : (num4 = -630283267);
          num1 = num4 ^ (int) num2 * 1601052441;
          continue;
        case 4:
          ++index;
          num1 = -673662428;
          continue;
        case 5:
          ++index;
          num1 = -1381985085;
          continue;
        case 6:
          this._phrasesWithDots = new List<string>((IEnumerable<string>) FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(914663202U), (object) this.PhrasesWithDotsFile), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1112900782U))));
          num1 = (int) num2 * -1096429463 ^ -193115922;
          continue;
        case 7:
          strArray = FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2120743685U), (object) this.StickersFile), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(844754735U)));
          index = 0;
          num1 = (int) num2 * -859500523 ^ 301092625;
          continue;
        case 8:
          int num5;
          num1 = num5 = index < strArray.Length ? -1553772896 : (num5 = -987075114);
          continue;
        case 9:
          int num6;
          num1 = num6 = FlooderTaskSettings.\u206B‪⁮⁫⁫‫‭‭⁪‪⁭‎‭⁬‪⁪⁫⁫‬‭⁪⁮‮‭‌‭​‭⁪⁬‬⁭⁮⁮⁮⁯⁭​​⁪‮(this.PhrasesWithDotsFile) ? -313383560 : (num6 = -1210744726);
          continue;
        case 10:
          goto label_3;
        case 11:
          num1 = (int) num2 * 2003934644 ^ 755809300;
          continue;
        case 12:
          str1 = strArray[index];
          num1 = -255535820;
          continue;
        case 13:
          num1 = (int) num2 * -348633431 ^ 1354764086;
          continue;
        case 14:
          num1 = (int) num2 * -1893385269 ^ -729087490;
          continue;
        case 15:
          int num7;
          num1 = num7 = index >= strArray.Length ? -978407930 : (num7 = -1502394022);
          continue;
        case 16 /*0x10*/:
          regex2 = FlooderTaskSettings.\u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(237976160U));
          num1 = (int) num2 * 1851736700 ^ 1765451375;
          continue;
        case 17:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3476474123U), (object) str1));
          num1 = -906702552;
          continue;
        case 18:
          List<MediaAttachment> stickers = this._stickers;
          Sticker sticker = FlooderTaskSettings.\u202D‌‭⁮‍⁯⁫⁫‮‫‎‪⁭‫‌‍⁯‍‍​‍⁪‏⁭‪⁪‏‫‍‫‍⁫‫‍‫‍⁫⁪⁬‍‮();
          FlooderTaskSettings.\u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮((MediaAttachment) sticker, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match1), 1)))));
          stickers.Add((MediaAttachment) sticker);
          num1 = (int) num2 * -560948525 ^ 893794481;
          continue;
        case 19:
          index = 0;
          num1 = (int) num2 * -425133144 ^ 1785450073;
          continue;
        case 20:
          this._documents = new List<MediaAttachment>();
          this._images = new List<MediaAttachment>();
          num1 = -1173373001;
          continue;
        case 21:
          strArray = FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3393321406U), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1112900782U)));
          num1 = -1176106241;
          continue;
        case 22:
          str2 = strArray[index];
          num1 = -1614062859;
          continue;
        case 23:
          goto label_1;
        case 24:
          match1 = FlooderTaskSettings.\u202B⁪‏‍‎⁮⁫​‍‮‫‮‮‫‮‍⁭⁪‌⁫⁮‬‪⁭‫‪‪‏‭⁬⁮‌‪‭‍​‎⁮⁪‎‮(regex1, str1);
          int num8 = FlooderTaskSettings.\u206E‪‍​‫⁬‪⁪‌‪‏‌‫‍⁬‪​⁫‌⁯⁫​⁯⁮⁯‎‍⁪‭‏⁬‍‍‌⁪‏⁭‫⁬‪‮((System.Text.RegularExpressions.Group) match1) ? -156050218 : (num8 = -45262539);
          num1 = num8 ^ (int) num2 * -878087873;
          continue;
        case 25:
          match2 = FlooderTaskSettings.\u202B⁪‏‍‎⁮⁫​‍‮‫‮‮‫‮‍⁭⁪‌⁫⁮‬‪⁭‫‪‪‏‭⁬⁮‌‪‭‍​‎⁮⁪‎‮(regex2, str2);
          int num9 = !FlooderTaskSettings.\u206E‪‍​‫⁬‪⁪‌‪‏‌‫‍⁬‪​⁫‌⁯⁫​⁯⁮⁯‎‍⁪‭‏⁬‍‍‌⁪‏⁭‫⁬‪‮((System.Text.RegularExpressions.Group) match2) ? -639333390 : (num9 = -1836005361);
          num1 = num9 ^ (int) num2 * 1085793340;
          continue;
        case 26:
          this.UploadDocuments(acc);
          num1 = -379844239;
          continue;
        case 27:
          this._stickers = new List<MediaAttachment>();
          num1 = (int) num2 * 1533480597 ^ -1985635253;
          continue;
        case 28:
          this._phrases = new List<string>((IEnumerable<string>) FlooderTaskSettings.\u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(787249279U), (object) this.PhrasesFile), FlooderTaskSettings.\u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3438476176U))));
          num1 = (int) num2 * -966005147 ^ 491022633;
          continue;
        case 29:
          int num10 = this.ImagesFromFolder ? 1238263639 : (num10 = 1752579804);
          num1 = num10 ^ (int) num2 * -556575127;
          continue;
        case 30:
          goto label_14;
        case 31 /*0x1F*/:
          List<MediaAttachment> images = this._images;
          Photo photo = FlooderTaskSettings.\u206A‎‭⁪‭⁯⁪​⁮‏⁪⁮⁭⁪⁮⁫⁪⁬‫⁮‌⁭‪‬‬‫‪⁪⁫⁫⁫‭‭‫‪⁫⁯‌⁭⁬‮();
          FlooderTaskSettings.\u202B‪‭‎‪⁮⁪​​‬‫‮⁮⁮‮⁯⁭⁮‬⁫⁫‍⁪‍‎‎‌⁪‬⁫⁪‏‫⁫‪‍​⁭‭⁬‮((MediaAttachment) photo, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match2), 1)))));
          FlooderTaskSettings.\u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮((MediaAttachment) photo, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(match2), 2)))));
          images.Add((MediaAttachment) photo);
          num1 = (int) num2 * 420527453 ^ 329408847;
          continue;
        default:
          goto label_34;
      }
    }
label_3:
    return;
label_34:
    return;
label_14:
    this.UploadImages(acc);
  }

  public void AddNewTarget(FlooderTarget target)
  {
    List<FlooderTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      FlooderTaskSettings.\u202C‮‎⁮‌‎​‍​⁪‍‭​‏‭‫‫⁮⁯⁭‮‪⁯⁬⁫‎‏⁫‭​⁪‮⁬⁬‪⁬‏‪‏‪‮((object) targets, ref flag);
      this.Targets.Add(target);
    }
    finally
    {
      if (flag)
      {
label_3:
        int num1 = -865329341;
        while (true)
        {
          uint num2;
          switch ((num2 = (uint) (num1 ^ -947749885)) % 3U)
          {
            case 0:
              goto label_3;
            case 1:
              FlooderTaskSettings.\u202A‭‬⁬​‮​‭⁭‌⁪‏‫⁭‏⁯‬⁭⁬‌​⁯⁯‫‭‫‮‎⁫‮‍‫‍‌⁭‪​‭‏‪‮((object) targets);
              num1 = (int) num2 * -2128101930 ^ -669237978;
              continue;
            default:
              goto label_6;
          }
        }
      }
label_6:;
    }
  }

  public void RemoveTarget(FlooderTarget target)
  {
    List<FlooderTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      FlooderTaskSettings.\u202C‮‎⁮‌‎​‍​⁪‍‭​‏‭‫‫⁮⁯⁭‮‪⁯⁬⁫‎‏⁫‭​⁪‮⁬⁬‪⁬‏‪‏‪‮((object) targets, ref flag);
      this.Targets.Remove(target);
    }
    finally
    {
      if (flag)
      {
label_3:
        int num1 = 1263707251;
        while (true)
        {
          uint num2;
          switch ((num2 = (uint) (num1 ^ 1253202482)) % 3U)
          {
            case 0:
              goto label_3;
            case 1:
              FlooderTaskSettings.\u202A‭‬⁬​‮​‭⁭‌⁪‏‫⁭‏⁯‬⁭⁬‌​⁯⁯‫‭‫‮‎⁫‮‍‫‍‌⁭‪​‭‏‪‮((object) targets);
              num1 = (int) num2 * -1044356371 ^ -1671345019;
              continue;
            default:
              goto label_6;
          }
        }
      }
label_6:;
    }
  }

  public void ReplaceTarget(FlooderTarget from, FlooderTarget to)
  {
    List<FlooderTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      FlooderTaskSettings.\u202C‮‎⁮‌‎​‍​⁪‍‭​‏‭‫‫⁮⁯⁭‮‪⁯⁬⁫‎‏⁫‭​⁪‮⁬⁬‪⁬‏‪‏‪‮((object) targets, ref flag);
label_2:
      int num1 = -533731069;
      int index;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -2008096653)) % 5U)
        {
          case 0:
            goto label_11;
          case 1:
            this.Targets[index] = to;
            num1 = (int) num2 * 767197165 ^ 1091762890;
            continue;
          case 2:
            index = this.Targets.IndexOf(from);
            num1 = (int) num2 * -202298507 ^ -967753584;
            continue;
          case 3:
            int num3 = index == -1 ? 1866718995 : (num3 = 834717410);
            num1 = num3 ^ (int) num2 * 806884125;
            continue;
          case 4:
            goto label_2;
          default:
            goto label_7;
        }
      }
label_11:
      return;
label_7:;
    }
    finally
    {
      if (flag)
      {
label_9:
        int num4 = -717228316;
        while (true)
        {
          uint num5;
          switch ((num5 = (uint) (num4 ^ -2008096653)) % 3U)
          {
            case 1:
              FlooderTaskSettings.\u202A‭‬⁬​‮​‭⁭‌⁪‏‫⁭‏⁯‬⁭⁬‌​⁯⁯‫‭‫‮‎⁫‮‍‫‍‌⁭‪​‭‏‪‮((object) targets);
              num4 = (int) num5 * -243334415 ^ -321445437;
              continue;
            case 2:
              goto label_9;
            default:
              goto label_13;
          }
        }
      }
label_13:;
    }
  }

  public FlooderTaskSettings()
  {
    this.Targets = new List<FlooderTarget>();
    this.ImagesFromFolder = false;
    this.PhrasesFile = this.PhrasesWithDotsFile = this.StickersFile = (string) null;
  }

  public override void Validate()
  {
    List<string> stringList1 = new List<string>((IEnumerable<string>) FlooderTaskSettings.\u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(92610755U)));
label_1:
    int num1 = 1681130084;
    List<string> stringList2;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1303679279)) % 8U)
      {
        case 0:
          goto label_1;
        case 1:
          this.StickersFile = (string) null;
          num1 = (int) num2 * 1472752589 ^ -767894466;
          continue;
        case 2:
          stringList2 = new List<string>((IEnumerable<string>) FlooderTaskSettings.\u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(1739015138U)));
          num1 = (int) num2 * -1008139449 ^ 680049574;
          continue;
        case 3:
          stringList1 = stringList1.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * 1934006952 ^ -572056299;
          continue;
        case 4:
          this.StickerId = (string) null;
          num1 = (int) num2 * -1438153797 ^ -1429496058;
          continue;
        case 5:
          goto label_3;
        case 6:
          List<string> stringList3 = new List<string>((IEnumerable<string>) FlooderTaskSettings.\u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2174952740U))).ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          if (!stringList1.Contains(this.PhrasesFile))
            this.PhrasesFile = (string) null;
          if (!stringList2.Contains(this.PhrasesWithDotsFile))
            this.PhrasesWithDotsFile = (string) null;
          string stickersFile = this.StickersFile;
          int num3;
          num1 = num3 = !stringList3.Contains(stickersFile) ? 1442731894 : (num3 = 1055473498);
          continue;
        case 7:
          stringList2 = stringList2.ConvertAll<string>(new Converter<string, string>(Path.GetFileName));
          num1 = (int) num2 * -1373078749 ^ 1851432076;
          continue;
        default:
          goto label_14;
      }
    }
label_3:
    return;
label_14:;
  }

  public void ParseDataGridView(DataGridView view)
  {
    List<FlooderTarget> targets = this.Targets;
    bool flag = false;
    try
    {
      FlooderTaskSettings.\u202C‮‎⁮‌‎​‍​⁪‍‭​‏‭‫‫⁮⁯⁭‮‪⁯⁬⁫‎‏⁫‭​⁪‮⁬⁬‪⁬‏‪‏‪‮((object) targets, ref flag);
label_2:
      int num1 = 1209380182;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1352093062)) % 3U)
        {
          case 0:
            goto label_2;
          case 1:
            this.Targets.Clear();
            num1 = (int) num2 * -1836295816 ^ -107272259;
            continue;
          default:
            goto label_5;
        }
      }
label_5:
      IEnumerator enumerator = FlooderTaskSettings.\u200E⁪⁪‫⁪‎⁭‌​⁮⁫‮⁮‏​​‮​‏‍⁬‏⁯⁪‪⁫‮​‫‏⁬⁬‏‌⁫‎⁮‎⁯⁯‮((IEnumerable) FlooderTaskSettings.\u202B‬‏‪‍‏​⁪⁪‏‏⁬‎‪‌⁫‭⁯⁫‎⁫⁬⁮​‏‪‭​​‭⁮‫‍⁫​‭‭‌‎⁬‮(view));
      try
      {
label_10:
        int num3 = !FlooderTaskSettings.\u206B‭⁬‬‫​‫‌‭‭⁪‪⁪⁬‭⁫​⁭⁬⁮⁭‮⁭⁮​⁯⁪‪⁪‎⁯‍‬‎‭​⁮‌⁭‬‮(enumerator) ? 517065707 : (num3 = 685980088);
        while (true)
        {
          uint num4;
          switch ((num4 = (uint) (num3 ^ 1352093062)) % 4U)
          {
            case 0:
              num3 = 685980088;
              continue;
            case 1:
              goto label_21;
            case 2:
              DataGridViewRow dataGridViewRow = (DataGridViewRow) FlooderTaskSettings.\u202B‍‬‬‫‬⁪‎⁮‍‫‎‏‍‍⁮‭‭‬‪‫‮‮‫‭‫‌‎‏‭‬‏⁫⁯‪‎⁮⁭⁪⁪‮(enumerator);
              this.Targets.Add(new FlooderTarget()
              {
                Link = FlooderTaskSettings.\u206F‭⁭⁪‭⁫⁭‎⁯‏​⁪‮​‏⁮‍‏‎‫‌‌⁭⁮‍⁪‏‬⁪‏‬⁫⁮⁭‌⁭⁫‮‪‍‮(FlooderTaskSettings.\u200C⁬‏‭⁯⁭​‍‎‏⁪⁬‌⁮⁫⁯‮‪⁫⁭‬⁫‫‌‪‬‬⁪‭‎‍‏‪‍⁮⁭⁪⁬‮⁭‮(FlooderTaskSettings.\u206D‎‏⁫⁮‎‏‏‍⁪⁫‫‮⁪⁮‌‌‭⁪⁯⁬‎⁯‪⁮​⁫‪‍‫​⁬⁬‮⁭⁪‮⁭⁭‍‮(FlooderTaskSettings.\u202C⁯‪‎‬⁯⁪​‫‏⁪‮⁮‬‎‏⁯⁭‍‭‮‌‬⁯⁫⁭‏‌⁯⁫‎‬⁫‭⁯‭‍⁬⁬‏‮(dataGridViewRow), 0)) ?? (object) ""),
                NamePlace = FlooderTaskSettings.\u206F‭⁭⁪‭⁫⁭‎⁯‏​⁪‮​‏⁮‍‏‎‫‌‌⁭⁮‍⁪‏‬⁪‏‬⁫⁮⁭‌⁭⁫‮‪‍‮(FlooderTaskSettings.\u200C⁬‏‭⁯⁭​‍‎‏⁪⁬‌⁮⁫⁯‮‪⁫⁭‬⁫‫‌‪‬‬⁪‭‎‍‏‪‍⁮⁭⁪⁬‮⁭‮(FlooderTaskSettings.\u206D‎‏⁫⁮‎‏‏‍⁪⁫‫‮⁪⁮‌‌‭⁪⁯⁬‎⁯‪⁮​⁫‪‍‫​⁬⁬‮⁭⁪‮⁭⁭‍‮(FlooderTaskSettings.\u202C⁯‪‎‬⁯⁪​‫‏⁪‮⁮‬‎‏⁯⁭‍‭‮‌‬⁯⁫⁭‏‌⁯⁫‎‬⁫‭⁯‭‍⁬⁬‏‮(dataGridViewRow), 1))),
                Name = FlooderTaskSettings.\u206F‭⁭⁪‭⁫⁭‎⁯‏​⁪‮​‏⁮‍‏‎‫‌‌⁭⁮‍⁪‏‬⁪‏‬⁫⁮⁭‌⁭⁫‮‪‍‮(FlooderTaskSettings.\u200C⁬‏‭⁯⁭​‍‎‏⁪⁬‌⁮⁫⁯‮‪⁫⁭‬⁫‫‌‪‬‬⁪‭‎‍‏‪‍⁮⁭⁪⁬‮⁭‮(FlooderTaskSettings.\u206D‎‏⁫⁮‎‏‏‍⁪⁫‫‮⁪⁮‌‌‭⁪⁯⁬‎⁯‪⁮​⁫‪‍‫​⁬⁬‮⁭⁪‮⁭⁭‍‮(FlooderTaskSettings.\u202C⁯‪‎‬⁯⁪​‫‏⁪‮⁮‬‎‏⁯⁭‍‭‮‌‬⁯⁫⁭‏‌⁯⁫‎‬⁫‭⁯‭‍⁬⁬‏‮(dataGridViewRow), 2)) ?? (object) ""),
                Contains = FlooderTaskSettings.\u206F‭⁭⁪‭⁫⁭‎⁯‏​⁪‮​‏⁮‍‏‎‫‌‌⁭⁮‍⁪‏‬⁪‏‬⁫⁮⁭‌⁭⁫‮‪‍‮(FlooderTaskSettings.\u200C⁬‏‭⁯⁭​‍‎‏⁪⁬‌⁮⁫⁯‮‪⁫⁭‬⁫‫‌‪‬‬⁪‭‎‍‏‪‍⁮⁭⁪⁬‮⁭‮(FlooderTaskSettings.\u206D‎‏⁫⁮‎‏‏‍⁪⁫‫‮⁪⁮‌‌‭⁪⁯⁬‎⁯‪⁮​⁫‪‍‫​⁬⁬‮⁭⁪‮⁭⁭‍‮(FlooderTaskSettings.\u202C⁯‪‎‬⁯⁪​‫‏⁪‮⁮‬‎‏⁯⁭‍‭‮‌‬⁯⁫⁭‏‌⁯⁫‎‬⁫‭⁯‭‍⁬⁬‏‮(dataGridViewRow), 3)))
              });
              num3 = 1484131545;
              continue;
            case 3:
              goto label_10;
            default:
              goto label_14;
          }
        }
label_21:
        return;
label_14:;
      }
      finally
      {
        IDisposable disposable = enumerator as IDisposable;
label_12:
        int num5 = 2069860507;
        while (true)
        {
          uint num6;
          switch ((num6 = (uint) (num5 ^ 1352093062)) % 4U)
          {
            case 0:
              FlooderTaskSettings.\u206F‮‫‬⁪⁮‬⁯⁬‎⁯‍​⁯‏⁬‍⁯⁭‌⁫‌⁭‎⁯‭​‎‎‬‫⁪‌‫⁬‎‭‎⁬⁬‮(disposable);
              num5 = (int) num6 * 215051613 ^ 1666416724;
              continue;
            case 1:
              int num7 = disposable == null ? 1601936877 : (num7 = 626388175);
              num5 = num7 ^ (int) num6 * -1676439111;
              continue;
            case 3:
              goto label_12;
            default:
              goto label_17;
          }
        }
label_17:;
      }
    }
    finally
    {
      if (flag)
      {
label_19:
        int num8 = 1646559254;
        while (true)
        {
          uint num9;
          switch ((num9 = (uint) (num8 ^ 1352093062)) % 3U)
          {
            case 0:
              goto label_19;
            case 2:
              FlooderTaskSettings.\u202A‭‬⁬​‮​‭⁭‌⁪‏‫⁭‏⁯‬⁭⁬‌​⁯⁯‫‭‫‮‎⁫‮‍‫‍‌⁭‪​‭‏‪‮((object) targets);
              num8 = (int) num9 * 1657982157 ^ -1729315283;
              continue;
            default:
              goto label_23;
          }
        }
      }
label_23:;
    }
  }

  private void UploadDocuments(Account acc)
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(acc, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1626172204U));
label_1:
    int num1 = 1789943069;
    string[] strArray1;
    int index;
    string str1;
    VkApi vkApi;
    System.Net.WebClient webClient;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1573096058)) % 9U)
      {
        case 0:
          index = 0;
          num1 = (int) num2 * 1012856391 ^ -264093532;
          continue;
        case 1:
          string[] strArray2 = FlooderTaskSettings.\u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(366793608U));
          webClient = FlooderTaskSettings.\u202D‬‭‏‍⁬⁮⁯‪⁫⁪‫‌⁬‪‫‎‫​‪​⁮​‪‎⁯⁪⁭‬‬‌⁯‬‮‌⁫⁪‏⁪‎‮();
          strArray1 = strArray2;
          num1 = (int) num2 * 643332969 ^ 1061993197;
          continue;
        case 2:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(acc, FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1419984987U), (object) str1));
          num1 = (int) num2 * 796398864 ^ -2144434159;
          continue;
        case 3:
          int num3;
          num1 = num3 = index >= strArray1.Length ? 46299034 : (num3 = 336404180);
          continue;
        case 4:
          str1 = strArray1[index];
          UploadServerInfo uploadServerInfo = FlooderTaskSettings.\u206A‏‎‏‮⁬⁫‌⁮⁭⁬⁭‮⁫‬⁪‬⁫‏‏‫⁫‏⁮‏‌‭‌‍‏⁮⁯‌‏‌‎‫⁯‪‮(FlooderTaskSettings.\u206E​‬⁫‌⁪‏‫⁫​‎‍⁫‫⁮⁬‪⁬‫⁯‌‍‮‫‏⁯‫⁮‮‪‮‬‪‪‎⁮‏⁬⁫‌‮(vkApi), new long?());
          string str2 = FlooderTaskSettings.\u206F‬⁬‌⁫‎‭‬⁯⁬⁯‭⁯‬‬‏​‫⁭⁯​​‮‫⁮‎‍⁯‍​⁪⁯‏⁮⁫‮‍⁭‮‌‮(FlooderTaskSettings.\u202A‫⁫⁯‭‭‌‎‎⁫‍‬‬‭‏⁬‮⁪‏⁮‫‎‏​⁭‏⁭⁯​‏‮⁬‫‪‎‬‌‏⁪‍‮(), FlooderTaskSettings.\u202A​‬⁯⁮⁮⁮‍⁪⁫‪⁬‍⁬⁭‌⁭⁯⁫‮​‬⁯‎‮​⁪⁪⁬⁬‎‫⁬‏‫‎‌‪‮⁬‮(webClient, FlooderTaskSettings.\u200B​​‬‪‪‫⁮‍‬‎⁬⁯​‭⁬‎⁯⁯‫​​‌​‍​‭⁫‫​‪⁫⁭‬‮‭‪​‎‫‮(uploadServerInfo), str1));
          this._documents.AddRange((IEnumerable<MediaAttachment>) FlooderTaskSettings.\u206B‬⁪‏‪⁭⁫‏‮‫⁬​‬⁯⁮‭‭‬​⁭⁮⁬‏‏‫‬⁪‫⁮‪⁫⁯⁪⁫​‬⁭‫‎⁫‮(FlooderTaskSettings.\u206E​‬⁫‌⁪‏‫⁫​‎‍⁫‫⁮⁬‪⁬‫⁯‌‍‮‫‏⁯‫⁮‮‪‮‬‪‪‎⁮‏⁬⁫‌‮(vkApi), str2, \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3604121261U), (string) null, new long?(), (string) null));
          num1 = 581667550;
          continue;
        case 5:
          vkApi = acc.VkApi;
          num1 = (int) num2 * 1031940517 ^ 388490177;
          continue;
        case 6:
          goto label_3;
        case 7:
          goto label_1;
        case 8:
          ++index;
          num1 = (int) num2 * -1156318821 ^ 1963982980;
          continue;
        default:
          goto label_11;
      }
    }
label_3:
    return;
label_11:;
  }

  private void UploadImages(Account acc)
  {
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(acc, \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(953789305U));
    VkApi vkApi = acc.VkApi;
label_1:
    int num1 = 584071993;
    int index;
    string str1;
    System.Net.WebClient webClient;
    string[] strArray1;
    string str2;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 880633388)) % 10U)
      {
        case 0:
          this._images.AddRange((IEnumerable<MediaAttachment>) FlooderTaskSettings.\u200F‍⁯‮‬‫​‬‏‌⁫⁯⁬⁪‬‌‮⁭‍​‏‫‏‎⁮⁯⁯‫‌‫⁫‪​⁬‮​⁫‮‮⁬‮(FlooderTaskSettings.\u206D‍‭‍‌‎​⁫​‭⁭‍‌​⁯‫‭‫⁯‎‬⁯⁪‏⁬‫⁮‎‏⁪​‍‬​⁫⁭‪⁫‬‍‮(vkApi), str2, new ulong?(), new ulong?(), (string) null));
          num1 = (int) num2 * 1778206821 ^ 397256685;
          continue;
        case 1:
          index = 0;
          num1 = (int) num2 * 1935822671 ^ 727744541;
          continue;
        case 2:
          goto label_3;
        case 3:
          int num3;
          num1 = num3 = index >= strArray1.Length ? 1280889652 : (num3 = 129138462);
          continue;
        case 4:
          num1 = (int) num2 * 1534040048 ^ -854634199;
          continue;
        case 5:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(acc, FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(67648066U), (object) str1));
          num1 = (int) num2 * -1520528117 ^ 1483021549;
          continue;
        case 6:
          ++index;
          num1 = (int) num2 * -592272685 ^ 199333963;
          continue;
        case 7:
          goto label_1;
        case 8:
          str1 = strArray1[index];
          UploadServerInfo uploadServerInfo = FlooderTaskSettings.\u200B⁮⁭​‮‭‮⁫⁫‬⁭⁯‪​⁭‪‬⁫‮‮‭‬⁭⁬‬‎⁭⁬‎‪‮‬⁬‪‌‍⁯‏⁬‫‮(FlooderTaskSettings.\u206D‍‭‍‌‎​⁫​‭⁭‍‌​⁯‫‭‫⁯‎‬⁯⁪‏⁬‫⁮‎‏⁪​‍‬​⁫⁭‪⁫‬‍‮(vkApi), new long?());
          str2 = FlooderTaskSettings.\u206F‬⁬‌⁫‎‭‬⁯⁬⁯‭⁯‬‬‏​‫⁭⁯​​‮‫⁮‎‍⁯‍​⁪⁯‏⁮⁫‮‍⁭‮‌‮(FlooderTaskSettings.\u202A‫⁫⁯‭‭‌‎‎⁫‍‬‬‭‏⁬‮⁪‏⁮‫‎‏​⁭‏⁭⁯​‏‮⁬‫‪‎‬‌‏⁪‍‮(), FlooderTaskSettings.\u202A​‬⁯⁮⁮⁮‍⁪⁫‪⁬‍⁬⁭‌⁭⁯⁫‮​‬⁯‎‮​⁪⁪⁬⁬‎‫⁬‏‫‎‌‪‮⁬‮(webClient, FlooderTaskSettings.\u200B​​‬‪‪‫⁮‍‬‎⁬⁯​‭⁬‎⁯⁯‫​​‌​‍​‭⁫‫​‪⁫⁭‬‮‭‪​‎‫‮(uploadServerInfo), str1));
          num1 = 125310328;
          continue;
        case 9:
          string[] strArray2 = FlooderTaskSettings.\u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮(\u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(2220594441U));
          webClient = FlooderTaskSettings.\u202D‬‭‏‍⁬⁮⁯‪⁫⁪‫‌⁬‪‫‎‫​‪​⁮​‪‎⁯⁪⁭‬‬‌⁯‬‮‌⁫⁪‏⁪‎‮();
          strArray1 = strArray2;
          num1 = (int) num2 * 1060241855 ^ -1749455100;
          continue;
        default:
          goto label_12;
      }
    }
label_3:
    return;
label_12:;
  }

  private static FlooderTaskSettings.CounterContainer CounterContainerFromTarget(
    Account acc,
    FlooderTarget ft)
  {
    \u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮ key = \u200D‪‬⁭‮‭‬⁬‌‬⁬‭‬⁭‌⁪⁪‌​⁪‫⁪⁫​‬​‍⁯‬‮‪‫⁭‪⁪​‌⁫‭‎‮.\u206B⁭⁫⁯⁫‭‏⁮‎‬‮‭‏⁬‬‪‮‍‍⁪⁫‭‌‭‭‮‌‎⁯‫‏⁯⁬‪⁪‏​⁪‭‍‮(acc, ft.Link);
    if (!FlooderTaskSettings._targetRelatedCounters.Keys.Contains<\u206A‎⁯‍‪‎​⁫‌⁯‪‍‏⁬⁯⁪‏‏⁯‏‪⁯‫⁮⁫⁬‫‎‎⁮‌⁯⁭‪‏​‍⁭‮⁬‮>(key))
    {
label_1:
      int num1 = -1083424059;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -1868231810)) % 3U)
        {
          case 0:
            goto label_1;
          case 1:
            FlooderTaskSettings._targetRelatedCounters[key] = new FlooderTaskSettings.CounterContainer();
            num1 = (int) num2 * -1154903932 ^ -1740850382;
            continue;
          default:
            goto label_4;
        }
      }
    }
label_4:
    return FlooderTaskSettings._targetRelatedCounters[key];
  }

  public IReadOnlyCollection<MediaAttachment> VoiceMessage(Account acc, string message)
  {
    IReadOnlyCollection<MediaAttachment> mediaAttachments;
    try
    {
      VoiceTaskSettings voiceTaskSettings = acc.VoiceTaskSettings;
label_1:
      int num1 = 1621324620;
      VkApi vkApi;
      UploadServerInfo uploadServerInfo;
      double num2;
      System.Net.WebClient webClient;
      string address;
      string str1;
      string str2;
      string str3;
      while (true)
      {
        uint num3;
        switch ((num3 = (uint) (num1 ^ 1101431774)) % 12U)
        {
          case 0:
            goto label_1;
          case 1:
            str2 = num2.ToString().Replace(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2153899039U), \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1044564416U));
            num1 = (int) num3 * 936696440 ^ -1557879650;
            continue;
          case 3:
            webClient.DownloadFile(address, str1);
            num1 = (int) num3 * 927819438 ^ 992221759;
            continue;
          case 4:
            num2 = (double) voiceTaskSettings.Speed * 0.1;
            num1 = (int) num3 * -1154998157 ^ 456190931;
            continue;
          case 5:
            VkParameters parameters1 = new VkParameters()
            {
              {
                \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3212809998U),
                str3
              }
            };
            // ISSUE: reference to a compiler-generated method
            ReadOnlyCollection<Document> onlyCollectionOf = vkApi.Call(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2163208437U), parameters1).ToReadOnlyCollectionOf<Document>((Func<VkResponse, Document>) (r => FlooderTaskSettings.\u003C\u003Ec.\u206E‫⁪​‪⁯‭‫⁯‍‬⁬‬⁭‬‏‮⁯⁪⁯⁬⁯‏‫⁪⁭‫‏‮⁯​‎⁪​‪‭⁭⁪⁮‫‮(r)));
            System.IO.File.Delete(str1);
            mediaAttachments = (IReadOnlyCollection<MediaAttachment>) onlyCollectionOf;
            num1 = 604848728;
            continue;
          case 6:
            webClient = FlooderTaskSettings.\u202D‬‭‏‍⁬⁮⁯‪⁫⁪‫‌⁬‪‫‎‫​‪​⁮​‪‎⁯⁪⁭‬‬‌⁯‬‮‌⁫⁪‏⁪‎‮();
            num1 = (int) num3 * 2040375791 ^ 1664098924;
            continue;
          case 7:
            VkParameters parameters2 = new VkParameters()
            {
              {
                \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(3935137868U),
                \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1946004862U)
              }
            };
            uploadServerInfo = (UploadServerInfo) vkApi.Call(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(1190807773U), parameters2);
            num1 = (int) num3 * -463941700 ^ -831462941;
            continue;
          case 8:
            str1 = string.Format(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(2767061942U), (object) FlooderTaskSettings._rnd.Next());
            num1 = (int) num3 * 295127741 ^ 2040520841;
            continue;
          case 9:
            str3 = \u206B‬‭⁮​‎‏⁪⁯​‌‎‎⁬‍‌⁪⁬⁪⁭‌⁪‬‮‮⁮‎‪⁮‌‮‏⁭‫⁮‌‎⁯‍‮.\u200D⁭⁫⁮‭‬⁬‍‍​‭‌‭‌‪⁪‌‪⁭⁭⁬⁮​‏‪‮‍‏‮‏⁫‪⁭‫⁯‏⁪‎⁮‫‮(Encoding.UTF8.GetString(webClient.UploadFile(uploadServerInfo.UploadUrl, str1)), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1743191569U), \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(906975708U));
            num1 = (int) num3 * -1833691222 ^ -512166643;
            continue;
          case 10:
            vkApi = acc.VkApi;
            num1 = (int) num3 * -1710223235 ^ 453603438;
            continue;
          case 11:
            message = WebUtility.UrlEncode(message);
            address = string.Format(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(1001339959U), (object) message, (object) voiceTaskSettings.Voice, (object) voiceTaskSettings.Emotion, (object) str2, (object) voiceTaskSettings.Yandexapi);
            num1 = (int) num3 * 750190844 ^ -1227142855;
            continue;
          default:
            goto label_14;
        }
      }
    }
    catch (Exception ex)
    {
      \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(acc, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(4042133908U) + ex.Message);
      mediaAttachments = (IReadOnlyCollection<MediaAttachment>) null;
    }
label_14:
    return mediaAttachments;
  }

  public IReadOnlyCollection<MediaAttachment> RandomImage()
  {
    if (this._images.Count == 0)
    {
label_1:
      int num1 = -213533718;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -859670216)) % 4U)
        {
          case 1:
            goto label_4;
          case 2:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3118698401U));
            num1 = (int) num2 * 1355321513 ^ -594904445;
            continue;
          case 3:
            goto label_1;
          default:
            goto label_5;
        }
      }
label_4:
      return (IReadOnlyCollection<MediaAttachment>) null;
    }
label_5:
    return (IReadOnlyCollection<MediaAttachment>) new List<MediaAttachment>()
    {
      this._images[FlooderTaskSettings.\u202D‏‫‫‏⁮‎​‬‏‎⁯⁭‫⁭​⁫⁭‭​‌‎‫‫⁪‮‮‌‎‫‭‪‏⁪⁫‎‏⁭⁮‍‮(FlooderTaskSettings._rnd, 0, this._images.Count)]
    }.ToReadOnlyCollection<MediaAttachment>();
  }

  public IReadOnlyCollection<MediaAttachment> RandomSticker(Account acc, FlooderTarget ft)
  {
    if (this._stickers.Count != 0)
      goto label_4;
label_1:
    int num1 = 1866665806;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 1047255391)) % 6U)
      {
        case 0:
          FlooderTaskSettings.CounterContainer counterContainer = FlooderTaskSettings.CounterContainerFromTarget(acc, ft);
          counterContainer.StIndex = (counterContainer.StIndex + 1) % this._stickers.Count;
          num1 = (int) num2 * 427949100 ^ 125997928;
          continue;
        case 1:
          goto label_6;
        case 2:
          goto label_4;
        case 3:
          goto label_3;
        case 5:
          goto label_1;
        default:
          goto label_7;
      }
    }
label_3:
    List<MediaAttachment> source = new List<MediaAttachment>()
    {
      this._stickers[FlooderTaskSettings.CounterContainerFromTarget(acc, ft).StIndex]
    };
    goto label_14;
label_6:
    \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3438200282U));
    return (IReadOnlyCollection<MediaAttachment>) null;
label_7:
    IReadOnlyCollection<MediaAttachment> mediaAttachments;
    try
    {
      List<MediaAttachment> mediaAttachmentList = new List<MediaAttachment>();
      Sticker sticker = FlooderTaskSettings.\u202D‌‭⁮‍⁯⁫⁫‮‫‎‪⁭‫‌‍⁯‍‍​‍⁪‏⁭‪⁪‏‫‍‫‍⁫‫‍‫‍⁫⁪⁬‍‮();
      FlooderTaskSettings.\u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮((MediaAttachment) sticker, new long?(long.Parse(FlooderTaskSettings.\u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮((Capture) FlooderTaskSettings.\u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(FlooderTaskSettings.\u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮(FlooderTaskSettings.\u202B‫​‎‭‌⁪‍‎⁯⁮​⁬⁪⁫‭​‭‭‭⁮⁪⁪‍⁭​⁫‫‭‎⁯‌‪​‍⁫⁬⁭‍⁪‮(FlooderTaskSettings.\u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮(\u003CModule\u003E.\u200B​‪‫⁮⁪‪‬‎‌‌⁭‏‍⁯⁯⁮⁯‏⁮⁯‬⁬⁭⁮⁭‌‍‌‬⁭‫⁭⁬‪‬⁮‪⁮⁭‮<string>(2426789459U)), this.StickerId)), 1)))));
      mediaAttachmentList.Add((MediaAttachment) sticker);
      source = mediaAttachmentList;
      goto label_14;
    }
    catch
    {
label_10:
      int num3 = 414162344;
      while (true)
      {
        uint num4;
        switch ((num4 = (uint) (num3 ^ 1047255391)) % 4U)
        {
          case 0:
            goto label_10;
          case 2:
            mediaAttachments = (IReadOnlyCollection<MediaAttachment>) null;
            num3 = (int) num4 * 717523854 ^ 1697024346;
            continue;
          case 3:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(FlooderTaskSettings.\u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(2499501394U), (object) this.StickerId));
            num3 = (int) num4 * -1619351574 ^ -798426409;
            continue;
          default:
            goto label_15;
        }
      }
    }
label_15:
    return mediaAttachments;
label_14:
    return (IReadOnlyCollection<MediaAttachment>) source.ToReadOnlyCollection<MediaAttachment>();
label_4:
    num1 = !FlooderTaskSettings.\u206F‏‏‎‬‪⁪‭‮‌‎‮⁪⁮⁪‫⁭⁬‍‏‎‍‭‎​⁯​‪‪⁮⁬‭‪⁪⁮⁭‮‏‬‍‮(this.StickerId, \u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(1469664138U)) ? 869248813 : (num1 = 1399695853);
    goto label_2;
  }

  public IReadOnlyCollection<MediaAttachment> RandomVideo()
  {
    if (FlooderTaskSettings._videos.Count == 0)
    {
label_1:
      uint num;
      switch ((num = (uint) (1241274752 ^ 2015561870)) % 3U)
      {
        case 0:
          goto label_1;
        case 1:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3661913062U));
          return (IReadOnlyCollection<MediaAttachment>) null;
      }
    }
    return (IReadOnlyCollection<MediaAttachment>) new List<MediaAttachment>()
    {
      FlooderTaskSettings._videos[FlooderTaskSettings.\u202D‏‫‫‏⁮‎​‬‏‎⁯⁭‫⁭​⁫⁭‭​‌‎‫‫⁪‮‮‌‎‫‭‪‏⁪⁫‎‏⁭⁮‍‮(FlooderTaskSettings._rnd, 0, FlooderTaskSettings._videos.Count)]
    }.ToReadOnlyCollection<MediaAttachment>();
  }

  public IReadOnlyCollection<MediaAttachment> RandomDocument()
  {
    if (this._documents.Count == 0)
    {
label_1:
      uint num;
      switch ((num = (uint) (-1775862749 ^ -1688755465)) % 3U)
      {
        case 0:
          goto label_1;
        case 2:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(2504458093U));
          return (IReadOnlyCollection<MediaAttachment>) null;
      }
    }
    return (IReadOnlyCollection<MediaAttachment>) new List<MediaAttachment>()
    {
      this._documents[FlooderTaskSettings.\u202D‏‫‫‏⁮‎​‬‏‎⁯⁭‫⁭​⁫⁭‭​‌‎‫‫⁪‮‮‌‎‫‭‪‏⁪⁫‎‏⁭⁮‍‮(FlooderTaskSettings._rnd, 0, this._documents.Count)]
    }.ToReadOnlyCollection<MediaAttachment>();
  }

  public IReadOnlyCollection<MediaAttachment> RandomAudio()
  {
    if (FlooderTaskSettings._audios.Count == 0)
    {
label_1:
      int num1 = 1670345599;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ 1614843908)) % 4U)
        {
          case 0:
            goto label_1;
          case 1:
            goto label_4;
          case 3:
            \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(340050919U));
            num1 = (int) num2 * 1505076916 ^ 748669289;
            continue;
          default:
            goto label_5;
        }
      }
label_4:
      return (IReadOnlyCollection<MediaAttachment>) null;
    }
label_5:
    return (IReadOnlyCollection<MediaAttachment>) new List<MediaAttachment>()
    {
      FlooderTaskSettings._audios[FlooderTaskSettings.\u202D‏‫‫‏⁮‎​‬‏‎⁯⁭‫⁭​⁫⁭‭​‌‎‫‫⁪‮‮‌‎‫‭‪‏⁪⁫‎‏⁭⁮‍‮(FlooderTaskSettings._rnd, 0, FlooderTaskSettings._audios.Count)]
    }.ToReadOnlyCollection<MediaAttachment>();
  }

  public string GetPhrase(Account acc, FlooderTarget ft)
  {
    if (this._phrases.Count != 0)
      goto label_3;
label_1:
    int num1 = 590579472;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 382509439)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          goto label_4;
        case 2:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u206A‭⁬⁯⁪‏⁪‭‌‫‪⁮⁬⁭‬⁬⁯‍⁬⁭⁫​‫‪‬‍‌‌⁭‌​‪​⁪⁮⁮‪⁫‎⁮‮<string>(3181379421U));
          num1 = (int) num2 * 329980852 ^ -193357396;
          continue;
        case 3:
          goto label_1;
        default:
          goto label_6;
      }
    }
label_4:
    return (string) null;
label_6:
    FlooderTaskSettings.CounterContainer counterContainer;
    return this._phrases[counterContainer.PhIndex];
label_3:
    counterContainer = FlooderTaskSettings.CounterContainerFromTarget(acc, ft);
    counterContainer.PhIndex = (counterContainer.PhIndex + 1) % this._phrases.Count;
    num1 = 906388025;
    goto label_2;
  }

  public string GetPhraseWithDots(Account acc, FlooderTarget ft)
  {
    if (this._phrasesWithDots.Count != 0)
      goto label_3;
label_1:
    int num1 = 1380953217;
label_2:
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 907283956)) % 5U)
      {
        case 0:
          goto label_3;
        case 1:
          goto label_4;
        case 3:
          goto label_1;
        case 4:
          \u0036\u0029V\u002A\u0029\u0024yAWOJ\u0027WQshZNr9\u0027\u0022Ul\u002C.\u200F⁪⁮‎⁬⁯​⁯‬‮⁬⁮‌⁮⁭‭‪‏​‏‎‭⁪‬‍​‎⁯⁭‍‎⁮​⁭⁯‭⁮‪⁯‫‮(\u003CModule\u003E.\u200D‭​⁪‏⁬‮⁪‪‭‮⁪⁯‫‏‎⁭⁪‫‮​⁫​‬‌‏‫‮⁭⁯⁮⁪⁫‪‭⁪⁬‏‮‍‮<string>(3248089859U));
          num1 = (int) num2 * -1806114223 ^ -743237438;
          continue;
        default:
          goto label_6;
      }
    }
label_4:
    return (string) null;
label_6:
    FlooderTaskSettings.CounterContainer counterContainer;
    counterContainer.PhDotsIndex = (counterContainer.PhDotsIndex + 1) % this._phrasesWithDots.Count;
    return this._phrasesWithDots[counterContainer.PhDotsIndex++];
label_3:
    counterContainer = FlooderTaskSettings.CounterContainerFromTarget(acc, ft);
    num1 = 56805447;
    goto label_2;
  }

  static Random \u206B‬⁯​⁮​⁪⁯​‎‎‪‮‫⁬‏‫‬‫‪‫⁭‏‪⁪⁬‍⁮‌⁯‌‎‌‭‬‏‌⁬‏‬‮() => new Random();

  static Regex \u200D‏‫‎‬‏⁮⁭‎‭​⁫⁬‍​⁬‭‎‬‬​⁫‫‬‫‍⁬⁯​‮‌‮‌​⁬‮⁯‌‏‎‮([In] string obj0) => new Regex(obj0);

  static Encoding \u200F⁪‍⁭⁯‎⁬‫‮‏‍‮‭⁭​⁬‍‌⁫⁪⁮⁮⁬‎​​‮‭‏⁪‌⁬‏‏⁯⁫‭‍⁮‭‮([In] string obj0)
  {
    return Encoding.GetEncoding(obj0);
  }

  static string[] \u200D‪‏⁪⁭‭⁪‫⁭‮‏‏⁭⁮‬‮​‏‌​⁮‬‍⁬​⁪⁯⁪⁮⁫‮⁬‬‮​‫‭⁪‏‎‮([In] string obj0, [In] Encoding obj1)
  {
    return System.IO.File.ReadAllLines(obj0, obj1);
  }

  static Match \u202B⁪‏‍‎⁮⁫​‍‮‫‮‮‫‮‍⁭⁪‌⁫⁮‬‪⁭‫‪‪‏‭⁬⁮‌‪‭‍​‎⁮⁪‎‮([In] Regex obj0, [In] string obj1)
  {
    return obj0.Match(obj1);
  }

  static bool \u206E‪‍​‫⁬‪⁪‌‪‏‌‫‍⁬‪​⁫‌⁯⁫​⁯⁮⁯‎‍⁪‭‏⁬‍‍‌⁪‏⁭‫⁬‪‮([In] System.Text.RegularExpressions.Group obj0)
  {
    return obj0.Success;
  }

  static Video \u202A‪⁯⁭‌⁪⁮‭⁪‬⁮⁭⁬‮‪⁫‍‬‏‏‪⁮⁭⁬‬​​‍⁫‪‌⁯‌⁬⁬⁪‭‪‪⁪‮() => new Video();

  static GroupCollection \u200D⁬‬‮⁮‏‮⁯‫⁮⁮⁪‏⁬⁪‬‭‬⁯⁯‬‭⁭⁫‫⁫‮⁯‍‎​‫⁭‌‎‎‏‌‫‭‮([In] Match obj0)
  {
    return obj0.Groups;
  }

  static System.Text.RegularExpressions.Group \u200E‫‏⁪‎⁬‏‬‪⁫‍⁮⁫​‬‬‏​⁪‪⁭⁭‬‎‍‫⁬‪‭⁪‫‭‬⁫‏⁪‭⁬‪‮‮(
    [In] GroupCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static string \u206E‎‏​‫⁮‏‬‮⁭‫‬‏‮⁯‬​⁭‎⁪⁪‬‭‬‪⁪⁭⁮‬⁫‍⁯⁮⁭⁬‎‫⁬‫⁫‮([In] Capture obj0) => obj0.Value;

  static void \u202B‪‭‎‪⁮⁪​​‬‫‮⁮⁮‮⁯⁭⁮‬⁫⁫‍⁪‍‎‎‌⁪‬⁫⁪‏‫⁫‪‍​⁭‭⁬‮([In] MediaAttachment obj0, [In] long? obj1)
  {
    obj0.OwnerId = obj1;
  }

  static void \u200E‪‪⁪‫⁭⁯‏⁬‮‎‌‬‫⁭‎⁬‫‫‫‮‏⁯⁭‮‭‫‮‬‫​⁮‍‍⁪‎​‎‌⁮‮([In] MediaAttachment obj0, [In] long? obj1)
  {
    obj0.Id = obj1;
  }

  static string \u202E⁭‎⁭⁬‫‫⁫⁫‮⁬‬​⁪‮⁬⁪​‪⁬‭‍⁯‏‏‍‌⁫⁪‎‏⁭​⁪⁯‌⁪⁪⁫‮‮([In] string obj0, [In] object obj1)
  {
    return string.Format(obj0, obj1);
  }

  static Audio \u202E‌‎‎‎‭⁪⁫⁮⁭⁪‎⁮‮‎‭‍‎⁪⁬‮⁬⁫⁫‬⁬‮‌‏‏⁫‮‎⁫‏⁯‫‬⁪‮‮() => new Audio();

  static bool \u206B‪⁮⁫⁫‫‭‭⁪‪⁭‎‭⁬‪⁪⁫⁫‬‭⁪⁮‮‭‌‭​‭⁪⁬‬⁭⁮⁮⁮⁯⁭​​⁪‮([In] string obj0)
  {
    return string.IsNullOrEmpty(obj0);
  }

  static Sticker \u202D‌‭⁮‍⁯⁫⁫‮‫‎‪⁭‫‌‍⁯‍‍​‍⁪‏⁭‪⁪‏‫‍‫‍⁫‫‍‫‍⁫⁪⁬‍‮() => new Sticker();

  static Photo \u206A‎‭⁪‭⁯⁪​⁮‏⁪⁮⁭⁪⁮⁫⁪⁬‫⁮‌⁭‪‬‬‫‪⁪⁫⁫⁫‭‭‫‪⁫⁯‌⁭⁬‮() => new Photo();

  static void \u202C‮‎⁮‌‎​‍​⁪‍‭​‏‭‫‫⁮⁯⁭‮‪⁯⁬⁫‎‏⁫‭​⁪‮⁬⁬‪⁬‏‪‏‪‮([In] object obj0, [In] ref bool obj1)
  {
    Monitor.Enter(obj0, ref obj1);
  }

  static void \u202A‭‬⁬​‮​‭⁭‌⁪‏‫⁭‏⁯‬⁭⁬‌​⁯⁯‫‭‫‮‎⁫‮‍‫‍‌⁭‪​‭‏‪‮([In] object obj0)
  {
    Monitor.Exit(obj0);
  }

  static string[] \u200C⁮‏‮⁭‏⁮⁭‌​‮⁫​⁫‪⁯‎‍⁫‪‍‎‬‎⁯‎⁯‭‪⁮⁪⁮⁪⁫‫‭‍‮‭⁫‮([In] string obj0)
  {
    return Directory.GetFiles(obj0);
  }

  static DataGridViewRowCollection \u202B‬‏‪‍‏​⁪⁪‏‏⁬‎‪‌⁫‭⁯⁫‎⁫⁬⁮​‏‪‭​​‭⁮‫‍⁫​‭‭‌‎⁬‮([In] DataGridView obj0)
  {
    return obj0.Rows;
  }

  static IEnumerator \u200E⁪⁪‫⁪‎⁭‌​⁮⁫‮⁮‏​​‮​‏‍⁬‏⁯⁪‪⁫‮​‫‏⁬⁬‏‌⁫‎⁮‎⁯⁯‮([In] IEnumerable obj0)
  {
    return obj0.GetEnumerator();
  }

  static object \u202B‍‬‬‫‬⁪‎⁮‍‫‎‏‍‍⁮‭‭‬‪‫‮‮‫‭‫‌‎‏‭‬‏⁫⁯‪‎⁮⁭⁪⁪‮([In] IEnumerator obj0)
  {
    return obj0.Current;
  }

  static DataGridViewCellCollection \u202C⁯‪‎‬⁯⁪​‫‏⁪‮⁮‬‎‏⁯⁭‍‭‮‌‬⁯⁫⁭‏‌⁯⁫‎‬⁫‭⁯‭‍⁬⁬‏‮(
    [In] DataGridViewRow obj0)
  {
    return obj0.Cells;
  }

  static DataGridViewCell \u206D‎‏⁫⁮‎‏‏‍⁪⁫‫‮⁪⁮‌‌‭⁪⁯⁬‎⁯‪⁮​⁫‪‍‫​⁬⁬‮⁭⁪‮⁭⁭‍‮(
    [In] DataGridViewCellCollection obj0,
    [In] int obj1)
  {
    return obj0[obj1];
  }

  static object \u200C⁬‏‭⁯⁭​‍‎‏⁪⁬‌⁮⁫⁯‮‪⁫⁭‬⁫‫‌‪‬‬⁪‭‎‍‏‪‍⁮⁭⁪⁬‮⁭‮([In] DataGridViewCell obj0)
  {
    return obj0.Value;
  }

  static string \u206F‭⁭⁪‭⁫⁭‎⁯‏​⁪‮​‏⁮‍‏‎‫‌‌⁭⁮‍⁪‏‬⁪‏‬⁫⁮⁭‌⁭⁫‮‪‍‮([In] object obj0) => obj0.ToString();

  static bool \u206B‭⁬‬‫​‫‌‭‭⁪‪⁪⁬‭⁫​⁭⁬⁮⁭‮⁭⁮​⁯⁪‪⁪‎⁯‍‬‎‭​⁮‌⁭‬‮([In] IEnumerator obj0)
  {
    return obj0.MoveNext();
  }

  static void \u206F‮‫‬⁪⁮‬⁯⁬‎⁯‍​⁯‏⁬‍⁯⁭‌⁫‌⁭‎⁯‭​‎‎‬‫⁪‌‫⁬‎‭‎⁬⁬‮([In] IDisposable obj0)
  {
    obj0.Dispose();
  }

  static System.Net.WebClient \u202D‬‭‏‍⁬⁮⁯‪⁫⁪‫‌⁬‪‫‎‫​‪​⁮​‪‎⁯⁪⁭‬‬‌⁯‬‮‌⁫⁪‏⁪‎‮() => new System.Net.WebClient();

  static DocsCategory \u206E​‬⁫‌⁪‏‫⁫​‎‍⁫‫⁮⁬‪⁬‫⁯‌‍‮‫‏⁯‫⁮‮‪‮‬‪‪‎⁮‏⁬⁫‌‮([In] VkApi obj0) => obj0.Docs;

  static UploadServerInfo \u206A‏‎‏‮⁬⁫‌⁮⁭⁬⁭‮⁫‬⁪‬⁫‏‏‫⁫‏⁮‏‌‭‌‍‏⁮⁯‌‏‌‎‫⁯‪‮(
    [In] DocsCategory obj0,
    [In] long? obj1)
  {
    return obj0.GetUploadServer(obj1);
  }

  static Encoding \u202A‫⁫⁯‭‭‌‎‎⁫‍‬‬‭‏⁬‮⁪‏⁮‫‎‏​⁭‏⁭⁯​‏‮⁬‫‪‎‬‌‏⁪‍‮() => Encoding.ASCII;

  static string \u200B​​‬‪‪‫⁮‍‬‎⁬⁯​‭⁬‎⁯⁯‫​​‌​‍​‭⁫‫​‪⁫⁭‬‮‭‪​‎‫‮([In] UploadServerInfo obj0)
  {
    return obj0.UploadUrl;
  }

  static byte[] \u202A​‬⁯⁮⁮⁮‍⁪⁫‪⁬‍⁬⁭‌⁭⁯⁫‮​‬⁯‎‮​⁪⁪⁬⁬‎‫⁬‏‫‎‌‪‮⁬‮(
    [In] System.Net.WebClient obj0,
    [In] string obj1,
    [In] string obj2)
  {
    return obj0.UploadFile(obj1, obj2);
  }

  static string \u206F‬⁬‌⁫‎‭‬⁯⁬⁯‭⁯‬‬‏​‫⁭⁯​​‮‫⁮‎‍⁯‍​⁪⁯‏⁮⁫‮‍⁭‮‌‮([In] Encoding obj0, [In] byte[] obj1)
  {
    return obj0.GetString(obj1);
  }

  static ReadOnlyCollection<Document> \u206B‬⁪‏‪⁭⁫‏‮‫⁬​‬⁯⁮‭‭‬​⁭⁮⁬‏‏‫‬⁪‫⁮‪⁫⁯⁪⁫​‬⁭‫‎⁫‮(
    [In] DocsCategory obj0,
    [In] string obj1,
    [In] string obj2,
    [In] string obj3,
    [In] long? obj4,
    [In] string obj5)
  {
    return obj0.Save(obj1, obj2, obj3, obj4, obj5);
  }

  static PhotoCategory \u206D‍‭‍‌‎​⁫​‭⁭‍‌​⁯‫‭‫⁯‎‬⁯⁪‏⁬‫⁮‎‏⁪​‍‬​⁫⁭‪⁫‬‍‮([In] VkApi obj0)
  {
    return obj0.Photo;
  }

  static UploadServerInfo \u200B⁮⁭​‮‭‮⁫⁫‬⁭⁯‪​⁭‪‬⁫‮‮‭‬⁭⁬‬‎⁭⁬‎‪‮‬⁬‪‌‍⁯‏⁬‫‮(
    [In] PhotoCategory obj0,
    [In] long? obj1)
  {
    return obj0.GetWallUploadServer(obj1);
  }

  static ReadOnlyCollection<Photo> \u200F‍⁯‮‬‫​‬‏‌⁫⁯⁬⁪‬‌‮⁭‍​‏‫‏‎⁮⁯⁯‫‌‫⁫‪​⁬‮​⁫‮‮⁬‮(
    [In] PhotoCategory obj0,
    [In] string obj1,
    [In] ulong? obj2,
    [In] ulong? obj3,
    [In] string obj4)
  {
    return obj0.SaveWallPhoto(obj1, obj2, obj3, obj4);
  }

  static int \u202D‏‫‫‏⁮‎​‬‏‎⁯⁭‫⁭​⁫⁭‭​‌‎‫‫⁪‮‮‌‎‫‭‪‏⁪⁫‎‏⁭⁮‍‮([In] Random obj0, [In] int obj1, [In] int obj2)
  {
    return obj0.Next(obj1, obj2);
  }

  static bool \u206F‏‏‎‬‪⁪‭‮‌‎‮⁪⁮⁪‫⁭⁬‍‏‎‍‭‎​⁯​‪‪⁮⁬‭‪⁪⁮⁭‮‏‬‍‮([In] string obj0, [In] string obj1)
  {
    return obj0 == obj1;
  }

  static Match \u202B‫​‎‭‌⁪‍‎⁯⁮​⁬⁪⁫‭​‭‭‭⁮⁪⁪‍⁭​⁫‫‭‎⁯‌‪​‍⁫⁬⁭‍⁪‮([In] Regex obj0, [In] string obj1)
  {
    return obj0.Match(obj1);
  }

  private class CounterContainer
  {
    public int PhIndex = -1;
    public int PhDotsIndex = -1;
    public int StIndex = -1;
  }
}
