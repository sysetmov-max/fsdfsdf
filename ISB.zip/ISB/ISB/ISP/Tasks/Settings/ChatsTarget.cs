﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.ChatsTarget
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using Newtonsoft.Json;
using System.Runtime.InteropServices;

#nullable disable
namespace ISP.Tasks.Settings;

internal sealed class ChatsTarget
{
  public string Link;
  public string TitleMode;
  public string Title;
  public string AvatarMode;
  [JsonIgnore]
  public string TargetPhoto200;
  public bool FloodWithAvatar;

  public override bool Equals(object obj)
  {
    if (obj != null)
      goto label_4;
label_1:
    int num1 = -1649531730;
label_2:
    ChatsTarget other;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -414952400)) % 6U)
      {
        case 0:
          goto label_6;
        case 1:
          goto label_4;
        case 2:
          goto label_3;
        case 3:
          int num3 = other != null ? -1271754760 : (num3 = -305886191);
          num1 = num3 ^ (int) num2 * 1000987591;
          continue;
        case 4:
          goto label_1;
        default:
          goto label_7;
      }
    }
label_3:
    return false;
label_6:
    return false;
label_7:
    return this.Equals(other);
label_4:
    other = obj as ChatsTarget;
    num1 = -1005760195;
    goto label_2;
  }

  private bool Equals(ChatsTarget other)
  {
    if (ChatsTarget.\u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮(this.Link, other.Link))
    {
label_1:
      int num1 = -2121795710;
      while (true)
      {
        uint num2;
        switch ((num2 = (uint) (num1 ^ -1752173147)) % 7U)
        {
          case 0:
            int num3 = !ChatsTarget.\u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮(this.AvatarMode, other.AvatarMode) ? 1891654871 : (num3 = 1463520581);
            num1 = num3 ^ (int) num2 * 2063491289;
            continue;
          case 1:
            int num4 = ChatsTarget.\u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮(this.TitleMode, other.TitleMode) ? -989425342 : (num4 = -47846990);
            num1 = num4 ^ (int) num2 * 1313321357;
            continue;
          case 2:
            int num5 = !ChatsTarget.\u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮(this.Title, other.Title) ? 1985287705 : (num5 = 361157947);
            num1 = num5 ^ (int) num2 * 1371902060;
            continue;
          case 3:
            goto label_4;
          case 4:
            int num6 = !ChatsTarget.\u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮(this.TargetPhoto200, other.TargetPhoto200) ? 1154355369 : (num6 = 1766754176);
            num1 = num6 ^ (int) num2 * -737775536;
            continue;
          case 6:
            goto label_1;
          default:
            goto label_8;
        }
      }
label_4:
      return this.FloodWithAvatar == other.FloodWithAvatar;
    }
label_8:
    return false;
  }

  public override int GetHashCode()
  {
    return (((((this.Link != null ? ChatsTarget.\u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮((object) this.Link) : 0) * 397 ^ (this.TitleMode != null ? ChatsTarget.\u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮((object) this.TitleMode) : 0)) * 397 ^ (this.Title != null ? ChatsTarget.\u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮((object) this.Title) : 0)) * 397 ^ (this.AvatarMode != null ? ChatsTarget.\u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮((object) this.AvatarMode) : 0)) * 397 ^ (this.TargetPhoto200 != null ? ChatsTarget.\u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮((object) this.TargetPhoto200) : 0)) * 397 ^ this.FloodWithAvatar.GetHashCode();
  }

  static bool \u206E‍​‪⁫‎‍⁮⁮⁫‪⁪‏⁫⁪⁬‪​​‎‎‍‪‌‬‬‭‍‎‬⁭⁫‪⁮‍‏‎​‍‬‮([In] string obj0, [In] string obj1)
  {
    return string.Equals(obj0, obj1);
  }

  static int \u200B‮⁮⁫‏‬​⁭‪‏⁭‮⁫‮​⁯‍⁪‮⁮‫⁫⁬‮‎⁭⁪⁮‭‏‏⁮‫⁫⁭‍‭‎⁪‍‮([In] object obj0) => obj0.GetHashCode();
}
