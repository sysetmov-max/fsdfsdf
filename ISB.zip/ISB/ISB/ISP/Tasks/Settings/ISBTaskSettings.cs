﻿// Decompiled with JetBrains decompiler
// Type: ISP.Tasks.Settings.ISBTaskSettings
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

#nullable disable
namespace ISP.Tasks.Settings;

public abstract class ISBTaskSettings
{
  public bool Enabled;
  public int Delay = 333;

  public abstract void Validate();
}
