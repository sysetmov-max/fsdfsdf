﻿// Decompiled with JetBrains decompiler
// Type: Z_;AJ4d{trZ),&U?h9qF4n0h!
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

#nullable disable
public sealed class Z_\u003BAJ4d\u007BtrZ\u0029\u002C\u0026U\u003Fh9qF4n0h\u0021 : 
  \u202E⁫⁮⁭‬⁬‍⁯‪‍‏‪‮⁫⁫‍​‭⁮‬‮⁬‏‫‭‍​‍‮‮‏​⁮⁭‏⁮⁭⁯⁯⁯‮
{
  private IContainer \u206D‍⁮‪‌​⁯​‌‏⁫‍‍⁮‬‬‮‬⁮‭‎‏‎⁮⁭⁬‏⁪‏‏‮​‬⁪⁪‌‪‬‌‪‮;
  private TabControl \u202C⁬‎‭⁭⁪‭‮‫‬‌⁪‮⁮⁮‎‎‌‬⁫⁭‌‌⁬​‬⁪​⁮‮⁯⁭‍⁫⁭⁪‍‏​⁮‮;
  private TabPage \u206D⁪‏‪​‍‮‫‭‎‏⁯‌⁬‫⁫⁬‌⁫‭‭⁭‪⁭‪⁮‬⁬‌‪‭⁬‮‮‍‫⁯⁬⁪‏‮;
  private TabPage \u202D⁪⁬⁮⁭⁯⁪‏‍‮⁫‌⁮⁮⁪‬⁬⁬‪‭⁪‌⁭‎⁫‭‪⁫‌‫‍⁪‍⁬⁬⁪‍‌‍‭‮;
  private TabControl \u206E⁪‫⁫‮⁮‌​‬‬⁪‬‏‮⁪⁮‬‎‍⁫‌‬⁬⁪‌‪‬‏⁫‍‬⁬‪‬‮⁮‮‍⁬‎‮;
  private TabPage \u202D‮⁫⁪⁭⁬‍‫‎⁬‪‬‮‎​⁭‭⁮‌⁬⁭‌⁯‏‎‌‬⁮⁫⁯‭⁯‪⁯⁫⁫‬‌⁬⁯‮;
  private RichTextBox \u206F⁪⁮⁬⁭‪⁪‏‭​‬⁬‮‪‌‬‎‎⁭​⁬‎‍⁫‌‎‬⁭⁬⁯‭‏‮⁪‏⁪‌⁪‪⁮‮;
  private TabPage \u206E‏​⁭‎‏⁪⁬‪‎‮⁭‏‬⁮‬‬​‫⁬⁬‌‮⁮‎‎‏‎‌⁬‫⁬‬​⁯⁯‎⁪⁭⁪‮;
  private TabPage \u206F‮‭⁯‎⁯‏⁯‎⁮⁯‎‍‪‫‬⁭⁬⁭⁯‬⁮‬⁪​‫‫⁪⁪‫‮‭⁮‪⁬‫⁯⁬‍‫‮;
  private TabControl \u202B⁬⁭‪⁬‬‫​‫​‌​‌⁬⁫⁫​‮⁫⁪‌⁯⁯‍‮⁭‏⁬‫⁭⁬⁬‏⁪‫⁪‎‎‮‮‮;
  private TabPage \u202A⁯⁮⁭⁫‎⁮⁫‍‎‮​⁪‭⁪‎⁮⁪​​⁭‪​‏⁪⁫‫⁪⁯‬​‭⁪‍⁮‎‭⁯⁬‪‮;
  private RichTextBox \u206A‎‭‬⁬‮‎‫‭⁮‬‎‍​‭‍⁫‫‬‮‫‭‮‮⁭⁪‮⁯‏‫‌‫⁪‪⁪‭⁭⁫‏⁯‮;
  private Label \u202E‭⁮‭⁪‎⁫⁬⁪⁭‍⁯‎‪⁭‌​‌​‌⁭​‪‎​‮⁬⁭‎⁪‎‏‭‍‍‬‬‭‫⁭‮;
  private Label \u206E‭‍⁬⁫⁮‎​​⁫‎‏‍‎‬‍‫⁭‫‬⁯‪‌⁭‫‮‬‌‫⁮⁫‪‏⁪​​‪‎‌‎‮;
  private TabControl \u202C⁬‏⁯⁭‮⁮⁮‬⁬‮⁪⁭‏⁯‮‮​‌​​‫‎⁭⁮⁬⁬⁭‫‍‫‎‌⁯‏‫⁪‮‎‌‮;
  private TabPage \u202A⁯⁯⁫​⁬‮‎⁮‎‏⁫⁫​‬‌‎‏‪⁫⁫‎⁯‌⁯⁭‮⁪⁫‭‎‌⁯⁮‮‎‎⁫‭‮‮;
  private Label \u202A‪⁭‮‍⁫⁪⁪‎⁭⁯​‎⁪‬‫‌‭⁭⁪⁯‮⁫⁫​⁪​⁭‫⁯‎⁭‫⁪‫‍‬​⁪‏‮;
  private RichTextBox \u206F⁮​⁭‭​‪‫‫‫‎‏​‬‮​⁬‫‪⁫‪⁬⁫⁪⁪‬‌‎⁮⁬⁮‍‌‎⁯‫⁪‫‭‪‮;
  private TabPage \u206C⁮‪‬‫‏​​‭‮⁭‬‌‎‍‍⁫⁪​‬‌​⁪‏‌‎‍‭‌‮‏⁪‬​‮‭‬⁬‪⁪‮;
  private TabPage \u200F‪‪‏‪⁮‎‪⁯‪​‍‌‫⁭‏⁯‌⁯‮⁪⁭‮‬⁭⁪⁫⁭‭‌⁬‌⁪⁯⁪⁯⁮‮‏⁫‮;
  private TabControl \u202A‌‏‬​⁫⁭‬‌‬‮‬‭‮‫‪⁯⁪‬‫‎⁫‭‍‎‎⁪⁪‍‌​‭⁯⁪‬‍‭⁫‌‫‮;
  private TabPage \u200F‪‮‎‎‫‍‍‭‎‍‌‎‍⁫​‭‮‭⁪‌‫⁯​‍‮‬⁪⁭‭⁮⁪⁫‬⁫‮⁮‪‮‪‮;
  private TabPage \u200F​‪⁭‫‏‎‭⁫‏​⁯‎⁫‬‏‭‪⁫⁬⁪⁭‍⁫‬⁬‎⁮‎‍‫⁫⁬‮⁫‮‍‏‪‌‮;
  private Button \u202D‫‫‫⁪‮‏⁮‭⁯⁯⁫⁫‌⁯⁪⁬⁯‍‏⁯‫‬‍‏⁭‏⁯‍⁬​⁫‮⁬​‪‌⁪‫‬‮;
  private Button \u206F‮‍‌‫⁮‎‮‎‬⁫⁪‎⁮⁬‬‍‪⁫⁫⁬‏⁭‏‬‬⁭⁫‫⁮⁯⁫‪⁭‍‫‮‎​⁭‮;
  private Button \u206C⁪‮‏‌‬⁭‎‍‮‌⁮⁮‌⁮‬⁫‌‫⁯‎‪‎⁮⁯​​⁭‏‌‬‮​‬⁭‎⁭‌‪‬‮;
  private Button \u206E‬‎‌‪‭‌‏‮⁬⁯‌⁬​⁫‬‪‫⁬‏‫‭‏‮⁮‮‫⁪‌⁮‪‌⁫⁫‎⁫⁭​‌⁬‮;
  private Label \u202D‍⁬‪‏‭⁮​‍⁫⁯‭⁪‍‫‫⁮​⁯⁪⁮‏‫⁫‌‪​‍⁯‮‫‍‎⁪‎‭‌‫​‬‮;
  private RichTextBox \u206B‏⁪⁪‭‭‫⁬‫‍‌​⁮‎‫‫‏‍⁪‏⁫​‫‮‮‬⁪‫⁯‫​​⁮‮⁮‬‪⁪⁭‭‮;
  private Label \u202E⁬​‍⁯‮‏‪⁬‎‪‍‍‭​‏⁭⁭⁫⁮⁯⁬‭‬‏⁫‫‌‪‭⁯‮‏‪⁬‫⁪‬⁮‏‮;
  private RichTextBox \u200C⁭⁫​‌‮‍⁭‍‪⁯‍⁪‬‫‮⁬‌⁭‪‮‬‎⁫‫‮⁬‎‮⁫​⁪‍⁫⁪⁭⁮‫⁯⁭‮;
  private Button \u202A⁪‏⁫‮‫​‭​‮⁯‌‎‬⁯⁮⁬⁭⁫‮‏‍‬​⁬⁫‎‎‌​‎‎‪‬‮‭‬‎‭‮‮;
  private TabPage \u206F‍‫⁫⁪‍‪‎‮‍⁪⁭‬⁪‌⁫‎‍⁪​⁭‏⁯‭‭⁮‫‭⁮‬‎‪⁮‮⁫⁭‮⁪‮‭‮;
  private TabControl \u200F‭⁬‫⁪‫‫‍‪⁮⁭‮⁯‍⁪‭​⁯​⁪⁪⁬⁭⁭‭‭⁭‎‏⁯⁪⁬‌‪⁪‫‎⁮⁫⁬‮;
  private TabPage \u200D​‭‏⁪‍‮‍‌‬‏‌⁫⁭‮⁯‍‫‮⁪​‭‮‭‬⁭‪⁮⁬‏⁪​‭⁬​‮‪⁭‏⁬‮;
  private Label \u200B​⁪‍‮⁭⁪‌‬‪‫⁪⁯⁬‏‭⁪​‫‮‮‏⁯‎‫‪‪‎‭‏‏⁫​⁫⁭⁫⁯⁫⁭⁪‮;
  private RichTextBox \u206A‮‏​‮‪⁫‫‫‍‬‭‎⁮‌‬​‍⁫⁮‏‏⁯⁭‏‫⁫⁮‭‫​‬‪⁫‎⁭⁭‭‬⁯‮;
  private TabPage \u206F‬‏‬‫‎⁮‮‮⁫‭‬​‭‪​⁭⁮‬⁭⁭‍‎‪⁫⁪‪⁫‬⁬‎‬‭⁮⁫‍⁫⁪‬⁫‮;
  private Button \u202B‏‭‬‎‏⁪‪⁬‏⁯‍⁮‌‬‎‌‭‌‫⁭⁬‭‮⁫‭⁫​‪‬‫​⁫⁫‍⁯​⁬‌‮‮;
  private void \u200D⁬⁬⁭‭‎⁬⁫​‏⁭‌⁯⁬‫​‌⁫⁬⁭‮‌‬⁮‪⁭‎‬⁮⁮‭⁫⁫‪‮⁫⁭‌‭⁮‮(object _param1, EventArgs _param2);
  private void \u202B⁬⁫⁮​‎⁪​‏‏‭‍‫‭‎‌‍⁫⁬‮‌⁬‭​‫‎⁭​⁯​⁭⁭⁯⁭‫‍‬‪⁪‌‮(object _param1, EventArgs _param2);
  private void \u200D⁫⁭⁯⁯⁮‌‮‎‮‭​‭‍‌‏‫⁯‌⁭⁭⁭‌‍⁮‍‬‬‍‍‪⁪‎‍⁯‬⁮​‮⁬‮(object _param1, EventArgs _param2);
  private void \u202D‌‮‎‎​​‌‬‏‫‭⁫⁮‭‭‌⁭⁪⁬‫⁮‍‮‏⁫‪‌‍‏‪⁯⁫‏⁬‭⁬‮‪⁭‮(object _param1, EventArgs _param2);
  private void \u206B‌‎‬‮​‎‏‮⁬⁪⁯⁫​‏‬⁯‭⁮‮‏⁬‎‍‏‏‪‭⁫⁫‫‍‍‌‮‬‍‭⁪‍‮(object _param1, EventArgs _param2);
  private void \u202A‬‬⁬⁯‍‮‫‪‏⁯⁮⁫‭‮‎‭‫⁮‬‮‎‍‍‫⁪‪​‬⁪‫⁪⁭‍‪⁬‫‫⁭‫‮(object _param1, EventArgs _param2);
  private void \u206F‌​‪‍⁮‬⁫‪‮⁫⁪⁯‪⁯‭‮⁮‪​‎‮⁬⁭‍‎‪⁬‫‬​‪⁪‪‮⁫‏‬‏‮(object _param1, EventArgs _param2);
  void Form.\u202D⁫⁫‍‭​⁪‌‫⁬‎⁮‭‌⁬‌‫‎‭‮‍‭⁫‬‭⁬‪⁪⁪‌⁮⁮‏‭⁯⁬⁮⁬‮‌‮(bool _param1);
  private void \u206F⁮​‬‭​‭‬‭‎‪​⁯‪‮‎⁭‎‪⁮‭‬‏⁭‬‌‎⁫⁬⁫⁮‫⁫‍⁪‎‍⁬⁭‏‮();
  static void \u206D‫‌‏‭⁬⁯‍⁪⁪⁮‪‪​‍⁫‌‪‌⁫⁪‏‬⁫‏‍‌‬⁫‬‫‮⁫​‫⁯⁬⁫‪‮([In] Control obj0, [In] Color obj1);
  static Encoding \u206A‮⁮‪⁪⁮⁭⁪‍⁫⁬‭‎​‍‮⁮‮‬‌‍​‫⁭‌⁭‮⁮‎‫⁫‎‬⁬⁯⁯‏‎‪‍‮([In] string obj0);
  static string \u206D‭‌‎‭‭‭‬‎​⁬‎⁪⁪⁯​‭⁭⁭‎‏‫⁫⁮⁭‮‬⁭⁯‮‎‏‍‍‎⁮⁯​‪‮([In] string obj0, [In] Encoding obj1);
  static void \u200D‪‍⁪⁪⁯⁫⁪⁯‭‮‏‍‬⁯‎⁭‍⁪‏‏⁫⁬‮‌‌‏⁫​‌​‎‪‏‮‎⁫⁮‫‪‮([In] Control obj0, [In] string obj1);
  static Process \u202D⁬​⁪‪⁮⁭‌⁪‎‪⁫⁪‎⁫‎‭‎‏‌‍⁮‌‭‭‬⁮⁯‪‎‪⁯⁭‎‎‍​‬⁪⁪‮([In] string obj0, [In] string obj1);
  static object \u200B⁮‏​⁯‫‭‬​‭‌‪‮‍⁬⁮⁯‮‏⁫‌⁮⁪⁪⁭​⁬⁯‮‌⁪‪‮‎​⁫‏⁭​‍‮([In] Control obj0);
  static string \u200B‌⁪⁬‌‮‌⁬‬‪⁯‎‪‬‮‬⁮‏‏⁯‍⁮‪‭‍‮⁪‫‎⁯‍‌⁬‪⁯⁮‍‏⁬‭‮([In] object obj0);
  static string \u200E‬‍⁯‬⁮‏‎‫⁭‍‏⁬⁮⁫‫⁭​‍‭⁮‬⁪‏‏⁭⁫⁪​‏‎‭⁬‪‬‌⁯⁪⁬⁫‮([In] Control obj0);
  static void \u202A⁪⁪⁯​‪⁪⁪⁬⁭⁪⁪‌⁭⁮‮‏⁪‏​⁮⁫⁯‪‏‏⁬‮⁯‎⁪‪⁫‭‎⁮‎⁮‌‏‮(
    [In] string obj0,
    [In] string obj1,
    [In] Encoding obj2);
  static void \u200E⁮‏⁫‌⁯‮​⁮‎⁪⁬​⁪‎‪​⁮‎‮‎⁫‬‏⁮‫⁭⁭​​‪‪‫⁭​⁯‭⁮⁮⁮‮([In] IDisposable obj0);
  static TabControl \u206E​⁯‪⁪‬⁮‭‫⁮⁯⁬⁮‮⁬‎‍‌⁭‎‫‭⁯‍‬‎⁪‍‮⁫⁪⁭‫‏‬‎⁪⁪⁫⁪‮();
  static TabPage \u200C⁬⁮⁮‪‌⁭‮‎​⁪‭‏‫⁪⁯⁬‏​‏‭⁭⁪⁭​‎⁯⁪⁭‏⁯‮‌⁫‎‪⁭‬‍‮();
  static Label \u202B‌⁫‍‍‮‍‍‫‫⁫⁬⁭‬⁪​⁮‬⁯⁯⁯‪‫⁪‌‮‫‍⁯⁭‍‌‭‬‌‫⁯⁭⁯⁮‮();
  static RichTextBox \u206E​⁫‭⁫⁯⁯​⁯‮⁮​⁮⁪⁯‮⁭‎‭‮‮‫‪⁬‌‌⁯​‫⁬‭‏⁫‬⁭⁪‭‫⁯‏‮();
  static Button \u206B⁬⁬⁭⁬‬‪‏‬⁭‬‪⁬‭‌⁭‬⁯‭‎⁫⁫‬⁬⁪‍⁭⁬⁯‫‭‭⁪⁬⁮⁪⁪⁮⁮‏‮();
  static void \u202D‫⁭‍‪‮‏⁮‭‪⁫⁭‍⁮‌⁮‎⁮⁫‪‫‎⁭‫​⁮‏‌‮‎‌‎⁪⁯⁬‎‪‌​⁪‮([In] Control obj0);
  static void \u206B⁭⁪⁬‏‬⁪‏‮‌‮⁪‬‌​⁯‭‎‬‪⁮‪‌⁫‫‏‭⁯‮‪‌⁮⁪‭‎‌‫‫‭‭‮([In] Control obj0);
  static Control.ControlCollection \u200E‪‭‏‏‮​‌‎‪​​⁮‍‎‭‪‬‫‌‭‏⁫⁭⁬‎⁮‮‌⁮‎‭⁭⁮‫⁫⁪⁭⁪‫‮([In] Control obj0);
  static void \u202E‭⁫‍‮⁫‫⁬⁯‏‪‎⁭⁮‬‫⁪‎‭‮‬‌⁯⁮‪‫‫⁪⁭​‮⁮⁮‍‍⁬‫‍‮‎‮(
    [In] Control.ControlCollection obj0,
    [In] Control obj1);
}
