﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyProduct("ISP")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("a1a85969-3813-49e5-a4c4-9c137da390d3")]
[assembly: AssemblyCompany("")]
[assembly: Extension]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("ISP")]
[assembly: AssemblyVersion("1.0.0.0")]
