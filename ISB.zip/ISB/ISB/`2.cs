﻿// Decompiled with JetBrains decompiler
// Type: ‌⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮`2
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
[CompilerGenerated]
internal sealed class \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u0001, \u0002>
{
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0001 \u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮;
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0002 \u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮;

  public \u0001 \u003C\u003Eh__TransparentIdentifier0
  {
    get => this.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮;
  }

  public \u0002 searchResult => this.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮;

  [DebuggerHidden]
  public \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮(\u0001 _param1, \u0002 _param2)
  {
    // ISSUE: reference to a compiler-generated field
    this.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮ = _param1;
    // ISSUE: reference to a compiler-generated field
    this.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮ = _param2;
  }

  [DebuggerHidden]
  virtual bool object.\u202E‭‪‎‏‍⁪‍‌‬‪⁬‭⁫‎⁬‍‎⁫​⁮⁫‍‫‎‪‎‪⁮‬‍⁬⁫⁬‍‍‌⁪‭‮‮(object _param1)
  {
    // ISSUE: variable of a compiler-generated type
    \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u0001, \u0002> obj = _param1 as \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u0001, \u0002>;
label_1:
    int num1 = 1958028158;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 621019932)) % 5U)
      {
        case 0:
          goto label_1;
        case 1:
          goto label_5;
        case 3:
          int num3 = obj == null ? -285165760 : (num3 = -2004099668);
          num1 = num3 ^ (int) num2 * -1893198835;
          continue;
        case 4:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          int num4 = EqualityComparer<\u0001>.Default.Equals(this.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮, obj.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮) ? 1833547593 : (num4 = 1057617288);
          num1 = num4 ^ (int) num2 * -734763547;
          continue;
        default:
          goto label_6;
      }
    }
label_5:
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return EqualityComparer<\u0002>.Default.Equals(this.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮, obj.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮);
label_6:
    return false;
  }

  [DebuggerHidden]
  virtual int object.\u202D‬‪‍⁬‏‍‪‮‍‭‬⁪⁫‎‫‎⁯‮‫⁯⁪⁮⁮‌‪‫​‌‮‫‬‮‭‮‎‮⁬‬‮()
  {
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return (96457578 * -1521134295 + EqualityComparer<\u0001>.Default.GetHashCode(this.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮)) * -1521134295 + EqualityComparer<\u0002>.Default.GetHashCode(this.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮);
  }

  [DebuggerHidden]
  virtual string object.\u200E‭‌‫‮⁫⁯⁫‬⁪‬‪⁪‮‎‬⁫‌⁮⁬‮‬​⁪‭‮⁮⁬⁪‬‮‫‮⁬⁮​⁬​⁮‭‮()
  {
    string str1 = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1479527444U);
    object[] objArray = new object[2];
    // ISSUE: reference to a compiler-generated field
    \u0001 obj1 = this.\u202C⁭⁪⁭​⁮⁫‌‮⁫‫⁯⁮⁬⁬⁭‫⁫​‪‭‭⁭‫⁬‫‏‬‮⁭‮‮‬‭⁮⁮‍‎‭‏‮;
    ref \u0001 local1 = ref obj1;
    string str2;
    if ((object) default (\u0001) == null)
    {
      \u0001 obj2 = local1;
      ref \u0001 local2 = ref obj2;
      if ((object) obj2 == null)
      {
        str2 = (string) null;
        goto label_4;
      }
      local1 = ref local2;
    }
    str2 = local1.ToString();
label_4:
    objArray[0] = (object) str2;
    // ISSUE: reference to a compiler-generated field
    \u0002 obj3 = this.\u202D‌‬‎⁬⁫⁪‮‬‏​‌⁬‪‏‎‏⁫‎‮‍‏⁬​‬⁬‏‭⁭⁭‌⁬⁮‌⁬‪‫‮‪⁪‮;
    ref \u0002 local3 = ref obj3;
    string str3;
    if ((object) default (\u0002) == null)
    {
      \u0002 obj4 = local3;
      ref \u0002 local4 = ref obj4;
      if ((object) obj4 == null)
      {
        str3 = (string) null;
        goto label_8;
      }
      local3 = ref local4;
    }
    str3 = local3.ToString();
label_8:
    objArray[1] = (object) str3;
    // ISSUE: reference to a compiler-generated method
    return \u200C⁫‪‎⁬⁫⁮‎⁮‌‬​⁯⁪‬‮⁮⁭‮​‎⁭⁮‏‎‏⁬⁫​​⁭⁯‭⁫⁭‭‌⁪‫‭‮<\u0001, \u0002>.\u200D‮‍‬⁫‮‎⁪‎‌⁫‬​‍‏⁭⁬⁮⁫‭‪​‌‫‭‍⁪⁫​‫‮⁬‏‍‫⁯‏‌⁫‭‮((IFormatProvider) null, str1, objArray);
  }

  static string \u200D‮‍‬⁫‮‎⁪‎‌⁫‬​‍‏⁭⁬⁮⁫‭‪​‌‫‭‍⁪⁫​‫‮⁬‏‍‫⁯‏‌⁫‭‮(
    [In] IFormatProvider obj0,
    [In] string obj1,
    [In] object[] obj2)
  {
    return string.Format(obj0, obj1, obj2);
  }
}
