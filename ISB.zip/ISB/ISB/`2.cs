﻿// Decompiled with JetBrains decompiler
// Type: ‏⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮`2
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
[CompilerGenerated]
internal sealed class \u200F⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮<\u0001, \u0002>
{
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0001 \u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮;
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0002 \u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮;

  public \u0001 accstr => this.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮;

  public \u0002 id => this.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮;

  [DebuggerHidden]
  public \u200F⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮(\u0001 _param1, \u0002 _param2)
  {
    // ISSUE: reference to a compiler-generated field
    this.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮ = _param1;
    // ISSUE: reference to a compiler-generated field
    this.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮ = _param2;
  }

  [DebuggerHidden]
  virtual bool object.\u202E‭‪‎‏‍⁪‍‌‬‪⁬‭⁫‎⁬‍‎⁫​⁮⁫‍‫‎‪‎‪⁮‬‍⁬⁫⁬‍‍‌⁪‭‮‮(object _param1)
  {
    // ISSUE: variable of a compiler-generated type
    \u200F⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮<\u0001, \u0002> obj = _param1 as \u200F⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮<\u0001, \u0002>;
label_1:
    int num1 = -883674511;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ -56648937)) % 5U)
      {
        case 0:
          goto label_1;
        case 2:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          int num3 = EqualityComparer<\u0001>.Default.Equals(this.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮, obj.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮) ? -786413603 : (num3 = -505515113);
          num1 = num3 ^ (int) num2 * 856668811;
          continue;
        case 3:
          goto label_5;
        case 4:
          int num4 = obj == null ? -835985850 : (num4 = -718822428);
          num1 = num4 ^ (int) num2 * 977081485;
          continue;
        default:
          goto label_6;
      }
    }
label_5:
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return EqualityComparer<\u0002>.Default.Equals(this.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮, obj.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮);
label_6:
    return false;
  }

  [DebuggerHidden]
  virtual int object.\u202D‬‪‍⁬‏‍‪‮‍‭‬⁪⁫‎‫‎⁯‮‫⁯⁪⁮⁮‌‪‫​‌‮‫‬‮‭‮‎‮⁬‬‮()
  {
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return (37840409 * -1521134295 + EqualityComparer<\u0001>.Default.GetHashCode(this.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮)) * -1521134295 + EqualityComparer<\u0002>.Default.GetHashCode(this.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮);
  }

  [DebuggerHidden]
  virtual string object.\u200E‭‌‫‮⁫⁯⁫‬⁪‬‪⁪‮‎‬⁫‌⁮⁬‮‬​⁪‭‮⁮⁬⁪‬‮‫‮⁬⁮​⁬​⁮‭‮()
  {
    string str1 = \u003CModule\u003E.\u206C​​‭‭⁫‮⁭‭‌⁯⁮‪⁫‮‪‏‍‬‭‍⁭‍⁮​⁮​⁯‏‌‎​⁬⁫‬⁭​⁭⁯‮‮<string>(1974079332U);
    object[] objArray = new object[2];
    // ISSUE: reference to a compiler-generated field
    \u0001 obj1 = this.\u206D⁫‌⁯‌⁪⁪‭‬‬‫‮‎⁭‪⁫‮⁪‍‮⁮‍⁬‏‮‪‮‌⁯⁬‏‮​‍⁬⁪‭⁮⁯‎‮;
    ref \u0001 local1 = ref obj1;
    string str2;
    if ((object) default (\u0001) == null)
    {
      \u0001 obj2 = local1;
      ref \u0001 local2 = ref obj2;
      if ((object) obj2 == null)
      {
        str2 = (string) null;
        goto label_4;
      }
      local1 = ref local2;
    }
    str2 = local1.ToString();
label_4:
    objArray[0] = (object) str2;
    // ISSUE: reference to a compiler-generated field
    \u0002 obj3 = this.\u202C‌‎‎⁫‏‪⁫⁭‌‍‍‪⁫‪‫⁯‫‭‮‮⁫‍‭⁯‏‪‌⁮​‮‬⁪⁪‭‏‭‬⁪⁮‮;
    ref \u0002 local3 = ref obj3;
    string str3;
    if ((object) default (\u0002) == null)
    {
      \u0002 obj4 = local3;
      ref \u0002 local4 = ref obj4;
      if ((object) obj4 == null)
      {
        str3 = (string) null;
        goto label_8;
      }
      local3 = ref local4;
    }
    str3 = local3.ToString();
label_8:
    objArray[1] = (object) str3;
    // ISSUE: reference to a compiler-generated method
    return \u200F⁪‎‏​‎⁯‭⁭‌‪⁯‭‫⁪‎⁮⁯⁯‌⁬​‍‬‎‪⁫⁮⁫⁪‌‍⁭⁫‏‍‮‎‪‏‮<\u0001, \u0002>.\u206A‭‏⁪⁪‫⁯​⁬​‪​‬⁪‌⁭‏‍‬‎​‭⁪⁬⁯​‭⁮‭⁬‭‏​‏‬‏⁭‌⁬‍‮((IFormatProvider) null, str1, objArray);
  }

  static string \u206A‭‏⁪⁪‫⁯​⁬​‪​‬⁪‌⁭‏‍‬‎​‭⁪⁬⁯​‭⁮‭⁬‭‏​‏‬‏⁭‌⁬‍‮(
    [In] IFormatProvider obj0,
    [In] string obj1,
    [In] object[] obj2)
  {
    return string.Format(obj0, obj1, obj2);
  }
}
