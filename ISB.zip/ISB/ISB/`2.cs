﻿// Decompiled with JetBrains decompiler
// Type: ⁬⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮`2
// Assembly: ISB, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E3C699B-BB47-49FB-B9E8-BFF25A969576
// Assembly location: C:\Users\Systemov\Desktop\ISB (2)\ISB\ISB.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
[CompilerGenerated]
internal sealed class \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<\u0001, \u0002>
{
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0001 \u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮;
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly \u0002 \u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮;

  public \u0001 account => this.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮;

  public \u0002 currAcc => this.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮;

  [DebuggerHidden]
  public \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮(\u0001 _param1, \u0002 _param2)
  {
    // ISSUE: reference to a compiler-generated field
    this.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮ = _param1;
    // ISSUE: reference to a compiler-generated field
    this.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮ = _param2;
  }

  [DebuggerHidden]
  virtual bool object.\u202E‭‪‎‏‍⁪‍‌‬‪⁬‭⁫‎⁬‍‎⁫​⁮⁫‍‫‎‪‎‪⁮‬‍⁬⁫⁬‍‍‌⁪‭‮‮(object _param1)
  {
    // ISSUE: variable of a compiler-generated type
    \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<\u0001, \u0002> obj = _param1 as \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<\u0001, \u0002>;
label_1:
    int num1 = 1828666314;
    while (true)
    {
      uint num2;
      switch ((num2 = (uint) (num1 ^ 442032509)) % 5U)
      {
        case 1:
          int num3 = obj != null ? -470828974 : (num3 = -36010091);
          num1 = num3 ^ (int) num2 * 1840601249;
          continue;
        case 2:
          goto label_5;
        case 3:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          int num4 = !EqualityComparer<\u0001>.Default.Equals(this.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮, obj.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮) ? 626280506 : (num4 = 2042881615);
          num1 = num4 ^ (int) num2 * 918483889;
          continue;
        case 4:
          goto label_1;
        default:
          goto label_6;
      }
    }
label_5:
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return EqualityComparer<\u0002>.Default.Equals(this.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮, obj.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮);
label_6:
    return false;
  }

  [DebuggerHidden]
  virtual int object.\u202D‬‪‍⁬‏‍‪‮‍‭‬⁪⁫‎‫‎⁯‮‫⁯⁪⁮⁮‌‪‫​‌‮‫‬‮‭‮‎‮⁬‬‮()
  {
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    return (-173562710 * -1521134295 + EqualityComparer<\u0001>.Default.GetHashCode(this.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮)) * -1521134295 + EqualityComparer<\u0002>.Default.GetHashCode(this.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮);
  }

  [DebuggerHidden]
  virtual string object.\u200E‭‌‫‮⁫⁯⁫‬⁪‬‪⁪‮‎‬⁫‌⁮⁬‮‬​⁪‭‮⁮⁬⁪‬‮‫‮⁬⁮​⁬​⁮‭‮()
  {
    string str1 = \u003CModule\u003E.\u202D‬​‪‎‪⁮‫‪‪‬‪‏⁭⁪⁪⁫⁫⁫‮⁫‌‭⁫‮​‫⁬⁮⁬⁪⁮⁫​⁫⁮​‌⁪⁭‮<string>(3787138827U);
    object[] objArray = new object[2];
    // ISSUE: reference to a compiler-generated field
    \u0001 obj1 = this.\u202B⁮‏‫⁪⁬‎‌⁬‫‏‪‫‌⁬‮‪‍‬‫‭‏⁫⁭‪‪⁪⁬⁫‪⁯⁫‏‬​‬‮‮‍‮;
    ref \u0001 local1 = ref obj1;
    string str2;
    if ((object) default (\u0001) == null)
    {
      \u0001 obj2 = local1;
      ref \u0001 local2 = ref obj2;
      if ((object) obj2 == null)
      {
        str2 = (string) null;
        goto label_4;
      }
      local1 = ref local2;
    }
    str2 = local1.ToString();
label_4:
    objArray[0] = (object) str2;
    // ISSUE: reference to a compiler-generated field
    \u0002 obj3 = this.\u200E‪‮⁭⁯‮‫‏⁮‮⁭⁫⁫‬​⁬‌⁭⁫⁮⁭‭⁫⁯⁮⁯‎‮⁫‏⁪⁪‪‭‎‍‬‮‫‪‮;
    ref \u0002 local3 = ref obj3;
    string str3;
    if ((object) default (\u0002) == null)
    {
      \u0002 obj4 = local3;
      ref \u0002 local4 = ref obj4;
      if ((object) obj4 == null)
      {
        str3 = (string) null;
        goto label_8;
      }
      local3 = ref local4;
    }
    str3 = local3.ToString();
label_8:
    objArray[1] = (object) str3;
    // ISSUE: reference to a compiler-generated method
    return \u206C⁬‌⁪​‪‏⁯‌‏‭‬‬‎⁪‍⁬‌‪‪⁪‌‬‎‏‭‪⁫⁮‍‫⁪‮‬‬‫⁭‎‫⁯‮<\u0001, \u0002>.\u200F‏⁫⁬‬⁬‌‎‭‎⁭‮‫‪‭⁭⁬‭⁭⁪⁬‏‪‏‭‍‭⁮⁪‫​‮⁮‌​⁪⁫‪⁯‌‮((IFormatProvider) null, str1, objArray);
  }

  static string \u200F‏⁫⁬‬⁬‌‎‭‎⁭‮‫‪‭⁭⁬‭⁭⁪⁬‏‪‏‭‍‭⁮⁪‫​‮⁮‌​⁪⁫‪⁯‌‮(
    [In] IFormatProvider obj0,
    [In] string obj1,
    [In] object[] obj2)
  {
    return string.Format(obj0, obj1, obj2);
  }
}
