﻿// Decompiled with JetBrains decompiler
// Type: CRIME.CRIMEPANEL
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

#nullable disable
namespace CRIME;

public class CRIMEPANEL
{
  private Dictionary<long, int> repeat = new Dictionary<long, int>();
  private bool _is64Bit;
  private Dictionary<string, IntPtr> modules = new Dictionary<string, IntPtr>();
  private ProcessModule mainModule;
  public Process theProc;
  private uint MEM_PRIVATE = 131072 /*0x020000*/;
  private uint MEM_IMAGE = 16777216 /*0x01000000*/;
  public IntPtr pHandle;
  private int x;

  [DllImport("kernel32.dll")]
  private static extern void GetSystemInfo(out CRIMEPANEL.SYSTEM_INFO lpSystemInfo);

  [DllImport("kernel32.dll")]
  public static extern IntPtr OpenProcess(
    uint dwDesiredAccess,
    bool bInheritHandle,
    int dwProcessId);

  [DllImport("kernel32")]
  public static extern bool IsWow64Process(IntPtr hProcess, out bool lpSystemInfo);

  [DllImport("kernel32.dll")]
  private static extern bool VirtualProtectEx(
    IntPtr hProcess,
    UIntPtr lpAddress,
    IntPtr dwSize,
    CRIMEPANEL.MemoryProtection flNewProtect,
    out CRIMEPANEL.MemoryProtection lpflOldProtect);

  [DllImport("kernel32.dll")]
  private static extern bool WriteProcessMemory(
    IntPtr hProcess,
    UIntPtr lpBaseAddress,
    byte[] lpBuffer,
    UIntPtr nSize,
    IntPtr lpNumberOfBytesWritten);

  [DllImport("kernel32.dll")]
  private static extern bool ReadProcessMemory(
    IntPtr hProcess,
    UIntPtr lpBaseAddress,
    [Out] byte[] lpBuffer,
    UIntPtr nSize,
    IntPtr lpNumberOfBytesRead);

  [DllImport("kernel32.dll")]
  public static extern int CloseHandle(IntPtr hObject);

  [DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
  public static extern UIntPtr Native_VirtualQueryEx(
    IntPtr hProcess,
    UIntPtr lpAddress,
    out CRIMEPANEL.MEMORY_BASIC_INFORMATION64 lpBuffer,
    UIntPtr dwLength);

  [DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
  public static extern UIntPtr Native_VirtualQueryEx(
    IntPtr hProcess,
    UIntPtr lpAddress,
    out CRIMEPANEL.MEMORY_BASIC_INFORMATION32 lpBuffer,
    UIntPtr dwLength);

  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
  private static extern uint GetPrivateProfileString(
    string lpAppName,
    string lpKeyName,
    string lpDefault,
    StringBuilder lpReturnedString,
    uint nSize,
    string lpFileName);

  [DllImport("kernel32.dll")]
  private static extern bool ReadProcessMemory(
    IntPtr hProcess,
    UIntPtr lpBaseAddress,
    [Out] IntPtr lpBuffer,
    UIntPtr nSize,
    out ulong lpNumberOfBytesRead);

  public string LoadCode(string name, string file)
  {
    StringBuilder lpReturnedString = new StringBuilder(1024 /*0x0400*/);
    if (file != "")
    {
      int privateProfileString = (int) CRIMEPANEL.GetPrivateProfileString("codes", name, "", lpReturnedString, (uint) lpReturnedString.Capacity, file);
    }
    else
      lpReturnedString.Append(name);
    return lpReturnedString.ToString();
  }

  public byte[] readMemory(string code, long length, string file = "")
  {
    byte[] lpBuffer = new byte[length];
    return CRIMEPANEL.ReadProcessMemory(this.pHandle, this.GetCode(code, file), lpBuffer, (UIntPtr) checked ((ulong) length), IntPtr.Zero) ? lpBuffer : (byte[]) null;
  }

  public void SaveRepeatDictionary(string filePath)
  {
    using (StreamWriter streamWriter = new StreamWriter(filePath))
    {
      foreach (KeyValuePair<long, int> keyValuePair in this.repeat)
        streamWriter.WriteLine($"{keyValuePair.Key:X},{keyValuePair.Value:X}");
    }
  }

  public void LoadRepeatDictionary(string filePath)
  {
    if (!File.Exists(filePath))
      return;
    foreach (string readAllLine in File.ReadAllLines(filePath))
    {
      char[] chArray = new char[1]{ ',' };
      string[] strArray = readAllLine.Split(chArray);
      this.repeat[Convert.ToInt64(strArray[0], 16 /*0x10*/)] = Convert.ToInt32(strArray[1], 16 /*0x10*/);
    }
  }

  public Task<IEnumerable<long>> AoBScanMultithreadedWithTasks(
    long start,
    long end,
    string searchPattern,
    bool readable,
    bool writable,
    bool executable,
    string file = "")
  {
    return Task.Run<IEnumerable<long>>((Func<Task<IEnumerable<long>>>) (async () =>
    {
      List<long> foundAddresses = new List<long>();
      string[] strArray;
      if (!string.IsNullOrEmpty(file))
        strArray = this.LoadCode(searchPattern, file).Split(' ');
      else
        strArray = searchPattern.Split(' ');
      byte[] pattern = new byte[strArray.Length];
      byte[] mask = new byte[strArray.Length];
      bool[] ignore00 = new bool[strArray.Length];
      for (int index = 0; index < strArray.Length; ++index)
      {
        string str = strArray[index];
        switch (str)
        {
          case "??":
            pattern[index] = (byte) 0;
            mask[index] = (byte) 0;
            ignore00[index] = false;
            break;
          case "!!":
            pattern[index] = (byte) 0;
            mask[index] = (byte) 0;
            ignore00[index] = true;
            break;
          default:
            mask[index] = byte.MaxValue;
            pattern[index] = Convert.ToByte(str, 16 /*0x10*/);
            ignore00[index] = false;
            break;
        }
      }
      List<CRIMEPANEL.MEMORY_BASIC_INFORMATION> basicInformationList = new List<CRIMEPANEL.MEMORY_BASIC_INFORMATION>();
      UIntPtr lpAddress = new UIntPtr((ulong) start);
      CRIMEPANEL.SYSTEM_INFO lpSystemInfo = new CRIMEPANEL.SYSTEM_INFO();
      CRIMEPANEL.GetSystemInfo(out lpSystemInfo);
      UIntPtr applicationAddress1 = lpSystemInfo.minimumApplicationAddress;
      UIntPtr applicationAddress2 = lpSystemInfo.maximumApplicationAddress;
      if (start < (long) applicationAddress1.ToUInt64())
        start = (long) applicationAddress1.ToUInt64();
      if (end > (long) applicationAddress2.ToUInt64())
        end = (long) applicationAddress2.ToUInt64();
      CRIMEPANEL.MEMORY_BASIC_INFORMATION lpBuffer1;
      for (; this.VirtualQueryEx(this.pHandle, lpAddress, out lpBuffer1) != UIntPtr.Zero && lpAddress.ToUInt64() < (ulong) end; lpAddress = new UIntPtr(lpAddress.ToUInt64() + (ulong) lpBuffer1.RegionSize))
      {
        if (lpBuffer1.State == 4096U /*0x1000*/ && ((int) lpBuffer1.Protect & 256 /*0x0100*/) == 0 && ((int) lpBuffer1.Protect & 1) == 0)
        {
          int num1 = (lpBuffer1.Protect & 2U) > 0U & readable ? 1 : 0;
          bool flag1 = (lpBuffer1.Protect & 4U) > 0U & writable;
          bool flag2 = (lpBuffer1.Protect & 32U /*0x20*/) > 0U & executable;
          int num2 = flag1 ? 1 : 0;
          if ((num1 | num2 | (flag2 ? 1 : 0)) != 0)
            basicInformationList.Add(lpBuffer1);
        }
      }
      List<Task> taskList = new List<Task>();
      foreach (CRIMEPANEL.MEMORY_BASIC_INFORMATION basicInformation in basicInformationList)
      {
        CRIMEPANEL.MEMORY_BASIC_INFORMATION region = basicInformation;
        taskList.Add(Task.Run((Action) (() =>
        {
          byte[] lpBuffer2 = new byte[(int) region.RegionSize];
          if (!CRIMEPANEL.ReadProcessMemory(this.pHandle, region.BaseAddress, lpBuffer2, (UIntPtr) (ulong) region.RegionSize, IntPtr.Zero))
            return;
          for (long index3 = 0; index3 < region.RegionSize - (long) pattern.Length; ++index3)
          {
            bool flag = true;
            for (int index4 = 0; index4 < pattern.Length; ++index4)
            {
              if (mask[index4] != (byte) 0 && (int) lpBuffer2[index3 + (long) index4] != ((int) pattern[index4] & (int) mask[index4]))
              {
                flag = false;
                break;
              }
              if (ignore00[index4] && lpBuffer2[index3 + (long) index4] == (byte) 0)
              {
                flag = false;
                break;
              }
            }
            if (flag)
            {
              long key = (long) (ulong) region.BaseAddress + index3;
              int num = (int) lpBuffer2[index3];
              lock (this.repeat)
              {
                if (this.repeat.ContainsKey(key))
                {
                  if (this.repeat[key] == num)
                    continue;
                }
                this.repeat[key] = num;
                lock (foundAddresses)
                  foundAddresses.Add(key);
              }
            }
          }
        })));
      }
      await Task.WhenAll((IEnumerable<Task>) taskList);
      return foundAddresses.AsEnumerable<long>();
    }));
  }

  public string MSize() => !this.Is64Bit ? "x8" : "x16";

  public void CloseProcess()
  {
    IntPtr pHandle = this.pHandle;
    if (false)
      return;
    CRIMEPANEL.CloseHandle(this.pHandle);
    this.theProc = (Process) null;
  }

  public bool Is64Bit
  {
    get => this._is64Bit;
    private set => this._is64Bit = value;
  }

  private unsafe long[] CompareScan(MemoryRegionResult item, byte[] aobPattern, byte[] mask)
  {
    if (mask.Length != aobPattern.Length)
      throw new ArgumentException("aobPattern.Length != mask.Length");
    IntPtr num1 = Marshal.AllocHGlobal((int) item.RegionSize);
    ulong lpNumberOfBytesRead;
    CRIMEPANEL.ReadProcessMemory(this.pHandle, item.CurrentBaseAddress, num1, (UIntPtr) (ulong) item.RegionSize, out lpNumberOfBytesRead);
    int num2 = -aobPattern.Length;
    List<long> longList = new List<long>();
    do
    {
      num2 = this.FindPattern((byte*) num1.ToPointer(), (int) lpNumberOfBytesRead, aobPattern, mask, num2 + aobPattern.Length);
      if (num2 >= 0)
        longList.Add((long) (ulong) item.CurrentBaseAddress + (long) num2);
    }
    while (num2 != -1);
    Marshal.FreeHGlobal(num1);
    return longList.ToArray();
  }

  private unsafe int FindPattern(
    byte* body,
    int bodyLength,
    byte[] pattern,
    byte[] masks,
    int start = 0)
  {
    int num = -1;
    int pattern1;
    if ((bodyLength <= 0 || pattern.Length == 0 || start > bodyLength - pattern.Length ? 1 : (pattern.Length > bodyLength ? 1 : 0)) != 0)
    {
      pattern1 = num;
    }
    else
    {
      for (int index1 = start; index1 <= bodyLength - pattern.Length; ++index1)
      {
        if (((int) body[index1] & (int) masks[0]) == ((int) pattern[0] & (int) masks[0]))
        {
          bool flag = true;
          for (int index2 = 1; index2 <= pattern.Length - 1; ++index2)
          {
            if (((int) body[index1 + index2] & (int) masks[index2]) != ((int) pattern[index2] & (int) masks[index2]))
            {
              flag = false;
              break;
            }
          }
          if (flag)
          {
            num = index1;
            break;
          }
        }
      }
      pattern1 = num;
    }
    return pattern1;
  }

  public UIntPtr VirtualQueryEx(
    IntPtr hProcess,
    UIntPtr lpAddress,
    out CRIMEPANEL.MEMORY_BASIC_INFORMATION lpBuffer)
  {
    UIntPtr num1;
    if ((this.Is64Bit ? 1 : (IntPtr.Size == 8 ? 1 : 0)) != 0)
    {
      CRIMEPANEL.MEMORY_BASIC_INFORMATION64 lpBuffer1 = new CRIMEPANEL.MEMORY_BASIC_INFORMATION64();
      UIntPtr num2 = CRIMEPANEL.Native_VirtualQueryEx(hProcess, lpAddress, out lpBuffer1, new UIntPtr((uint) Marshal.SizeOf<CRIMEPANEL.MEMORY_BASIC_INFORMATION64>(lpBuffer1)));
      lpBuffer.BaseAddress = lpBuffer1.BaseAddress;
      lpBuffer.AllocationBase = lpBuffer1.AllocationBase;
      lpBuffer.AllocationProtect = lpBuffer1.AllocationProtect;
      lpBuffer.RegionSize = (long) lpBuffer1.RegionSize;
      lpBuffer.State = lpBuffer1.State;
      lpBuffer.Protect = lpBuffer1.Protect;
      lpBuffer.Type = lpBuffer1.Type;
      num1 = num2;
    }
    else
    {
      CRIMEPANEL.MEMORY_BASIC_INFORMATION32 lpBuffer2 = new CRIMEPANEL.MEMORY_BASIC_INFORMATION32();
      UIntPtr num3 = CRIMEPANEL.Native_VirtualQueryEx(hProcess, lpAddress, out lpBuffer2, new UIntPtr((uint) Marshal.SizeOf<CRIMEPANEL.MEMORY_BASIC_INFORMATION32>(lpBuffer2)));
      lpBuffer.BaseAddress = lpBuffer2.BaseAddress;
      lpBuffer.AllocationBase = lpBuffer2.AllocationBase;
      lpBuffer.AllocationProtect = lpBuffer2.AllocationProtect;
      lpBuffer.RegionSize = (long) lpBuffer2.RegionSize;
      lpBuffer.State = lpBuffer2.State;
      lpBuffer.Protect = lpBuffer2.Protect;
      lpBuffer.Type = lpBuffer2.Type;
      num1 = num3;
    }
    return num1;
  }

  public static void notify(string message)
  {
    Process.Start(new ProcessStartInfo("cmd.exe", $"/c start cmd /C \"color b && title Error && echo {message} && timeout /t 5\"")
    {
      CreateNoWindow = true,
      RedirectStandardOutput = true,
      RedirectStandardError = true,
      UseShellExecute = false
    });
    Environment.Exit(0);
  }

  public UIntPtr Get64BitCode(string name, string path = "", int size = 16 /*0x10*/)
  {
    string str1 = !(path != "") ? name : this.LoadCode(name, path);
    UIntPtr num1;
    if (str1 == "")
    {
      num1 = UIntPtr.Zero;
    }
    else
    {
      if (str1.Contains(" "))
        str1.Replace(" ", string.Empty);
      string source = str1;
      if (str1.Contains("+"))
        source = str1.Substring(str1.IndexOf('+') + 1);
      byte[] lpBuffer = new byte[size];
      if ((str1.Contains("+") ? 0 : (!str1.Contains(",") ? 1 : 0)) != 0)
        num1 = new UIntPtr(Convert.ToUInt64(str1, 16 /*0x10*/));
      else if (source.Contains<char>(','))
      {
        List<long> longList = new List<long>();
        string str2 = source;
        char[] chArray = new char[1]{ ',' };
        foreach (string str3 in str2.Split(chArray))
        {
          string s = str3;
          if (str3.Contains("0x"))
            s = str3.Replace("0x", "");
          long num2 = str3.Contains("-") ? long.Parse(s.Replace("-", ""), NumberStyles.AllowHexSpecifier) * -1L : long.Parse(s, NumberStyles.AllowHexSpecifier);
          longList.Add(num2);
        }
        long[] array = longList.ToArray();
        if ((str1.Contains("base") ? 1 : (str1.Contains("main") ? 1 : 0)) != 0)
          CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) ((long) this.mainModule.BaseAddress + array[0]), lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
        else if ((str1.Contains("base") || str1.Contains("main") ? 0 : (str1.Contains("+") ? 1 : 0)) != 0)
        {
          string[] strArray = str1.Split('+');
          IntPtr num3 = IntPtr.Zero;
          if ((strArray[0].ToLower().Contains(".dll") || strArray[0].ToLower().Contains(".exe") ? 0 : (!strArray[0].ToLower().Contains(".bin") ? 1 : 0)) != 0)
          {
            num3 = (IntPtr) long.Parse(strArray[0], NumberStyles.HexNumber);
          }
          else
          {
            try
            {
              num3 = this.modules[strArray[0]];
            }
            catch
            {
            }
          }
          CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) ((long) num3 + array[0]), lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
        }
        else
          CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) array[0], lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
        long int64 = BitConverter.ToInt64(lpBuffer, 0);
        UIntPtr lpBaseAddress = (UIntPtr) 0UL;
        for (int index = 1; index < array.Length; ++index)
        {
          lpBaseAddress = new UIntPtr(Convert.ToUInt64(int64 + array[index]));
          CRIMEPANEL.ReadProcessMemory(this.pHandle, lpBaseAddress, lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
          int64 = BitConverter.ToInt64(lpBuffer, 0);
        }
        num1 = lpBaseAddress;
      }
      else
      {
        long int64 = Convert.ToInt64(source, 16 /*0x10*/);
        IntPtr num4 = IntPtr.Zero;
        if ((str1.Contains("base") ? 1 : (str1.Contains("main") ? 1 : 0)) != 0)
          num4 = this.mainModule.BaseAddress;
        else if ((str1.Contains("base") || str1.Contains("main") ? 0 : (str1.Contains("+") ? 1 : 0)) != 0)
        {
          string[] strArray = str1.Split('+');
          if ((strArray[0].ToLower().Contains(".dll") || strArray[0].ToLower().Contains(".exe") ? 0 : (!strArray[0].ToLower().Contains(".bin") ? 1 : 0)) != 0)
          {
            string s = strArray[0];
            if (s.Contains("0x"))
              s = s.Replace("0x", "");
            num4 = (IntPtr) long.Parse(s, NumberStyles.HexNumber);
          }
          else
          {
            try
            {
              num4 = this.modules[strArray[0]];
            }
            catch
            {
            }
          }
        }
        else
          num4 = this.modules[str1.Split('+')[0]];
        num1 = (UIntPtr) (ulong) ((long) num4 + int64);
      }
    }
    return num1;
  }

  public UIntPtr GetCode(string name, string path = "", int size = 8)
  {
    UIntPtr code;
    if (this.Is64Bit)
    {
      if (size == 8)
        size = 16 /*0x10*/;
      code = this.Get64BitCode(name, path, size);
    }
    else
    {
      string str1 = !(path != "") ? name : this.LoadCode(name, path);
      if (str1 == "")
      {
        code = UIntPtr.Zero;
      }
      else
      {
        if (str1.Contains(" "))
          str1.Replace(" ", string.Empty);
        if ((str1.Contains("+") ? 0 : (!str1.Contains(",") ? 1 : 0)) != 0)
        {
          code = new UIntPtr(Convert.ToUInt32(str1, 16 /*0x10*/));
        }
        else
        {
          string source = str1;
          if (str1.Contains("+"))
            source = str1.Substring(str1.IndexOf('+') + 1);
          byte[] lpBuffer = new byte[size];
          if (source.Contains<char>(','))
          {
            List<int> intList = new List<int>();
            string str2 = source;
            char[] chArray = new char[1]{ ',' };
            foreach (string str3 in str2.Split(chArray))
            {
              string s = str3;
              if (str3.Contains("0x"))
                s = str3.Replace("0x", "");
              int num = str3.Contains("-") ? int.Parse(s.Replace("-", ""), NumberStyles.AllowHexSpecifier) * -1 : int.Parse(s, NumberStyles.AllowHexSpecifier);
              intList.Add(num);
            }
            int[] array = intList.ToArray();
            if ((str1.Contains("base") ? 1 : (str1.Contains("main") ? 1 : 0)) != 0)
              CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) ((int) this.mainModule.BaseAddress + array[0]), lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
            else if ((str1.Contains("base") || str1.Contains("main") ? 0 : (str1.Contains("+") ? 1 : 0)) != 0)
            {
              string[] strArray = str1.Split('+');
              IntPtr num = IntPtr.Zero;
              if ((strArray[0].ToLower().Contains(".dll") || strArray[0].ToLower().Contains(".exe") ? 0 : (!strArray[0].ToLower().Contains(".bin") ? 1 : 0)) != 0)
              {
                string s = strArray[0];
                if (s.Contains("0x"))
                  s = s.Replace("0x", "");
                num = (IntPtr) int.Parse(s, NumberStyles.HexNumber);
              }
              else
              {
                try
                {
                  num = this.modules[strArray[0]];
                }
                catch
                {
                }
              }
              CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) ((int) num + array[0]), lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
            }
            else
              CRIMEPANEL.ReadProcessMemory(this.pHandle, (UIntPtr) (ulong) array[0], lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
            uint uint32 = BitConverter.ToUInt32(lpBuffer, 0);
            UIntPtr lpBaseAddress = (UIntPtr) 0UL;
            for (int index = 1; index < array.Length; ++index)
            {
              lpBaseAddress = new UIntPtr(Convert.ToUInt32((long) uint32 + (long) array[index]));
              CRIMEPANEL.ReadProcessMemory(this.pHandle, lpBaseAddress, lpBuffer, (UIntPtr) (ulong) size, IntPtr.Zero);
              uint32 = BitConverter.ToUInt32(lpBuffer, 0);
            }
            code = lpBaseAddress;
          }
          else
          {
            int int32 = Convert.ToInt32(source, 16 /*0x10*/);
            IntPtr num = IntPtr.Zero;
            if ((str1.ToLower().Contains("base") ? 1 : (str1.ToLower().Contains("main") ? 1 : 0)) != 0)
              num = this.mainModule.BaseAddress;
            else if ((str1.ToLower().Contains("base") || str1.ToLower().Contains("main") ? 0 : (str1.Contains("+") ? 1 : 0)) != 0)
            {
              string[] strArray = str1.Split('+');
              if ((strArray[0].ToLower().Contains(".dll") || strArray[0].ToLower().Contains(".exe") ? 0 : (!strArray[0].ToLower().Contains(".bin") ? 1 : 0)) != 0)
              {
                string s = strArray[0];
                if (s.Contains("0x"))
                  s = s.Replace("0x", "");
                num = (IntPtr) int.Parse(s, NumberStyles.HexNumber);
              }
              else
              {
                try
                {
                  num = this.modules[strArray[0]];
                }
                catch
                {
                }
              }
            }
            else
              num = this.modules[str1.Split('+')[0]];
            code = (UIntPtr) (ulong) ((int) num + int32);
          }
        }
      }
    }
    return code;
  }

  public bool WriteMemory(
    string code,
    string type,
    string write,
    string file = "",
    Encoding stringEncoding = null)
  {
    byte[] lpBuffer = new byte[4];
    int nSize = 4;
    UIntPtr code1 = this.GetCode(code, file);
    if (type.ToLower() == "float")
    {
      lpBuffer = BitConverter.GetBytes(Convert.ToSingle(write));
      nSize = 4;
    }
    else if (type.ToLower() == "int")
    {
      lpBuffer = BitConverter.GetBytes(Convert.ToInt32(write));
      nSize = 4;
    }
    else if (type.ToLower() == "byte")
    {
      lpBuffer = new byte[1]
      {
        Convert.ToByte(write, 16 /*0x10*/)
      };
      nSize = 1;
    }
    else if (type.ToLower() == "2bytes")
    {
      lpBuffer = new byte[2]
      {
        (byte) (Convert.ToInt32(write) % 256 /*0x0100*/),
        (byte) (Convert.ToInt32(write) / 256 /*0x0100*/)
      };
      nSize = 2;
    }
    else if (type.ToLower() == "bytes")
    {
      if ((write.Contains(",") ? 1 : (write.Contains(" ") ? 1 : 0)) != 0)
      {
        string[] source;
        if (write.Contains(","))
          source = write.Split(',');
        else
          source = write.Split(' ');
        int length = ((IEnumerable<string>) source).Count<string>();
        lpBuffer = new byte[length];
        for (int index = 0; index < length; ++index)
          lpBuffer[index] = Convert.ToByte(source[index], 16 /*0x10*/);
        nSize = ((IEnumerable<string>) source).Count<string>();
      }
      else
      {
        lpBuffer = new byte[1]
        {
          Convert.ToByte(write, 16 /*0x10*/)
        };
        nSize = 1;
      }
    }
    else if (type.ToLower() == "double")
    {
      lpBuffer = BitConverter.GetBytes(Convert.ToDouble(write));
      nSize = 8;
    }
    else if (type.ToLower() == "long")
    {
      lpBuffer = BitConverter.GetBytes(Convert.ToInt64(write));
      nSize = 8;
    }
    else if (type.ToLower() == "string")
    {
      lpBuffer = stringEncoding != null ? stringEncoding.GetBytes(write) : Encoding.UTF8.GetBytes(write);
      nSize = lpBuffer.Length;
    }
    return CRIMEPANEL.WriteProcessMemory(this.pHandle, code1, lpBuffer, (UIntPtr) (ulong) nSize, IntPtr.Zero);
  }

  public bool IsAdmin()
  {
    using (WindowsIdentity current = WindowsIdentity.GetCurrent())
      return new WindowsPrincipal(current).IsInRole(WindowsBuiltInRole.Administrator);
  }

  public bool OpenProcess(int pid)
  {
    if (!this.IsAdmin())
      CRIMEPANEL.notify("WARNING: You are NOT running this program as admin! For More Help Visit https://discord.gg/emmWnPRrYX");
    bool flag;
    if (pid <= 0)
      flag = false;
    else if ((this.theProc == null ? 0 : (this.theProc.Id == pid ? 1 : 0)) != 0)
    {
      flag = true;
    }
    else
    {
      try
      {
        this.theProc = Process.GetProcessById(pid);
        if ((this.theProc == null ? 0 : (!this.theProc.Responding ? 1 : 0)) != 0)
        {
          flag = false;
        }
        else
        {
          this.pHandle = CRIMEPANEL.OpenProcess(2035711U, true, pid);
          Process.EnterDebugMode();
          if (this.pHandle == IntPtr.Zero)
          {
            Process.LeaveDebugMode();
            this.theProc = (Process) null;
            flag = false;
          }
          else
          {
            this.mainModule = this.theProc.MainModule;
            this.GetModules();
            bool lpSystemInfo;
            this.Is64Bit = Environment.Is64BitOperatingSystem && CRIMEPANEL.IsWow64Process(this.pHandle, out lpSystemInfo) && !lpSystemInfo;
            Process theProc = this.theProc;
            flag = true;
          }
        }
      }
      catch
      {
        flag = false;
      }
    }
    return flag;
  }

  public void GetModules()
  {
    if (this.theProc == null)
      return;
    this.modules.Clear();
    foreach (ProcessModule module in (ReadOnlyCollectionBase) this.theProc.Modules)
    {
      if ((string.IsNullOrEmpty(module.ModuleName) ? 0 : (!this.modules.ContainsKey(module.ModuleName) ? 1 : 0)) != 0)
        this.modules.Add(module.ModuleName, module.BaseAddress);
    }
  }

  public Task<IEnumerable<long>> AoBScan2(
    string search,
    bool writable = false,
    bool executable = false,
    string file = "")
  {
    return this.AoBScan(0L, long.MaxValue, search, writable, executable, file);
  }

  public Task<IEnumerable<long>> AoBScan(
    long start,
    long end,
    string search,
    bool writable,
    bool executable,
    string file = "")
  {
    return this.AoBScanMultithreadedWithTasks(start, end, search, true, writable, executable, file);
  }

  public bool ChangeProtection(
    string code,
    CRIMEPANEL.MemoryProtection newProtection,
    out CRIMEPANEL.MemoryProtection oldProtection,
    string file = "")
  {
    UIntPtr code1 = this.GetCode(code, file);
    bool flag;
    if ((code1 == UIntPtr.Zero ? 1 : (this.pHandle == IntPtr.Zero ? 1 : 0)) != 0)
    {
      oldProtection = (CRIMEPANEL.MemoryProtection) 0;
      flag = false;
    }
    else
      flag = CRIMEPANEL.VirtualProtectEx(this.pHandle, code1, (IntPtr) (this.Is64Bit ? 8 : 4), newProtection, out oldProtection);
    return flag;
  }

  internal async Task<IEnumerable<long>> AoBScan(string v) => throw new NotImplementedException();

  internal void AobReplace(long id, string v) => throw new NotImplementedException();

  internal bool SetProcess(string[] processName) => throw new NotImplementedException();

  [Flags]
  public enum ThreadAccess
  {
    TERMINATE = 1,
    SUSPEND_RESUME = 2,
    GET_CONTEXT = 8,
    SET_CONTEXT = 16, // 0x00000010
    SET_INFORMATION = 32, // 0x00000020
    QUERY_INFORMATION = 64, // 0x00000040
    SET_THREAD_TOKEN = 128, // 0x00000080
    IMPERSONATE = 256, // 0x00000100
    DIRECT_IMPERSONATION = 512, // 0x00000200
  }

  public struct MEMORY_BASIC_INFORMATION32
  {
    public UIntPtr BaseAddress;
    public UIntPtr AllocationBase;
    public uint AllocationProtect;
    public uint RegionSize;
    public uint State;
    public uint Protect;
    public uint Type;
  }

  public struct MEMORY_BASIC_INFORMATION64
  {
    public UIntPtr BaseAddress;
    public UIntPtr AllocationBase;
    public uint AllocationProtect;
    public uint __alignment1;
    public ulong RegionSize;
    public uint State;
    public uint Protect;
    public uint Type;
    public uint __alignment2;
  }

  [Flags]
  public enum MemoryProtection : uint
  {
    Execute = 16, // 0x00000010
    ExecuteRead = 32, // 0x00000020
    ExecuteReadWrite = 64, // 0x00000040
    ExecuteWriteCopy = 128, // 0x00000080
    NoAccess = 1,
    ReadOnly = 2,
    ReadWrite = 4,
    WriteCopy = 8,
    GuardModifierflag = 256, // 0x00000100
    NoCacheModifierflag = 512, // 0x00000200
    WriteCombineModifierflag = 1024, // 0x00000400
  }

  public struct SYSTEM_INFO
  {
    public ushort processorArchitecture;
    private ushort reserved;
    public uint pageSize;
    public UIntPtr minimumApplicationAddress;
    public UIntPtr maximumApplicationAddress;
    public IntPtr activeProcessorMask;
    public uint numberOfProcessors;
    public uint processorType;
    public uint allocationGranularity;
    public ushort processorLevel;
    public ushort processorRevision;
  }

  public struct MEMORY_BASIC_INFORMATION
  {
    public UIntPtr BaseAddress;
    public UIntPtr AllocationBase;
    public uint AllocationProtect;
    public long RegionSize;
    public uint State;
    public uint Protect;
    public uint Type;
  }
}
