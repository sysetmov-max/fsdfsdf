﻿// Decompiled with JetBrains decompiler
// Type: ERA_XITERS.UI
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using CRIME;
using Gma.System.MouseKeyHook;
using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using MagıcMemory;
using NAZMUL;
using Nazmulscope;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace ERA_XITERS;

public class UI : Form
{
  private NAZMULEXE NAZMUL = new NAZMULEXE();
  private const int HOTKEY_ID = 9000;
  private bool isListening;
  private int customKey;
  private const int WH_KEYBOARD_LL = 13;
  private const int WM_KEYDOWN = 256 /*0x0100*/;
  private IntPtr hookID = IntPtr.Zero;
  private UI.LowLevelKeyboardProc hookCallback;
  private Dictionary<Guna2Button, Keys> keyBindings = new Dictionary<Guna2Button, Keys>();
  private Dictionary<Guna2Button, Guna2ToggleSwitch> toggleMapping = new Dictionary<Guna2Button, Guna2ToggleSwitch>();
  private Guna2Button waitingForKeyButton;
  private const int WS_EX_TOOLWINDOW = 128 /*0x80*/;
  private const int SW_HIDE = 0;
  private const int SW_SHOW = 5;
  private const int GWL_EXSTYLE = -20;
  private const int WS_EX_LAYERED = 524288 /*0x080000*/;
  private const int WS_EX_TRANSPARENT = 32 /*0x20*/;
  private const uint LWA_ALPHA = 2;
  private Size originalButtonSize;
  private Point originalButtonLocation;
  private System.Windows.Forms.Timer clickAnimationTimer;
  private float clickAnimationRatio;
  private const float clickAnimationSpeed = 0.25f;
  private Color originalBackColor;
  private Color originalForeColor;
  private bool isClickAnimationActive;
  private static MagıcMemory31 magıcMemory = new MagıcMemory31();
  private string AimbotScan = "FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FF FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 A5 43";
  private string headoffset = "0xDA";
  private string chestoffset = "0xA6";
  private Dictionary<long, int> OrginalValues1 = new Dictionary<long, int>();
  private Dictionary<long, int> OrginalValues2 = new Dictionary<long, int>();
  private Dictionary<long, int> OrginalValues3 = new Dictionary<long, int>();
  private Dictionary<long, int> OrginalValues4 = new Dictionary<long, int>();
  private List<long> foundAddresses6262;
  private string originalPattern6262 = "";
  private string replacePattern6262 = "";
  private bool isModified6262;
  private bool isFirstClick6262 = true;
  private List<long> aimbotBaseAddresses = new List<long>();
  private long readOffset;
  private long writeOffset;
  private bool isAimbotActive;
  private UI ui;
  private static CRIMEPANEL CRIME = new CRIMEPANEL();
  internal static readonly object KeyAuthApp;
  private NAZMULEXE MemLib = new NAZMULEXE();
  private List<long> speed = new List<long>();
  private List<string> srchspeed = new List<string>()
  {
    "02 2B 07 3D 02 2B 07 3D 02 2B 07 3D 00 00 00 00 9B 6C F2 41"
  };
  private List<string> replacespeed = new List<string>()
  {
    "E3 A5 9B 3C E3 A5 9B 3C 02 2B 07 3D 00 00 00 00 9B 6C F2 41"
  };
  private string camScan = "00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 80 7f 00 00 80 7f 00 00 80 7f 00 00 80 ff";
  private string camReplace = "00 00 00 00 22 9E 93 40 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF";
  private List<long> camAddresses = new List<long>();
  private bool isCamActive;
  private bool isWaitingForKey;
  private Keys camHotkey;
  private const int WM_NCLBUTTONDOWN = 161;
  private const int HTCAPTION = 2;
  private HttpListener _webListener;
  private readonly object _webLock = new object();
  private readonly List<string> _webLogs = new List<string>();
  private const uint PROCESS_CREATE_THREAD = 2;
  private const uint PROCESS_QUERY_INFORMATION = 1024 /*0x0400*/;
  private const uint PROCESS_VM_OPERATION = 8;
  private const uint PROCESS_VM_WRITE = 32 /*0x20*/;
  private const uint PROCESS_VM_READ = 16 /*0x10*/;
  private const uint MEM_COMMIT = 4096 /*0x1000*/;
  private const uint PAGE_READWRITE = 4;
  private List<long> sniperScopeAddresses = new List<long>();
  private string sniperScopeoriginalBytes = "CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F";
  private string patchedBytes = "CC 3D 06 00 00 00 00 00 FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 80 80 3F";
  private nazmulexe nazmulscope = new nazmulexe();
  private string[] processname = new string[1]
  {
    "HD-Player"
  };
  private IKeyboardMouseEvents globalHook;
  private System.Windows.Forms.Timer sniperTimeoutTimer;
  private DateTime lastToggleTime;
  private bool isSniperScopeOn;
  private bool isListeningForKey;
  private Keys toggleKey;
  private MouseButtons toggleMouseButton;
  private int toggleWheelDirection;
  private DateTime lastToggleAttempt = DateTime.MinValue;
  private readonly int toggleCooldownMs = 200;
  private static string GTC;
  public static bool Streaming;
  private object memoryfast;
  private object PID;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2Button guna2Button1;
  private Guna2Panel mainpnl;
  private Guna2HtmlLabel keybind;
  private Guna2HtmlLabel exploits;
  private Guna2HtmlLabel esp;
  private Guna2HtmlLabel main;
  private Guna2HtmlLabel hooked;
  private Guna2DragControl guna2DragControl1;
  private Guna2Panel panel1;
  private Guna2Panel panel5;
  private Guna2Panel panel3;
  private Guna2Panel panel4;
  private Guna2Panel panel2;
  private Guna2Panel guna2Panel1;
  private Label label1;
  private Label label2;
  private Guna2Panel guna2Panel6;
  private Label label5;
  private Label label4;
  private Guna2Panel guna2Panel5;
  private Label label11;
  private Label label12;
  private Guna2Panel guna2Panel4;
  private Label label9;
  private Label label10;
  private Guna2Panel guna2Panel3;
  private Label label7;
  private Label label8;
  private Guna2Panel guna2Panel2;
  private Label label3;
  private Label label6;
  private Guna2Button keybind1;
  private Guna2Panel guna2Panel10;
  private Label label20;
  private Guna2Panel guna2Panel9;
  private Label label18;
  private Guna2Panel guna2Panel8;
  private Guna2ToggleSwitch guna2ToggleSwitch6;
  private Label label16;
  private Guna2Panel guna2Panel7;
  private Guna2ToggleSwitch guna2ToggleSwitch5;
  private Label label14;
  private Guna2Panel guna2Panel11;
  private Guna2Button guna2Button6;
  private Label label21;
  private Label label22;
  private Guna2Panel guna2Panel12;
  private Label label23;
  private Label label24;
  private Guna2Panel guna2Panel13;
  private Label label25;
  private Label label26;
  private Guna2Panel guna2Panel14;
  private Label label27;
  private Label label28;
  private Guna2Button guna2Button7;
  private Guna2Button guna2Button8;
  private Guna2Button guna2Button9;
  private Label status1;
  private Guna2Button guna2Button15;
  private Guna2ToggleSwitch guna2ToggleSwitch1;
  private Guna2ToggleSwitch guna2ToggleSwitch8;
  private Guna2Panel guna2Panel19;
  private Guna2CirclePictureBox guna2CirclePictureBox1;
  private Guna2HtmlLabel guna2HtmlLabel2;
  private Guna2HtmlLabel guna2HtmlLabel1;
  private Guna2Button guna2Button3;
  private Guna2Panel guna2Panel15;
  private Label label19;
  private Label label29;
  private Guna2Panel guna2Panel16;
  private Label label30;
  private Label label31;
  private Guna2Button guna2Button5;
  private Guna2Button guna2Button4;
  private Guna2Panel guna2Panel17;
  private Label label32;
  private Label label33;
  private Guna2CustomCheckBox guna2CustomCheckBox10;
  private Guna2Panel guna2Panel18;
  private Guna2Button C;
  private Label label34;
  private Label label35;
  private Guna2Panel guna2Panel20;
  private Label label36;
  private Label label38;
  private Label label37;
  private Guna2Button guna2Button11;
  private Guna2Button guna2Button10;
  private Guna2Panel guna2Panel21;
  private Guna2CustomCheckBox guna2CustomCheckBox1;
  private Label label39;
  private Label label40;
  private Guna2ToggleSwitch guna2ToggleSwitch2;
  private Guna2Button h2;
  private Guna2Panel guna2Panel22;
  private Label label41;
  private Label label42;
  private Guna2Button guna2Button12;
  private Guna2ToggleSwitch guna2ToggleSwitch10;
  private Guna2Button guna2Button2;
  private Guna2Panel guna2Panel23;
  private Label label43;
  private Label label44;
  private Guna2Panel guna2Panel25;
  private Guna2ToggleSwitch guna2ToggleSwitch12;
  private Label label15;
  private Guna2Panel guna2Panel24;
  private Guna2ToggleSwitch guna2ToggleSwitch11;
  private Label label13;
  private Guna2Panel guna2Panel26;
  private Guna2Button guna2Button14;
  private Label label17;
  private Label label45;
  private Guna2Panel guna2Panel27;
  private Guna2CustomCheckBox guna2CustomCheckBox2;
  private Label label46;
  private Label label47;
  private PictureBox qrPictureBox;
  private Guna2Button h1;
  private System.Windows.Forms.Timer hotkeyTimer;
  private Guna2ToggleSwitch guna2ToggleSwitch13;
  private Label label49;
  private Label label48;
  private Guna2Button guna2Button13;
  private Guna2HtmlLabel guna2HtmlLabel4;
  private Guna2HtmlLabel guna2HtmlLabel3;
  private Guna2Button guna2Button16;
  private Guna2Button guna2Button17;
  private Guna2Button guna2Button18;
  private Guna2Button guna2Button19;
  private Label lblExpiry;
  private Label lblUser;

  [DllImport("user32.dll")]
  private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

  [DllImport("user32.dll")]
  private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

  [DllImport("user32.dll")]
  public static extern short GetAsyncKeyState(int vKey);

  [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
  private static extern IntPtr SetWindowsHookEx(
    int idHook,
    UI.LowLevelKeyboardProc lpfn,
    IntPtr hMod,
    uint dwThreadId);

  [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
  [return: MarshalAs(UnmanagedType.Bool)]
  private static extern bool UnhookWindowsHookEx(IntPtr hhk);

  [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
  private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

  protected override void WndProc(ref Message m)
  {
    base.WndProc(ref m);
    if (m.Msg != 786 || m.WParam.ToInt32() != 9000)
      return;
    this.ExecuteCameraHack();
  }

  [DllImport("kernel32.dll")]
  private static extern IntPtr GetConsoleWindow();

  [DllImport("user32.dll")]
  private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

  [DllImport("user32.dll")]
  public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

  [DllImport("user32.dll")]
  public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

  [DllImport("user32.dll")]
  public static extern bool SetLayeredWindowAttributes(
    IntPtr hwnd,
    uint crKey,
    byte bAlpha,
    uint dwFlags);

  public UI()
  {
    this.InitializeComponent();
    this.KeyPreview = true;
    this.KeyDown += new KeyEventHandler(this.UI_KeyDown);
    this.KeyDown += new KeyEventHandler(this.Manual_KeyDown);
    this.KeyPreview = true;
    this.KeyPreview = true;
    this.hotkeyTimer.Interval = 50;
    this.hotkeyTimer.Start();
    this.hookCallback = new UI.LowLevelKeyboardProc(this.HookCallback);
    Application.ApplicationExit += new EventHandler(this.Application_ApplicationExit);
    this.keyBindings[this.h2] = Keys.None;
    this.toggleMapping[this.h2] = this.guna2ToggleSwitch2;
    this.FormBorderStyle = FormBorderStyle.None;
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Opacity = 0.9;
    this.SetActiveButton((Control) this.hooked);
  }

  protected override void OnHandleCreated(EventArgs e)
  {
    base.OnHandleCreated(e);
    try
    {
      UI.SetWindowLong(this.Handle, -20, UI.GetWindowLong(this.Handle, -20) | 524288 /*0x080000*/);
      UI.SetLayeredWindowAttributes(this.Handle, 0U, (byte) 230, 2U);
    }
    catch (Exception ex)
    {
    }
  }

  [DllImport("user32.dll")]
  private static extern bool ReleaseCapture();

  [DllImport("user32.dll")]
  private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

  private void DragForm_MouseDown(object sender, MouseEventArgs e)
  {
    if (e.Button != MouseButtons.Left)
      return;
    UI.ReleaseCapture();
    UI.SendMessage(this.Handle, 161, 2, 0);
  }

  private void GenerateOfflineQRCode()
  {
  }

  private void SetActiveButton(Control activeButton)
  {
    ((Control) this.hooked).ForeColor = Color.Gray;
    ((Control) this.main).ForeColor = Color.Gray;
    ((Control) this.esp).ForeColor = Color.Gray;
    ((Control) this.exploits).ForeColor = Color.Gray;
    ((Control) this.keybind).ForeColor = Color.Gray;
    activeButton.ForeColor = Color.White;
  }

  private void hooked_Click(object sender, EventArgs e)
  {
    this.SetActiveButton((Control) this.hooked);
    ((Control) this.panel1).BringToFront();
  }

  private void main_Click(object sender, EventArgs e)
  {
    this.SetActiveButton((Control) this.main);
    ((Control) this.panel2).BringToFront();
  }

  private void esp_Click(object sender, EventArgs e)
  {
    this.SetActiveButton((Control) this.esp);
    ((Control) this.panel3).BringToFront();
  }

  private void exploits_Click(object sender, EventArgs e)
  {
    this.SetActiveButton((Control) this.exploits);
    ((Control) this.panel4).BringToFront();
  }

  private void keybind_Click(object sender, EventArgs e)
  {
    this.SetActiveButton((Control) this.keybind);
    ((Control) this.panel5).BringToFront();
  }

  private async void guna2ToggleSwitch1_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void label37_Click(object sender, EventArgs e)
  {
  }

  private async void guna2Button6_Click(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "Anti-Cheats : Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string fastReloadReplace;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Error: Open Emulator!";
      this.status1.ForeColor = Color.Red;
      fastReloadReplace = (string) null;
    }
    else
    {
      string bytePattern = "04 00 A0 E1 0A 00 00 EB 00 50 A0 E1 04 00 A0 E1 99 10 A0 E3 6D 00 00 EB 00 0A B7 EE 10 0A 01 EE 00 0A 31 EE 10 5A 01 EE 00 0A 21 EE 10 0A 10 EE";
      fastReloadReplace = "04 00 A0 E1 0A 00 00 EB 00 50 A0 E1 04 00 A0 E1 99 10 A0 E3 00 00 00 EB 00 0A B7 EE 10 0A 01 EE 00 0A 31 EE 10 5A 01 EE 00 0A 21 EE 10 0A 10 EE";
      bool isApplied = false;
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, fastReloadReplace);
        isApplied = true;
      }
      if (isApplied)
      {
        Console.Beep(800, 200);
        this.status1.Text = "Fast Reload: Success!";
        this.status1.ForeColor = Color.Lime;
        fastReloadReplace = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Fast Reload: Failed!";
        this.status1.ForeColor = Color.Red;
        fastReloadReplace = (string) null;
      }
    }
  }

  private void guna2Button1_Click(object sender, EventArgs e) => Environment.Exit(0);

  private static string GetLocalIPAddress()
  {
    foreach (IPAddress address in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
    {
      if (address.AddressFamily == AddressFamily.InterNetwork)
        return address.ToString();
    }
    throw new Exception("No IPv4 address found.");
  }

  private void UI_FormClosing(object sender, FormClosingEventArgs e)
  {
    try
    {
      this.StopWebServer();
    }
    catch
    {
    }
    UI.UnregisterHotKey(this.Handle, 9000);
  }

  private void WriteResponse(
    HttpListenerContext context,
    string content,
    string contentType = "text/plain; charset=utf-8",
    int statusCode = 200)
  {
    try
    {
      byte[] bytes = Encoding.UTF8.GetBytes(content ?? "");
      context.Response.ContentType = contentType;
      context.Response.StatusCode = statusCode;
      context.Response.ContentLength64 = (long) bytes.Length;
      context.Response.OutputStream.Write(bytes, 0, bytes.Length);
      context.Response.OutputStream.Close();
    }
    catch
    {
    }
  }

  public void StopWebServer()
  {
    lock (this._webLock)
    {
      if (this._webListener == null)
        return;
      try
      {
        this._webListener.Stop();
        this._webListener.Close();
      }
      catch
      {
      }
      finally
      {
        this._webListener = (HttpListener) null;
      }
    }
    this.AppendWebLog("Web server stopped.");
  }

  private void AppendWebLog(string message)
  {
    string line = string.Format("[{0:HH:mm:ss.fff}] {1}", (object) DateTime.Now, (object) message);
    lock (this._webLock)
    {
      this._webLogs.Add(line);
      if (this._webLogs.Count > 1000)
        this._webLogs.RemoveRange(0, this._webLogs.Count - 1000);
    }
    if (!this.IsHandleCreated || this.IsDisposed)
      return;
    this.BeginInvoke((Delegate) (() =>
    {
      if (((IEnumerable<Control>) this.Controls.Find("rtbConsole", true)).FirstOrDefault<Control>() is RichTextBox richTextBox2)
      {
        richTextBox2.AppendText(line + Environment.NewLine);
        richTextBox2.ScrollToCaret();
      }
      else
      {
        try
        {
          this.status1.Text = line;
        }
        catch
        {
        }
      }
    }));
  }

  private void mainpnl_Paint(object sender, PaintEventArgs e)
  {
  }

  private void panel1_Paint(object sender, PaintEventArgs e)
  {
  }

  private void UI_Load(object sender, EventArgs e)
  {
    this.globalHook = Hook.GlobalEvents();
    ((IKeyboardEvents) this.globalHook).KeyUp += new KeyEventHandler(this.GlobalHook_KeyUp);
    ((IMouseEvents) this.globalHook).MouseUp += new MouseEventHandler(this.GlobalHook_MouseUp);
    ((IMouseEvents) this.globalHook).MouseWheel += new MouseEventHandler(this.GlobalHook_MouseWheel);
    this.sniperTimeoutTimer = new System.Windows.Forms.Timer();
    this.sniperTimeoutTimer.Interval = 1000;
    this.sniperTimeoutTimer.Tick += new EventHandler(this.SniperTimeoutTimer_Tick);
    this.sniperTimeoutTimer.Start();
    this.lblUser.Text = "Username: " + Login.KeyAuthApp.user_data.username;
    if (Login.KeyAuthApp.user_data.subscriptions.Count <= 0)
      return;
    this.lblExpiry.Text = "Expires: " + DateTimeOffset.FromUnixTimeSeconds(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry)).DateTime.ToString("dd/MM/yyyy");
  }

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr OpenProcess(uint processAccess, bool bInheritHandle, int processId);

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr GetModuleHandle(string lpModuleName);

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr VirtualAllocEx(
    IntPtr hProcess,
    IntPtr lpAddress,
    IntPtr dwSize,
    uint flAllocationType,
    uint flProtect);

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern bool WriteProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    byte[] lpBuffer,
    uint nSize,
    out IntPtr lpNumberOfBytesWritten);

  [DllImport("kernel32.dll")]
  private static extern IntPtr CreateRemoteThread(
    IntPtr hProcess,
    IntPtr lpThreadAttribute,
    IntPtr dwStackSize,
    IntPtr lpStartAddress,
    IntPtr lpParameter,
    uint dwCreationFlags,
    IntPtr lpThreadId);

  private static void ExtractEmbeddedResource(string resourceName, string outputPath)
  {
    using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
    {
      if (manifestResourceStream == null)
        throw new ArgumentException($"Resource '{resourceName}' not found.");
      using (FileStream fileStream = new FileStream(outputPath, FileMode.Create))
      {
        byte[] buffer = new byte[manifestResourceStream.Length];
        manifestResourceStream.Read(buffer, 0, buffer.Length);
        fileStream.Write(buffer, 0, buffer.Length);
      }
    }
  }

  private void guna2ToggleSwitch5_CheckedChanged(object sender, EventArgs e)
  {
    string processName = "HD-Player";
    string str = Path.Combine(Path.GetTempPath(), "nazmul.dll");
    UI.ExtractEmbeddedResource("ABNORMAL_CHEATS.nazmul.dll", str);
    Console.WriteLine("DLL extracted successfully to: " + str);
    Process[] processesByName = Process.GetProcessesByName(processName);
    if (processesByName.Length == 0)
    {
      Console.WriteLine($"Waiting for {processName}.exe...");
    }
    else
    {
      IntPtr hProcess = UI.OpenProcess(1082U, false, processesByName[0].Id);
      IntPtr procAddress = UI.GetProcAddress(UI.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
      IntPtr num = UI.VirtualAllocEx(hProcess, IntPtr.Zero, (IntPtr) str.Length, 4096U /*0x1000*/, 4U);
      UI.WriteProcessMemory(hProcess, num, Encoding.ASCII.GetBytes(str), (uint) str.Length, out IntPtr _);
      UI.CreateRemoteThread(hProcess, IntPtr.Zero, IntPtr.Zero, procAddress, num, 0U, IntPtr.Zero);
      Console.Beep(240 /*0xF0*/, 300);
    }
  }

  private async void guna2Button14_Click(object sender, EventArgs e)
  {
  }

  private async void guna2ToggleSwitch2_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void guna2ToggleSwitch6_CheckedChanged(object sender, EventArgs e)
  {
    string processName = "HD-Player";
    string str = Path.Combine(Path.GetTempPath(), "chamsblue.dll");
    UI.ExtractEmbeddedResource("ABNORMAL_CHEATS.chamsblue.dll", str);
    Console.WriteLine("DLL extracted successfully to: " + str);
    Process[] processesByName = Process.GetProcessesByName(processName);
    if (processesByName.Length == 0)
    {
      Console.WriteLine($"Waiting for {processName}.exe...");
    }
    else
    {
      IntPtr hProcess = UI.OpenProcess(1082U, false, processesByName[0].Id);
      IntPtr procAddress = UI.GetProcAddress(UI.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
      IntPtr num = UI.VirtualAllocEx(hProcess, IntPtr.Zero, (IntPtr) str.Length, 4096U /*0x1000*/, 4U);
      UI.WriteProcessMemory(hProcess, num, Encoding.ASCII.GetBytes(str), (uint) str.Length, out IntPtr _);
      UI.CreateRemoteThread(hProcess, IntPtr.Zero, IntPtr.Zero, procAddress, num, 0U, IntPtr.Zero);
      Console.Beep(240 /*0xF0*/, 300);
      this.status1.Text = "Injected";
    }
  }

  private void PlaySound(string soundFileName)
  {
    using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ABNORMAL_CHEATS.sound." + soundFileName))
    {
      if (manifestResourceStream != null)
      {
        new SoundPlayer(manifestResourceStream).Play();
      }
      else
      {
        int num = (int) MessageBox.Show($"Sound file '{soundFileName}' not found.");
      }
    }
  }

  private async void guna2Button15_Click(object sender, EventArgs e)
  {
    int num1;
    if (num1 != 0 && Process.GetProcessesByName("HD-Player").Length == 0)
    {
      this.status1.Text = "Emulator not found";
      this.status1.ForeColor = Color.Red;
      Console.Beep(500, 300);
    }
    else
    {
      try
      {
        if (!UI.magıcMemory.SetProcess(new string[1]
        {
          "HD-Player"
        }))
        {
          this.status1.Text = "Failed to open process";
        }
        else
        {
          this.status1.Text = "Scanning...";
          this.status1.ForeColor = Color.Yellow;
          string bytePattern = "FF FF FF FF FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 A5 43";
          IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
          if (source == null || !source.Any<long>())
          {
            this.status1.Text = "Pattern not found";
            this.status1.ForeColor = Color.Orange;
          }
          else
          {
            foreach (long num2 in source)
            {
              long addressToRead = num2 + 128L /*0x80*/;
              long num3 = num2 + 124L;
              try
              {
                int num4 = UI.magıcMemory.ReadInt(addressToRead);
                string address = num3.ToString("X");
                UI.magıcMemory.WriteMemory<int>(address, "int", num4.ToString());
              }
              catch (Exception ex)
              {
              }
            }
            this.status1.Text = "Aimbot Drag Activated";
            this.status1.ForeColor = Color.Green;
            this.PlaySound("activated.wav");
          }
        }
      }
      catch (Exception ex)
      {
        this.status1.Text = "Error: " + ex.Message;
        this.status1.ForeColor = Color.Red;
        int num5 = (int) MessageBox.Show(ex.StackTrace, "Debug Info");
      }
    }
  }

  public async void AimbotLoad()
  {
  }

  private void guna2ToggleSwitch1_CheckedChanged_1(object sender, EventArgs e)
  {
    string processName = "HD-Player";
    string str = Path.Combine(Path.GetTempPath(), "Transparent.dll.dll");
    UI.ExtractEmbeddedResource("ABNORMAL_CHEATS.Transparent.dll", str);
    Console.WriteLine("DLL extracted successfully to: " + str);
    Process[] processesByName = Process.GetProcessesByName(processName);
    if (processesByName.Length == 0)
    {
      Console.WriteLine($"Waiting for {processName}.exe...");
    }
    else
    {
      IntPtr hProcess = UI.OpenProcess(1082U, false, processesByName[0].Id);
      IntPtr procAddress = UI.GetProcAddress(UI.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
      IntPtr num = UI.VirtualAllocEx(hProcess, IntPtr.Zero, (IntPtr) str.Length, 4096U /*0x1000*/, 4U);
      UI.WriteProcessMemory(hProcess, num, Encoding.ASCII.GetBytes(str), (uint) str.Length, out IntPtr _);
      UI.CreateRemoteThread(hProcess, IntPtr.Zero, IntPtr.Zero, procAddress, num, 0U, IntPtr.Zero);
      Console.Beep(240 /*0xF0*/, 300);
      this.status1.Text = "Injected";
    }
  }

  private void sniperscopeoff()
  {
    if (this.sniperScopeAddresses.Count == 0)
      return;
    foreach (long sniperScopeAddress in this.sniperScopeAddresses)
      this.nazmulscope.AobReplace(sniperScopeAddress, this.sniperScopeoriginalBytes);
    this.Invoke((Delegate) (() => { }));
  }

  private void sniperscopeon()
  {
    if (this.sniperScopeAddresses.Count == 0)
      return;
    foreach (long sniperScopeAddress in this.sniperScopeAddresses)
      this.nazmulscope.AobReplace(sniperScopeAddress, this.patchedBytes);
    this.Invoke((Delegate) (() => { }));
  }

  private async void SniperTimeoutTimer_Tick(object sender, EventArgs e)
  {
    if (!this.isSniperScopeOn || (DateTime.Now - this.lastToggleTime).TotalSeconds < 0.0)
      return;
    this.sniperscopeon();
    await Task.Delay(330);
    this.isSniperScopeOn = false;
  }

  private void GlobalHook_KeyUp(object sender, KeyEventArgs e)
  {
    if (this.isListeningForKey)
    {
      this.toggleKey = e.KeyCode;
      this.toggleMouseButton = MouseButtons.None;
      this.toggleWheelDirection = 0;
      this.isListeningForKey = false;
    }
    else
    {
      if (e.KeyCode != this.toggleKey)
        return;
      this.ToggleSniperScope();
    }
  }

  private void GlobalHook_MouseUp(object sender, MouseEventArgs e)
  {
    if (this.isListeningForKey)
    {
      this.toggleMouseButton = e.Button;
      this.toggleKey = Keys.None;
      this.toggleWheelDirection = 0;
      this.isListeningForKey = false;
    }
    else
    {
      if (e.Button != this.toggleMouseButton && e.Button != MouseButtons.Left)
        return;
      this.ToggleSniperScope();
    }
  }

  private void GlobalHook_MouseWheel(object sender, MouseEventArgs e)
  {
    if (this.isListeningForKey)
    {
      this.toggleWheelDirection = e.Delta > 0 ? 1 : -1;
      this.toggleKey = Keys.None;
      this.toggleMouseButton = MouseButtons.None;
      this.status1.Text = "Sniper Toggle set to " + (this.toggleWheelDirection == 1 ? "Wheel UP" : "Wheel DOWN");
      this.isListeningForKey = false;
    }
    else
    {
      if ((this.toggleWheelDirection != 1 || e.Delta <= 0) && (this.toggleWheelDirection != -1 || e.Delta >= 0))
        return;
      this.ToggleSniperScope();
    }
  }

  private async void ToggleSniperScope()
  {
    DateTime now = DateTime.Now;
    if ((now - this.lastToggleAttempt).TotalMilliseconds < (double) this.toggleCooldownMs)
      return;
    this.lastToggleAttempt = now;
    if (!this.isSniperScopeOn)
      this.sniperscopeoff();
    this.isSniperScopeOn = !this.isSniperScopeOn;
    this.lastToggleTime = now;
  }

  private async void keybind1_Click(object sender, EventArgs e)
  {
    if (!this.nazmulscope.SetProcess(this.processname))
      return;
    this.sniperScopeAddresses = (await this.nazmulscope.AoBScan(this.sniperScopeoriginalBytes)).ToList<long>();
    if (this.sniperScopeAddresses.Count <= 0)
      return;
    this.status1.Text = "Activating...";
    this.sniperscopeon();
    this.status1.Text = "Success";
  }

  private void guna2Button5_Click(object sender, EventArgs e)
  {
  }

  private async void guna2Button9_Click(object sender, EventArgs e)
  {
    Process[] processesByName = Process.GetProcessesByName("HD-Player");
    if (processesByName.Length == 0)
    {
      this.status1.Text = "Error: Open Emulator First!";
    }
    else
    {
      this.MemLib.OpenProcess(processesByName[0].Id);
      this.status1.Text = "Scanning Camera...";
      IEnumerable<long> source = await this.MemLib.AoBScanMultithreadedWithTasks(0L, 140737488355327L /*0x7FFFFFFFFFFF*/, this.camScan, true, true, true);
      if (source != null && source.Any<long>())
      {
        this.camAddresses = source.ToList<long>();
        this.status1.Text = $"Success: Found {this.camAddresses.Count} locations!";
        Console.Beep(1000, 200);
      }
      else
        this.status1.Text = "Error: Scan failed. Restart game.";
    }
  }

  private async void guna2Button8_Click(object sender, EventArgs e)
  {
    this.speed.Clear();
    Process[] processesByName = Process.GetProcessesByName("HD-Player");
    if (processesByName.Length == 0)
      this.status1.Text = "Open Emulator";
    else if (!this.MemLib.OpenProcess(processesByName[0].Id))
    {
      this.status1.Text = "Run as Admin!";
    }
    else
    {
      this.status1.Text = "Scanning...";
      foreach (string searchPattern in this.srchspeed)
      {
        IEnumerable<long> collection = await this.MemLib.AoBScanMultithreadedWithTasks(0L, 140737488355327L /*0x7FFFFFFFFFFF*/, searchPattern, true, true, true);
        if (collection != null)
          this.speed.AddRange(collection);
      }
      if (this.speed.Any<long>())
      {
        this.status1.Text = $"Found {this.speed.Count} addresses.";
        Console.Beep(300, 500);
      }
      else
        this.status1.Text = "No addresses found.";
    }
  }

  private async void guna2Button7_Click(object sender, EventArgs e)
  {
    this.status1.Text = "Wall Hack  INJECTING....";
    this.status1.ForeColor = Color.Gray;
    int id = Process.GetProcessesByName("HD-Player")[0].Id;
    UI.CRIME.OpenProcess(id);
    IEnumerable<long> source = await UI.CRIME.AoBScan(65536L /*0x010000*/, 140737488289791L, "3F AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30 00 4F E2 43 2A B0 EE EF 0A 60 F4 43 6A F0 EE 1C 00 8A E2 43 5A F0 EE 8F 0A 48 F4 43 2A F0 EE 43 7A B0 EE 8F 0A 40 F4 41 AA B0", true, true, string.Empty);
    UI.GTC = "OX" + source.FirstOrDefault<long>().ToString();
    foreach (long num in source)
      UI.CRIME.WriteMemory(num.ToString("X"), "bytes", "BF AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30 00 4F E2 43 2A B0 EE EF 0A 60 F4 43 6A F0 EE 1C 00 8A E2 43 5A F0 EE 8F 0A 48 F4 43 2A F0 EE 43 7A B0 EE 8F 0A 40 F4 41 AA B0", string.Empty);
    this.status1.Text = "Wall Hack Applied";
    this.status1.ForeColor = Color.Gray;
    Console.Beep(400, 300);
  }

  private void guna2Button4_Click(object sender, EventArgs e)
  {
  }

  private async void guna2ToggleSwitch3_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void guna2Button10_Click(object sender, EventArgs e)
  {
  }

  private async void guna2ToggleSwitch7_CheckedChanged(object sender, EventArgs e)
  {
    this.status1.Text = "AWM/AWM-Y Location Injecting....";
    this.status1.ForeColor = Color.Gray;
    int id = Process.GetProcessesByName("HD-Player")[0].Id;
    UI.CRIME.OpenProcess(id);
    IEnumerable<long> source = await UI.CRIME.AoBScan(65536L /*0x010000*/, 140737488289791L, "", true, true, string.Empty);
    UI.GTC = "OX" + source.FirstOrDefault<long>().ToString();
    foreach (long num in source)
      UI.CRIME.WriteMemory(num.ToString("X"), "bytes", "", string.Empty);
    this.status1.Text = "AWM/AWM-Y Location Succese";
    this.status1.ForeColor = Color.Gray;
    Console.Beep(400, 300);
  }

  private void panel2_Paint(object sender, PaintEventArgs e)
  {
  }

  private async void guna2ToggleSwitch4_CheckedChanged(object sender, EventArgs e)
  {
    this.status1.Text = "M82B/AMMO Location Injecting....";
    this.status1.ForeColor = Color.Gray;
    int id = Process.GetProcessesByName("HD-Player")[0].Id;
    UI.CRIME.OpenProcess(id);
    IEnumerable<long> source = await UI.CRIME.AoBScan(65536L /*0x010000*/, 140737488289791L, "", true, true, string.Empty);
    UI.GTC = "OX" + source.FirstOrDefault<long>().ToString();
    foreach (long num in source)
      UI.CRIME.WriteMemory(num.ToString("X"), "bytes", "", string.Empty);
    this.status1.Text = "M82B/AMMO Location Succese";
    this.status1.ForeColor = Color.Gray;
    Console.Beep(400, 300);
  }

  [DllImport("user32.dll")]
  public static extern uint SetWindowDisplayAffinity(IntPtr hwnd, uint dwAffinity);

  private void guna2ToggleSwitch8_CheckedChanged(object sender, EventArgs e)
  {
    if (this.guna2ToggleSwitch8.Checked)
    {
      this.ShowInTaskbar = false;
      UI.Streaming = true;
      int num = (int) UI.SetWindowDisplayAffinity(this.Handle, 17U);
    }
    else
    {
      this.ShowInTaskbar = true;
      UI.Streaming = false;
      int num = (int) UI.SetWindowDisplayAffinity(this.Handle, 0U);
    }
  }

  private void guna2Panel19_Paint(object sender, PaintEventArgs e)
  {
  }

  private async void guna2Button3_Click(object sender, EventArgs e)
  {
  }

  private void guna2Button4_Click_1(object sender, EventArgs e)
  {
  }

  private async void ToggleSwitch2_CheckedChanged_1(object sender, EventArgs e)
  {
  }

  private void guna2ToggleSwitch9_CheckedChanged(object sender, EventArgs e)
  {
  }

  public void ExecuteCommand(string command)
  {
    ProcessStartInfo processStartInfo = new ProcessStartInfo("cmd.exe")
    {
      RedirectStandardInput = true,
      RedirectStandardOutput = true,
      RedirectStandardError = true,
      UseShellExecute = false,
      CreateNoWindow = true
    };
    using (Process process = new Process()
    {
      StartInfo = processStartInfo
    })
    {
      process.Start();
      process.StandardInput.WriteLine(command);
      process.StandardInput.Flush();
      process.StandardInput.Close();
      process.WaitForExit();
    }
  }

  private void guna2Button5_Click_1(object sender, EventArgs e)
  {
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=in action=block profile=any program=\"C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=out action=block profile=any program=\"C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=in action=block profile=any program=\"C:\\Program Files\\BlueStacks\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=out action=block profile=any program=\"C:\\Program Files\\BlueStacks\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=in action=block profile=any program=\"C:\\Program Files\\BlueStacks_msi2\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=out action=block profile=any program=\"C:\\Program Files\\BlueStacks_msi2\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=in action=block profile=any program=\"C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall add rule name=\"TemporaryBlock2\" dir=out action=block profile=any program=\"C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe");
    this.status1.Text = "INTERNET ON";
    Console.Beep();
  }

  private void guna2Button4_Click_2(object sender, EventArgs e)
  {
    this.ExecuteCommand("netsh advfirewall firewall delete rule name=all program=\"C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall delete rule name=all program=\"C:\\Program Files\\BlueStacks\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall delete rule name=all program=\"C:\\Program Files\\BlueStacks_msi2\\HD-Player.exe");
    this.ExecuteCommand("netsh advfirewall firewall delete rule name=all program=\"C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe");
    this.status1.Text = "INTERNET OFF";
    Console.Beep();
  }

  private void guna2Button11_Click(object sender, EventArgs e)
  {
    if (!this.guna2CustomCheckBox10.Checked)
      return;
    try
    {
      string str = "\r\n    Write-Host '\uD83D\uDEE0 Starting Advanced Cleanup...' -ForegroundColor Cyan;\r\n\r\n    # Clean Temporary Directories\r\n    Write-Host '\uD83E\uDDF9 Cleaning Temp Directories...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 3; # Simulated delay\r\n    Remove-Item -Path $env:TEMP\\* -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean Windows Temp\r\n    Write-Host '\uD83E\uDDF9 Cleaning Windows Temp...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 3;\r\n    Remove-Item -Path 'C:\\Windows\\Temp\\*' -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean Windows Prefetch\r\n    Write-Host '\uD83D\uDCC2 Clearing Prefetch...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 2; \r\n    Remove-Item -Path 'C:\\Windows\\Prefetch\\*' -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean SoftwareDistribution Cache\r\n    Write-Host '\uD83D\uDD04 Purging SoftwareDistribution Cache...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 3;\r\n    Remove-Item -Path 'C:\\Windows\\SoftwareDistribution\\Download\\*' -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean User Temp Files\r\n    Write-Host '\uD83D\uDC64 Cleaning User Temp Files...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 2;\r\n    Remove-Item -Path 'C:\\Users\\*\\AppData\\Local\\Temp\\*' -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean Windows Logs\r\n    Write-Host '\uD83D\uDCDD Cleaning Windows Logs...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 3;\r\n    Remove-Item -Path 'C:\\Windows\\System32\\winevt\\Logs\\*' -Recurse -Force -ErrorAction SilentlyContinue;\r\n\r\n    # Clean additional items\r\n    Write-Host '\uD83D\uDD0D Cleaning additional items...' -ForegroundColor Yellow;\r\n    Start-Sleep -Seconds 2;\r\n    Remove-Item -Path 'C:\\Users\\*\\AppData\\Local\\Microsoft\\Windows\\Explorer\\*' -Recurse -Force -ErrorAction SilentlyContinue; # Explorer thumbnail cache\r\n\r\n    Write-Host '✅ Advanced Cleanup Complete! Closing...' -ForegroundColor Green;\r\n    Start-Sleep -Seconds 2; # Allow time to see the completion message\r\n    exit\r\n    ";
      Process.Start(new ProcessStartInfo("cmd.exe", "/c " + "\r\n    @echo off\r\n    color 5\r\n    echo Cleaning CMD Advanced System Files...\r\n    echo Cleaning Windows Temp Files...\r\n    del /s /q C:\\Windows\\Temp\\* >> cleanup_output.txt 2>&1 \r\n    timeout /t 2\r\n    echo Cleaning Windows Prefetch...\r\n    del /s /q C:\\Windows\\Prefetch\\* >> cleanup_output.txt 2>&1 \r\n    timeout /t 2\r\n    echo Cleaning User Temp Files...\r\n    del /s /q C:\\Users\\*\\AppData\\Local\\Temp\\* >> cleanup_output.txt 2>&1 \r\n    timeout /t 2\r\n    echo Cleaning Software Distribution Download...\r\n    del /s /q C:\\Windows\\SoftwareDistribution\\Download\\* >> cleanup_output.txt 2>&1 \r\n    timeout /t 2\r\n    echo Cleaning Windows Event Logs...\r\n    del /s /q C:\\Windows\\System32\\winevt\\Logs\\* >> cleanup_output.txt 2>&1 \r\n    timeout /t 2\r\n    echo Completed cleanup!\r\n    pause >> cleanup_output.txt 2>&1\r\n    exit\r\n    ")
      {
        Verb = "runas",
        UseShellExecute = true,
        CreateNoWindow = false
      });
      Process.Start(new ProcessStartInfo("powershell.exe", $"-NoProfile -ExecutionPolicy Bypass -Command \"{str}\"")
      {
        Verb = "runas",
        UseShellExecute = true,
        CreateNoWindow = false
      });
      this.status1.Text = "\uD83D\uDE80 Advanced Cleanup initiated. Running tasks in CMD and PowerShell...\n";
    }
    catch (Exception ex)
    {
      this.status1.Text = $"❌ Error during advanced temp cleanup: {ex.Message}\n";
    }
  }

  private void CleanFolder(string folderPath)
  {
    DirectoryInfo directoryInfo = new DirectoryInfo(folderPath);
    foreach (FileInfo file in directoryInfo.GetFiles())
    {
      try
      {
        file.Delete();
      }
      catch
      {
      }
    }
    foreach (DirectoryInfo directory in directoryInfo.GetDirectories())
    {
      try
      {
        directory.Delete(true);
      }
      catch
      {
      }
    }
  }

  private void guna2CustomCheckBox10_Click(object sender, EventArgs e)
  {
    string tempPath = Path.GetTempPath();
    string folderPath = "C:\\Windows\\Temp";
    this.CleanFolder(tempPath);
    this.CleanFolder(folderPath);
    int num = (int) MessageBox.Show("PC Cleaned Successfully!", "Cleaner", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
  }

  private void C_Click(object sender, EventArgs e)
  {
    ColorDialog colorDialog = new ColorDialog();
    if (colorDialog.ShowDialog() != DialogResult.OK)
      return;
    this.C.FillColor = colorDialog.Color;
    this.C.BorderColor = colorDialog.Color;
    ((Control) this.C).BackColor = Color.Transparent;
    this.guna2BorderlessForm1.ShadowColor = colorDialog.Color;
    this.guna2Button1.FillColor = colorDialog.Color;
    this.guna2Button2.BorderColor = colorDialog.Color;
    this.guna2Button3.BorderColor = colorDialog.Color;
    this.guna2Button4.BorderColor = colorDialog.Color;
    this.guna2Button5.BorderColor = colorDialog.Color;
    this.guna2Button6.BorderColor = colorDialog.Color;
    this.guna2Button7.BorderColor = colorDialog.Color;
    this.guna2Button8.BorderColor = colorDialog.Color;
    this.guna2Button9.BorderColor = colorDialog.Color;
    ((Control) this.guna2HtmlLabel1).ForeColor = colorDialog.Color;
    this.mainpnl.BorderColor = colorDialog.Color;
    this.keybind1.BorderColor = colorDialog.Color;
    this.guna2Button15.BorderColor = colorDialog.Color;
    this.h2.BorderColor = colorDialog.Color;
    ((Control) this.guna2CustomCheckBox10).BackColor = Color.Transparent;
    this.guna2Button12.BorderColor = colorDialog.Color;
    this.guna2Button11.BorderColor = colorDialog.Color;
    this.guna2Button14.BorderColor = colorDialog.Color;
    this.guna2CustomCheckBox10.CheckMarkColor = Color.Transparent;
    this.guna2CustomCheckBox1.CheckMarkColor = colorDialog.Color;
    this.guna2CustomCheckBox2.CheckMarkColor = colorDialog.Color;
  }

  private void guna2CustomCheckBox6_Click(object sender, EventArgs e)
  {
  }

  private void HideFromTaskManager()
  {
    UI.ShowWindow(UI.GetConsoleWindow(), 0);
    this.ShowInTaskbar = false;
    UI.SetWindowLong(this.Handle, -20, UI.GetWindowLong(this.Handle, -20) | 128 /*0x80*/);
    Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.BelowNormal;
  }

  private void ShowInTaskManager()
  {
    UI.ShowWindow(UI.GetConsoleWindow(), 5);
    this.ShowInTaskbar = true;
    UI.SetWindowLong(this.Handle, -20, UI.GetWindowLong(this.Handle, -20) & -129);
    Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.Normal;
  }

  private void guna2Button10_Click_1(object sender, EventArgs e) => this.HideFromTaskManager();

  private void guna2Button11_Click_1(object sender, EventArgs e) => this.ShowInTaskManager();

  private void guna2CustomCheckBox1_Click(object sender, EventArgs e)
  {
    try
    {
      string str1 = "C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe";
      string str2 = "--instance Nougat32 --cmd launchApp --package \"com.dts.freefireth\"";
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = str1;
      startInfo.Arguments = str2;
      startInfo.UseShellExecute = true;
      this.status1.Text = "Emulator Opened Successfully!";
      Process.Start(startInfo);
    }
    catch (Exception ex)
    {
      this.status1.Text = "An error occurred: " + ex.Message;
    }
  }

  private void guna2ToggleSwitch2_CheckedChanged_1(object sender, EventArgs e)
  {
  }

  private async void guna2ToggleSwitch2_CheckedChanged_2(object sender, EventArgs e)
  {
  }

  private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
  {
  }

  private void Application_ApplicationExit(object sender, EventArgs e)
  {
    UI.UnhookWindowsHookEx(this.hookID);
  }

  private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
  {
    if (nCode >= 0 && wParam == (IntPtr) 256 /*0x0100*/)
    {
      Keys keys = (Keys) Marshal.ReadInt32(lParam);
      if (this.waitingForKeyButton != null)
      {
        if (keys == Keys.Escape)
        {
          this.keyBindings[this.waitingForKeyButton] = Keys.None;
          ((Control) this.waitingForKeyButton).Text = "None";
        }
        else
        {
          this.keyBindings[this.waitingForKeyButton] = keys;
          ((Control) this.waitingForKeyButton).Text = keys.ToString();
        }
        this.waitingForKeyButton = (Guna2Button) null;
      }
      else
      {
        foreach (KeyValuePair<Guna2Button, Keys> keyBinding in this.keyBindings)
        {
          if (keyBinding.Value == keys)
          {
            Guna2ToggleSwitch guna2ToggleSwitch = this.toggleMapping[keyBinding.Key];
            guna2ToggleSwitch.Checked = !guna2ToggleSwitch.Checked;
          }
        }
      }
    }
    return UI.CallNextHookEx(this.hookID, nCode, wParam, lParam);
  }

  private void StartKeyBinding(Guna2Button button)
  {
    this.waitingForKeyButton = button;
    ((Control) button).Text = "...";
  }

  private void h2_Click(object sender, EventArgs e)
  {
    this.StartKeyBinding(this.h2);
    ((Control) this.h2).Text = "Press a key..";
    ((Control) this.h1).Text = "Press a key..";
  }

  private void guna2Button13_Click(object sender, EventArgs e)
  {
  }

  private void guna2Button2_Click(object sender, EventArgs e)
  {
  }

  private void guna2CustomCheckBox2_Click(object sender, EventArgs e)
  {
    if (this.guna2CustomCheckBox2.Checked)
      this.GenerateOfflineQRCode();
    else
      this.StopWebServer();
  }

  private void panel5_Paint(object sender, PaintEventArgs e)
  {
  }

  private async void guna2Button14_Click_1(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "No Recoil Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string replacePattern;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Emulator Not Found / No Admin Permissions";
      this.status1.ForeColor = Color.Red;
      replacePattern = (string) null;
    }
    else
    {
      bool k1 = false;
      string bytePattern = "81 EE 10 0A 10 EE 10 8C BD E8 00 00 7A 44 F0";
      replacePattern = "81 EE 10 0A 10 EE 10 8C BD E8 00 00 00 00 F0";
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, replacePattern);
        k1 = true;
      }
      if (k1)
      {
        Console.Beep(400, 300);
        this.status1.Text = "No Recoil Injected";
        this.status1.ForeColor = Color.Lime;
        replacePattern = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Failed -!";
        this.status1.ForeColor = Color.Red;
        replacePattern = (string) null;
      }
    }
  }

  private void panel4_Paint(object sender, PaintEventArgs e)
  {
  }

  private void guna2TextBox1_TextChanged(object sender, EventArgs e)
  {
  }

  private void guna2Panel27_Paint(object sender, PaintEventArgs e)
  {
  }

  private void qrPictureBox_Click(object sender, EventArgs e)
  {
  }

  private void guna2ToggleSwitch11_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void panel3_Paint(object sender, PaintEventArgs e)
  {
  }

  private void guna2ToggleSwitch10_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void Manual_KeyDown(object sender, KeyEventArgs e)
  {
    if (!this.isListening)
      return;
    this.customKey = (int) e.KeyCode;
    ((Control) this.h1).Text = "Key: " + e.KeyCode.ToString();
    if (this.status1 != null)
      this.status1.Text = "Key Set!";
    this.isListening = false;
    e.Handled = true;
    e.SuppressKeyPress = true;
  }

  private void h1_Click(object sender, EventArgs e)
  {
    this.isListening = true;
    this.KeyPreview = true;
    ((Control) this.h1).Text = "Press any key...";
    this.status1.Text = "Waiting for key...";
  }

  private void guna2HtmlLabel2_Click(object sender, EventArgs e)
  {
  }

  private void hotkeyTimer_Tick(object sender, EventArgs e)
  {
    if (this.customKey == 0 || this.isListening || ((int) UI.GetAsyncKeyState(this.customKey) & 32768 /*0x8000*/) <= 0)
      return;
    this.guna2Button15.PerformClick();
    Thread.Sleep(200);
  }

  private void mainpnl_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
  {
  }

  private void hotkeyTimer_Tick_1(object sender, EventArgs e)
  {
    if (this.customKey == 0 || this.isListening || ((int) UI.GetAsyncKeyState(this.customKey) & 32768 /*0x8000*/) == 0)
      return;
    Console.Beep(800, 100);
    if (this.guna2Button15 != null)
      this.guna2Button15.PerformClick();
    Thread.Sleep(500);
  }

  private void guna2ToggleSwitch14_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void guna2ToggleSwitch13_CheckedChanged(object sender, EventArgs e)
  {
    if (!this.speed.Any<long>())
    {
      this.status1.Text = "Load first!";
      this.guna2ToggleSwitch13.Checked = false;
    }
    else
    {
      this.status1.Text = this.guna2ToggleSwitch13.Checked ? "Activating..." : "Disabling...";
      string write = this.guna2ToggleSwitch13.Checked ? this.replacespeed[0] : this.srchspeed[0];
      for (int index = 0; index < this.speed.Count; ++index)
        this.MemLib.WriteMemory(this.speed[index].ToString("X"), "bytes", write);
      this.status1.Text = this.guna2ToggleSwitch13.Checked ? "Speed Activated." : "Speed Disabled.";
      Console.Beep(500, 300);
    }
  }

  private void label28_Click(object sender, EventArgs e)
  {
  }

  private async void UI_KeyDown(object sender, KeyEventArgs e)
  {
    UI ui = this;
    if (ui.isWaitingForKey)
    {
      ui.camHotkey = e.KeyCode;
      ((Control) ui.guna2Button13).Text = "Key: " + ui.camHotkey.ToString();
      ui.isWaitingForKey = false;
      // ISSUE: explicit non-virtual call
      UI.RegisterHotKey(__nonvirtual (ui.Handle), 9000, 0U, (uint) ui.camHotkey);
      ui.status1.Text = "Global Keybind Active!";
    }
    else
    {
      if (ui.camHotkey == Keys.None || e.KeyCode != ui.camHotkey)
        return;
      Console.Beep(1000, 100);
      await ui.ExecuteCameraHack();
    }
  }

  private async Task ExecuteCameraHack()
  {
    if (this.camAddresses.Count == 0)
    {
      this.status1.Text = "Error: Click LOAD first!";
    }
    else
    {
      this.isCamActive = !this.isCamActive;
      this.status1.Text = this.isCamActive ? "Camera Hack: ON" : "Camera Hack: OFF";
      string write = this.isCamActive ? this.camReplace : this.camScan;
      foreach (long camAddress in this.camAddresses)
        this.MemLib.WriteMemory(camAddress.ToString("X"), "bytes", write);
    }
  }

  private void guna2Button13_Click_1(object sender, EventArgs e)
  {
    this.isWaitingForKey = true;
    ((Control) this.guna2Button13).Text = "PRESS ANY KEY...";
    this.status1.Text = "Waiting for input...";
    this.ActiveControl = (Control) null;
  }

  private void label45_Click(object sender, EventArgs e)
  {
  }

  private async void guna2Button16_Click(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "M82B Switch Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string replacePattern;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Emulator Not Found / No Admin Permissions";
      this.status1.ForeColor = Color.Red;
      replacePattern = (string) null;
    }
    else
    {
      bool k1 = false;
      string bytePattern = "3F 00 00 80 3E 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 9A 99 19 3F CD CC 8C 3F 00 00 80 3F 00 00 00 00 66 66 66 3F 00 00 80 3F 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 80 3F 00 00 80 3F 00 00 00 00 01 00 00 00 0A D7 23 3C CD CC CC 3D 9A 99 19 3F 1F 85 6B 3F 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F 00 00 00 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
      replacePattern = "3F 00 00 80 3E EC 51 B8 3D 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 9A 99 19 3F CD CC 8C 3F 00 00 80 3F 00 00 00 00 66 66 66 3F 00 00 80 3F 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 80 3F 00 00 80 3F 00 00 00 00 01 00 00 00 0A D7 23 3C CD CC CC 3D 9A 99 19 3F 1F 85 6B 3F 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F 00 00 00 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, replacePattern);
        k1 = true;
      }
      if (k1)
      {
        Console.Beep(400, 300);
        this.status1.Text = "M82B Switch Injected";
        this.status1.ForeColor = Color.Lime;
        replacePattern = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Failed -!";
        this.status1.ForeColor = Color.Red;
        replacePattern = (string) null;
      }
    }
  }

  private async void guna2Button17_Click(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "M24 Switch Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string replacePattern;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Emulator Not Found / No Admin Permissions";
      this.status1.ForeColor = Color.Red;
      replacePattern = (string) null;
    }
    else
    {
      bool k1 = false;
      string bytePattern = "00 00 78 42 00 00 A4 42 32 00 00 00 00 00 00 00 00 00 00 3F 00 00 80 3E 00 00 00 00 06 00 00 00 CD CC 4C 3F 00 00 20 41 00 00 34 42 01 00 00 00";
      replacePattern = "00 00 78 42 00 00 A4 42 32 00 00 00 00 00 00 00 00 00 00 3C 00 00 80 3C 00 00 00 00 06 00 00 00 CD CC 4C 3F 00 00 20 41 00 00 34 42 01";
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, replacePattern);
        k1 = true;
      }
      if (k1)
      {
        Console.Beep(400, 300);
        this.status1.Text = "M24 Switch Injected";
        this.status1.ForeColor = Color.Lime;
        replacePattern = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Failed -!";
        this.status1.ForeColor = Color.Red;
        replacePattern = (string) null;
      }
    }
  }

  private async void guna2Button18_Click(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "All Switch Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string replacePattern;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Emulator Not Found / No Admin Permissions";
      this.status1.ForeColor = Color.Red;
      replacePattern = (string) null;
    }
    else
    {
      bool k1 = false;
      string bytePattern = "3F 00 00 80 3E 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F";
      replacePattern = "01 00 00 80 00 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01";
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, replacePattern);
        k1 = true;
      }
      if (k1)
      {
        Console.Beep(400, 300);
        this.status1.Text = "All Switch Injected";
        this.status1.ForeColor = Color.Lime;
        replacePattern = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Failed -!";
        this.status1.ForeColor = Color.Red;
        replacePattern = (string) null;
      }
    }
  }

  private async void guna2Button19_Click(object sender, EventArgs e)
  {
    this.status1.ForeColor = Color.Yellow;
    this.status1.Text = "Ammo location Injecting...";
    string[] processNames = new string[1]{ "HD-Player" };
    string replacePattern;
    if (!UI.magıcMemory.SetProcess(processNames))
    {
      this.status1.Text = "Emulator Not Found / No Admin Permissions";
      this.status1.ForeColor = Color.Red;
      replacePattern = (string) null;
    }
    else
    {
      bool k1 = false;
      string bytePattern = "22 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 61 00 6D 00 6D 00 6F 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 6D 00 6D 00 6F 00 5F 00 73 00 6E 00 67";
      replacePattern = "1C 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 67 00 61 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 72 00 65 00 64 00";
      IEnumerable<long> source = await UI.magıcMemory.AoBScan(bytePattern);
      if (source != null && source.Any<long>())
      {
        foreach (long address in source)
          UI.magıcMemory.AobReplace(address, replacePattern);
        k1 = true;
      }
      if (k1)
      {
        Console.Beep(400, 300);
        this.status1.Text = "Ammo location Injected";
        this.status1.ForeColor = Color.Lime;
        replacePattern = (string) null;
      }
      else
      {
        Console.Beep(240 /*0xF0*/, 300);
        this.status1.Text = "Failed -!";
        this.status1.ForeColor = Color.Red;
        replacePattern = (string) null;
      }
    }
  }

  private void label4_Click(object sender, EventArgs e)
  {
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (UI));
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2Button1 = new Guna2Button();
    this.mainpnl = new Guna2Panel();
    this.guna2HtmlLabel3 = new Guna2HtmlLabel();
    this.guna2HtmlLabel4 = new Guna2HtmlLabel();
    this.guna2CirclePictureBox1 = new Guna2CirclePictureBox();
    this.guna2HtmlLabel1 = new Guna2HtmlLabel();
    this.guna2HtmlLabel2 = new Guna2HtmlLabel();
    this.label37 = new Label();
    this.status1 = new Label();
    this.guna2Panel19 = new Guna2Panel();
    this.main = new Guna2HtmlLabel();
    this.hooked = new Guna2HtmlLabel();
    this.esp = new Guna2HtmlLabel();
    this.exploits = new Guna2HtmlLabel();
    this.keybind = new Guna2HtmlLabel();
    this.panel1 = new Guna2Panel();
    this.guna2Panel6 = new Guna2Panel();
    this.h1 = new Guna2Button();
    this.guna2Button15 = new Guna2Button();
    this.label5 = new Label();
    this.label4 = new Label();
    this.guna2Panel22 = new Guna2Panel();
    this.guna2ToggleSwitch10 = new Guna2ToggleSwitch();
    this.label41 = new Label();
    this.label42 = new Label();
    this.guna2Button12 = new Guna2Button();
    this.guna2Panel1 = new Guna2Panel();
    this.label1 = new Label();
    this.guna2ToggleSwitch2 = new Guna2ToggleSwitch();
    this.label2 = new Label();
    this.h2 = new Guna2Button();
    this.guna2Panel15 = new Guna2Panel();
    this.guna2Button2 = new Guna2Button();
    this.guna2Button3 = new Guna2Button();
    this.label19 = new Label();
    this.label29 = new Label();
    this.panel5 = new Guna2Panel();
    this.lblExpiry = new Label();
    this.lblUser = new Label();
    this.qrPictureBox = new PictureBox();
    this.guna2Panel27 = new Guna2Panel();
    this.guna2CustomCheckBox2 = new Guna2CustomCheckBox();
    this.label46 = new Label();
    this.label47 = new Label();
    this.guna2Panel21 = new Guna2Panel();
    this.guna2CustomCheckBox1 = new Guna2CustomCheckBox();
    this.label39 = new Label();
    this.label40 = new Label();
    this.guna2Panel20 = new Guna2Panel();
    this.guna2Button11 = new Guna2Button();
    this.guna2Button10 = new Guna2Button();
    this.label36 = new Label();
    this.label38 = new Label();
    this.guna2Panel18 = new Guna2Panel();
    this.C = new Guna2Button();
    this.label34 = new Label();
    this.label35 = new Label();
    this.guna2Panel17 = new Guna2Panel();
    this.guna2CustomCheckBox10 = new Guna2CustomCheckBox();
    this.label32 = new Label();
    this.label33 = new Label();
    this.guna2Panel16 = new Guna2Panel();
    this.guna2Button5 = new Guna2Button();
    this.guna2Button4 = new Guna2Button();
    this.label30 = new Label();
    this.label31 = new Label();
    this.panel4 = new Guna2Panel();
    this.guna2Panel26 = new Guna2Panel();
    this.guna2Button14 = new Guna2Button();
    this.label17 = new Label();
    this.label45 = new Label();
    this.guna2Panel11 = new Guna2Panel();
    this.guna2Button6 = new Guna2Button();
    this.label21 = new Label();
    this.label22 = new Label();
    this.guna2Panel12 = new Guna2Panel();
    this.guna2Button7 = new Guna2Button();
    this.label23 = new Label();
    this.label24 = new Label();
    this.guna2Panel13 = new Guna2Panel();
    this.label49 = new Label();
    this.label48 = new Label();
    this.guna2Button8 = new Guna2Button();
    this.guna2ToggleSwitch13 = new Guna2ToggleSwitch();
    this.label25 = new Label();
    this.label26 = new Label();
    this.guna2Panel14 = new Guna2Panel();
    this.guna2Button13 = new Guna2Button();
    this.guna2Button9 = new Guna2Button();
    this.label27 = new Label();
    this.label28 = new Label();
    this.panel3 = new Guna2Panel();
    this.guna2Panel25 = new Guna2Panel();
    this.guna2ToggleSwitch12 = new Guna2ToggleSwitch();
    this.label15 = new Label();
    this.guna2Panel24 = new Guna2Panel();
    this.guna2ToggleSwitch11 = new Guna2ToggleSwitch();
    this.label13 = new Label();
    this.guna2Panel10 = new Guna2Panel();
    this.guna2ToggleSwitch8 = new Guna2ToggleSwitch();
    this.label20 = new Label();
    this.guna2Panel9 = new Guna2Panel();
    this.guna2ToggleSwitch1 = new Guna2ToggleSwitch();
    this.label18 = new Label();
    this.guna2Panel8 = new Guna2Panel();
    this.guna2ToggleSwitch6 = new Guna2ToggleSwitch();
    this.label16 = new Label();
    this.guna2Panel7 = new Guna2Panel();
    this.guna2ToggleSwitch5 = new Guna2ToggleSwitch();
    this.label14 = new Label();
    this.panel2 = new Guna2Panel();
    this.guna2Panel23 = new Guna2Panel();
    this.guna2Button16 = new Guna2Button();
    this.label43 = new Label();
    this.label44 = new Label();
    this.guna2Panel3 = new Guna2Panel();
    this.guna2Button18 = new Guna2Button();
    this.label7 = new Label();
    this.label8 = new Label();
    this.guna2Panel5 = new Guna2Panel();
    this.guna2Button17 = new Guna2Button();
    this.label11 = new Label();
    this.label12 = new Label();
    this.guna2Panel4 = new Guna2Panel();
    this.guna2Button19 = new Guna2Button();
    this.label9 = new Label();
    this.label10 = new Label();
    this.guna2Panel2 = new Guna2Panel();
    this.label3 = new Label();
    this.label6 = new Label();
    this.keybind1 = new Guna2Button();
    this.guna2DragControl1 = new Guna2DragControl(this.components);
    this.hotkeyTimer = new System.Windows.Forms.Timer(this.components);
    ((Control) this.mainpnl).SuspendLayout();
    ((ISupportInitialize) this.guna2CirclePictureBox1).BeginInit();
    ((Control) this.guna2Panel19).SuspendLayout();
    ((Control) this.panel1).SuspendLayout();
    ((Control) this.guna2Panel6).SuspendLayout();
    ((Control) this.guna2Panel22).SuspendLayout();
    ((Control) this.guna2Panel1).SuspendLayout();
    ((Control) this.guna2Panel15).SuspendLayout();
    ((Control) this.panel5).SuspendLayout();
    ((ISupportInitialize) this.qrPictureBox).BeginInit();
    ((Control) this.guna2Panel27).SuspendLayout();
    ((Control) this.guna2Panel21).SuspendLayout();
    ((Control) this.guna2Panel20).SuspendLayout();
    ((Control) this.guna2Panel18).SuspendLayout();
    ((Control) this.guna2Panel17).SuspendLayout();
    ((Control) this.guna2Panel16).SuspendLayout();
    ((Control) this.panel4).SuspendLayout();
    ((Control) this.guna2Panel26).SuspendLayout();
    ((Control) this.guna2Panel11).SuspendLayout();
    ((Control) this.guna2Panel12).SuspendLayout();
    ((Control) this.guna2Panel13).SuspendLayout();
    ((Control) this.guna2Panel14).SuspendLayout();
    ((Control) this.panel3).SuspendLayout();
    ((Control) this.guna2Panel25).SuspendLayout();
    ((Control) this.guna2Panel24).SuspendLayout();
    ((Control) this.guna2Panel10).SuspendLayout();
    ((Control) this.guna2Panel9).SuspendLayout();
    ((Control) this.guna2Panel8).SuspendLayout();
    ((Control) this.guna2Panel7).SuspendLayout();
    ((Control) this.panel2).SuspendLayout();
    ((Control) this.guna2Panel23).SuspendLayout();
    ((Control) this.guna2Panel3).SuspendLayout();
    ((Control) this.guna2Panel5).SuspendLayout();
    ((Control) this.guna2Panel4).SuspendLayout();
    ((Control) this.guna2Panel2).SuspendLayout();
    this.SuspendLayout();
    this.guna2BorderlessForm1.BorderRadius = 4;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.HasFormShadow = false;
    this.guna2BorderlessForm1.ResizeForm = false;
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2Button1.Animated = true;
    this.guna2Button1.BorderColor = Color.FromArgb(33, 33, 33);
    this.guna2Button1.BorderRadius = 4;
    this.guna2Button1.BorderThickness = 1;
    this.guna2Button1.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button1.FillColor = Color.Gray;
    ((Control) this.guna2Button1).Font = new Font("Segoe UI", 9f, FontStyle.Bold);
    ((Control) this.guna2Button1).ForeColor = Color.White;
    ((Control) this.guna2Button1).Location = new Point(625, 3);
    ((Control) this.guna2Button1).Name = "guna2Button1";
    ((Control) this.guna2Button1).Size = new Size(37, 29);
    ((Control) this.guna2Button1).TabIndex = 29;
    ((Control) this.guna2Button1).Text = "X";
    ((Control) this.guna2Button1).Click += new EventHandler(this.guna2Button1_Click);
    ((Control) this.mainpnl).BackColor = Color.Transparent;
    this.mainpnl.BorderColor = Color.Gray;
    this.mainpnl.BorderRadius = 4;
    this.mainpnl.BorderThickness = 1;
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2HtmlLabel3);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2HtmlLabel4);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2CirclePictureBox1);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2HtmlLabel1);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2HtmlLabel2);
    ((Control) this.mainpnl).Controls.Add((Control) this.label37);
    ((Control) this.mainpnl).Controls.Add((Control) this.status1);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2Button1);
    ((Control) this.mainpnl).Controls.Add((Control) this.guna2Panel19);
    ((Control) this.mainpnl).Controls.Add((Control) this.panel1);
    ((Control) this.mainpnl).Controls.Add((Control) this.panel5);
    ((Control) this.mainpnl).Controls.Add((Control) this.panel4);
    ((Control) this.mainpnl).Controls.Add((Control) this.panel3);
    ((Control) this.mainpnl).Controls.Add((Control) this.panel2);
    this.mainpnl.FillColor = Color.Transparent;
    ((Control) this.mainpnl).ForeColor = Color.Transparent;
    ((Control) this.mainpnl).Location = new Point(0, 0);
    ((Control) this.mainpnl).Name = "mainpnl";
    ((Control) this.mainpnl).Size = new Size(666, 428);
    ((Control) this.mainpnl).TabIndex = 222;
    ((Control) this.mainpnl).Paint += new PaintEventHandler(this.mainpnl_Paint);
    ((Control) this.guna2HtmlLabel3).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel3).Font = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2HtmlLabel3).ForeColor = Color.White;
    this.guna2HtmlLabel3.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel3).Location = new Point(491, 3);
    ((Control) this.guna2HtmlLabel3).Name = "guna2HtmlLabel3";
    ((Control) this.guna2HtmlLabel3).Size = new Size(25, 39);
    ((Control) this.guna2HtmlLabel3).TabIndex = 281;
    ((Control) this.guna2HtmlLabel3).Text = "\u2075\u00B2";
    ((Control) this.guna2HtmlLabel4).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel4).Font = new Font("Times New Roman", 24f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2HtmlLabel4).ForeColor = Color.Yellow;
    this.guna2HtmlLabel4.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel4).Location = new Point(439, 10);
    ((Control) this.guna2HtmlLabel4).Name = "guna2HtmlLabel4";
    ((Control) this.guna2HtmlLabel4).Size = new Size(50, 38);
    ((Control) this.guna2HtmlLabel4).TabIndex = 280;
    ((Control) this.guna2HtmlLabel4).Text = "OB";
    ((PictureBox) this.guna2CirclePictureBox1).Image = (Image) componentResourceManager.GetObject("guna2CirclePictureBox1.Image");
    this.guna2CirclePictureBox1.ImageRotate = 0.0f;
    ((Control) this.guna2CirclePictureBox1).Location = new Point(9, 10);
    ((Control) this.guna2CirclePictureBox1).Name = "guna2CirclePictureBox1";
    this.guna2CirclePictureBox1.ShadowDecoration.Mode = (ShadowMode) 1;
    ((Control) this.guna2CirclePictureBox1).Size = new Size(97, 91);
    ((PictureBox) this.guna2CirclePictureBox1).SizeMode = PictureBoxSizeMode.StretchImage;
    ((PictureBox) this.guna2CirclePictureBox1).TabIndex = 258;
    ((PictureBox) this.guna2CirclePictureBox1).TabStop = false;
    this.guna2CirclePictureBox1.UseTransparentBackground = true;
    ((Control) this.guna2CirclePictureBox1).Click += new EventHandler(this.guna2CirclePictureBox1_Click);
    ((Control) this.guna2HtmlLabel1).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel1).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2HtmlLabel1).ForeColor = Color.Gray;
    this.guna2HtmlLabel1.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel1).Location = new Point(331, 10);
    ((Control) this.guna2HtmlLabel1).Name = "guna2HtmlLabel1";
    ((Control) this.guna2HtmlLabel1).Size = new Size(81, 41);
    ((Control) this.guna2HtmlLabel1).TabIndex = 278;
    ((Control) this.guna2HtmlLabel1).Text = "CHEATS";
    ((Control) this.guna2HtmlLabel2).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel2).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2HtmlLabel2).ForeColor = Color.White;
    this.guna2HtmlLabel2.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel2).Location = new Point(231, 10);
    ((Control) this.guna2HtmlLabel2).Name = "guna2HtmlLabel2";
    ((Control) this.guna2HtmlLabel2).Size = new Size(94, 41);
    ((Control) this.guna2HtmlLabel2).TabIndex = 277;
    ((Control) this.guna2HtmlLabel2).Text = "TELAPOS";
    ((Control) this.guna2HtmlLabel2).Click += new EventHandler(this.guna2HtmlLabel2_Click);
    this.label37.AutoSize = true;
    this.label37.BackColor = Color.Transparent;
    this.label37.Font = new Font("Bahnschrift", 9.75f);
    this.label37.ForeColor = Color.White;
    this.label37.Location = new Point(580, 403);
    this.label37.Margin = new Padding(2, 0, 2, 0);
    this.label37.Name = "label37";
    this.label37.Size = new Size(70, 16 /*0x10*/);
    this.label37.TabIndex = 262;
    this.label37.Text = "</>Sameer";
    this.status1.AutoSize = true;
    this.status1.BackColor = Color.Transparent;
    this.status1.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.status1.ForeColor = Color.White;
    this.status1.Location = new Point(14, 403);
    this.status1.Margin = new Padding(2, 0, 2, 0);
    this.status1.Name = "status1";
    this.status1.Size = new Size(31 /*0x1F*/, 17);
    this.status1.TabIndex = 2;
    this.status1.Text = "N/A";
    this.status1.Click += new EventHandler(this.label37_Click);
    this.guna2Panel19.BorderColor = Color.Gray;
    this.guna2Panel19.BorderRadius = 4;
    this.guna2Panel19.BorderThickness = 1;
    ((Control) this.guna2Panel19).Controls.Add((Control) this.main);
    ((Control) this.guna2Panel19).Controls.Add((Control) this.hooked);
    ((Control) this.guna2Panel19).Controls.Add((Control) this.esp);
    ((Control) this.guna2Panel19).Controls.Add((Control) this.exploits);
    ((Control) this.guna2Panel19).Controls.Add((Control) this.keybind);
    ((Control) this.guna2Panel19).Location = new Point(112 /*0x70*/, 66);
    ((Control) this.guna2Panel19).Name = "guna2Panel19";
    ((Control) this.guna2Panel19).Size = new Size(443, 35);
    ((Control) this.guna2Panel19).TabIndex = 263;
    ((Control) this.main).BackColor = Color.Transparent;
    ((Control) this.main).Font = new Font("Calibri", 9.75f, FontStyle.Bold);
    ((Control) this.main).ForeColor = Color.Gray;
    this.main.IsSelectionEnabled = false;
    ((Control) this.main).Location = new Point(124, 8);
    ((Control) this.main).Name = "main";
    ((Control) this.main).Size = new Size(41, 17);
    ((Control) this.main).TabIndex = 31 /*0x1F*/;
    ((Control) this.main).Text = "SNIPER";
    ((Control) this.main).Click += new EventHandler(this.main_Click);
    ((Control) this.hooked).BackColor = Color.Transparent;
    ((Control) this.hooked).Font = new Font("Calibri", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.hooked).ForeColor = Color.White;
    this.hooked.IsSelectionEnabled = false;
    ((Control) this.hooked).Location = new Point(12, 8);
    ((Control) this.hooked).Name = "hooked";
    ((Control) this.hooked).Size = new Size(85, 17);
    ((Control) this.hooked).TabIndex = 30;
    ((Control) this.hooked).Text = "AIM FUNCTION";
    ((Control) this.hooked).Click += new EventHandler(this.hooked_Click);
    ((Control) this.esp).BackColor = Color.Transparent;
    ((Control) this.esp).Font = new Font("Calibri", 9.75f, FontStyle.Bold);
    ((Control) this.esp).ForeColor = Color.Gray;
    this.esp.IsSelectionEnabled = false;
    ((Control) this.esp).Location = new Point(200, 8);
    ((Control) this.esp).Name = "esp";
    ((Control) this.esp).Size = new Size(60, 17);
    ((Control) this.esp).TabIndex = 32 /*0x20*/;
    ((Control) this.esp).Text = "LOCATION";
    ((Control) this.esp).Click += new EventHandler(this.esp_Click);
    ((Control) this.exploits).BackColor = Color.Transparent;
    ((Control) this.exploits).Font = new Font("Calibri", 9.75f, FontStyle.Bold);
    ((Control) this.exploits).ForeColor = Color.Gray;
    this.exploits.IsSelectionEnabled = false;
    ((Control) this.exploits).Location = new Point(293, 8);
    ((Control) this.exploits).Name = "exploits";
    ((Control) this.exploits).Size = new Size(45, 17);
    ((Control) this.exploits).TabIndex = 34;
    ((Control) this.exploits).Text = "BRUTAL";
    ((Control) this.exploits).Click += new EventHandler(this.exploits_Click);
    ((Control) this.keybind).BackColor = Color.Transparent;
    ((Control) this.keybind).Font = new Font("Calibri", 9.75f, FontStyle.Bold);
    ((Control) this.keybind).ForeColor = Color.Gray;
    this.keybind.IsSelectionEnabled = false;
    ((Control) this.keybind).Location = new Point(371, 8);
    ((Control) this.keybind).Name = "keybind";
    ((Control) this.keybind).Size = new Size(47, 17);
    ((Control) this.keybind).TabIndex = 35;
    ((Control) this.keybind).Text = "SETTING";
    ((Control) this.keybind).Click += new EventHandler(this.keybind_Click);
    ((Control) this.panel1).BackColor = Color.Transparent;
    ((Control) this.panel1).Controls.Add((Control) this.guna2Panel6);
    ((Control) this.panel1).Controls.Add((Control) this.guna2Panel22);
    ((Control) this.panel1).Controls.Add((Control) this.guna2Panel1);
    ((Control) this.panel1).Controls.Add((Control) this.guna2Panel15);
    ((Control) this.panel1).ForeColor = Color.Transparent;
    ((Control) this.panel1).Location = new Point(17, 120);
    ((Control) this.panel1).Name = "panel1";
    ((Control) this.panel1).Size = new Size(633, 280);
    ((Control) this.panel1).TabIndex = 39;
    ((Control) this.panel1).Paint += new PaintEventHandler(this.panel1_Paint);
    ((Control) this.guna2Panel6).BackColor = Color.Transparent;
    this.guna2Panel6.BorderRadius = 4;
    ((Control) this.guna2Panel6).Controls.Add((Control) this.h1);
    ((Control) this.guna2Panel6).Controls.Add((Control) this.guna2Button15);
    ((Control) this.guna2Panel6).Controls.Add((Control) this.label5);
    ((Control) this.guna2Panel6).Controls.Add((Control) this.label4);
    this.guna2Panel6.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel6).Location = new Point(21, 11);
    ((Control) this.guna2Panel6).Margin = new Padding(2);
    ((Control) this.guna2Panel6).Name = "guna2Panel6";
    ((Control) this.guna2Panel6).Size = new Size(590, 58);
    ((Control) this.guna2Panel6).TabIndex = 256 /*0x0100*/;
    this.guna2Panel6.UseTransparentBackground = true;
    this.h1.BorderColor = Color.Gray;
    this.h1.BorderRadius = 1;
    this.h1.BorderThickness = 1;
    this.h1.DisabledState.BorderColor = Color.DarkGray;
    this.h1.DisabledState.CustomBorderColor = Color.DarkGray;
    this.h1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.h1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.h1.FillColor = Color.Transparent;
    ((Control) this.h1).Font = new Font("Arial", 8.25f, FontStyle.Bold);
    ((Control) this.h1).ForeColor = Color.WhiteSmoke;
    ((Control) this.h1).Location = new Point(429, 17);
    ((Control) this.h1).Name = "h1";
    this.h1.PressedColor = Color.DimGray;
    ((Control) this.h1).Size = new Size(67, 24);
    ((Control) this.h1).TabIndex = 265;
    ((Control) this.h1).Text = "N/A";
    ((Control) this.h1).Click += new EventHandler(this.h1_Click);
    this.guna2Button15.Animated = true;
    this.guna2Button15.BorderColor = Color.Gray;
    this.guna2Button15.BorderRadius = 5;
    this.guna2Button15.BorderThickness = 2;
    this.guna2Button15.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button15.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button15.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button15.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button15.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button15).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button15).ForeColor = Color.Gray;
    this.guna2Button15.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button15).Location = new Point(502, 14);
    ((Control) this.guna2Button15).Name = "guna2Button15";
    ((Control) this.guna2Button15).Size = new Size(82, 28);
    ((Control) this.guna2Button15).TabIndex = 264;
    ((Control) this.guna2Button15).Text = "LOAD";
    ((Control) this.guna2Button15).Click += new EventHandler(this.guna2Button15_Click);
    this.label5.AutoSize = true;
    this.label5.BackColor = Color.Transparent;
    this.label5.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label5.ForeColor = Color.Gray;
    this.label5.Location = new Point(9, 31 /*0x1F*/);
    this.label5.Margin = new Padding(2, 0, 2, 0);
    this.label5.Name = "label5";
    this.label5.Size = new Size(91, 13);
    this.label5.TabIndex = 3;
    this.label5.Text = "Enabled In-Match";
    this.label4.AutoSize = true;
    this.label4.BackColor = Color.Transparent;
    this.label4.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label4.ForeColor = Color.White;
    this.label4.Location = new Point(9, 12);
    this.label4.Margin = new Padding(2, 0, 2, 0);
    this.label4.Name = "label4";
    this.label4.Size = new Size(137, 17);
    this.label4.TabIndex = 2;
    this.label4.Text = "AIMBOT EXTERNAL";
    this.label4.Click += new EventHandler(this.label4_Click);
    ((Control) this.guna2Panel22).BackColor = Color.Transparent;
    this.guna2Panel22.BorderRadius = 4;
    ((Control) this.guna2Panel22).Controls.Add((Control) this.guna2ToggleSwitch10);
    ((Control) this.guna2Panel22).Controls.Add((Control) this.label41);
    ((Control) this.guna2Panel22).Controls.Add((Control) this.label42);
    ((Control) this.guna2Panel22).Controls.Add((Control) this.guna2Button12);
    this.guna2Panel22.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel22).Location = new Point(21, 214);
    ((Control) this.guna2Panel22).Margin = new Padding(2);
    ((Control) this.guna2Panel22).Name = "guna2Panel22";
    ((Control) this.guna2Panel22).Size = new Size(590, 58);
    ((Control) this.guna2Panel22).TabIndex = 257;
    this.guna2ToggleSwitch10.Animated = true;
    ((Control) this.guna2ToggleSwitch10).BackColor = Color.Transparent;
    this.guna2ToggleSwitch10.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch10.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch10.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch10.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch10.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch10).Location = new Point(519, 16 /*0x10*/);
    ((Control) this.guna2ToggleSwitch10).Name = "guna2ToggleSwitch10";
    ((Control) this.guna2ToggleSwitch10).Size = new Size(40, 23);
    ((Control) this.guna2ToggleSwitch10).TabIndex = 260;
    this.guna2ToggleSwitch10.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch10.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch10.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch10.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch10.CheckedChanged += new EventHandler(this.guna2ToggleSwitch10_CheckedChanged);
    this.label41.AutoSize = true;
    this.label41.BackColor = Color.Transparent;
    this.label41.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label41.ForeColor = Color.Gray;
    this.label41.Location = new Point(9, 31 /*0x1F*/);
    this.label41.Margin = new Padding(2, 0, 2, 0);
    this.label41.Name = "label41";
    this.label41.Size = new Size(91, 13);
    this.label41.TabIndex = 3;
    this.label41.Text = "Enabled In-Match";
    this.label42.AutoSize = true;
    this.label42.BackColor = Color.Transparent;
    this.label42.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label42.ForeColor = Color.White;
    this.label42.Location = new Point(9, 12);
    this.label42.Margin = new Padding(2, 0, 2, 0);
    this.label42.Name = "label42";
    this.label42.Size = new Size(198, 17);
    this.label42.TabIndex = 2;
    this.label42.Text = "AIMBOT DLL TOGGLE (soon)";
    this.guna2Button12.BorderColor = Color.Gray;
    this.guna2Button12.BorderRadius = 1;
    this.guna2Button12.BorderThickness = 1;
    this.guna2Button12.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button12.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button12.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button12.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button12.FillColor = Color.Transparent;
    ((Control) this.guna2Button12).Font = new Font("Arial", 8.25f, FontStyle.Bold);
    ((Control) this.guna2Button12).ForeColor = Color.WhiteSmoke;
    ((Control) this.guna2Button12).Location = new Point(429, 16 /*0x10*/);
    ((Control) this.guna2Button12).Name = "guna2Button12";
    this.guna2Button12.PressedColor = Color.DimGray;
    ((Control) this.guna2Button12).Size = new Size(67, 23);
    ((Control) this.guna2Button12).TabIndex = 182;
    ((Control) this.guna2Button12).Text = "N/A";
    ((Control) this.guna2Button12).Click += new EventHandler(this.h2_Click);
    ((Control) this.guna2Panel1).BackColor = Color.Transparent;
    this.guna2Panel1.BorderRadius = 4;
    ((Control) this.guna2Panel1).Controls.Add((Control) this.label1);
    ((Control) this.guna2Panel1).Controls.Add((Control) this.guna2ToggleSwitch2);
    ((Control) this.guna2Panel1).Controls.Add((Control) this.label2);
    ((Control) this.guna2Panel1).Controls.Add((Control) this.h2);
    this.guna2Panel1.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel1).Location = new Point(21, 79);
    ((Control) this.guna2Panel1).Margin = new Padding(2);
    ((Control) this.guna2Panel1).Name = "guna2Panel1";
    ((Control) this.guna2Panel1).Size = new Size(590, 58);
    ((Control) this.guna2Panel1).TabIndex = 257;
    this.label1.AutoSize = true;
    this.label1.BackColor = Color.Transparent;
    this.label1.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label1.ForeColor = Color.Gray;
    this.label1.Location = new Point(9, 31 /*0x1F*/);
    this.label1.Margin = new Padding(2, 0, 2, 0);
    this.label1.Name = "label1";
    this.label1.Size = new Size(91, 13);
    this.label1.TabIndex = 3;
    this.label1.Text = "Enabled In-Match";
    this.guna2ToggleSwitch2.Animated = true;
    ((Control) this.guna2ToggleSwitch2).BackColor = Color.Transparent;
    this.guna2ToggleSwitch2.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch2.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch2.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch2.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch2.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch2).Location = new Point(519, 16 /*0x10*/);
    ((Control) this.guna2ToggleSwitch2).Name = "guna2ToggleSwitch2";
    ((Control) this.guna2ToggleSwitch2).Size = new Size(40, 23);
    ((Control) this.guna2ToggleSwitch2).TabIndex = 259;
    this.guna2ToggleSwitch2.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch2.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch2.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch2.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch2.CheckedChanged += new EventHandler(this.guna2ToggleSwitch2_CheckedChanged_2);
    this.label2.AutoSize = true;
    this.label2.BackColor = Color.Transparent;
    this.label2.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label2.ForeColor = Color.White;
    this.label2.Location = new Point(9, 12);
    this.label2.Margin = new Padding(2, 0, 2, 0);
    this.label2.Name = "label2";
    this.label2.Size = new Size(168, 17);
    this.label2.TabIndex = 2;
    this.label2.Text = "AIMBOT TOGGLE (soon)";
    this.h2.BorderColor = Color.Gray;
    this.h2.BorderRadius = 1;
    this.h2.BorderThickness = 1;
    this.h2.DisabledState.BorderColor = Color.DarkGray;
    this.h2.DisabledState.CustomBorderColor = Color.DarkGray;
    this.h2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.h2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.h2.FillColor = Color.Transparent;
    ((Control) this.h2).Font = new Font("Arial", 8.25f, FontStyle.Bold);
    ((Control) this.h2).ForeColor = Color.WhiteSmoke;
    ((Control) this.h2).Location = new Point(429, 16 /*0x10*/);
    ((Control) this.h2).Name = "h2";
    this.h2.PressedColor = Color.DimGray;
    ((Control) this.h2).Size = new Size(67, 24);
    ((Control) this.h2).TabIndex = 182;
    ((Control) this.h2).Text = "N/A";
    ((Control) this.h2).Click += new EventHandler(this.h2_Click);
    ((Control) this.guna2Panel15).BackColor = Color.Transparent;
    this.guna2Panel15.BorderRadius = 4;
    ((Control) this.guna2Panel15).Controls.Add((Control) this.guna2Button2);
    ((Control) this.guna2Panel15).Controls.Add((Control) this.guna2Button3);
    ((Control) this.guna2Panel15).Controls.Add((Control) this.label19);
    ((Control) this.guna2Panel15).Controls.Add((Control) this.label29);
    this.guna2Panel15.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel15).Location = new Point(21, 147);
    ((Control) this.guna2Panel15).Margin = new Padding(2);
    ((Control) this.guna2Panel15).Name = "guna2Panel15";
    ((Control) this.guna2Panel15).Size = new Size(590, 58);
    ((Control) this.guna2Panel15).TabIndex = 258;
    this.guna2Button2.BorderColor = Color.Gray;
    this.guna2Button2.BorderRadius = 1;
    this.guna2Button2.BorderThickness = 1;
    this.guna2Button2.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button2.FillColor = Color.Transparent;
    ((Control) this.guna2Button2).Font = new Font("Arial", 8.25f, FontStyle.Bold);
    ((Control) this.guna2Button2).ForeColor = Color.WhiteSmoke;
    ((Control) this.guna2Button2).Location = new Point(429, 15);
    ((Control) this.guna2Button2).Name = "guna2Button2";
    this.guna2Button2.PressedColor = Color.DimGray;
    ((Control) this.guna2Button2).Size = new Size(67, 25);
    ((Control) this.guna2Button2).TabIndex = 266;
    ((Control) this.guna2Button2).Text = "N/A";
    ((Control) this.guna2Button2).Click += new EventHandler(this.guna2Button2_Click);
    this.guna2Button3.Animated = true;
    this.guna2Button3.BorderColor = Color.Gray;
    this.guna2Button3.BorderRadius = 5;
    this.guna2Button3.BorderThickness = 2;
    this.guna2Button3.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button3.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button3).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button3).ForeColor = Color.Gray;
    this.guna2Button3.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button3).Location = new Point(502, 12);
    ((Control) this.guna2Button3).Name = "guna2Button3";
    ((Control) this.guna2Button3).Size = new Size(82, 28);
    ((Control) this.guna2Button3).TabIndex = 265;
    ((Control) this.guna2Button3).Text = "LOAD";
    ((Control) this.guna2Button3).Click += new EventHandler(this.guna2Button3_Click);
    this.label19.AutoSize = true;
    this.label19.BackColor = Color.Transparent;
    this.label19.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label19.ForeColor = Color.Gray;
    this.label19.Location = new Point(9, 31 /*0x1F*/);
    this.label19.Margin = new Padding(2, 0, 2, 0);
    this.label19.Name = "label19";
    this.label19.Size = new Size(91, 13);
    this.label19.TabIndex = 3;
    this.label19.Text = "Enabled In-Match";
    this.label29.AutoSize = true;
    this.label29.BackColor = Color.Transparent;
    this.label29.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label29.ForeColor = Color.White;
    this.label29.Location = new Point(9, 12);
    this.label29.Margin = new Padding(2, 0, 2, 0);
    this.label29.Name = "label29";
    this.label29.Size = new Size(176 /*0xB0*/, 17);
    this.label29.TabIndex = 2;
    this.label29.Text = "AIMBOT NECK DLL (soon)";
    ((Control) this.panel5).Controls.Add((Control) this.lblExpiry);
    ((Control) this.panel5).Controls.Add((Control) this.lblUser);
    ((Control) this.panel5).Controls.Add((Control) this.qrPictureBox);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel27);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel21);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel20);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel18);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel17);
    ((Control) this.panel5).Controls.Add((Control) this.guna2Panel16);
    ((Control) this.panel5).Location = new Point(17, 120);
    ((Control) this.panel5).Name = "panel5";
    ((Control) this.panel5).Size = new Size(633, 280);
    ((Control) this.panel5).TabIndex = 225;
    ((Control) this.panel5).Paint += new PaintEventHandler(this.panel5_Paint);
    this.lblExpiry.AutoSize = true;
    this.lblExpiry.BackColor = Color.Transparent;
    this.lblExpiry.Font = new Font("Bahnschrift", 9.75f);
    this.lblExpiry.ForeColor = Color.White;
    this.lblExpiry.Location = new Point(350, 245);
    this.lblExpiry.Margin = new Padding(2, 0, 2, 0);
    this.lblExpiry.Name = "lblExpiry";
    this.lblExpiry.Size = new Size(29, 16 /*0x10*/);
    this.lblExpiry.TabIndex = 282;
    this.lblExpiry.Text = "N/A";
    this.lblUser.AutoSize = true;
    this.lblUser.BackColor = Color.Transparent;
    this.lblUser.Font = new Font("Bahnschrift", 9.75f);
    this.lblUser.ForeColor = Color.White;
    this.lblUser.Location = new Point(350, 211);
    this.lblUser.Margin = new Padding(2, 0, 2, 0);
    this.lblUser.Name = "lblUser";
    this.lblUser.Size = new Size(29, 16 /*0x10*/);
    this.lblUser.TabIndex = 281;
    this.lblUser.Text = "N/A";
    this.qrPictureBox.Location = new Point(331, 176 /*0xB0*/);
    this.qrPictureBox.Name = "qrPictureBox";
    this.qrPictureBox.Size = new Size(280, 93);
    this.qrPictureBox.TabIndex = 280;
    this.qrPictureBox.TabStop = false;
    ((Control) this.guna2Panel27).BackColor = Color.Transparent;
    this.guna2Panel27.BorderRadius = 4;
    ((Control) this.guna2Panel27).Controls.Add((Control) this.guna2CustomCheckBox2);
    ((Control) this.guna2Panel27).Controls.Add((Control) this.label46);
    ((Control) this.guna2Panel27).Controls.Add((Control) this.label47);
    this.guna2Panel27.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel27).Location = new Point(331, 81);
    ((Control) this.guna2Panel27).Margin = new Padding(2);
    ((Control) this.guna2Panel27).Name = "guna2Panel27";
    ((Control) this.guna2Panel27).Size = new Size(280, 58);
    ((Control) this.guna2Panel27).TabIndex = 268;
    ((Control) this.guna2Panel27).Paint += new PaintEventHandler(this.guna2Panel27_Paint);
    this.guna2CustomCheckBox2.CheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox2.CheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox2.CheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox2.CheckedState.FillColor = Color.Gray;
    ((Control) this.guna2CustomCheckBox2).Location = new Point(248, 18);
    ((Control) this.guna2CustomCheckBox2).Name = "guna2CustomCheckBox2";
    ((Control) this.guna2CustomCheckBox2).Size = new Size(20, 20);
    ((Control) this.guna2CustomCheckBox2).TabIndex = 35;
    ((Control) this.guna2CustomCheckBox2).Text = "guna2CustomCheckBox2";
    this.guna2CustomCheckBox2.UncheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox2.UncheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox2.UncheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox2.UncheckedState.FillColor = Color.DimGray;
    ((Control) this.guna2CustomCheckBox2).Click += new EventHandler(this.guna2CustomCheckBox2_Click);
    this.label46.AutoSize = true;
    this.label46.BackColor = Color.Transparent;
    this.label46.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label46.ForeColor = Color.Gray;
    this.label46.Location = new Point(9, 31 /*0x1F*/);
    this.label46.Margin = new Padding(2, 0, 2, 0);
    this.label46.Name = "label46";
    this.label46.Size = new Size(0, 13);
    this.label46.TabIndex = 3;
    this.label47.AutoSize = true;
    this.label47.BackColor = Color.Transparent;
    this.label47.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label47.ForeColor = Color.White;
    this.label47.Location = new Point(9, 16 /*0x10*/);
    this.label47.Margin = new Padding(2, 0, 2, 0);
    this.label47.Name = "label47";
    this.label47.Size = new Size(150, 17);
    this.label47.TabIndex = 2;
    this.label47.Text = "START WEB-SERVER";
    ((Control) this.guna2Panel21).BackColor = Color.Transparent;
    this.guna2Panel21.BorderRadius = 4;
    ((Control) this.guna2Panel21).Controls.Add((Control) this.guna2CustomCheckBox1);
    ((Control) this.guna2Panel21).Controls.Add((Control) this.label39);
    ((Control) this.guna2Panel21).Controls.Add((Control) this.label40);
    this.guna2Panel21.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel21).Location = new Point(331, 13);
    ((Control) this.guna2Panel21).Margin = new Padding(2);
    ((Control) this.guna2Panel21).Name = "guna2Panel21";
    ((Control) this.guna2Panel21).Size = new Size(280, 58);
    ((Control) this.guna2Panel21).TabIndex = 267;
    this.guna2CustomCheckBox1.CheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox1.CheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox1.CheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox1.CheckedState.FillColor = Color.Gray;
    ((Control) this.guna2CustomCheckBox1).Location = new Point(248, 18);
    ((Control) this.guna2CustomCheckBox1).Name = "guna2CustomCheckBox1";
    ((Control) this.guna2CustomCheckBox1).Size = new Size(20, 20);
    ((Control) this.guna2CustomCheckBox1).TabIndex = 35;
    ((Control) this.guna2CustomCheckBox1).Text = "guna2CustomCheckBox1";
    this.guna2CustomCheckBox1.UncheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox1.UncheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox1.UncheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox1.UncheckedState.FillColor = Color.DimGray;
    ((Control) this.guna2CustomCheckBox1).Click += new EventHandler(this.guna2CustomCheckBox1_Click);
    this.label39.AutoSize = true;
    this.label39.BackColor = Color.Transparent;
    this.label39.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label39.ForeColor = Color.Gray;
    this.label39.Location = new Point(9, 31 /*0x1F*/);
    this.label39.Margin = new Padding(2, 0, 2, 0);
    this.label39.Name = "label39";
    this.label39.Size = new Size(0, 13);
    this.label39.TabIndex = 3;
    this.label40.AutoSize = true;
    this.label40.BackColor = Color.Transparent;
    this.label40.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label40.ForeColor = Color.White;
    this.label40.Location = new Point(9, 16 /*0x10*/);
    this.label40.Margin = new Padding(2, 0, 2, 0);
    this.label40.Name = "label40";
    this.label40.Size = new Size(67, 17);
    this.label40.TabIndex = 2;
    this.label40.Text = "OPEN FF";
    ((Control) this.guna2Panel20).BackColor = Color.Transparent;
    this.guna2Panel20.BorderRadius = 4;
    ((Control) this.guna2Panel20).Controls.Add((Control) this.guna2Button11);
    ((Control) this.guna2Panel20).Controls.Add((Control) this.guna2Button10);
    ((Control) this.guna2Panel20).Controls.Add((Control) this.label36);
    ((Control) this.guna2Panel20).Controls.Add((Control) this.label38);
    this.guna2Panel20.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel20).Location = new Point(19, 213);
    ((Control) this.guna2Panel20).Margin = new Padding(2);
    ((Control) this.guna2Panel20).Name = "guna2Panel20";
    ((Control) this.guna2Panel20).Size = new Size(280, 58);
    ((Control) this.guna2Panel20).TabIndex = 266;
    this.guna2Button11.Animated = true;
    this.guna2Button11.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button11.BorderRadius = 5;
    this.guna2Button11.BorderThickness = 1;
    this.guna2Button11.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button11.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button11.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button11.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button11.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button11).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button11).ForeColor = Color.Gray;
    this.guna2Button11.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button11).Location = new Point(213, 15);
    ((Control) this.guna2Button11).Name = "guna2Button11";
    ((Control) this.guna2Button11).Size = new Size(55, 28);
    ((Control) this.guna2Button11).TabIndex = 263;
    ((Control) this.guna2Button11).Text = "SHOW";
    ((Control) this.guna2Button11).Click += new EventHandler(this.guna2Button11_Click_1);
    this.guna2Button10.Animated = true;
    this.guna2Button10.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button10.BorderRadius = 5;
    this.guna2Button10.BorderThickness = 1;
    this.guna2Button10.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button10.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button10.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button10.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button10.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button10).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button10).ForeColor = Color.Gray;
    this.guna2Button10.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button10).Location = new Point(151, 15);
    ((Control) this.guna2Button10).Name = "guna2Button10";
    ((Control) this.guna2Button10).Size = new Size(56, 28);
    ((Control) this.guna2Button10).TabIndex = 262;
    ((Control) this.guna2Button10).Text = "HIDE";
    ((Control) this.guna2Button10).Click += new EventHandler(this.guna2Button10_Click_1);
    this.label36.AutoSize = true;
    this.label36.BackColor = Color.Transparent;
    this.label36.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label36.ForeColor = Color.Gray;
    this.label36.Location = new Point(9, 31 /*0x1F*/);
    this.label36.Margin = new Padding(2, 0, 2, 0);
    this.label36.Name = "label36";
    this.label36.Size = new Size(0, 13);
    this.label36.TabIndex = 3;
    this.label38.AutoSize = true;
    this.label38.BackColor = Color.Transparent;
    this.label38.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label38.ForeColor = Color.White;
    this.label38.Location = new Point(9, 21);
    this.label38.Margin = new Padding(2, 0, 2, 0);
    this.label38.Name = "label38";
    this.label38.Size = new Size(134, 17);
    this.label38.TabIndex = 2;
    this.label38.Text = "HIDE TASK MANAG";
    ((Control) this.guna2Panel18).BackColor = Color.Transparent;
    this.guna2Panel18.BorderRadius = 4;
    ((Control) this.guna2Panel18).Controls.Add((Control) this.C);
    ((Control) this.guna2Panel18).Controls.Add((Control) this.label34);
    ((Control) this.guna2Panel18).Controls.Add((Control) this.label35);
    this.guna2Panel18.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel18).Location = new Point(19, 149);
    ((Control) this.guna2Panel18).Margin = new Padding(2);
    ((Control) this.guna2Panel18).Name = "guna2Panel18";
    ((Control) this.guna2Panel18).Size = new Size(280, 58);
    ((Control) this.guna2Panel18).TabIndex = 265;
    this.C.Animated = true;
    this.C.BorderColor = Color.White;
    this.C.BorderRadius = 3;
    this.C.BorderThickness = 1;
    this.C.DisabledState.BorderColor = Color.DarkGray;
    this.C.DisabledState.CustomBorderColor = Color.DarkGray;
    this.C.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.C.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.C.FillColor = Color.Gray;
    ((Control) this.C).Font = new Font("Segoe UI", 9f);
    ((Control) this.C).ForeColor = Color.White;
    ((Control) this.C).Location = new Point(248, 19);
    ((Control) this.C).Name = "C";
    ((Control) this.C).Size = new Size(20, 20);
    ((Control) this.C).TabIndex = 41;
    ((Control) this.C).Click += new EventHandler(this.C_Click);
    this.label34.AutoSize = true;
    this.label34.BackColor = Color.Transparent;
    this.label34.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label34.ForeColor = Color.Gray;
    this.label34.Location = new Point(9, 31 /*0x1F*/);
    this.label34.Margin = new Padding(2, 0, 2, 0);
    this.label34.Name = "label34";
    this.label34.Size = new Size(0, 13);
    this.label34.TabIndex = 3;
    this.label35.AutoSize = true;
    this.label35.BackColor = Color.Transparent;
    this.label35.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label35.ForeColor = Color.White;
    this.label35.Location = new Point(9, 22);
    this.label35.Margin = new Padding(2, 0, 2, 0);
    this.label35.Name = "label35";
    this.label35.Size = new Size(88, 17);
    this.label35.TabIndex = 2;
    this.label35.Text = "COLOR SET";
    ((Control) this.guna2Panel17).BackColor = Color.Transparent;
    this.guna2Panel17.BorderRadius = 4;
    ((Control) this.guna2Panel17).Controls.Add((Control) this.guna2CustomCheckBox10);
    ((Control) this.guna2Panel17).Controls.Add((Control) this.label32);
    ((Control) this.guna2Panel17).Controls.Add((Control) this.label33);
    this.guna2Panel17.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel17).Location = new Point(19, 81);
    ((Control) this.guna2Panel17).Margin = new Padding(2);
    ((Control) this.guna2Panel17).Name = "guna2Panel17";
    ((Control) this.guna2Panel17).Size = new Size(280, 58);
    ((Control) this.guna2Panel17).TabIndex = 264;
    ((Control) this.guna2CustomCheckBox10).BackColor = Color.Transparent;
    this.guna2CustomCheckBox10.CheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox10.CheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox10.CheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox10.CheckedState.FillColor = Color.Gray;
    ((Control) this.guna2CustomCheckBox10).Location = new Point(248, 18);
    ((Control) this.guna2CustomCheckBox10).Name = "guna2CustomCheckBox10";
    ((Control) this.guna2CustomCheckBox10).Size = new Size(20, 20);
    ((Control) this.guna2CustomCheckBox10).TabIndex = 35;
    ((Control) this.guna2CustomCheckBox10).Text = "guna2CustomCheckBox10";
    this.guna2CustomCheckBox10.UncheckedState.BorderColor = Color.White;
    this.guna2CustomCheckBox10.UncheckedState.BorderRadius = 3;
    this.guna2CustomCheckBox10.UncheckedState.BorderThickness = 1;
    this.guna2CustomCheckBox10.UncheckedState.FillColor = Color.DimGray;
    ((Control) this.guna2CustomCheckBox10).Click += new EventHandler(this.guna2CustomCheckBox10_Click);
    this.label32.AutoSize = true;
    this.label32.BackColor = Color.Transparent;
    this.label32.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label32.ForeColor = Color.Gray;
    this.label32.Location = new Point(9, 31 /*0x1F*/);
    this.label32.Margin = new Padding(2, 0, 2, 0);
    this.label32.Name = "label32";
    this.label32.Size = new Size(0, 13);
    this.label32.TabIndex = 3;
    this.label33.AutoSize = true;
    this.label33.BackColor = Color.Transparent;
    this.label33.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label33.ForeColor = Color.White;
    this.label33.Location = new Point(13, 20);
    this.label33.Margin = new Padding(2, 0, 2, 0);
    this.label33.Name = "label33";
    this.label33.Size = new Size(75, 17);
    this.label33.TabIndex = 2;
    this.label33.Text = "CLEAN PC";
    ((Control) this.guna2Panel16).BackColor = Color.Transparent;
    this.guna2Panel16.BorderRadius = 4;
    ((Control) this.guna2Panel16).Controls.Add((Control) this.guna2Button5);
    ((Control) this.guna2Panel16).Controls.Add((Control) this.guna2Button4);
    ((Control) this.guna2Panel16).Controls.Add((Control) this.label30);
    ((Control) this.guna2Panel16).Controls.Add((Control) this.label31);
    this.guna2Panel16.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel16).Location = new Point(19, 13);
    ((Control) this.guna2Panel16).Margin = new Padding(2);
    ((Control) this.guna2Panel16).Name = "guna2Panel16";
    ((Control) this.guna2Panel16).Size = new Size(280, 58);
    ((Control) this.guna2Panel16).TabIndex = 263;
    this.guna2Button5.Animated = true;
    this.guna2Button5.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button5.BorderRadius = 5;
    this.guna2Button5.BorderThickness = 1;
    this.guna2Button5.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button5.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button5).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button5).ForeColor = Color.Gray;
    this.guna2Button5.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button5).Location = new Point(158, 13);
    ((Control) this.guna2Button5).Name = "guna2Button5";
    ((Control) this.guna2Button5).Size = new Size(56, 28);
    ((Control) this.guna2Button5).TabIndex = 261;
    ((Control) this.guna2Button5).Text = "ON";
    ((Control) this.guna2Button5).Click += new EventHandler(this.guna2Button5_Click_1);
    this.guna2Button4.Animated = true;
    this.guna2Button4.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button4.BorderRadius = 5;
    this.guna2Button4.BorderThickness = 1;
    this.guna2Button4.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button4.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button4).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button4).ForeColor = Color.Gray;
    this.guna2Button4.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button4).Location = new Point(220, 13);
    ((Control) this.guna2Button4).Name = "guna2Button4";
    ((Control) this.guna2Button4).Size = new Size(48 /*0x30*/, 28);
    ((Control) this.guna2Button4).TabIndex = 260;
    ((Control) this.guna2Button4).Text = "OFF";
    ((Control) this.guna2Button4).Click += new EventHandler(this.guna2Button4_Click_2);
    this.label30.AutoSize = true;
    this.label30.BackColor = Color.Transparent;
    this.label30.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label30.ForeColor = Color.Gray;
    this.label30.Location = new Point(9, 31 /*0x1F*/);
    this.label30.Margin = new Padding(2, 0, 2, 0);
    this.label30.Name = "label30";
    this.label30.Size = new Size(0, 13);
    this.label30.TabIndex = 3;
    this.label31.AutoSize = true;
    this.label31.BackColor = Color.Transparent;
    this.label31.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label31.ForeColor = Color.White;
    this.label31.Location = new Point(9, 16 /*0x10*/);
    this.label31.Margin = new Padding(2, 0, 2, 0);
    this.label31.Name = "label31";
    this.label31.Size = new Size(92, 17);
    this.label31.TabIndex = 2;
    this.label31.Text = "NET ON/OFF";
    ((Control) this.panel4).Controls.Add((Control) this.guna2Panel26);
    ((Control) this.panel4).Controls.Add((Control) this.guna2Panel11);
    ((Control) this.panel4).Controls.Add((Control) this.guna2Panel12);
    ((Control) this.panel4).Controls.Add((Control) this.guna2Panel13);
    ((Control) this.panel4).Controls.Add((Control) this.guna2Panel14);
    ((Control) this.panel4).Location = new Point(17, 120);
    ((Control) this.panel4).Name = "panel4";
    ((Control) this.panel4).Size = new Size(633, 280);
    ((Control) this.panel4).TabIndex = 223;
    ((Control) this.panel4).Paint += new PaintEventHandler(this.panel4_Paint);
    ((Control) this.guna2Panel26).BackColor = Color.Transparent;
    this.guna2Panel26.BorderRadius = 4;
    ((Control) this.guna2Panel26).Controls.Add((Control) this.guna2Button14);
    ((Control) this.guna2Panel26).Controls.Add((Control) this.label17);
    ((Control) this.guna2Panel26).Controls.Add((Control) this.label45);
    this.guna2Panel26.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel26).Location = new Point(21, 220);
    ((Control) this.guna2Panel26).Margin = new Padding(2);
    ((Control) this.guna2Panel26).Name = "guna2Panel26";
    ((Control) this.guna2Panel26).Size = new Size(590, 44);
    ((Control) this.guna2Panel26).TabIndex = 269;
    this.guna2Button14.Animated = true;
    this.guna2Button14.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button14.BorderRadius = 5;
    this.guna2Button14.BorderThickness = 1;
    this.guna2Button14.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button14.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button14.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button14.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button14.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button14).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button14).ForeColor = Color.Gray;
    this.guna2Button14.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button14).Location = new Point(502, 11);
    ((Control) this.guna2Button14).Name = "guna2Button14";
    ((Control) this.guna2Button14).Size = new Size(82, 28);
    ((Control) this.guna2Button14).TabIndex = 258;
    ((Control) this.guna2Button14).Text = "INJECT";
    ((Control) this.guna2Button14).Click += new EventHandler(this.guna2Button14_Click_1);
    this.label17.AutoSize = true;
    this.label17.BackColor = Color.Transparent;
    this.label17.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label17.ForeColor = Color.Gray;
    this.label17.Location = new Point(9, 28);
    this.label17.Margin = new Padding(2, 0, 2, 0);
    this.label17.Name = "label17";
    this.label17.Size = new Size(90, 13);
    this.label17.TabIndex = 3;
    this.label17.Text = "Enabled In-Lobby";
    this.label45.AutoSize = true;
    this.label45.BackColor = Color.Transparent;
    this.label45.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label45.ForeColor = Color.White;
    this.label45.Location = new Point(11, 8);
    this.label45.Margin = new Padding(2, 0, 2, 0);
    this.label45.Name = "label45";
    this.label45.Size = new Size(83, 17);
    this.label45.TabIndex = 2;
    this.label45.Text = "NO RECOIL";
    this.label45.Click += new EventHandler(this.label45_Click);
    ((Control) this.guna2Panel11).BackColor = Color.Transparent;
    this.guna2Panel11.BorderRadius = 4;
    ((Control) this.guna2Panel11).Controls.Add((Control) this.guna2Button6);
    ((Control) this.guna2Panel11).Controls.Add((Control) this.label21);
    ((Control) this.guna2Panel11).Controls.Add((Control) this.label22);
    this.guna2Panel11.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel11).Location = new Point(21, 168);
    ((Control) this.guna2Panel11).Margin = new Padding(2);
    ((Control) this.guna2Panel11).Name = "guna2Panel11";
    ((Control) this.guna2Panel11).Size = new Size(590, 46);
    ((Control) this.guna2Panel11).TabIndex = 266;
    this.guna2Button6.Animated = true;
    this.guna2Button6.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button6.BorderRadius = 5;
    this.guna2Button6.BorderThickness = 1;
    this.guna2Button6.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button6.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button6).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button6).ForeColor = Color.Gray;
    this.guna2Button6.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button6).Location = new Point(502, 11);
    ((Control) this.guna2Button6).Name = "guna2Button6";
    ((Control) this.guna2Button6).Size = new Size(82, 28);
    ((Control) this.guna2Button6).TabIndex = 258;
    ((Control) this.guna2Button6).Text = "INJECT";
    ((Control) this.guna2Button6).Click += new EventHandler(this.guna2Button6_Click);
    this.label21.AutoSize = true;
    this.label21.BackColor = Color.Transparent;
    this.label21.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label21.ForeColor = Color.Gray;
    this.label21.Location = new Point(9, 31 /*0x1F*/);
    this.label21.Margin = new Padding(2, 0, 2, 0);
    this.label21.Name = "label21";
    this.label21.Size = new Size(89, 13);
    this.label21.TabIndex = 3;
    this.label21.Text = "Enabled In-Game";
    this.label22.AutoSize = true;
    this.label22.BackColor = Color.Transparent;
    this.label22.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label22.ForeColor = Color.White;
    this.label22.Location = new Point(9, 12);
    this.label22.Margin = new Padding(2, 0, 2, 0);
    this.label22.Name = "label22";
    this.label22.Size = new Size(84, 17);
    this.label22.TabIndex = 2;
    this.label22.Text = "Fast Reload";
    ((Control) this.guna2Panel12).BackColor = Color.Transparent;
    this.guna2Panel12.BorderRadius = 4;
    ((Control) this.guna2Panel12).Controls.Add((Control) this.guna2Button7);
    ((Control) this.guna2Panel12).Controls.Add((Control) this.label23);
    ((Control) this.guna2Panel12).Controls.Add((Control) this.label24);
    this.guna2Panel12.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel12).Location = new Point(21, 115);
    ((Control) this.guna2Panel12).Margin = new Padding(2);
    ((Control) this.guna2Panel12).Name = "guna2Panel12";
    ((Control) this.guna2Panel12).Size = new Size(590, 48 /*0x30*/);
    ((Control) this.guna2Panel12).TabIndex = 268;
    this.guna2Button7.Animated = true;
    this.guna2Button7.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button7.BorderRadius = 5;
    this.guna2Button7.BorderThickness = 1;
    this.guna2Button7.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button7.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button7).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button7).ForeColor = Color.Gray;
    this.guna2Button7.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button7).Location = new Point(502, 12);
    ((Control) this.guna2Button7).Name = "guna2Button7";
    ((Control) this.guna2Button7).Size = new Size(82, 28);
    ((Control) this.guna2Button7).TabIndex = 259;
    ((Control) this.guna2Button7).Text = "INJECT";
    ((Control) this.guna2Button7).Click += new EventHandler(this.guna2Button7_Click);
    this.label23.AutoSize = true;
    this.label23.BackColor = Color.Transparent;
    this.label23.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label23.ForeColor = Color.Gray;
    this.label23.Location = new Point(9, 31 /*0x1F*/);
    this.label23.Margin = new Padding(2, 0, 2, 0);
    this.label23.Name = "label23";
    this.label23.Size = new Size(90, 13);
    this.label23.TabIndex = 3;
    this.label23.Text = "Enabled In-Lobby";
    this.label24.AutoSize = true;
    this.label24.BackColor = Color.Transparent;
    this.label24.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label24.ForeColor = Color.White;
    this.label24.Location = new Point(9, 12);
    this.label24.Margin = new Padding(2, 0, 2, 0);
    this.label24.Name = "label24";
    this.label24.Size = new Size(132, 17);
    this.label24.TabIndex = 2;
    this.label24.Text = "WALL HACK (soon)";
    ((Control) this.guna2Panel13).BackColor = Color.Transparent;
    this.guna2Panel13.BorderRadius = 4;
    ((Control) this.guna2Panel13).Controls.Add((Control) this.label49);
    ((Control) this.guna2Panel13).Controls.Add((Control) this.label48);
    ((Control) this.guna2Panel13).Controls.Add((Control) this.guna2Button8);
    ((Control) this.guna2Panel13).Controls.Add((Control) this.guna2ToggleSwitch13);
    ((Control) this.guna2Panel13).Controls.Add((Control) this.label25);
    ((Control) this.guna2Panel13).Controls.Add((Control) this.label26);
    this.guna2Panel13.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel13).Location = new Point(21, 59);
    ((Control) this.guna2Panel13).Margin = new Padding(2);
    ((Control) this.guna2Panel13).Name = "guna2Panel13";
    ((Control) this.guna2Panel13).Size = new Size(590, 50);
    ((Control) this.guna2Panel13).TabIndex = 267;
    this.label49.AutoSize = true;
    this.label49.BackColor = Color.Transparent;
    this.label49.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label49.ForeColor = Color.Red;
    this.label49.Location = new Point(104, 10);
    this.label49.Margin = new Padding(2, 0, 2, 0);
    this.label49.Name = "label49";
    this.label49.Size = new Size(45, 17);
    this.label49.TabIndex = 262;
    this.label49.Text = "(Risk)";
    this.label48.AutoSize = true;
    this.label48.BackColor = Color.Transparent;
    this.label48.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label48.ForeColor = Color.Red;
    this.label48.Location = new Point(104, 29);
    this.label48.Margin = new Padding(2, 0, 2, 0);
    this.label48.Name = "label48";
    this.label48.Size = new Size(174, 15);
    this.label48.TabIndex = 261;
    this.label48.Text = "Disable Before finishing Game";
    this.guna2Button8.Animated = true;
    this.guna2Button8.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button8.BorderRadius = 5;
    this.guna2Button8.BorderThickness = 1;
    this.guna2Button8.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button8.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button8.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button8).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button8).ForeColor = Color.Gray;
    this.guna2Button8.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button8).Location = new Point(502, 10);
    ((Control) this.guna2Button8).Name = "guna2Button8";
    ((Control) this.guna2Button8).Size = new Size(82, 28);
    ((Control) this.guna2Button8).TabIndex = 259;
    ((Control) this.guna2Button8).Text = "LOAD";
    ((Control) this.guna2Button8).Click += new EventHandler(this.guna2Button8_Click);
    this.guna2ToggleSwitch13.CheckedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
    this.guna2ToggleSwitch13.CheckedState.FillColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
    this.guna2ToggleSwitch13.CheckedState.InnerBorderColor = Color.White;
    this.guna2ToggleSwitch13.CheckedState.InnerColor = Color.White;
    ((Control) this.guna2ToggleSwitch13).Location = new Point(420, 13);
    ((Control) this.guna2ToggleSwitch13).Name = "guna2ToggleSwitch13";
    ((Control) this.guna2ToggleSwitch13).Size = new Size(49, 20);
    ((Control) this.guna2ToggleSwitch13).TabIndex = 260;
    this.guna2ToggleSwitch13.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
    this.guna2ToggleSwitch13.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
    this.guna2ToggleSwitch13.UncheckedState.InnerBorderColor = Color.White;
    this.guna2ToggleSwitch13.UncheckedState.InnerColor = Color.White;
    this.guna2ToggleSwitch13.CheckedChanged += new EventHandler(this.guna2ToggleSwitch13_CheckedChanged);
    this.label25.AutoSize = true;
    this.label25.BackColor = Color.Transparent;
    this.label25.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label25.ForeColor = Color.Gray;
    this.label25.Location = new Point(9, 31 /*0x1F*/);
    this.label25.Margin = new Padding(2, 0, 2, 0);
    this.label25.Name = "label25";
    this.label25.Size = new Size(92, 13);
    this.label25.TabIndex = 3;
    this.label25.Text = "Enabled In-Game ";
    this.label26.AutoSize = true;
    this.label26.BackColor = Color.Transparent;
    this.label26.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label26.ForeColor = Color.White;
    this.label26.Location = new Point(9, 12);
    this.label26.Margin = new Padding(2, 0, 2, 0);
    this.label26.Name = "label26";
    this.label26.Size = new Size(95, 17);
    this.label26.TabIndex = 2;
    this.label26.Text = "SPEED HACK";
    ((Control) this.guna2Panel14).BackColor = Color.Transparent;
    this.guna2Panel14.BorderRadius = 4;
    ((Control) this.guna2Panel14).Controls.Add((Control) this.guna2Button13);
    ((Control) this.guna2Panel14).Controls.Add((Control) this.guna2Button9);
    ((Control) this.guna2Panel14).Controls.Add((Control) this.label27);
    ((Control) this.guna2Panel14).Controls.Add((Control) this.label28);
    this.guna2Panel14.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel14).Location = new Point(21, 7);
    ((Control) this.guna2Panel14).Margin = new Padding(2);
    ((Control) this.guna2Panel14).Name = "guna2Panel14";
    ((Control) this.guna2Panel14).Size = new Size(590, 46);
    ((Control) this.guna2Panel14).TabIndex = 265;
    this.guna2Button13.BorderColor = Color.Gray;
    this.guna2Button13.BorderRadius = 1;
    this.guna2Button13.BorderThickness = 1;
    this.guna2Button13.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button13.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button13.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button13.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button13.FillColor = Color.Transparent;
    ((Control) this.guna2Button13).Font = new Font("Arial", 8.25f, FontStyle.Bold);
    ((Control) this.guna2Button13).ForeColor = Color.WhiteSmoke;
    ((Control) this.guna2Button13).Location = new Point(420, 11);
    ((Control) this.guna2Button13).Name = "guna2Button13";
    this.guna2Button13.PressedColor = Color.DimGray;
    ((Control) this.guna2Button13).Size = new Size(67, 24);
    ((Control) this.guna2Button13).TabIndex = 266;
    ((Control) this.guna2Button13).Text = "N/A";
    ((Control) this.guna2Button13).Click += new EventHandler(this.guna2Button13_Click_1);
    this.guna2Button9.Animated = true;
    this.guna2Button9.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button9.BorderRadius = 5;
    this.guna2Button9.BorderThickness = 1;
    this.guna2Button9.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button9.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button9.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button9).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button9).ForeColor = Color.Gray;
    this.guna2Button9.HoverState.FillColor = Color.FromArgb(67, 166, 201);
    ((Control) this.guna2Button9).Location = new Point(502, 11);
    ((Control) this.guna2Button9).Name = "guna2Button9";
    ((Control) this.guna2Button9).Size = new Size(82, 28);
    ((Control) this.guna2Button9).TabIndex = 259;
    ((Control) this.guna2Button9).Text = "INJECT";
    ((Control) this.guna2Button9).Click += new EventHandler(this.guna2Button9_Click);
    this.label27.AutoSize = true;
    this.label27.BackColor = Color.Transparent;
    this.label27.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label27.ForeColor = Color.Gray;
    this.label27.Location = new Point(9, 31 /*0x1F*/);
    this.label27.Margin = new Padding(2, 0, 2, 0);
    this.label27.Name = "label27";
    this.label27.Size = new Size(89, 13);
    this.label27.TabIndex = 3;
    this.label27.Text = "Enabled In-Game";
    this.label28.AutoSize = true;
    this.label28.BackColor = Color.Transparent;
    this.label28.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label28.ForeColor = Color.White;
    this.label28.Location = new Point(9, 12);
    this.label28.Margin = new Padding(2, 0, 2, 0);
    this.label28.Name = "label28";
    this.label28.Size = new Size(85, 17);
    this.label28.TabIndex = 2;
    this.label28.Text = "Camera Left";
    this.label28.Click += new EventHandler(this.label28_Click);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel25);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel24);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel10);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel9);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel8);
    ((Control) this.panel3).Controls.Add((Control) this.guna2Panel7);
    ((Control) this.panel3).Location = new Point(17, 120);
    ((Control) this.panel3).Name = "panel3";
    ((Control) this.panel3).Size = new Size(633, 280);
    ((Control) this.panel3).TabIndex = 224 /*0xE0*/;
    ((Control) this.panel3).Paint += new PaintEventHandler(this.panel3_Paint);
    ((Control) this.guna2Panel25).BackColor = Color.Transparent;
    this.guna2Panel25.BorderRadius = 4;
    ((Control) this.guna2Panel25).Controls.Add((Control) this.guna2ToggleSwitch12);
    ((Control) this.guna2Panel25).Controls.Add((Control) this.label15);
    this.guna2Panel25.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel25).Location = new Point(21, 178);
    ((Control) this.guna2Panel25).Margin = new Padding(2);
    ((Control) this.guna2Panel25).Name = "guna2Panel25";
    ((Control) this.guna2Panel25).Size = new Size(590, 38);
    ((Control) this.guna2Panel25).TabIndex = 266;
    this.guna2ToggleSwitch12.Animated = true;
    ((Control) this.guna2ToggleSwitch12).BackColor = Color.Transparent;
    this.guna2ToggleSwitch12.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch12.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch12.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch12.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch12.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch12).Location = new Point(538, 8);
    ((Control) this.guna2ToggleSwitch12).Name = "guna2ToggleSwitch12";
    ((Control) this.guna2ToggleSwitch12).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch12).TabIndex = 6;
    this.guna2ToggleSwitch12.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch12.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch12.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch12.UncheckedState.InnerColor = Color.DimGray;
    this.label15.AutoSize = true;
    this.label15.BackColor = Color.Transparent;
    this.label15.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label15.ForeColor = Color.White;
    this.label15.Location = new Point(9, 13);
    this.label15.Margin = new Padding(2, 0, 2, 0);
    this.label15.Name = "label15";
    this.label15.Size = new Size(132, 17);
    this.label15.TabIndex = 2;
    this.label15.Text = "CHAMS ESP (soon)";
    ((Control) this.guna2Panel24).BackColor = Color.Transparent;
    this.guna2Panel24.BorderRadius = 4;
    ((Control) this.guna2Panel24).Controls.Add((Control) this.guna2ToggleSwitch11);
    ((Control) this.guna2Panel24).Controls.Add((Control) this.label13);
    this.guna2Panel24.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel24).Location = new Point(21, 136);
    ((Control) this.guna2Panel24).Margin = new Padding(2);
    ((Control) this.guna2Panel24).Name = "guna2Panel24";
    ((Control) this.guna2Panel24).Size = new Size(590, 38);
    ((Control) this.guna2Panel24).TabIndex = 265;
    this.guna2ToggleSwitch11.Animated = true;
    ((Control) this.guna2ToggleSwitch11).BackColor = Color.Transparent;
    this.guna2ToggleSwitch11.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch11.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch11.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch11.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch11.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch11).Location = new Point(538, 7);
    ((Control) this.guna2ToggleSwitch11).Name = "guna2ToggleSwitch11";
    ((Control) this.guna2ToggleSwitch11).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch11).TabIndex = 6;
    this.guna2ToggleSwitch11.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch11.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch11.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch11.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch11.CheckedChanged += new EventHandler(this.guna2ToggleSwitch11_CheckedChanged);
    this.label13.AutoSize = true;
    this.label13.BackColor = Color.Transparent;
    this.label13.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label13.ForeColor = Color.White;
    this.label13.Location = new Point(9, 13);
    this.label13.Margin = new Padding(2, 0, 2, 0);
    this.label13.Name = "label13";
    this.label13.Size = new Size(147, 17);
    this.label13.TabIndex = 2;
    this.label13.Text = "CHAMS MOCO (soon)";
    ((Control) this.guna2Panel10).BackColor = Color.Transparent;
    this.guna2Panel10.BorderRadius = 4;
    ((Control) this.guna2Panel10).Controls.Add((Control) this.guna2ToggleSwitch8);
    ((Control) this.guna2Panel10).Controls.Add((Control) this.label20);
    this.guna2Panel10.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel10).Location = new Point(21, 222);
    ((Control) this.guna2Panel10).Margin = new Padding(2);
    ((Control) this.guna2Panel10).Name = "guna2Panel10";
    ((Control) this.guna2Panel10).Size = new Size(590, 45);
    ((Control) this.guna2Panel10).TabIndex = 263;
    this.guna2ToggleSwitch8.Animated = true;
    ((Control) this.guna2ToggleSwitch8).BackColor = Color.Transparent;
    this.guna2ToggleSwitch8.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch8.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch8.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch8.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch8.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch8).Location = new Point(538, 10);
    ((Control) this.guna2ToggleSwitch8).Name = "guna2ToggleSwitch8";
    ((Control) this.guna2ToggleSwitch8).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch8).TabIndex = 6;
    this.guna2ToggleSwitch8.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch8.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch8.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch8.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch8.CheckedChanged += new EventHandler(this.guna2ToggleSwitch8_CheckedChanged);
    this.label20.AutoSize = true;
    this.label20.BackColor = Color.Transparent;
    this.label20.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label20.ForeColor = Color.White;
    this.label20.Location = new Point(9, 13);
    this.label20.Margin = new Padding(2, 0, 2, 0);
    this.label20.Name = "label20";
    this.label20.Size = new Size(133, 17);
    this.label20.TabIndex = 2;
    this.label20.Text = "STREAMER MODE ";
    ((Control) this.guna2Panel9).BackColor = Color.Transparent;
    this.guna2Panel9.BorderRadius = 4;
    ((Control) this.guna2Panel9).Controls.Add((Control) this.guna2ToggleSwitch1);
    ((Control) this.guna2Panel9).Controls.Add((Control) this.label18);
    this.guna2Panel9.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel9).Location = new Point(21, 95);
    ((Control) this.guna2Panel9).Margin = new Padding(2);
    ((Control) this.guna2Panel9).Name = "guna2Panel9";
    ((Control) this.guna2Panel9).Size = new Size(590, 37);
    ((Control) this.guna2Panel9).TabIndex = 264;
    this.guna2ToggleSwitch1.Animated = true;
    ((Control) this.guna2ToggleSwitch1).BackColor = Color.Transparent;
    this.guna2ToggleSwitch1.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch1.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch1.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch1.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch1.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch1).Location = new Point(539, 7);
    ((Control) this.guna2ToggleSwitch1).Name = "guna2ToggleSwitch1";
    ((Control) this.guna2ToggleSwitch1).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch1).TabIndex = 5;
    this.guna2ToggleSwitch1.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch1.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch1.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch1.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch1.CheckedChanged += new EventHandler(this.guna2ToggleSwitch1_CheckedChanged_1);
    this.label18.AutoSize = true;
    this.label18.BackColor = Color.Transparent;
    this.label18.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label18.ForeColor = Color.White;
    this.label18.Location = new Point(9, 12);
    this.label18.Margin = new Padding(2, 0, 2, 0);
    this.label18.Name = "label18";
    this.label18.Size = new Size(156, 17);
    this.label18.TabIndex = 2;
    this.label18.Text = "CHAMS BOX 3D (soon)";
    ((Control) this.guna2Panel8).BackColor = Color.Transparent;
    this.guna2Panel8.BorderRadius = 4;
    ((Control) this.guna2Panel8).Controls.Add((Control) this.guna2ToggleSwitch6);
    ((Control) this.guna2Panel8).Controls.Add((Control) this.label16);
    this.guna2Panel8.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel8).Location = new Point(21, 51);
    ((Control) this.guna2Panel8).Margin = new Padding(2);
    ((Control) this.guna2Panel8).Name = "guna2Panel8";
    ((Control) this.guna2Panel8).Size = new Size(590, 39);
    ((Control) this.guna2Panel8).TabIndex = 263;
    this.guna2ToggleSwitch6.Animated = true;
    ((Control) this.guna2ToggleSwitch6).BackColor = Color.Transparent;
    this.guna2ToggleSwitch6.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch6.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch6.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch6.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch6.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch6).Location = new Point(539, 8);
    ((Control) this.guna2ToggleSwitch6).Name = "guna2ToggleSwitch6";
    ((Control) this.guna2ToggleSwitch6).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch6).TabIndex = 4;
    this.guna2ToggleSwitch6.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch6.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch6.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch6.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch6.CheckedChanged += new EventHandler(this.guna2ToggleSwitch6_CheckedChanged);
    this.label16.AutoSize = true;
    this.label16.BackColor = Color.Transparent;
    this.label16.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label16.ForeColor = Color.White;
    this.label16.Location = new Point(9, 12);
    this.label16.Margin = new Padding(2, 0, 2, 0);
    this.label16.Name = "label16";
    this.label16.Size = new Size(96 /*0x60*/, 17);
    this.label16.TabIndex = 2;
    this.label16.Text = "CHAMS BLUE";
    ((Control) this.guna2Panel7).BackColor = Color.Transparent;
    this.guna2Panel7.BorderRadius = 4;
    ((Control) this.guna2Panel7).Controls.Add((Control) this.guna2ToggleSwitch5);
    ((Control) this.guna2Panel7).Controls.Add((Control) this.label14);
    this.guna2Panel7.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel7).Location = new Point(21, 6);
    ((Control) this.guna2Panel7).Margin = new Padding(2);
    ((Control) this.guna2Panel7).Name = "guna2Panel7";
    ((Control) this.guna2Panel7).Size = new Size(590, 40);
    ((Control) this.guna2Panel7).TabIndex = 262;
    this.guna2ToggleSwitch5.Animated = true;
    ((Control) this.guna2ToggleSwitch5).BackColor = Color.Transparent;
    this.guna2ToggleSwitch5.CheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch5.CheckedState.BorderThickness = 2;
    this.guna2ToggleSwitch5.CheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch5.CheckedState.InnerBorderColor = Color.DodgerBlue;
    this.guna2ToggleSwitch5.CheckedState.InnerColor = Color.DodgerBlue;
    ((Control) this.guna2ToggleSwitch5).Location = new Point(539, 8);
    ((Control) this.guna2ToggleSwitch5).Name = "guna2ToggleSwitch5";
    ((Control) this.guna2ToggleSwitch5).Size = new Size(40, 21);
    ((Control) this.guna2ToggleSwitch5).TabIndex = 4;
    this.guna2ToggleSwitch5.UncheckedState.BorderColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch5.UncheckedState.FillColor = Color.FromArgb(44, 44, 44);
    this.guna2ToggleSwitch5.UncheckedState.InnerBorderColor = Color.DimGray;
    this.guna2ToggleSwitch5.UncheckedState.InnerColor = Color.DimGray;
    this.guna2ToggleSwitch5.CheckedChanged += new EventHandler(this.guna2ToggleSwitch5_CheckedChanged);
    this.label14.AutoSize = true;
    this.label14.BackColor = Color.Transparent;
    this.label14.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label14.ForeColor = Color.White;
    this.label14.Location = new Point(9, 8);
    this.label14.Margin = new Padding(2, 0, 2, 0);
    this.label14.Name = "label14";
    this.label14.Size = new Size(100, 17);
    this.label14.TabIndex = 2;
    this.label14.Text = "CHAMS MENU";
    ((Control) this.panel2).Controls.Add((Control) this.guna2Panel23);
    ((Control) this.panel2).Controls.Add((Control) this.guna2Panel3);
    ((Control) this.panel2).Controls.Add((Control) this.guna2Panel5);
    ((Control) this.panel2).Controls.Add((Control) this.guna2Panel4);
    ((Control) this.panel2).Controls.Add((Control) this.guna2Panel2);
    ((Control) this.panel2).Location = new Point(17, 117);
    ((Control) this.panel2).Name = "panel2";
    ((Control) this.panel2).Size = new Size(633, 280);
    ((Control) this.panel2).TabIndex = 40;
    ((Control) this.panel2).Paint += new PaintEventHandler(this.panel2_Paint);
    ((Control) this.guna2Panel23).BackColor = Color.Transparent;
    this.guna2Panel23.BorderRadius = 4;
    ((Control) this.guna2Panel23).Controls.Add((Control) this.guna2Button16);
    ((Control) this.guna2Panel23).Controls.Add((Control) this.label43);
    ((Control) this.guna2Panel23).Controls.Add((Control) this.label44);
    this.guna2Panel23.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel23).Location = new Point(21, 115);
    ((Control) this.guna2Panel23).Margin = new Padding(2);
    ((Control) this.guna2Panel23).Name = "guna2Panel23";
    ((Control) this.guna2Panel23).Size = new Size(590, 45);
    ((Control) this.guna2Panel23).TabIndex = 262;
    this.guna2Button16.Animated = true;
    this.guna2Button16.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button16.BorderRadius = 5;
    this.guna2Button16.BorderThickness = 1;
    this.guna2Button16.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button16.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button16.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button16.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button16.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button16).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button16).ForeColor = Color.Gray;
    this.guna2Button16.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button16).Location = new Point(497, 6);
    ((Control) this.guna2Button16).Name = "guna2Button16";
    ((Control) this.guna2Button16).Size = new Size(82, 28);
    ((Control) this.guna2Button16).TabIndex = 258;
    ((Control) this.guna2Button16).Text = "INJECT";
    ((Control) this.guna2Button16).Click += new EventHandler(this.guna2Button16_Click);
    this.label43.AutoSize = true;
    this.label43.BackColor = Color.Transparent;
    this.label43.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label43.ForeColor = Color.Gray;
    this.label43.Location = new Point(9, 31 /*0x1F*/);
    this.label43.Margin = new Padding(2, 0, 2, 0);
    this.label43.Name = "label43";
    this.label43.Size = new Size(91, 13);
    this.label43.TabIndex = 3;
    this.label43.Text = "Enabled In-Match";
    this.label44.AutoSize = true;
    this.label44.BackColor = Color.Transparent;
    this.label44.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label44.ForeColor = Color.White;
    this.label44.Location = new Point(9, 12);
    this.label44.Margin = new Padding(2, 0, 2, 0);
    this.label44.Name = "label44";
    this.label44.Size = new Size(101, 17);
    this.label44.TabIndex = 2;
    this.label44.Text = "M82B SWITCH";
    ((Control) this.guna2Panel3).BackColor = Color.Transparent;
    this.guna2Panel3.BorderRadius = 4;
    ((Control) this.guna2Panel3).Controls.Add((Control) this.guna2Button18);
    ((Control) this.guna2Panel3).Controls.Add((Control) this.label7);
    ((Control) this.guna2Panel3).Controls.Add((Control) this.label8);
    this.guna2Panel3.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel3).Location = new Point(21, 63 /*0x3F*/);
    ((Control) this.guna2Panel3).Margin = new Padding(2);
    ((Control) this.guna2Panel3).Name = "guna2Panel3";
    ((Control) this.guna2Panel3).Size = new Size(590, 47);
    ((Control) this.guna2Panel3).TabIndex = 259;
    this.guna2Button18.Animated = true;
    this.guna2Button18.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button18.BorderRadius = 5;
    this.guna2Button18.BorderThickness = 1;
    this.guna2Button18.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button18.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button18.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button18.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button18.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button18).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button18).ForeColor = Color.Gray;
    this.guna2Button18.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button18).Location = new Point(497, 11);
    ((Control) this.guna2Button18).Name = "guna2Button18";
    ((Control) this.guna2Button18).Size = new Size(82, 28);
    ((Control) this.guna2Button18).TabIndex = 258;
    ((Control) this.guna2Button18).Text = "INJECT";
    ((Control) this.guna2Button18).Click += new EventHandler(this.guna2Button18_Click);
    this.label7.AutoSize = true;
    this.label7.BackColor = Color.Transparent;
    this.label7.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label7.ForeColor = Color.Gray;
    this.label7.Location = new Point(9, 31 /*0x1F*/);
    this.label7.Margin = new Padding(2, 0, 2, 0);
    this.label7.Name = "label7";
    this.label7.Size = new Size(91, 13);
    this.label7.TabIndex = 3;
    this.label7.Text = "Enabled In-Match";
    this.label8.AutoSize = true;
    this.label8.BackColor = Color.Transparent;
    this.label8.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label8.ForeColor = Color.White;
    this.label8.Location = new Point(9, 12);
    this.label8.Margin = new Padding(2, 0, 2, 0);
    this.label8.Name = "label8";
    this.label8.Size = new Size(186, 17);
    this.label8.TabIndex = 2;
    this.label8.Text = "ALL SNIPER SWITCH (Test)";
    ((Control) this.guna2Panel5).BackColor = Color.Transparent;
    this.guna2Panel5.BorderRadius = 4;
    ((Control) this.guna2Panel5).Controls.Add((Control) this.guna2Button17);
    ((Control) this.guna2Panel5).Controls.Add((Control) this.label11);
    ((Control) this.guna2Panel5).Controls.Add((Control) this.label12);
    this.guna2Panel5.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel5).Location = new Point(21, 165);
    ((Control) this.guna2Panel5).Margin = new Padding(2);
    ((Control) this.guna2Panel5).Name = "guna2Panel5";
    ((Control) this.guna2Panel5).Size = new Size(590, 45);
    ((Control) this.guna2Panel5).TabIndex = 261;
    this.guna2Button17.Animated = true;
    this.guna2Button17.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button17.BorderRadius = 5;
    this.guna2Button17.BorderThickness = 1;
    this.guna2Button17.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button17.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button17.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button17.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button17.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button17).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button17).ForeColor = Color.Gray;
    this.guna2Button17.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button17).Location = new Point(496, 9);
    ((Control) this.guna2Button17).Name = "guna2Button17";
    ((Control) this.guna2Button17).Size = new Size(82, 28);
    ((Control) this.guna2Button17).TabIndex = 259;
    ((Control) this.guna2Button17).Text = "INJECT";
    ((Control) this.guna2Button17).Click += new EventHandler(this.guna2Button17_Click);
    this.label11.AutoSize = true;
    this.label11.BackColor = Color.Transparent;
    this.label11.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label11.ForeColor = Color.Gray;
    this.label11.Location = new Point(9, 31 /*0x1F*/);
    this.label11.Margin = new Padding(2, 0, 2, 0);
    this.label11.Name = "label11";
    this.label11.Size = new Size(91, 13);
    this.label11.TabIndex = 3;
    this.label11.Text = "Enabled In-Match";
    this.label12.AutoSize = true;
    this.label12.BackColor = Color.Transparent;
    this.label12.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label12.ForeColor = Color.White;
    this.label12.Location = new Point(9, 12);
    this.label12.Margin = new Padding(2, 0, 2, 0);
    this.label12.Name = "label12";
    this.label12.Size = new Size(79, 17);
    this.label12.TabIndex = 2;
    this.label12.Text = "M24 Switch";
    ((Control) this.guna2Panel4).BackColor = Color.Transparent;
    this.guna2Panel4.BorderRadius = 4;
    ((Control) this.guna2Panel4).Controls.Add((Control) this.guna2Button19);
    ((Control) this.guna2Panel4).Controls.Add((Control) this.label9);
    ((Control) this.guna2Panel4).Controls.Add((Control) this.label10);
    this.guna2Panel4.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel4).Location = new Point(21, 214);
    ((Control) this.guna2Panel4).Margin = new Padding(2);
    ((Control) this.guna2Panel4).Name = "guna2Panel4";
    ((Control) this.guna2Panel4).Size = new Size(590, 46);
    ((Control) this.guna2Panel4).TabIndex = 260;
    this.guna2Button19.Animated = true;
    this.guna2Button19.BorderColor = Color.FromArgb(30, 30, 30);
    this.guna2Button19.BorderRadius = 5;
    this.guna2Button19.BorderThickness = 1;
    this.guna2Button19.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button19.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button19.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button19.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button19.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.guna2Button19).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.guna2Button19).ForeColor = Color.Gray;
    this.guna2Button19.HoverState.FillColor = Color.White;
    ((Control) this.guna2Button19).Location = new Point(496, 12);
    ((Control) this.guna2Button19).Name = "guna2Button19";
    ((Control) this.guna2Button19).Size = new Size(82, 28);
    ((Control) this.guna2Button19).TabIndex = 260;
    ((Control) this.guna2Button19).Text = "INJECT";
    ((Control) this.guna2Button19).Click += new EventHandler(this.guna2Button19_Click);
    this.label9.AutoSize = true;
    this.label9.BackColor = Color.Transparent;
    this.label9.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label9.ForeColor = Color.Gray;
    this.label9.Location = new Point(9, 31 /*0x1F*/);
    this.label9.Margin = new Padding(2, 0, 2, 0);
    this.label9.Name = "label9";
    this.label9.Size = new Size(91, 13);
    this.label9.TabIndex = 3;
    this.label9.Text = "Enabled In-Match";
    this.label10.AutoSize = true;
    this.label10.BackColor = Color.Transparent;
    this.label10.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label10.ForeColor = Color.White;
    this.label10.Location = new Point(9, 11);
    this.label10.Margin = new Padding(2, 0, 2, 0);
    this.label10.Name = "label10";
    this.label10.Size = new Size(161, 17);
    this.label10.TabIndex = 2;
    this.label10.Text = "AWM AMMO LOCATION";
    ((Control) this.guna2Panel2).BackColor = Color.Transparent;
    this.guna2Panel2.BorderRadius = 4;
    ((Control) this.guna2Panel2).Controls.Add((Control) this.label3);
    ((Control) this.guna2Panel2).Controls.Add((Control) this.label6);
    ((Control) this.guna2Panel2).Controls.Add((Control) this.keybind1);
    this.guna2Panel2.FillColor = Color.FromArgb(19, 19, 19);
    ((Control) this.guna2Panel2).Location = new Point(21, 7);
    ((Control) this.guna2Panel2).Margin = new Padding(2);
    ((Control) this.guna2Panel2).Name = "guna2Panel2";
    ((Control) this.guna2Panel2).Size = new Size(590, 48 /*0x30*/);
    ((Control) this.guna2Panel2).TabIndex = 258;
    this.label3.AutoSize = true;
    this.label3.BackColor = Color.Transparent;
    this.label3.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label3.ForeColor = Color.Gray;
    this.label3.Location = new Point(9, 31 /*0x1F*/);
    this.label3.Margin = new Padding(2, 0, 2, 0);
    this.label3.Name = "label3";
    this.label3.Size = new Size(91, 13);
    this.label3.TabIndex = 3;
    this.label3.Text = "Enabled In-Match";
    this.label6.AutoSize = true;
    this.label6.BackColor = Color.Transparent;
    this.label6.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label6.ForeColor = Color.White;
    this.label6.Location = new Point(9, 12);
    this.label6.Margin = new Padding(2, 0, 2, 0);
    this.label6.Name = "label6";
    this.label6.Size = new Size(151, 17);
    this.label6.TabIndex = 2;
    this.label6.Text = "SNIPER SCOPE LOAD";
    this.keybind1.Animated = true;
    this.keybind1.BorderColor = Color.FromArgb(30, 30, 30);
    this.keybind1.BorderRadius = 5;
    this.keybind1.BorderThickness = 1;
    this.keybind1.DisabledState.BorderColor = Color.DarkGray;
    this.keybind1.DisabledState.CustomBorderColor = Color.DarkGray;
    this.keybind1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.keybind1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.keybind1.FillColor = Color.FromArgb(20, 20, 20);
    ((Control) this.keybind1).Font = new Font("Bahnschrift SemiCondensed", 9f);
    ((Control) this.keybind1).ForeColor = Color.Gray;
    this.keybind1.HoverState.FillColor = Color.White;
    ((Control) this.keybind1).Location = new Point(497, 11);
    ((Control) this.keybind1).Name = "keybind1";
    ((Control) this.keybind1).Size = new Size(82, 28);
    ((Control) this.keybind1).TabIndex = 257;
    ((Control) this.keybind1).Text = "INJECT";
    ((Control) this.keybind1).Click += new EventHandler(this.keybind1_Click);
    this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl1.TargetControl = (Control) this.mainpnl;
    this.guna2DragControl1.TransparentWhileDrag = false;
    this.hotkeyTimer.Tick += new EventHandler(this.hotkeyTimer_Tick_1);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.FromArgb(17, 17, 17);
    this.ClientSize = new Size(667, 431);
    this.Controls.Add((Control) this.mainpnl);
    this.ForeColor = Color.Transparent;
    this.FormBorderStyle = FormBorderStyle.None;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.Name = nameof (UI);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Load += new EventHandler(this.UI_Load);
    ((Control) this.mainpnl).ResumeLayout(false);
    ((Control) this.mainpnl).PerformLayout();
    ((ISupportInitialize) this.guna2CirclePictureBox1).EndInit();
    ((Control) this.guna2Panel19).ResumeLayout(false);
    ((Control) this.guna2Panel19).PerformLayout();
    ((Control) this.panel1).ResumeLayout(false);
    ((Control) this.guna2Panel6).ResumeLayout(false);
    ((Control) this.guna2Panel6).PerformLayout();
    ((Control) this.guna2Panel22).ResumeLayout(false);
    ((Control) this.guna2Panel22).PerformLayout();
    ((Control) this.guna2Panel1).ResumeLayout(false);
    ((Control) this.guna2Panel1).PerformLayout();
    ((Control) this.guna2Panel15).ResumeLayout(false);
    ((Control) this.guna2Panel15).PerformLayout();
    ((Control) this.panel5).ResumeLayout(false);
    ((Control) this.panel5).PerformLayout();
    ((ISupportInitialize) this.qrPictureBox).EndInit();
    ((Control) this.guna2Panel27).ResumeLayout(false);
    ((Control) this.guna2Panel27).PerformLayout();
    ((Control) this.guna2Panel21).ResumeLayout(false);
    ((Control) this.guna2Panel21).PerformLayout();
    ((Control) this.guna2Panel20).ResumeLayout(false);
    ((Control) this.guna2Panel20).PerformLayout();
    ((Control) this.guna2Panel18).ResumeLayout(false);
    ((Control) this.guna2Panel18).PerformLayout();
    ((Control) this.guna2Panel17).ResumeLayout(false);
    ((Control) this.guna2Panel17).PerformLayout();
    ((Control) this.guna2Panel16).ResumeLayout(false);
    ((Control) this.guna2Panel16).PerformLayout();
    ((Control) this.panel4).ResumeLayout(false);
    ((Control) this.guna2Panel26).ResumeLayout(false);
    ((Control) this.guna2Panel26).PerformLayout();
    ((Control) this.guna2Panel11).ResumeLayout(false);
    ((Control) this.guna2Panel11).PerformLayout();
    ((Control) this.guna2Panel12).ResumeLayout(false);
    ((Control) this.guna2Panel12).PerformLayout();
    ((Control) this.guna2Panel13).ResumeLayout(false);
    ((Control) this.guna2Panel13).PerformLayout();
    ((Control) this.guna2Panel14).ResumeLayout(false);
    ((Control) this.guna2Panel14).PerformLayout();
    ((Control) this.panel3).ResumeLayout(false);
    ((Control) this.guna2Panel25).ResumeLayout(false);
    ((Control) this.guna2Panel25).PerformLayout();
    ((Control) this.guna2Panel24).ResumeLayout(false);
    ((Control) this.guna2Panel24).PerformLayout();
    ((Control) this.guna2Panel10).ResumeLayout(false);
    ((Control) this.guna2Panel10).PerformLayout();
    ((Control) this.guna2Panel9).ResumeLayout(false);
    ((Control) this.guna2Panel9).PerformLayout();
    ((Control) this.guna2Panel8).ResumeLayout(false);
    ((Control) this.guna2Panel8).PerformLayout();
    ((Control) this.guna2Panel7).ResumeLayout(false);
    ((Control) this.guna2Panel7).PerformLayout();
    ((Control) this.panel2).ResumeLayout(false);
    ((Control) this.guna2Panel23).ResumeLayout(false);
    ((Control) this.guna2Panel23).PerformLayout();
    ((Control) this.guna2Panel3).ResumeLayout(false);
    ((Control) this.guna2Panel3).PerformLayout();
    ((Control) this.guna2Panel5).ResumeLayout(false);
    ((Control) this.guna2Panel5).PerformLayout();
    ((Control) this.guna2Panel4).ResumeLayout(false);
    ((Control) this.guna2Panel4).PerformLayout();
    ((Control) this.guna2Panel2).ResumeLayout(false);
    ((Control) this.guna2Panel2).PerformLayout();
    this.ResumeLayout(false);
  }

  private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

  public class TriangleParticle
  {
    public float X { get; set; }

    public float Y { get; set; }

    public float Speed { get; set; }

    public float Size { get; set; }

    public Color Color { get; set; }

    public TriangleParticle(float x, float y, float speed, float size, Color color)
    {
      this.X = x;
      this.Y = y;
      this.Speed = speed;
      this.Size = size;
      this.Color = color;
    }
  }
}
