﻿// Decompiled with JetBrains decompiler
// Type: ERA_XITERS.LoadingFrom
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace ERA_XITERS;

public class LoadingFrom : Form
{
  private const int ParticleCount = 40;
  private readonly Random _random = new Random();
  private readonly PointF[] _particlePositions = new PointF[40];
  private readonly float[] _particleSpeeds = new float[40];
  private readonly float[] _particleSizes = new float[40];
  private readonly float[] _particleRotations = new float[40];
  private Color _particleColor = Color.FromArgb(146, 145, 145);
  private Color _glowColor = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
  private bool _particlesEnabled = true;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2CircleProgressBar pbar;
  private Guna2HtmlLabel labelProgress;
  private Label label1;
  private Timer timer1;
  private Label label2;
  private Guna2Panel guna2Panel1;
  private Guna2DragControl guna2DragControl1;
  private Guna2HtmlLabel guna2HtmlLabel1;
  private Guna2HtmlLabel guna2HtmlLabel4;

  public LoadingFrom()
  {
    this.InitializeComponent();
    this.DoubleBuffered = true;
    this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    this.InitializeParticles();
    Timer timer = new Timer();
    timer.Interval = 16 /*0x10*/;
    timer.Tick += (EventHandler) ((s, e) =>
    {
      this.UpdateParticles();
      this.Invalidate();
    });
    timer.Start();
  }

  private void InitializeParticles()
  {
    Size size = Screen.PrimaryScreen.Bounds.Size;
    for (int i = 0; i < 40; ++i)
      this.ResetParticle(i, size);
  }

  private void ResetParticle(int i, Size screenSize)
  {
    this._particlePositions[i] = new PointF((float) this._random.Next(screenSize.Width), -20f);
    this._particleSpeeds[i] = (float) (2.0 + this._random.NextDouble() * 4.0);
    this._particleSizes[i] = (float) (4.0 + this._random.NextDouble() * 6.0);
    this._particleRotations[i] = 0.0f;
  }

  private void UpdateParticles()
  {
    if (!this._particlesEnabled)
      return;
    Size size = Screen.PrimaryScreen.Bounds.Size;
    float num = 3f;
    for (int i = 0; i < 40; ++i)
    {
      this._particlePositions[i] = new PointF(this._particlePositions[i].X, this._particlePositions[i].Y + num * this._particleSpeeds[i]);
      this._particleRotations[i] += 0.05f;
      if ((double) this._particlePositions[i].Y > (double) (size.Height + 20))
        this.ResetParticle(i, size);
    }
  }

  protected override void OnPaint(PaintEventArgs e)
  {
    base.OnPaint(e);
    if (!this._particlesEnabled)
      return;
    Graphics graphics = e.Graphics;
    graphics.SmoothingMode = SmoothingMode.HighQuality;
    float num1 = 2.09439516f;
    for (int index1 = 0; index1 < 40; ++index1)
    {
      PointF particlePosition = this._particlePositions[index1];
      float particleSiz = this._particleSizes[index1];
      float particleRotation = this._particleRotations[index1];
      using (Brush brush = (Brush) new SolidBrush(this._glowColor))
      {
        float num2 = particleSiz * 2.5f;
        graphics.FillEllipse(brush, particlePosition.X - num2 / 2f, particlePosition.Y - num2 / 2f, num2, num2);
      }
      PointF[] points = new PointF[3];
      for (int index2 = 0; index2 < 3; ++index2)
      {
        float num3 = particleRotation + (float) index2 * num1;
        points[index2] = new PointF(particlePosition.X + particleSiz * (float) Math.Cos((double) num3), particlePosition.Y + particleSiz * (float) Math.Sin((double) num3));
      }
      using (Brush brush = (Brush) new SolidBrush(this._particleColor))
        graphics.FillPolygon(brush, points);
    }
  }

  private void label1_Click(object sender, EventArgs e)
  {
  }

  private void guna2CircleProgressBar1_ValueChanged(object sender, EventArgs e)
  {
  }

  private void timer1_Tick(object sender, EventArgs e)
  {
    if (this.pbar.Value < 100)
    {
      ++this.pbar.Value;
      ((Control) this.labelProgress).Text = this.pbar.Value.ToString() + "%";
      if (this.pbar.Value == 1 || this.pbar.Value == 30 || this.pbar.Value == 60)
        return;
      int num = this.pbar.Value;
    }
    else
    {
      this.timer1.Stop();
      this.Hide();
      new UI().Show();
    }
  }

  private async void LoadingFrom_Load(object sender, EventArgs e)
  {
    this.pbar.Minimum = 0;
    this.pbar.Maximum = 100;
    this.pbar.Value = 0;
    this.timer1.Interval = 50;
    this.timer1.Start();
    this.label1.Text = "   Loading Codes!";
    await Task.Delay(2000);
    this.label1.Text = "   Preparing UI!";
    await Task.Delay(2000);
    this.label1.Text = "   Starting Panel!";
    await Task.Delay(2000);
    this.label1.Text = "   Welcome Back!";
    await Task.Delay(1000);
  }

  private void guna2Panel1_Paint(object sender, PaintEventArgs e)
  {
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (LoadingFrom));
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.pbar = new Guna2CircleProgressBar();
    this.label2 = new Label();
    this.labelProgress = new Guna2HtmlLabel();
    this.label1 = new Label();
    this.timer1 = new Timer(this.components);
    this.guna2Panel1 = new Guna2Panel();
    this.guna2HtmlLabel1 = new Guna2HtmlLabel();
    this.guna2HtmlLabel4 = new Guna2HtmlLabel();
    this.guna2DragControl1 = new Guna2DragControl(this.components);
    ((Control) this.pbar).SuspendLayout();
    ((Control) this.guna2Panel1).SuspendLayout();
    this.SuspendLayout();
    this.guna2BorderlessForm1.AnimationInterval = 1500;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    ((Control) this.pbar).BackColor = Color.Transparent;
    ((Control) this.pbar).Controls.Add((Control) this.label2);
    ((Control) this.pbar).Controls.Add((Control) this.labelProgress);
    this.pbar.FillColor = Color.Transparent;
    this.pbar.FillThickness = 10;
    ((Control) this.pbar).Font = new Font("Segoe UI", 12f);
    ((Control) this.pbar).ForeColor = Color.White;
    ((Control) this.pbar).Location = new Point(109, 152);
    this.pbar.Minimum = 0;
    ((Control) this.pbar).Name = "pbar";
    this.pbar.ProgressColor = Color.DimGray;
    this.pbar.ProgressColor2 = Color.FromArgb(64 /*0x40*/, 64 /*0x40*/, 64 /*0x40*/);
    this.pbar.ShadowDecoration.Mode = (ShadowMode) 1;
    ((Control) this.pbar).Size = new Size(130, 130);
    ((Control) this.pbar).TabIndex = 0;
    ((Control) this.pbar).Text = "pbar";
    this.pbar.ValueChanged += new EventHandler(this.guna2CircleProgressBar1_ValueChanged);
    this.label2.AutoSize = true;
    this.label2.Font = new Font("Nirmala UI", 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label2.ForeColor = Color.White;
    this.label2.Location = new Point(-4, 52);
    this.label2.Name = "label2";
    this.label2.Size = new Size(0, 21);
    this.label2.TabIndex = 281;
    ((Control) this.labelProgress).BackColor = Color.Transparent;
    ((Control) this.labelProgress).Font = new Font("Segoe UI", 14.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    ((Control) this.labelProgress).Location = new Point(50, 52);
    ((Control) this.labelProgress).Name = "labelProgress";
    ((Control) this.labelProgress).Size = new Size(30, 27);
    ((Control) this.labelProgress).TabIndex = 0;
    ((Control) this.labelProgress).Text = "0%";
    this.label1.AutoSize = true;
    this.label1.BackColor = Color.Transparent;
    this.label1.Font = new Font("Nirmala UI", 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label1.ForeColor = Color.White;
    this.label1.Location = new Point(105, 285);
    this.label1.Name = "label1";
    this.label1.Size = new Size(139, 21);
    this.label1.TabIndex = 280;
    this.label1.Text = "Loading Account";
    this.label1.Click += new EventHandler(this.label1_Click);
    this.timer1.Tick += new EventHandler(this.timer1_Tick);
    ((Control) this.guna2Panel1).BackColor = Color.Transparent;
    this.guna2Panel1.BorderColor = Color.Gray;
    this.guna2Panel1.BorderRadius = 4;
    this.guna2Panel1.BorderThickness = 1;
    ((Control) this.guna2Panel1).Controls.Add((Control) this.guna2HtmlLabel1);
    ((Control) this.guna2Panel1).Controls.Add((Control) this.guna2HtmlLabel4);
    ((Control) this.guna2Panel1).Location = new Point(0, 0);
    ((Control) this.guna2Panel1).Name = "guna2Panel1";
    ((Control) this.guna2Panel1).Size = new Size(342, 430);
    ((Control) this.guna2Panel1).TabIndex = 281;
    ((Control) this.guna2Panel1).Paint += new PaintEventHandler(this.guna2Panel1_Paint);
    ((Control) this.guna2HtmlLabel1).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel1).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold);
    ((Control) this.guna2HtmlLabel1).ForeColor = Color.White;
    this.guna2HtmlLabel1.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel1).Location = new Point(65, 21);
    ((Control) this.guna2HtmlLabel1).Name = "guna2HtmlLabel1";
    ((Control) this.guna2HtmlLabel1).Size = new Size(94, 41);
    ((Control) this.guna2HtmlLabel1).TabIndex = 281;
    ((Control) this.guna2HtmlLabel1).Text = "TELAPOS";
    ((Control) this.guna2HtmlLabel4).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel4).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold);
    ((Control) this.guna2HtmlLabel4).ForeColor = Color.Gray;
    this.guna2HtmlLabel4.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel4).Location = new Point(165, 21);
    ((Control) this.guna2HtmlLabel4).Name = "guna2HtmlLabel4";
    ((Control) this.guna2HtmlLabel4).Size = new Size(81, 41);
    ((Control) this.guna2HtmlLabel4).TabIndex = 280;
    ((Control) this.guna2HtmlLabel4).Text = "CHEATS";
    this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl1.TargetControl = (Control) this.guna2Panel1;
    this.guna2DragControl1.UseTransparentDrag = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.FromArgb(8, 8, 8);
    this.ClientSize = new Size(342, 432);
    this.Controls.Add((Control) this.label1);
    this.Controls.Add((Control) this.pbar);
    this.Controls.Add((Control) this.guna2Panel1);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.Name = nameof (LoadingFrom);
    this.Text = nameof (LoadingFrom);
    this.Load += new EventHandler(this.LoadingFrom_Load);
    ((Control) this.pbar).ResumeLayout(false);
    ((Control) this.pbar).PerformLayout();
    ((Control) this.guna2Panel1).ResumeLayout(false);
    ((Control) this.guna2Panel1).PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
