﻿// Decompiled with JetBrains decompiler
// Type: ERA_XITERS.Login
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using ABNORMAL_CHEATS.Properties;
using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using KeyAuth;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

#nullable disable
namespace ERA_XITERS;

public class Login : Form
{
  private Size originalButtonSize;
  private Point originalButtonLocation;
  private Timer clickAnimationTimer;
  private float clickAnimationRatio;
  private const float clickAnimationSpeed = 0.25f;
  private Color originalBackColor;
  private Color originalForeColor;
  private bool isClickAnimationActive;
  private Timer animationTimer;
  private readonly Size originalSize = new Size(272, 31 /*0x1F*/);
  private readonly Size hoverSize = new Size(285, 40);
  private Point usernameLocation = new Point(43, 208 /*0xD0*/);
  private Point passwordLocation = new Point(43, 261);
  private float usernameRatio;
  private float passwordRatio;
  private const float animationSpeed = 0.08f;
  public static api KeyAuthApp = new api("Telapos", "E4kQPYxBxj", "1.0");
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2Button guna2Button2;
  private Label status;
  private Label label37;
  private Guna2TextBox guna2TextBox1;
  private Guna2TextBox guna2TextBox2;
  private Guna2Panel loginpanel;
  private Guna2HtmlLabel guna2HtmlLabel1;
  private Guna2CirclePictureBox guna2CirclePictureBox1;
  private Guna2Button guna2Button4;
  private Guna2DragControl guna2DragControl1;
  private Guna2HtmlLabel guna2HtmlLabel2;
  private Guna2CheckBox guna2CheckBox1;

  public Login()
  {
    this.InitializeComponent();
    ((Control) this.guna2TextBox1).Size = this.originalSize;
    ((Control) this.guna2TextBox1).Location = this.usernameLocation;
    ((Control) this.guna2TextBox2).Size = this.originalSize;
    ((Control) this.guna2TextBox2).Location = this.passwordLocation;
    this.DoubleBuffered = true;
    this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    this.InitializeParticles();
    this.SetupAnimation1();
    this.SetupAnimation();
    this.clickAnimationTimer = new Timer()
    {
      Interval = 16 /*0x10*/
    };
    this.clickAnimationTimer.Tick += new EventHandler(this.AdvancedClickAnimationTimer_Tick);
    ((Control) this.guna2TextBox1).MouseEnter += new EventHandler(this.username_MouseEnter);
    ((Control) this.guna2TextBox1).MouseLeave += new EventHandler(this.username_MouseLeave);
    ((Control) this.guna2TextBox2).MouseEnter += new EventHandler(this.password_MouseEnter);
    ((Control) this.guna2TextBox2).MouseLeave += new EventHandler(this.password_MouseLeave);
    this.MouseMove += (MouseEventHandler) ((s, e) => this.animationTimer?.Start());
    ((Control) this.guna2Button2).Click += (EventHandler) ((s, e) => this.StartClickAnimation());
  }

  private void SetupAnimation()
  {
    this.animationTimer = new Timer()
    {
      Interval = 16 /*0x10*/
    };
    this.animationTimer.Tick += new EventHandler(this.AnimationTimer_Tick);
    this.animationTimer.Start();
  }

  private void AnimationTimer_Tick(object sender, EventArgs e)
  {
    bool isHovering1 = ((Control) this.guna2TextBox1).RectangleToScreen(((Control) this.guna2TextBox1).ClientRectangle).Contains(Cursor.Position);
    bool isHovering2 = ((Control) this.guna2TextBox2).RectangleToScreen(((Control) this.guna2TextBox2).ClientRectangle).Contains(Cursor.Position);
    this.usernameRatio = this.UpdateRatio(this.usernameRatio, isHovering1);
    this.passwordRatio = this.UpdateRatio(this.passwordRatio, isHovering2);
    ((Control) this.guna2TextBox1).SuspendLayout();
    this.UpdateControlSizeAndPosition(this.guna2TextBox1, this.usernameRatio, this.usernameLocation);
    ((Control) this.guna2TextBox1).ResumeLayout();
    ((Control) this.guna2TextBox1).Invalidate();
    ((Control) this.guna2TextBox2).SuspendLayout();
    this.UpdateControlSizeAndPosition(this.guna2TextBox2, this.passwordRatio, this.passwordLocation);
    ((Control) this.guna2TextBox2).ResumeLayout();
    ((Control) this.guna2TextBox2).Invalidate();
    if (isHovering1 || (double) this.usernameRatio > 1.0 / 1000.0 || isHovering2 || (double) this.passwordRatio > 1.0 / 1000.0)
      return;
    this.animationTimer.Stop();
  }

  private void StartClickAnimation()
  {
    try
    {
      if (this.guna2Button2 == null)
        return;
      this.originalButtonSize = ((Control) this.guna2Button2).Size;
      this.originalButtonLocation = ((Control) this.guna2Button2).Location;
      this.originalBackColor = this.guna2Button2.FillColor;
      this.originalForeColor = ((Control) this.guna2Button2).ForeColor;
      this.clickAnimationRatio = 0.0f;
      this.isClickAnimationActive = true;
      this.clickAnimationTimer?.Start();
    }
    catch
    {
    }
  }

  private void SetupAnimation1()
  {
    if (this.animationTimer != null)
      return;
    this.animationTimer = new Timer()
    {
      Interval = 16 /*0x10*/
    };
    this.animationTimer.Tick += new EventHandler(this.AdvancedClickAnimationTimer_Tick);
    this.animationTimer.Start();
    foreach (Control control in (ArrangedElementCollection) this.Controls)
    {
      control.MouseMove -= (MouseEventHandler) ((s, e) => this.animationTimer.Start());
      control.MouseMove += (MouseEventHandler) ((s, e) => this.animationTimer.Start());
    }
    this.MouseMove -= (MouseEventHandler) ((s, e) => this.animationTimer.Start());
    this.MouseMove += (MouseEventHandler) ((s, e) => this.animationTimer.Start());
  }

  private void AdvancedClickAnimationTimer_Tick(object sender, EventArgs e)
  {
    if (!this.isClickAnimationActive)
      return;
    this.clickAnimationRatio += 0.25f;
    if ((double) this.clickAnimationRatio >= 1.0)
    {
      this.clickAnimationRatio = 0.0f;
      this.isClickAnimationActive = false;
      this.clickAnimationTimer.Stop();
      if (this.guna2Button2 == null)
        return;
      this.guna2Button2.FillColor = this.originalBackColor;
      ((Control) this.guna2Button2).ForeColor = this.originalForeColor;
      ((Control) this.guna2Button2).Size = this.originalButtonSize;
      ((Control) this.guna2Button2).Location = this.originalButtonLocation;
    }
    else
    {
      float num1 = (float) (1.0 - 0.079999998211860657 * (double) this.clickAnimationRatio);
      Size size = new Size(Math.Max(1, (int) ((double) this.originalButtonSize.Width * (double) num1)), Math.Max(1, (int) ((double) this.originalButtonSize.Height * (double) num1)));
      int num2 = (this.originalButtonSize.Width - size.Width) / 2;
      int num3 = (this.originalButtonSize.Height - size.Height) / 2;
      if (this.guna2Button2 == null)
        return;
      ((Control) this.guna2Button2).Size = size;
      ((Control) this.guna2Button2).Location = new Point(this.originalButtonLocation.X + num2, this.originalButtonLocation.Y + num3);
      int num4 = (int) ((double) this.originalBackColor.R * (1.0 - 0.30000001192092896 * (double) this.clickAnimationRatio));
      int num5 = (int) ((double) this.originalBackColor.G * (1.0 - 0.30000001192092896 * (double) this.clickAnimationRatio));
      int num6 = (int) ((double) this.originalBackColor.B * (1.0 - 0.30000001192092896 * (double) this.clickAnimationRatio));
      this.guna2Button2.FillColor = Color.FromArgb((int) this.originalBackColor.A, num4 < 0 ? 0 : (num4 > (int) byte.MaxValue ? (int) byte.MaxValue : num4), num5 < 0 ? 0 : (num5 > (int) byte.MaxValue ? (int) byte.MaxValue : num5), num6 < 0 ? 0 : (num6 > (int) byte.MaxValue ? (int) byte.MaxValue : num6));
    }
  }

  private void username_MouseEnter(object sender, EventArgs e) => this.animationTimer.Start();

  private void username_MouseLeave(object sender, EventArgs e) => this.animationTimer.Start();

  private void password_MouseEnter(object sender, EventArgs e) => this.animationTimer.Start();

  private void password_MouseLeave(object sender, EventArgs e) => this.animationTimer.Start();

  private void UpdateControlSizeAndPosition(
    Guna2TextBox control,
    float ratio,
    Point originalLocation)
  {
    Size size1;
    ref Size local = ref size1;
    Size size2 = this.originalSize;
    int width1 = size2.Width;
    size2 = this.hoverSize;
    int width2 = size2.Width;
    size2 = this.originalSize;
    int width3 = size2.Width;
    int num1 = (int) ((double) (width2 - width3) * (double) ratio);
    int width4 = width1 + num1;
    size2 = this.originalSize;
    int height1 = size2.Height;
    size2 = this.hoverSize;
    int height2 = size2.Height;
    size2 = this.originalSize;
    int height3 = size2.Height;
    int num2 = (int) ((double) (height2 - height3) * (double) ratio);
    int height4 = height1 + num2;
    local = new Size(width4, height4);
    int num3 = (this.originalSize.Width - size1.Width) / 2;
    int num4 = (this.originalSize.Height - size1.Height) / 2;
    ((Control) control).Size = size1;
    ((Control) control).Location = new Point(originalLocation.X + num3, originalLocation.Y + num4);
  }

  private float UpdateRatio(float ratio, bool isHovering)
  {
    return !isHovering ? Math.Max(0.0f, ratio - 0.08f) : Math.Min(1f, ratio + 0.08f);
  }

  private Size CalculateSize(float ratio)
  {
    Size size = this.originalSize;
    int width1 = size.Width;
    size = this.hoverSize;
    int width2 = size.Width;
    size = this.originalSize;
    int width3 = size.Width;
    int num1 = (int) ((double) (width2 - width3) * (double) ratio);
    int width4 = width1 + num1;
    size = this.originalSize;
    int height1 = size.Height;
    size = this.hoverSize;
    int height2 = size.Height;
    size = this.originalSize;
    int height3 = size.Height;
    int num2 = (int) ((double) (height2 - height3) * (double) ratio);
    int height4 = height1 + num2;
    return new Size(width4, height4);
  }

  private void InitializeParticles()
  {
  }

  private void ResetParticle(int i, Size screenSize)
  {
  }

  private void UpdateParticles()
  {
  }

  protected override void OnPaint(PaintEventArgs e) => base.OnPaint(e);

  public void ToggleParticles()
  {
  }

  private void Login_Load(object sender, EventArgs e)
  {
    Login.KeyAuthApp.init();
    Login.KeyAuthApp.init();
    if (string.IsNullOrEmpty(Settings.Default.Username))
      return;
    ((Control) this.guna2TextBox1).Text = Settings.Default.Username;
    ((Control) this.guna2TextBox2).Text = Settings.Default.Password;
    ((CheckBox) this.guna2CheckBox1).Checked = true;
  }

  private void status1_Click(object sender, EventArgs e)
  {
  }

  private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
  {
  }

  private void bar3_Click(object sender, EventArgs e)
  {
  }

  private void guna2Button3_Click(object sender, EventArgs e)
  {
  }

  private void h2_Click(object sender, EventArgs e)
  {
  }

  private void guna2TextBox1_TextChanged(object sender, EventArgs e)
  {
  }

  private void guna2Button3_Click_1(object sender, EventArgs e) => Environment.Exit(0);

  private void guna2Button2_Click(object sender, EventArgs e)
  {
    Login.KeyAuthApp.login(((Control) this.guna2TextBox1).Text, ((Control) this.guna2TextBox2).Text);
    if (Login.KeyAuthApp.response.success)
    {
      Settings.Default.Username = ((Control) this.guna2TextBox1).Text;
      Settings.Default.Password = ((Control) this.guna2TextBox2).Text;
      Settings.Default.Save();
      this.Hide();
      new LoadingFrom().Show();
    }
    else
      this.status.Text = "Status: " + Login.KeyAuthApp.response.message;
  }

  private void guna2Button1_Click(object sender, EventArgs e)
  {
    new LoadingFrom().Show();
    this.Hide();
  }

  private void guna2ProgressBar1_ValueChanged(object sender, EventArgs e)
  {
  }

  private void guna2Button4_Click(object sender, EventArgs e) => Environment.Exit(0);

  private void loginpanel_Paint(object sender, PaintEventArgs e)
  {
  }

  private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
  {
    if (((CheckBox) this.guna2CheckBox1).Checked)
      this.guna2TextBox2.UseSystemPasswordChar = false;
    else
      this.guna2TextBox2.UseSystemPasswordChar = true;
  }

  private void guna2HtmlLabel1_Click(object sender, EventArgs e)
  {
  }

  private void guna2HtmlLabel4_Click(object sender, EventArgs e)
  {
  }

  private void guna2HtmlLabel3_Click(object sender, EventArgs e)
  {
  }

  private void guna2CirclePictureBox1_Click_1(object sender, EventArgs e)
  {
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Login));
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2Button2 = new Guna2Button();
    this.status = new Label();
    this.label37 = new Label();
    this.guna2TextBox1 = new Guna2TextBox();
    this.guna2TextBox2 = new Guna2TextBox();
    this.loginpanel = new Guna2Panel();
    this.guna2CheckBox1 = new Guna2CheckBox();
    this.guna2HtmlLabel2 = new Guna2HtmlLabel();
    this.guna2Button4 = new Guna2Button();
    this.guna2HtmlLabel1 = new Guna2HtmlLabel();
    this.guna2CirclePictureBox1 = new Guna2CirclePictureBox();
    this.guna2DragControl1 = new Guna2DragControl(this.components);
    ((Control) this.loginpanel).SuspendLayout();
    ((ISupportInitialize) this.guna2CirclePictureBox1).BeginInit();
    this.SuspendLayout();
    this.guna2BorderlessForm1.AnimateWindow = true;
    this.guna2BorderlessForm1.AnimationInterval = 1500;
    this.guna2BorderlessForm1.BorderRadius = 4;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.ResizeForm = false;
    this.guna2BorderlessForm1.ShadowColor = Color.Gray;
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2Button2.Animated = true;
    this.guna2Button2.BorderColor = Color.FromArgb(33, 33, 33);
    this.guna2Button2.BorderRadius = 8;
    this.guna2Button2.BorderThickness = 1;
    this.guna2Button2.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button2.FillColor = Color.Gray;
    ((Control) this.guna2Button2).Font = new Font("Bahnschrift Condensed", 9f, FontStyle.Bold);
    ((Control) this.guna2Button2).ForeColor = Color.White;
    this.guna2Button2.HoverState.FillColor = Color.Goldenrod;
    ((Control) this.guna2Button2).Location = new Point(109, 317);
    ((Control) this.guna2Button2).Name = "guna2Button2";
    ((Control) this.guna2Button2).Size = new Size(124, 35);
    ((Control) this.guna2Button2).TabIndex = 39;
    ((Control) this.guna2Button2).Text = "L O G I N";
    ((Control) this.guna2Button2).Click += new EventHandler(this.guna2Button2_Click);
    this.status.AutoSize = true;
    this.status.BackColor = Color.Transparent;
    this.status.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.status.ForeColor = Color.White;
    this.status.Location = new Point(2, 410);
    this.status.Margin = new Padding(2, 0, 2, 0);
    this.status.Name = "status";
    this.status.Size = new Size(31 /*0x1F*/, 17);
    this.status.TabIndex = 40;
    this.status.Text = "N/A";
    this.status.Click += new EventHandler(this.status1_Click);
    this.label37.AutoSize = true;
    this.label37.BackColor = Color.Transparent;
    this.label37.Font = new Font("Bahnschrift", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label37.ForeColor = Color.Gray;
    this.label37.Location = new Point(269, 408);
    this.label37.Margin = new Padding(2, 0, 2, 0);
    this.label37.Name = "label37";
    this.label37.Size = new Size(70, 16 /*0x10*/);
    this.label37.TabIndex = 263;
    this.label37.Text = "</>Sameer";
    this.guna2TextBox1.Animated = true;
    ((Control) this.guna2TextBox1).BackColor = Color.Transparent;
    this.guna2TextBox1.BorderColor = Color.Gray;
    this.guna2TextBox1.BorderRadius = 4;
    this.guna2TextBox1.BorderThickness = 2;
    ((Control) this.guna2TextBox1).Cursor = Cursors.IBeam;
    this.guna2TextBox1.DefaultText = "";
    this.guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208 /*0xD0*/, 208 /*0xD0*/, 208 /*0xD0*/);
    this.guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
    this.guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
    this.guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
    this.guna2TextBox1.FillColor = Color.FromArgb(15, 15, 15);
    this.guna2TextBox1.FocusedState.BorderColor = Color.White;
    this.guna2TextBox1.FocusedState.FillColor = Color.Transparent;
    this.guna2TextBox1.FocusedState.ForeColor = Color.Transparent;
    this.guna2TextBox1.FocusedState.PlaceholderForeColor = Color.Transparent;
    ((Control) this.guna2TextBox1).Font = new Font("Nirmala UI", 9f);
    ((Control) this.guna2TextBox1).ForeColor = Color.White;
    this.guna2TextBox1.HoverState.BorderColor = Color.White;
    this.guna2TextBox1.HoverState.FillColor = Color.Transparent;
    this.guna2TextBox1.HoverState.ForeColor = Color.Transparent;
    this.guna2TextBox1.HoverState.PlaceholderForeColor = Color.White;
    ((Control) this.guna2TextBox1).Location = new Point(38, 198);
    ((Control) this.guna2TextBox1).Name = "guna2TextBox1";
    this.guna2TextBox1.PlaceholderForeColor = Color.White;
    this.guna2TextBox1.PlaceholderText = "Enter Username";
    this.guna2TextBox1.SelectedText = "";
    ((Control) this.guna2TextBox1).Size = new Size(272, 36);
    ((Control) this.guna2TextBox1).TabIndex = 268;
    this.guna2TextBox1.TextAlign = HorizontalAlignment.Center;
    this.guna2TextBox1.TextChanged += new EventHandler(this.guna2TextBox1_TextChanged);
    this.guna2TextBox2.Animated = true;
    ((Control) this.guna2TextBox2).BackColor = Color.Transparent;
    this.guna2TextBox2.BorderColor = Color.Gray;
    this.guna2TextBox2.BorderRadius = 4;
    this.guna2TextBox2.BorderThickness = 2;
    ((Control) this.guna2TextBox2).Cursor = Cursors.IBeam;
    this.guna2TextBox2.DefaultText = "";
    this.guna2TextBox2.DisabledState.BorderColor = Color.FromArgb(208 /*0xD0*/, 208 /*0xD0*/, 208 /*0xD0*/);
    this.guna2TextBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
    this.guna2TextBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
    this.guna2TextBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
    this.guna2TextBox2.FillColor = Color.FromArgb(15, 15, 15);
    this.guna2TextBox2.FocusedState.BorderColor = Color.White;
    this.guna2TextBox2.FocusedState.FillColor = Color.Transparent;
    this.guna2TextBox2.FocusedState.ForeColor = Color.Transparent;
    this.guna2TextBox2.FocusedState.PlaceholderForeColor = Color.Transparent;
    ((Control) this.guna2TextBox2).Font = new Font("Nirmala UI", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2TextBox2).ForeColor = Color.White;
    this.guna2TextBox2.HoverState.BorderColor = Color.White;
    this.guna2TextBox2.HoverState.FillColor = Color.Transparent;
    this.guna2TextBox2.HoverState.ForeColor = Color.Transparent;
    this.guna2TextBox2.HoverState.PlaceholderForeColor = Color.White;
    ((Control) this.guna2TextBox2).Location = new Point(38, 259);
    ((Control) this.guna2TextBox2).Name = "guna2TextBox2";
    this.guna2TextBox2.PlaceholderForeColor = Color.White;
    this.guna2TextBox2.PlaceholderText = "Enter Password";
    this.guna2TextBox2.SelectedText = "";
    ((Control) this.guna2TextBox2).Size = new Size(272, 38);
    ((Control) this.guna2TextBox2).TabIndex = 269;
    this.guna2TextBox2.TextAlign = HorizontalAlignment.Center;
    ((Control) this.loginpanel).BackColor = Color.Transparent;
    this.loginpanel.BorderColor = Color.Gray;
    this.loginpanel.BorderRadius = 4;
    this.loginpanel.BorderThickness = 1;
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2CheckBox1);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2HtmlLabel2);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2Button4);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2HtmlLabel1);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2CirclePictureBox1);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2Button2);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2TextBox1);
    ((Control) this.loginpanel).Controls.Add((Control) this.guna2TextBox2);
    ((Control) this.loginpanel).Controls.Add((Control) this.label37);
    ((Control) this.loginpanel).Controls.Add((Control) this.status);
    ((Control) this.loginpanel).Location = new Point(1, 2);
    ((Control) this.loginpanel).Name = "loginpanel";
    ((Control) this.loginpanel).Size = new Size(348, 429);
    ((Control) this.loginpanel).TabIndex = 271;
    this.loginpanel.UseTransparentBackground = true;
    ((Control) this.loginpanel).Paint += new PaintEventHandler(this.loginpanel_Paint);
    ((Control) this.guna2CheckBox1).AutoSize = true;
    this.guna2CheckBox1.CheckedState.BorderColor = Color.White;
    this.guna2CheckBox1.CheckedState.BorderRadius = 0;
    this.guna2CheckBox1.CheckedState.BorderThickness = 2;
    this.guna2CheckBox1.CheckedState.FillColor = Color.Gray;
    ((Control) this.guna2CheckBox1).Font = new Font("Bahnschrift Condensed", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    ((Control) this.guna2CheckBox1).ForeColor = Color.White;
    ((Control) this.guna2CheckBox1).Location = new Point(38, 390);
    ((Control) this.guna2CheckBox1).Name = "guna2CheckBox1";
    ((Control) this.guna2CheckBox1).Size = new Size(56, 17);
    ((Control) this.guna2CheckBox1).TabIndex = 277;
    ((Control) this.guna2CheckBox1).Text = "SAVE US";
    this.guna2CheckBox1.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
    this.guna2CheckBox1.UncheckedState.BorderRadius = 2;
    this.guna2CheckBox1.UncheckedState.BorderThickness = 2;
    this.guna2CheckBox1.UncheckedState.FillColor = Color.FromArgb(64 /*0x40*/, 64 /*0x40*/, 64 /*0x40*/);
    ((CheckBox) this.guna2CheckBox1).CheckedChanged += new EventHandler(this.guna2CheckBox1_CheckedChanged);
    ((Control) this.guna2HtmlLabel2).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel2).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold);
    ((Control) this.guna2HtmlLabel2).ForeColor = Color.White;
    this.guna2HtmlLabel2.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel2).Location = new Point(87, 20);
    ((Control) this.guna2HtmlLabel2).Name = "guna2HtmlLabel2";
    ((Control) this.guna2HtmlLabel2).Size = new Size(94, 41);
    ((Control) this.guna2HtmlLabel2).TabIndex = 276;
    ((Control) this.guna2HtmlLabel2).Text = "TELAPOS";
    this.guna2Button4.Animated = true;
    this.guna2Button4.BorderColor = Color.FromArgb(33, 33, 33);
    this.guna2Button4.BorderRadius = 2;
    this.guna2Button4.BorderThickness = 1;
    this.guna2Button4.DisabledState.BorderColor = Color.DarkGray;
    this.guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
    this.guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
    this.guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
    this.guna2Button4.FillColor = Color.Gray;
    ((Control) this.guna2Button4).Font = new Font("Segoe UI", 9f, FontStyle.Bold);
    ((Control) this.guna2Button4).ForeColor = Color.White;
    ((Control) this.guna2Button4).Location = new Point(307, 3);
    ((Control) this.guna2Button4).Name = "guna2Button4";
    ((Control) this.guna2Button4).Size = new Size(37, 29);
    ((Control) this.guna2Button4).TabIndex = 275;
    ((Control) this.guna2Button4).Text = "X";
    ((Control) this.guna2Button4).Click += new EventHandler(this.guna2Button4_Click);
    ((Control) this.guna2HtmlLabel1).BackColor = Color.Transparent;
    ((Control) this.guna2HtmlLabel1).Font = new Font("Bahnschrift Condensed", 24f, FontStyle.Bold);
    ((Control) this.guna2HtmlLabel1).ForeColor = Color.Gray;
    this.guna2HtmlLabel1.IsSelectionEnabled = false;
    ((Control) this.guna2HtmlLabel1).Location = new Point(187, 20);
    ((Control) this.guna2HtmlLabel1).Name = "guna2HtmlLabel1";
    ((Control) this.guna2HtmlLabel1).Size = new Size(81, 41);
    ((Control) this.guna2HtmlLabel1).TabIndex = 274;
    ((Control) this.guna2HtmlLabel1).Text = "CHEATS";
    ((Control) this.guna2HtmlLabel1).Click += new EventHandler(this.guna2HtmlLabel1_Click);
    ((Control) this.guna2CirclePictureBox1).BackColor = Color.Transparent;
    ((PictureBox) this.guna2CirclePictureBox1).Image = (Image) componentResourceManager.GetObject("guna2CirclePictureBox1.Image");
    this.guna2CirclePictureBox1.ImageRotate = 0.0f;
    ((Control) this.guna2CirclePictureBox1).Location = new Point(109, 67);
    ((Control) this.guna2CirclePictureBox1).Name = "guna2CirclePictureBox1";
    this.guna2CirclePictureBox1.ShadowDecoration.Mode = (ShadowMode) 1;
    ((Control) this.guna2CirclePictureBox1).Size = new Size(131, 125);
    ((PictureBox) this.guna2CirclePictureBox1).SizeMode = PictureBoxSizeMode.StretchImage;
    ((PictureBox) this.guna2CirclePictureBox1).TabIndex = 270;
    ((PictureBox) this.guna2CirclePictureBox1).TabStop = false;
    this.guna2CirclePictureBox1.UseTransparentBackground = true;
    ((Control) this.guna2CirclePictureBox1).Click += new EventHandler(this.guna2CirclePictureBox1_Click_1);
    this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl1.TargetControl = (Control) this.loginpanel;
    this.guna2DragControl1.UseTransparentDrag = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.FromArgb(15, 15, 15);
    this.ClientSize = new Size(351, 435);
    this.Controls.Add((Control) this.loginpanel);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.Name = nameof (Login);
    this.Text = nameof (Login);
    this.Load += new EventHandler(this.Login_Load);
    ((Control) this.loginpanel).ResumeLayout(false);
    ((Control) this.loginpanel).PerformLayout();
    ((ISupportInitialize) this.guna2CirclePictureBox1).EndInit();
    this.ResumeLayout(false);
  }
}
