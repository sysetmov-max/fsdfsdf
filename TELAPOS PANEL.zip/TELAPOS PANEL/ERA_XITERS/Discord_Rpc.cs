﻿// Decompiled with JetBrains decompiler
// Type: ERA_XITERS.Discord_Rpc
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using DiscordRPC;
using System;

#nullable disable
namespace ERA_XITERS;

internal class Discord_Rpc
{
  public static DiscordRpcClient client;
  private static RichPresence presence;

  public static Timestamps rpctimestamp { get; set; }

  public static void InitializeRPC()
  {
    Discord_Rpc.client = new DiscordRpcClient("1447389708559585354");
    Discord_Rpc.client.Initialize();
    Button[] buttonArray = new Button[2]
    {
      new Button()
      {
        Label = "Discord ",
        Url = "https://discord.gg/gAUbCEZy"
      },
      new Button()
      {
        Label = "Contact Developer",
        Url = "https://discord.gg/gKdfsN6E"
      }
    };
    RichPresence richPresence = new RichPresence();
    richPresence.Buttons = buttonArray;
    ((BaseRichPresence) richPresence).Timestamps = Discord_Rpc.rpctimestamp;
    ((BaseRichPresence) richPresence).Assets = new Assets()
    {
      LargeImageKey = "https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExaGlwcWh1NGNkNWgyaDhkNzIweWtmZWsxaW92azNlcjVyaWU3aWZ2OCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/7CxAelnI5cOi0e7F6x/giphy.gif",
      LargeImageText = "Erox Cheats",
      SmallImageKey = "https://media4.giphy.com/media/xmOMPI63SsyZyKz2Tx/giphy.gif?cid=790b7611485d6e9b471bcd8f93609e96f8a02c35a7e05685&rid=giphy.gif&ct=s",
      SmallImageText = "</> Developer Abubakar"
    };
    Discord_Rpc.presence = richPresence;
    Discord_Rpc.client.SetPresence(Discord_Rpc.presence);
    Discord_Rpc.UpdateDiscordPresence();
  }

  public static void SetState(string state, bool watching = false)
  {
    if (watching)
      state = "Looking at " + state;
    ((BaseRichPresence) Discord_Rpc.presence).State = state;
    Discord_Rpc.client.SetPresence(Discord_Rpc.presence);
  }

  private static void UpdateDiscordPresence()
  {
    if (Login.KeyAuthApp.user_data != null)
    {
      string username = Login.KeyAuthApp.user_data.username;
      DateTime dateTime = Discord_Rpc.UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry));
      ((BaseRichPresence) Discord_Rpc.presence).Details = "User: " + username;
      ((BaseRichPresence) Discord_Rpc.presence).State = string.Format("Expiry Date: {0:yyyy/MM/dd HH:mm}", (object) dateTime);
    }
    else
    {
      ((BaseRichPresence) Discord_Rpc.presence).Details = "USER";
      ((BaseRichPresence) Discord_Rpc.presence).State = "";
    }
    Discord_Rpc.client.SetPresence(Discord_Rpc.presence);
  }

  private static DateTime UnixTimeToDateTime(long unixTime)
  {
    return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds((double) unixTime).ToLocalTime();
  }
}
