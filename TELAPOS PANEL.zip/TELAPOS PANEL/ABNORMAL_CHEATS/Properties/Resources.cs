﻿// Decompiled with JetBrains decompiler
// Type: ABNORMAL_CHEATS.Properties.Resources
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ABNORMAL_CHEATS.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "18.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal Resources()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (ABNORMAL_CHEATS.Properties.Resources.resourceMan == null)
        ABNORMAL_CHEATS.Properties.Resources.resourceMan = new ResourceManager("ABNORMAL_CHEATS.Properties.Resources", typeof (ABNORMAL_CHEATS.Properties.Resources).Assembly);
      return ABNORMAL_CHEATS.Properties.Resources.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => ABNORMAL_CHEATS.Properties.Resources.resourceCulture;
    set => ABNORMAL_CHEATS.Properties.Resources.resourceCulture = value;
  }
}
