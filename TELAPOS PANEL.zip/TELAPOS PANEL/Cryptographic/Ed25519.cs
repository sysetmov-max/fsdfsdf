﻿// Decompiled with JetBrains decompiler
// Type: Cryptographic.Ed25519
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;

#nullable disable
namespace Cryptographic;

public class Ed25519
{
  private static readonly Dictionary<BigInteger, BigInteger> InverseCache = new Dictionary<BigInteger, BigInteger>();
  private const int BitLength = 256 /*0x0100*/;
  private static readonly BigInteger TwoPowBitLengthMinusTwo = BigInteger.Pow((BigInteger) 2, 254);
  private static readonly BigInteger[] TwoPowCache = Enumerable.Range(0, 512 /*0x0200*/).Select<int, BigInteger>((Func<int, BigInteger>) (i => BigInteger.Pow((BigInteger) 2, i))).ToArray<BigInteger>();
  private static readonly BigInteger Q = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819949");
  private static readonly BigInteger Qm2 = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819947");
  private static readonly BigInteger Qp3 = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819952");
  private static readonly BigInteger L = BigInteger.Parse("7237005577332262213973186563042994240857116359379907606001950938285454250989");
  private static readonly BigInteger D = BigInteger.Parse("-4513249062541557337682894930092624173785641285191125241628941591882900924598840740");
  private static readonly BigInteger I = BigInteger.Parse("19681161376707505956807079304988542015446066515923890162744021073123829784752");
  private static readonly BigInteger By = BigInteger.Parse("46316835694926478169428394003475163141307993866256225615783033603165251855960");
  private static readonly BigInteger Bx = BigInteger.Parse("15112221349535400772501151409588531511454012693041857206046113283949847762202");
  private static readonly Tuple<BigInteger, BigInteger> B = new Tuple<BigInteger, BigInteger>(Ed25519.Bx.Mod(Ed25519.Q), Ed25519.By.Mod(Ed25519.Q));
  private static readonly BigInteger Un = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819967");
  private static readonly BigInteger Two = new BigInteger(2);
  private static readonly BigInteger Eight = new BigInteger(8);

  private static byte[] ComputeHash(byte[] m)
  {
    using (SHA512 shA512 = SHA512.Create())
      return shA512.ComputeHash(m);
  }

  private static BigInteger ExpMod(BigInteger number, BigInteger exponent, BigInteger modulo)
  {
    BigInteger bigInteger1 = BigInteger.One;
    BigInteger bigInteger2 = number.Mod(modulo);
    while (exponent > 0L)
    {
      if (!exponent.IsEven)
        bigInteger1 = (bigInteger1 * bigInteger2).Mod(modulo);
      bigInteger2 = (bigInteger2 * bigInteger2).Mod(modulo);
      exponent /= (BigInteger) 2;
    }
    return bigInteger1;
  }

  private static BigInteger Inv(BigInteger x)
  {
    if (!Ed25519.InverseCache.ContainsKey(x))
      Ed25519.InverseCache[x] = Ed25519.ExpMod(x, Ed25519.Qm2, Ed25519.Q);
    return Ed25519.InverseCache[x];
  }

  private static BigInteger RecoverX(BigInteger y)
  {
    BigInteger bigInteger1 = y * y;
    BigInteger number = (bigInteger1 - (BigInteger) 1) * Ed25519.Inv(Ed25519.D * bigInteger1 + (BigInteger) 1);
    BigInteger bigInteger2 = Ed25519.ExpMod(number, Ed25519.Qp3 / Ed25519.Eight, Ed25519.Q);
    if (!(bigInteger2 * bigInteger2 - number).Mod(Ed25519.Q).Equals(BigInteger.Zero))
      bigInteger2 = (bigInteger2 * Ed25519.I).Mod(Ed25519.Q);
    if (!bigInteger2.IsEven)
      bigInteger2 = Ed25519.Q - bigInteger2;
    return bigInteger2;
  }

  private static Tuple<BigInteger, BigInteger> Edwards(
    BigInteger px,
    BigInteger py,
    BigInteger qx,
    BigInteger qy)
  {
    BigInteger bigInteger1 = px * qx;
    BigInteger bigInteger2 = py * qy;
    BigInteger bigInteger3 = Ed25519.D * bigInteger1 * bigInteger2;
    BigInteger num1 = (px * qy + qx * py) * Ed25519.Inv((BigInteger) 1 + bigInteger3);
    BigInteger num2 = (py * qy + bigInteger1) * Ed25519.Inv((BigInteger) 1 - bigInteger3);
    BigInteger q = Ed25519.Q;
    return new Tuple<BigInteger, BigInteger>(num1.Mod(q), num2.Mod(Ed25519.Q));
  }

  private static Tuple<BigInteger, BigInteger> EdwardsSquare(BigInteger x, BigInteger y)
  {
    BigInteger bigInteger1 = x * x;
    BigInteger bigInteger2 = y * y;
    BigInteger bigInteger3 = Ed25519.D * bigInteger1 * bigInteger2;
    BigInteger num1 = (BigInteger) 2 * x * y * Ed25519.Inv((BigInteger) 1 + bigInteger3);
    BigInteger num2 = (bigInteger2 + bigInteger1) * Ed25519.Inv((BigInteger) 1 - bigInteger3);
    BigInteger q = Ed25519.Q;
    return new Tuple<BigInteger, BigInteger>(num1.Mod(q), num2.Mod(Ed25519.Q));
  }

  private static Tuple<BigInteger, BigInteger> ScalarMul(
    Tuple<BigInteger, BigInteger> point,
    BigInteger scalar)
  {
    Tuple<BigInteger, BigInteger> tuple1 = new Tuple<BigInteger, BigInteger>(BigInteger.Zero, BigInteger.One);
    Tuple<BigInteger, BigInteger> tuple2 = point;
    while (scalar > 0L)
    {
      if (!scalar.IsEven)
        tuple1 = Ed25519.Edwards(tuple1.Item1, tuple1.Item2, tuple2.Item1, tuple2.Item2);
      tuple2 = Ed25519.EdwardsSquare(tuple2.Item1, tuple2.Item2);
      scalar >>= 1;
    }
    return tuple1;
  }

  public static byte[] EncodeInt(BigInteger y)
  {
    byte[] byteArray = y.ToByteArray();
    byte[] destinationArray = new byte[Math.Max(byteArray.Length, 32 /*0x20*/)];
    Array.Copy((Array) byteArray, (Array) destinationArray, byteArray.Length);
    return destinationArray;
  }

  public static byte[] EncodePoint(BigInteger x, BigInteger y)
  {
    byte[] numArray = Ed25519.EncodeInt(y);
    numArray[numArray.Length - 1] |= x.IsEven ? (byte) 0 : (byte) 128 /*0x80*/;
    return numArray;
  }

  private static int GetBit(byte[] h, int i) => (int) h[i / 8] >> i % 8 & 1;

  public static byte[] PublicKey(byte[] signingKey)
  {
    byte[] hash = Ed25519.ComputeHash(signingKey);
    BigInteger bitLengthMinusTwo = Ed25519.TwoPowBitLengthMinusTwo;
    for (int i = 3; i < 254; ++i)
    {
      if (Ed25519.GetBit(hash, i) != 0)
        bitLengthMinusTwo += Ed25519.TwoPowCache[i];
    }
    Tuple<BigInteger, BigInteger> tuple = Ed25519.ScalarMul(Ed25519.B, bitLengthMinusTwo);
    return Ed25519.EncodePoint(tuple.Item1, tuple.Item2);
  }

  private static BigInteger HashInt(byte[] m)
  {
    byte[] hash = Ed25519.ComputeHash(m);
    BigInteger zero = BigInteger.Zero;
    for (int i = 0; i < 512 /*0x0200*/; ++i)
    {
      if (Ed25519.GetBit(hash, i) != 0)
        zero += Ed25519.TwoPowCache[i];
    }
    return zero;
  }

  public static byte[] Signature(byte[] message, byte[] signingKey, byte[] publicKey)
  {
    byte[] hash = Ed25519.ComputeHash(signingKey);
    BigInteger bitLengthMinusTwo = Ed25519.TwoPowBitLengthMinusTwo;
    for (int i = 3; i < 254; ++i)
    {
      if (Ed25519.GetBit(hash, i) != 0)
        bitLengthMinusTwo += Ed25519.TwoPowCache[i];
    }
    BigInteger scalar;
    using (MemoryStream memoryStream = new MemoryStream(32 /*0x20*/ + message.Length))
    {
      memoryStream.Write(hash, 32 /*0x20*/, 32 /*0x20*/);
      memoryStream.Write(message, 0, message.Length);
      scalar = Ed25519.HashInt(memoryStream.ToArray());
    }
    Tuple<BigInteger, BigInteger> tuple = Ed25519.ScalarMul(Ed25519.B, scalar);
    byte[] buffer1 = Ed25519.EncodePoint(tuple.Item1, tuple.Item2);
    BigInteger y;
    using (MemoryStream memoryStream = new MemoryStream(32 /*0x20*/ + publicKey.Length + message.Length))
    {
      memoryStream.Write(buffer1, 0, buffer1.Length);
      memoryStream.Write(publicKey, 0, publicKey.Length);
      memoryStream.Write(message, 0, message.Length);
      y = (scalar + Ed25519.HashInt(memoryStream.ToArray()) * bitLengthMinusTwo).Mod(Ed25519.L);
    }
    using (MemoryStream memoryStream = new MemoryStream(64 /*0x40*/))
    {
      memoryStream.Write(buffer1, 0, buffer1.Length);
      byte[] buffer2 = Ed25519.EncodeInt(y);
      memoryStream.Write(buffer2, 0, buffer2.Length);
      return memoryStream.ToArray();
    }
  }

  private static bool IsOnCurve(BigInteger x, BigInteger y)
  {
    BigInteger bigInteger1 = x * x;
    BigInteger bigInteger2 = y * y;
    BigInteger bigInteger3 = Ed25519.D * bigInteger2 * bigInteger1;
    return (bigInteger2 - bigInteger1 - bigInteger3 - (BigInteger) 1).Mod(Ed25519.Q).Equals(BigInteger.Zero);
  }

  private static BigInteger DecodeInt(byte[] s) => new BigInteger(s) & Ed25519.Un;

  private static Tuple<BigInteger, BigInteger> DecodePoint(byte[] pointBytes)
  {
    BigInteger y = new BigInteger(pointBytes) & Ed25519.Un;
    BigInteger x = Ed25519.RecoverX(y);
    if ((!x.IsEven ? 1 : 0) != Ed25519.GetBit(pointBytes, (int) byte.MaxValue))
      x = Ed25519.Q - x;
    Tuple<BigInteger, BigInteger> tuple = new Tuple<BigInteger, BigInteger>(x, y);
    if (Ed25519.IsOnCurve(x, y))
      return tuple;
    throw new ArgumentException("Decoding point that is not on curve");
  }

  public static bool CheckValid(byte[] signature, byte[] message, byte[] publicKey)
  {
    Console.Write(".");
    if (signature.Length != 64 /*0x40*/)
      throw new ArgumentException("Signature length is wrong");
    if (publicKey.Length != 32 /*0x20*/)
      throw new ArgumentException("Public key length is wrong");
    Tuple<BigInteger, BigInteger> tuple1 = Ed25519.DecodePoint(Arrays.CopyOfRange(signature, 0, 32 /*0x20*/));
    Tuple<BigInteger, BigInteger> point = Ed25519.DecodePoint(publicKey);
    BigInteger scalar1 = Ed25519.DecodeInt(Arrays.CopyOfRange(signature, 32 /*0x20*/, 64 /*0x40*/));
    BigInteger scalar2;
    using (MemoryStream memoryStream = new MemoryStream(32 /*0x20*/ + publicKey.Length + message.Length))
    {
      byte[] buffer = Ed25519.EncodePoint(tuple1.Item1, tuple1.Item2);
      memoryStream.Write(buffer, 0, buffer.Length);
      memoryStream.Write(publicKey, 0, publicKey.Length);
      memoryStream.Write(message, 0, message.Length);
      scalar2 = Ed25519.HashInt(memoryStream.ToArray());
    }
    Console.Write(".");
    Tuple<BigInteger, BigInteger> tuple2 = Ed25519.ScalarMul(Ed25519.B, scalar1);
    Console.Write(".");
    Tuple<BigInteger, BigInteger> tuple3 = Ed25519.ScalarMul(point, scalar2);
    Tuple<BigInteger, BigInteger> tuple4 = Ed25519.Edwards(tuple1.Item1, tuple1.Item2, tuple3.Item1, tuple3.Item2);
    return tuple2.Item1.Equals(tuple4.Item1) && tuple2.Item2.Equals(tuple4.Item2);
  }
}
