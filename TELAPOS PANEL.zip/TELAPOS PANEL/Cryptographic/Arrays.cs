﻿// Decompiled with JetBrains decompiler
// Type: Cryptographic.Arrays
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;

#nullable disable
namespace Cryptographic;

internal static class Arrays
{
  public static byte[] CopyOfRange(byte[] original, int from, int to)
  {
    int length = to - from;
    byte[] destinationArray = new byte[length];
    Array.Copy((Array) original, from, (Array) destinationArray, 0, length);
    return destinationArray;
  }
}
