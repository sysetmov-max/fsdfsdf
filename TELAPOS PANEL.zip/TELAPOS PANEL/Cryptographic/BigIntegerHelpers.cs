﻿// Decompiled with JetBrains decompiler
// Type: Cryptographic.BigIntegerHelpers
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System.Numerics;

#nullable disable
namespace Cryptographic;

internal static class BigIntegerHelpers
{
  public static BigInteger Mod(this BigInteger num, BigInteger modulo)
  {
    BigInteger bigInteger = num % modulo;
    return !(bigInteger < 0L) ? bigInteger : bigInteger + modulo;
  }
}
