﻿// Decompiled with JetBrains decompiler
// Type: TELAPOS PANEL_ProcessedByFody
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

#nullable disable
internal class TELAPOS\u0020PANEL_ProcessedByFody
{
  internal const string FodyVersion = "6.9.3.0";
  internal const string Costura = "6.0.0";
}
