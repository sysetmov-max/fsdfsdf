﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using Costura;

#nullable disable
internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach(true);
}
