﻿// Decompiled with JetBrains decompiler
// Type: NAZMUL.MemoryRegionResult
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;

#nullable disable
namespace NAZMUL;

internal struct MemoryRegionResult
{
  public UIntPtr CurrentBaseAddress { get; set; }

  public long RegionSize { get; set; }

  public UIntPtr RegionBase { get; set; }
}
