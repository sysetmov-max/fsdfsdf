﻿// Decompiled with JetBrains decompiler
// Type: MagıcMemory.MagıcMemory31
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace MagıcMemory;

public class MagıcMemory31
{
  public bool isPrivate;
  public int processId;
  public IntPtr _processHandle;
  private bool _enableCheck = true;
  public const uint MEM_COMMIT = 4096 /*0x1000*/;
  public const uint MEM_PRIVATE = 131072 /*0x020000*/;
  public const uint PAGE_READWRITE = 4;

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr OpenProcess(
    MagıcMemory31.ProcessAccessFlags dwDesiredAccess,
    [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle,
    int dwProcessId);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr VirtualAllocEx(
    IntPtr hProcess,
    IntPtr lpAddress,
    uint dwSize,
    uint flAllocationType,
    uint flProtect);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern int VirtualQueryEx(
    IntPtr hProcess,
    IntPtr lpAddress,
    out MagıcMemory31.MEMORY_BASIC_INFORMATION lpBuffer,
    uint dwLength);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern bool ReadProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    [Out] byte[] lpBuffer,
    IntPtr nSize,
    out IntPtr lpNumberOfBytesRead);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern bool WriteProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    byte[] lpBuffer,
    IntPtr nSize,
    IntPtr lpNumberOfBytesWritten);

  [DllImport("kernel32.dll")]
  public static extern IntPtr OpenThread(
    MagıcMemory31.ThreadAccess dwDesiredAccess,
    bool bInheritHandle,
    uint dwThreadId);

  [DllImport("kernel32.dll")]
  public static extern int ResumeThread(IntPtr hThread);

  [DllImport("kernel32.dll")]
  public static extern int CloseHandle(IntPtr hObject);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetModuleHandle(string lpModuleName);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

  [DllImport("kernel32.dll")]
  public static extern IntPtr CreateRemoteThread(
    IntPtr hProcess,
    IntPtr lpThreadAttributes,
    uint dwStackSize,
    IntPtr lpStartAddress,
    IntPtr lpParameter,
    uint dwCreationFlags,
    IntPtr lpThreadId);

  public bool SetProcess(string[] processNames)
  {
    this.processId = 0;
    foreach (Process process in Process.GetProcesses())
    {
      string processName = process.ProcessName;
      if (Array.Exists<string>(processNames, (Predicate<string>) (name => name.Equals(processName, StringComparison.CurrentCultureIgnoreCase))))
      {
        this.processId = process.Id;
        break;
      }
    }
    if (this.processId <= 0)
    {
      int num = (int) MessageBox.Show("Proses bulunamadı.");
      return false;
    }
    this._processHandle = MagıcMemory31.OpenProcess(MagıcMemory31.ProcessAccessFlags.AllAccess, false, this.processId);
    if (!(this._processHandle == IntPtr.Zero))
      return true;
    int num1 = (int) MessageBox.Show("Proses açılamadı.");
    return false;
  }

  public void CheckProcess()
  {
    if (!this._enableCheck)
      return;
    foreach (ProcessThread thread in (ReadOnlyCollectionBase) Process.GetProcessById(this.processId).Threads)
    {
      IntPtr num = MagıcMemory31.OpenThread(MagıcMemory31.ThreadAccess.SUSPEND_RESUME, false, (uint) thread.Id);
      if (num != IntPtr.Zero)
      {
        do
          ;
        while (MagıcMemory31.ResumeThread(num) > 0);
        MagıcMemory31.CloseHandle(num);
      }
    }
  }

  public byte ReadByte(long address)
  {
    byte[] lpBuffer = new byte[1];
    MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) address, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _);
    return lpBuffer[0];
  }

  public async Task<IEnumerable<long>> AoBScan(string bytePattern)
  {
    try
    {
      IEnumerable<long> source = await this.AobScan(bytePattern);
      source.Any<long>();
      return source;
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show("AoBScan Error: " + ex.Message);
      return Enumerable.Empty<long>();
    }
  }

  private async Task<IEnumerable<long>> AobScan(string pattern)
  {
    MagıcMemory31.PatternData patternData = this.GetPatternDataFromPattern(pattern);
    List<long> addressRet = new List<long>();
    await Task.Run((Action) (() =>
    {
      List<MagıcMemory31.MemoryPage> source = new List<MagıcMemory31.MemoryPage>();
      MagıcMemory31.MEMORY_BASIC_INFORMATION lpBuffer;
      for (IntPtr index = IntPtr.Zero; (long) MagıcMemory31.VirtualQueryEx(this._processHandle, index, out lpBuffer, (uint) Marshal.SizeOf(typeof (MagıcMemory31.MEMORY_BASIC_INFORMATION))) == (long) (uint) Marshal.SizeOf(typeof (MagıcMemory31.MEMORY_BASIC_INFORMATION)); index = (IntPtr) ((long) lpBuffer.BaseAddress + (long) (ulong) lpBuffer.RegionSize))
      {
        if (this.CanReadPage(lpBuffer))
          source.Add(new MagıcMemory31.MemoryPage(index, (int) lpBuffer.RegionSize.ToUInt64()));
      }
      int patternLength = patternData.pattern.Length;
      Parallel.ForEach<MagıcMemory31.MemoryPage>((IEnumerable<MagıcMemory31.MemoryPage>) source, (Action<MagıcMemory31.MemoryPage>) (addresss =>
      {
        byte[] array = new byte[addresss.Size];
        IntPtr lpNumberOfBytesRead;
        if (MagıcMemory31.ReadProcessMemory(this._processHandle, addresss.Start, array, (IntPtr) addresss.Size, out lpNumberOfBytesRead))
        {
          int num = -patternLength;
          do
          {
            num = this.FindPattern(array, patternData.pattern, patternData.mask, num + patternLength);
            if (num >= 0)
            {
              lock (addressRet)
                addressRet.Add((long) addresss.Start + (long) num);
            }
          }
          while (num != -1);
        }
        Array.Resize<byte>(ref array, (int) lpNumberOfBytesRead);
      }));
    }));
    return addressRet.OrderBy<long, long>((Func<long, long>) (c => c)).AsEnumerable<long>();
  }

  public bool CanReadPage(MagıcMemory31.MEMORY_BASIC_INFORMATION page)
  {
    return page.State == 4096U /*0x1000*/ && page.Type == 131072U /*0x020000*/ && page.Protect == 4U;
  }

  private MagıcMemory31.PatternData GetPatternDataFromPattern(string pattern)
  {
    string[] source = pattern.Split(' ');
    return new MagıcMemory31.PatternData()
    {
      pattern = ((IEnumerable<string>) source).Select<string, byte>((Func<string, byte>) (s => !s.Contains("??") ? byte.Parse(s, NumberStyles.HexNumber) : (byte) 0)).ToArray<byte>(),
      mask = ((IEnumerable<string>) source).Select<string, byte>((Func<string, byte>) (s => !s.Contains("??") ? byte.MaxValue : (byte) 0)).ToArray<byte>()
    };
  }

  public bool AobReplace(long address, string bytePattern)
  {
    try
    {
      byte[] byteArray = this.StringToByteArray(bytePattern);
      return MagıcMemory31.WriteProcessMemory(this._processHandle, (IntPtr) address, byteArray, (IntPtr) byteArray.Length, IntPtr.Zero);
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show("AobReplace Error: " + ex.Message);
      return false;
    }
  }

  public bool AobReplace(long address, int bytePattern)
  {
    byte[] bytes = BitConverter.GetBytes(bytePattern);
    return MagıcMemory31.WriteProcessMemory(this._processHandle, (IntPtr) address, bytes, (IntPtr) bytes.Length, IntPtr.Zero);
  }

  public async Task<int> ReadIntAsync(long addressToRead)
  {
    return await Task.Run<int>((Func<int>) (() => this.ReadInt(addressToRead)));
  }

  public int ReadInt(long addressToRead)
  {
    byte[] lpBuffer = new byte[4];
    return MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToInt32(lpBuffer, 0) : 0;
  }

  public float ReadFloat(long addressToRead)
  {
    byte[] lpBuffer = new byte[4];
    return MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToSingle(lpBuffer, 0) : 0.0f;
  }

  public byte ReadHexByte(long addressToRead)
  {
    byte[] lpBuffer = new byte[1];
    return MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? lpBuffer[0] : (byte) 0;
  }

  public short ReadInt16(long addressToRead)
  {
    byte[] lpBuffer = new byte[2];
    return MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToInt16(lpBuffer, 0) : (short) 0;
  }

  public string ReadString(long addressToRead, int size)
  {
    byte[] lpBuffer = new byte[size];
    IntPtr lpNumberOfBytesRead;
    return MagıcMemory31.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) size, out lpNumberOfBytesRead) && lpNumberOfBytesRead.ToInt64() == (long) size ? BitConverter.ToString(lpBuffer).Replace("-", " ") : "";
  }

  private byte[] StringToByteArray(string hexString)
  {
    return ((IEnumerable<string>) hexString.Split(' ')).Select<string, byte>((Func<string, byte>) (hex => byte.Parse(hex, NumberStyles.HexNumber))).ToArray<byte>();
  }

  private int FindPattern(byte[] body, byte[] pattern, byte[] masks, int start = 0)
  {
    int pattern1 = -1;
    if (body.Length == 0 || pattern.Length == 0 || start > body.Length - pattern.Length || pattern.Length > body.Length)
      return pattern1;
    for (int index1 = start; index1 <= body.Length - pattern.Length; ++index1)
    {
      if (((int) body[index1] & (int) masks[0]) == ((int) pattern[0] & (int) masks[0]))
      {
        bool flag = true;
        for (int index2 = pattern.Length - 1; index2 >= 1; --index2)
        {
          if (((int) body[index1 + index2] & (int) masks[index2]) != ((int) pattern[index2] & (int) masks[index2]))
          {
            flag = false;
            break;
          }
        }
        if (flag)
        {
          pattern1 = index1;
          break;
        }
      }
    }
    return pattern1;
  }

  public T ReadMemory<T>(string address, string moduleName = "") where T : struct
  {
    IntPtr hProcess = string.IsNullOrEmpty(moduleName) ? this._processHandle : Process.GetProcessesByName(moduleName)[0].Handle;
    IntPtr int64 = (IntPtr) Convert.ToInt64(address, 16 /*0x10*/);
    byte[] bytes = new byte[Marshal.SizeOf(typeof (T))];
    IntPtr lpBaseAddress = int64;
    byte[] lpBuffer = bytes;
    IntPtr length = (IntPtr) bytes.Length;
    IntPtr num;
    ref IntPtr local = ref num;
    MagıcMemory31.ReadProcessMemory(hProcess, lpBaseAddress, lpBuffer, length, out local);
    return this.ByteArrayToStructure<T>(bytes);
  }

  private T ByteArrayToStructure<T>(byte[] bytes) where T : struct
  {
    GCHandle gcHandle = GCHandle.Alloc((object) bytes, GCHandleType.Pinned);
    T structure = (T) Marshal.PtrToStructure(gcHandle.AddrOfPinnedObject(), typeof (T));
    gcHandle.Free();
    return structure;
  }

  public void WriteMemory<T>(
    string address,
    string type,
    string value,
    string moduleName = "",
    Encoding encoding = null,
    bool isModuleRelative = false)
    where T : struct
  {
    IntPtr hProcess = string.IsNullOrEmpty(moduleName) ? this._processHandle : Process.GetProcessesByName(moduleName)[0].Handle;
    IntPtr int64 = (IntPtr) Convert.ToInt64(address, 16 /*0x10*/);
    byte[] bytes;
    if (typeof (T) == typeof (int))
    {
      bytes = BitConverter.GetBytes(Convert.ToInt32(value));
    }
    else
    {
      if (!(typeof (T) == typeof (float)))
        throw new NotImplementedException($"Type {typeof (T)} not supported.");
      bytes = BitConverter.GetBytes(Convert.ToSingle(value));
    }
    IntPtr lpBaseAddress = int64;
    byte[] lpBuffer = bytes;
    IntPtr length = (IntPtr) bytes.Length;
    IntPtr zero = IntPtr.Zero;
    MagıcMemory31.WriteProcessMemory(hProcess, lpBaseAddress, lpBuffer, length, zero);
  }

  [Flags]
  public enum ProcessAccessFlags
  {
    AllAccess = 2035711, // 0x001F0FFF
    CreateProcess = 128, // 0x00000080
    CreateThread = 2,
    DupHandle = 64, // 0x00000040
    QueryInformation = 1024, // 0x00000400
    QueryLimitedInformation = 4096, // 0x00001000
    SetInformation = 512, // 0x00000200
    SetQuota = 256, // 0x00000100
    SuspendResume = 2048, // 0x00000800
    Terminate = 1,
    VmOperation = 8,
    VmRead = 16, // 0x00000010
    VmWrite = 32, // 0x00000020
    Synchronize = 1048576, // 0x00100000
  }

  public enum ThreadAccess
  {
    TERMINATE = 1,
    SUSPEND_RESUME = 2,
    GET_CONTEXT = 8,
    SET_CONTEXT = 16, // 0x00000010
    SET_INFORMATION = 32, // 0x00000020
    QUERY_INFORMATION = 64, // 0x00000040
    SET_THREAD_TOKEN = 128, // 0x00000080
    IMPERSONATE = 256, // 0x00000100
    DIRECT_IMPERSONATION = 512, // 0x00000200
  }

  public enum AllocationProtectEnum : uint
  {
    PAGE_NOACCESS = 1,
    PAGE_READONLY = 2,
    PAGE_READWRITE = 4,
    PAGE_WRITECOPY = 8,
    PAGE_EXECUTE = 16, // 0x00000010
    PAGE_EXECUTE_READ = 32, // 0x00000020
    PAGE_EXECUTE_READWRITE = 64, // 0x00000040
    PAGE_EXECUTE_WRITECOPY = 128, // 0x00000080
    PAGE_GUARD = 256, // 0x00000100
    PAGE_NOCACHE = 512, // 0x00000200
    PAGE_WRITECOMBINE = 1024, // 0x00000400
  }

  public enum StateEnum : uint
  {
    MEM_COMMIT = 4096, // 0x00001000
    MEM_RESERVE = 8192, // 0x00002000
    MEM_FREE = 65536, // 0x00010000
  }

  public enum TypeEnum : uint
  {
    MEM_PRIVATE = 131072, // 0x00020000
    MEM_MAPPED = 262144, // 0x00040000
    MEM_IMAGE = 16777216, // 0x01000000
  }

  public struct PatternData
  {
    public byte[] pattern { get; set; }

    public byte[] mask { get; set; }
  }

  public struct MemoryPage(IntPtr start, int size)
  {
    public IntPtr Start = start;
    public int Size = size;
  }

  public struct MEMORY_BASIC_INFORMATION
  {
    public IntPtr BaseAddress;
    public IntPtr AllocationBase;
    public uint AllocationProtect;
    public UIntPtr RegionSize;
    public uint State;
    public uint Protect;
    public uint Type;
  }
}
