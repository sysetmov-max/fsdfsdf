﻿// Decompiled with JetBrains decompiler
// Type: Nazmulscope.StateEnum
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

#nullable disable
namespace Nazmulscope;

public enum StateEnum : uint
{
  MEM_COMMIT = 4096, // 0x00001000
  MEM_RESERVE = 8192, // 0x00002000
  MEM_FREE = 65536, // 0x00010000
}
