﻿// Decompiled with JetBrains decompiler
// Type: Nazmulscope.TypeEnum
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

#nullable disable
namespace Nazmulscope;

public enum TypeEnum : uint
{
  MEM_PRIVATE = 131072, // 0x00020000
  MEM_MAPPED = 262144, // 0x00040000
  MEM_IMAGE = 16777216, // 0x01000000
}
