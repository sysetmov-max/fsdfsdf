﻿// Decompiled with JetBrains decompiler
// Type: Nazmulscope.AllocationProtectEnum
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

#nullable disable
namespace Nazmulscope;

public enum AllocationProtectEnum : uint
{
  PAGE_NOACCESS = 1,
  PAGE_READONLY = 2,
  PAGE_READWRITE = 4,
  PAGE_WRITECOPY = 8,
  PAGE_EXECUTE = 16, // 0x00000010
  PAGE_EXECUTE_READ = 32, // 0x00000020
  PAGE_EXECUTE_READWRITE = 64, // 0x00000040
  PAGE_EXECUTE_WRITECOPY = 128, // 0x00000080
  PAGE_GUARD = 256, // 0x00000100
  PAGE_NOCACHE = 512, // 0x00000200
  PAGE_WRITECOMBINE = 1024, // 0x00000400
}
