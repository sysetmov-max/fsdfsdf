﻿// Decompiled with JetBrains decompiler
// Type: Nazmulscope.ThreadAccess
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;

#nullable disable
namespace Nazmulscope;

[Flags]
public enum ThreadAccess
{
  TERMINATE = 1,
  SUSPEND_RESUME = 2,
  GET_CONTEXT = 8,
  SET_CONTEXT = 16, // 0x00000010
  SET_INFORMATION = 32, // 0x00000020
  QUERY_INFORMATION = 64, // 0x00000040
  SET_THREAD_TOKEN = 128, // 0x00000080
  IMPERSONATE = 256, // 0x00000100
  DIRECT_IMPERSONATION = 512, // 0x00000200
}
