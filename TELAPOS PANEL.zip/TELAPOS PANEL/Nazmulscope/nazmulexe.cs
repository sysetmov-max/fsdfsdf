﻿// Decompiled with JetBrains decompiler
// Type: Nazmulscope.nazmulexe
// Assembly: TELAPOS PANEL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4D73708C-AF85-40BB-87D0-FA5D75D95CDB
// Assembly location: C:\Users\Systemov\Desktop\TELAPOS PANEL.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

#nullable disable
namespace Nazmulscope;

public class nazmulexe
{
  private IntPtr processHandle;
  public bool isPrivate;
  public int processId;
  public IntPtr _processHandle;
  private bool _enableCheck = true;
  public const uint MEM_COMMIT = 4096 /*0x1000*/;
  public const uint MEM_PRIVATE = 131072 /*0x020000*/;
  public const uint PAGE_READWRITE = 4;

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr OpenProcess(
    ProcessAccessFlags dwDesiredAccess,
    [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle,
    int dwProcessId);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr VirtualAllocEx(
    IntPtr hProcess,
    IntPtr lpAddress,
    uint dwSize,
    uint flAllocationType,
    uint flProtect);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern int VirtualQueryEx(
    IntPtr hProcess,
    IntPtr lpAddress,
    out nazmulexe.MEMORY_BASIC_INFORMATION lpBuffer,
    uint dwLength);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern bool ReadProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    [Out] byte[] lpBuffer,
    IntPtr nSize,
    out IntPtr lpNumberOfBytesRead);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern bool WriteProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    byte[] lpBuffer,
    IntPtr nSize,
    IntPtr lpNumberOfBytesWritten);

  [DllImport("kernel32.dll")]
  public static extern IntPtr OpenThread(
    ThreadAccess dwDesiredAccess,
    bool bInheritHandle,
    uint dwThreadId);

  [DllImport("kernel32.dll")]
  public static extern int ResumeThread(IntPtr hThread);

  [DllImport("kernel32.dll")]
  public static extern int CloseHandle(IntPtr hObject);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetModuleHandle(string lpModuleName);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

  [DllImport("kernel32.dll")]
  public static extern IntPtr CreateRemoteThread(
    IntPtr hProcess,
    IntPtr lpThreadAttributes,
    uint dwStackSize,
    IntPtr lpStartAddress,
    IntPtr lpParameter,
    uint dwCreationFlags,
    IntPtr lpThreadId);

  [DllImport("kernel32.dll")]
  private static extern bool ReadProcessMemory(
    IntPtr hProcess,
    IntPtr lpBaseAddress,
    [Out] byte[] lpBuffer,
    int dwSize,
    out int lpNumberOfBytesRead);

  public byte[] ReadBytes(long address, int length)
  {
    byte[] lpBuffer = new byte[length];
    nazmulexe.ReadProcessMemory(this.processHandle, new IntPtr(address), lpBuffer, length, out int _);
    return lpBuffer;
  }

  public bool SetProcess(string[] processNames)
  {
    this.processId = 0;
    foreach (Process process in Process.GetProcesses())
    {
      string processName = process.ProcessName;
      if (Array.Exists<string>(processNames, (Predicate<string>) (name => name.Equals(processName, StringComparison.CurrentCultureIgnoreCase))))
      {
        this.processId = process.Id;
        break;
      }
    }
    if (this.processId <= 0)
      return false;
    this._processHandle = nazmulexe.OpenProcess(ProcessAccessFlags.AllAccess, false, this.processId);
    return !(this._processHandle == IntPtr.Zero);
  }

  public void CheckProcess()
  {
    if (!this._enableCheck)
      return;
    foreach (ProcessThread thread in (ReadOnlyCollectionBase) Process.GetProcessById(this.processId).Threads)
    {
      IntPtr num = nazmulexe.OpenThread(ThreadAccess.SUSPEND_RESUME, false, (uint) thread.Id);
      if (num != IntPtr.Zero)
      {
        do
          ;
        while (nazmulexe.ResumeThread(num) > 0);
        nazmulexe.CloseHandle(num);
      }
    }
  }

  public async Task<IEnumerable<long>> AoBScan(string bytePattern)
  {
    return await this.AobScan(bytePattern);
  }

  private async Task<IEnumerable<long>> AobScan(string pattern)
  {
    nazmulexe.PatternData patternData = this.GetPatternDataFromPattern(pattern);
    List<long> addressRet = new List<long>();
    await Task.Run((Action) (() =>
    {
      List<nazmulexe.MemoryPage> source = new List<nazmulexe.MemoryPage>();
      nazmulexe.MEMORY_BASIC_INFORMATION lpBuffer;
      for (IntPtr index = IntPtr.Zero; (long) nazmulexe.VirtualQueryEx(this._processHandle, index, out lpBuffer, (uint) Marshal.SizeOf(typeof (nazmulexe.MEMORY_BASIC_INFORMATION))) == (long) (uint) Marshal.SizeOf(typeof (nazmulexe.MEMORY_BASIC_INFORMATION)); index = (IntPtr) ((long) lpBuffer.BaseAddress + (long) (ulong) lpBuffer.RegionSize))
      {
        if (this.CanReadPage(lpBuffer))
          source.Add(new nazmulexe.MemoryPage(index, (int) lpBuffer.RegionSize.ToUInt64()));
      }
      int patternLength = patternData.pattern.Length;
      Parallel.ForEach<nazmulexe.MemoryPage>((IEnumerable<nazmulexe.MemoryPage>) source, (Action<nazmulexe.MemoryPage>) (addresss =>
      {
        byte[] array = new byte[addresss.Size];
        IntPtr lpNumberOfBytesRead;
        if (nazmulexe.ReadProcessMemory(this._processHandle, addresss.Start, array, (IntPtr) addresss.Size, out lpNumberOfBytesRead))
        {
          int num = -patternLength;
          do
          {
            num = this.FindPattern(array, patternData.pattern, patternData.mask, num + patternLength);
            if (num >= 0)
            {
              lock (addressRet)
                addressRet.Add((long) addresss.Start + (long) num);
            }
          }
          while (num != -1);
        }
        Array.Resize<byte>(ref array, (int) lpNumberOfBytesRead);
      }));
    }));
    return addressRet.OrderBy<long, long>((Func<long, long>) (c => c)).AsEnumerable<long>();
  }

  public bool CanReadPage(nazmulexe.MEMORY_BASIC_INFORMATION page)
  {
    return page.State == 4096U /*0x1000*/ && page.Type == 131072U /*0x020000*/ && page.Protect == 4U;
  }

  private nazmulexe.PatternData GetPatternDataFromPattern(string pattern)
  {
    string[] source = pattern.Split(' ');
    return new nazmulexe.PatternData()
    {
      pattern = ((IEnumerable<string>) source).Select<string, byte>((Func<string, byte>) (s => !s.Contains("??") ? byte.Parse(s, NumberStyles.HexNumber) : (byte) 0)).ToArray<byte>(),
      mask = ((IEnumerable<string>) source).Select<string, byte>((Func<string, byte>) (s => !s.Contains("??") ? byte.MaxValue : (byte) 0)).ToArray<byte>()
    };
  }

  public bool AobReplace(long address, string bytePattern)
  {
    try
    {
      byte[] byteArray = this.StringToByteArray(bytePattern);
      return nazmulexe.WriteProcessMemory(this._processHandle, (IntPtr) address, byteArray, (IntPtr) byteArray.Length, IntPtr.Zero);
    }
    catch (Exception ex)
    {
    }
    return false;
  }

  public bool AobReplace(long address, int bytePattern)
  {
    byte[] bytes = BitConverter.GetBytes(bytePattern);
    return nazmulexe.WriteProcessMemory(this._processHandle, (IntPtr) address, bytes, (IntPtr) bytes.Length, IntPtr.Zero);
  }

  public async Task<int> ReadIntAsync(long addressToRead)
  {
    return await Task.Run<int>((Func<int>) (() => this.ReadInt(addressToRead)));
  }

  public int ReadInt(long addressToRead)
  {
    byte[] lpBuffer = new byte[4];
    return nazmulexe.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToInt32(lpBuffer, 0) : 0;
  }

  public float ReadFloat(long addressToRead)
  {
    byte[] lpBuffer = new byte[4];
    return nazmulexe.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToSingle(lpBuffer, 0) : 0.0f;
  }

  public byte ReadHexByte(long addressToRead)
  {
    byte[] lpBuffer = new byte[1];
    return nazmulexe.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? lpBuffer[0] : (byte) 0;
  }

  public short ReadInt16(long addressToRead)
  {
    byte[] lpBuffer = new byte[2];
    return nazmulexe.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) lpBuffer.Length, out IntPtr _) ? BitConverter.ToInt16(lpBuffer, 0) : (short) 0;
  }

  public string ReadString(long addressToRead, int size)
  {
    byte[] lpBuffer = new byte[size];
    IntPtr lpNumberOfBytesRead;
    return nazmulexe.ReadProcessMemory(this._processHandle, (IntPtr) addressToRead, lpBuffer, (IntPtr) size, out lpNumberOfBytesRead) && lpNumberOfBytesRead.ToInt64() == (long) size ? BitConverter.ToString(lpBuffer).Replace("-", " ") : "";
  }

  private byte[] StringToByteArray(string hexString)
  {
    return ((IEnumerable<string>) hexString.Split(' ')).Select<string, byte>((Func<string, byte>) (hex => byte.Parse(hex, NumberStyles.HexNumber))).ToArray<byte>();
  }

  private int FindPattern(byte[] body, byte[] pattern, byte[] masks, int start = 0)
  {
    int pattern1 = -1;
    if (body.Length == 0 || pattern.Length == 0 || start > body.Length - pattern.Length || pattern.Length > body.Length)
      return pattern1;
    for (int index1 = start; index1 <= body.Length - pattern.Length; ++index1)
    {
      if (((int) body[index1] & (int) masks[0]) == ((int) pattern[0] & (int) masks[0]))
      {
        bool flag = true;
        for (int index2 = pattern.Length - 1; index2 >= 1; --index2)
        {
          if (((int) body[index1 + index2] & (int) masks[index2]) != ((int) pattern[index2] & (int) masks[index2]))
          {
            flag = false;
            break;
          }
        }
        if (flag)
        {
          pattern1 = index1;
          break;
        }
      }
    }
    return pattern1;
  }

  internal void WriteMemory(string v1, string v2, string v3) => throw new NotImplementedException();

  public byte[] readMemory(long address, int length) => throw new NotImplementedException();

  internal async Task AoBScan2(string aimAOB, bool v1, bool v2)
  {
    throw new NotImplementedException();
  }

  internal void OpenProcess(int proc) => throw new NotImplementedException();

  public struct PatternData
  {
    public byte[] pattern { get; set; }

    public byte[] mask { get; set; }
  }

  public struct MemoryPage(IntPtr start, int size)
  {
    public IntPtr Start = start;
    public int Size = size;
  }

  public struct MEMORY_BASIC_INFORMATION
  {
    public IntPtr BaseAddress;
    public IntPtr AllocationBase;
    public uint AllocationProtect;
    public UIntPtr RegionSize;
    public uint State;
    public uint Protect;
    public uint Type;
  }
}
